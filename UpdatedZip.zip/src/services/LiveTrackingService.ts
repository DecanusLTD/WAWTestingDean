export interface Location {
  lat: number;
  lng: number;
  address: string;
  timestamp: Date;
}

export interface TrackingData {
  jobId: string;
  customerLocation: Location;
  valeterLocation: Location;
  valeterETA: number; // minutes
  customerETA: number; // minutes
  status: 'en_route' | 'arrived' | 'in_progress' | 'completed';
  routePolyline: string; // Google Maps polyline
  distance: number; // kilometers
  valeterSpeed: number; // km/h
  lastUpdated: Date;
}

export interface MovementSimulation {
  startLocation: Location;
  endLocation: Location;
  startTime: Date;
  estimatedDuration: number; // minutes
  currentProgress: number; // 0-1
  currentLocation: Location;
  speed: number; // km/h
  trafficConditions: 'light' | 'medium' | 'heavy';
}

export class LiveTrackingService {
  private static instance: LiveTrackingService;
  private trackingData: Map<string, TrackingData> = new Map();
  private movementSimulations: Map<string, MovementSimulation> = new Map();
  private updateIntervals: Map<string, NodeJS.Timeout> = new Map();

  // UK city coordinates for realistic simulation
  private ukCities = {
    'London': { lat: 51.5074, lng: -0.1278 },
    'Manchester': { lat: 53.4808, lng: -2.2426 },
    'Birmingham': { lat: 52.4862, lng: -1.8904 },
    'Liverpool': { lat: 53.4084, lng: -2.9916 },
    'Leeds': { lat: 53.8008, lng: -1.5491 },
    'Sheffield': { lat: 53.3811, lng: -1.4701 },
    'Edinburgh': { lat: 55.9533, lng: -3.1883 },
    'Glasgow': { lat: 55.8642, lng: -4.2518 },
    'Cardiff': { lat: 51.4816, lng: -3.1791 },
    'Bristol': { lat: 51.4545, lng: -2.5879 }
  };

  static getInstance(): LiveTrackingService {
    if (!LiveTrackingService.instance) {
      LiveTrackingService.instance = new LiveTrackingService();
    }
    return LiveTrackingService.instance;
  }

  // Start tracking for a job
  startTracking(
    jobId: string,
    customerLocation: Location,
    valeterLocation: Location
  ): void {
    const distance = this.calculateDistance(
      valeterLocation.lat, valeterLocation.lng,
      customerLocation.lat, customerLocation.lng
    );

    const valeterETA = this.calculateETA(distance, 'valeter');
    const customerETA = this.calculateETA(distance, 'customer');

    const trackingData: TrackingData = {
      jobId,
      customerLocation,
      valeterLocation,
      valeterETA,
      customerETA,
      status: 'en_route',
      routePolyline: this.generateRoutePolyline(valeterLocation, customerLocation),
      distance,
      valeterSpeed: this.calculateSpeed(distance, valeterETA),
      lastUpdated: new Date()
    };

    this.trackingData.set(jobId, trackingData);

    // Start movement simulation
    this.startMovementSimulation(jobId, valeterLocation, customerLocation);

    // Start real-time updates
    this.startRealTimeUpdates(jobId);
  }

  // Get current tracking data
  getTrackingData(jobId: string): TrackingData | undefined {
    return this.trackingData.get(jobId);
  }

  // Update valeter location (simulated)
  updateValeterLocation(jobId: string, newLocation: Location): void {
    const tracking = this.trackingData.get(jobId);
    if (!tracking) return;

    tracking.valeterLocation = newLocation;
    tracking.lastUpdated = new Date();

    // Recalculate ETA
    const distance = this.calculateDistance(
      newLocation.lat, newLocation.lng,
      tracking.customerLocation.lat, tracking.customerLocation.lng
    );
    tracking.distance = distance;
    tracking.valeterETA = this.calculateETA(distance, 'valeter');
    tracking.customerETA = this.calculateETA(distance, 'customer');
    tracking.valeterSpeed = this.calculateSpeed(distance, tracking.valeterETA);

    this.trackingData.set(jobId, tracking);
  }

  // Update job status
  updateJobStatus(jobId: string, status: TrackingData['status']): void {
    const tracking = this.trackingData.get(jobId);
    if (!tracking) return;

    tracking.status = status;
    tracking.lastUpdated = new Date();

    if (status === 'arrived') {
      tracking.valeterETA = 0;
      tracking.customerETA = 0;
    }

    this.trackingData.set(jobId, tracking);
  }

  // Start movement simulation
  private startMovementSimulation(
    jobId: string,
    startLocation: Location,
    endLocation: Location
  ): void {
    const distance = this.calculateDistance(
      startLocation.lat, startLocation.lng,
      endLocation.lat, endLocation.lng
    );

    const speed = this.getRandomSpeed();
    const duration = (distance / speed) * 60; // Convert to minutes

    const simulation: MovementSimulation = {
      startLocation,
      endLocation,
      startTime: new Date(),
      estimatedDuration: duration,
      currentProgress: 0,
      currentLocation: { ...startLocation },
      speed,
      trafficConditions: this.getRandomTrafficConditions()
    };

    this.movementSimulations.set(jobId, simulation);
  }

  // Start real-time updates
  private startRealTimeUpdates(jobId: string): void {
    const interval = setInterval(() => {
      this.updateSimulation(jobId);
    }, 5000); // Update every 5 seconds

    this.updateIntervals.set(jobId, interval);
  }

  // Update simulation
  private updateSimulation(jobId: string): void {
    const simulation = this.movementSimulations.get(jobId);
    const tracking = this.trackingData.get(jobId);
    
    if (!simulation || !tracking) return;

    const elapsed = (Date.now() - simulation.startTime.getTime()) / 60000; // minutes
    const progress = Math.min(elapsed / simulation.estimatedDuration, 1);

    simulation.currentProgress = progress;

    // Calculate current position
    const currentLat = simulation.startLocation.lat + 
      (simulation.endLocation.lat - simulation.startLocation.lat) * progress;
    const currentLng = simulation.startLocation.lng + 
      (simulation.endLocation.lng - simulation.startLocation.lng) * progress;

    simulation.currentLocation = {
      lat: currentLat,
      lng: currentLng,
      address: this.getAddressFromCoordinates(currentLat, currentLng),
      timestamp: new Date()
    };

    // Update tracking data
    this.updateValeterLocation(jobId, simulation.currentLocation);

    // Check if arrived
    if (progress >= 1) {
      this.updateJobStatus(jobId, 'arrived');
      this.stopTracking(jobId);
    }

    this.movementSimulations.set(jobId, simulation);
  }

  // Stop tracking
  stopTracking(jobId: string): void {
    const interval = this.updateIntervals.get(jobId);
    if (interval) {
      clearInterval(interval);
      this.updateIntervals.delete(jobId);
    }
    this.movementSimulations.delete(jobId);
  }

  // Calculate distance between two points (Haversine formula)
  private calculateDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
    const R = 6371; // Earth's radius in kilometers
    const dLat = this.toRadians(lat2 - lat1);
    const dLng = this.toRadians(lng2 - lng1);
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(this.toRadians(lat1)) * Math.cos(this.toRadians(lat2)) *
      Math.sin(dLng / 2) * Math.sin(dLng / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }

  private toRadians(degrees: number): number {
    return degrees * (Math.PI / 180);
  }

  // Calculate ETA based on distance and user type
  private calculateETA(distance: number, userType: 'valeter' | 'customer'): number {
    const baseSpeed = userType === 'valeter' ? 25 : 20; // km/h
    const trafficMultiplier = this.getTrafficMultiplier();
    const speed = baseSpeed * trafficMultiplier;
    return Math.round((distance / speed) * 60); // minutes
  }

  // Calculate speed
  private calculateSpeed(distance: number, etaMinutes: number): number {
    return Math.round((distance / etaMinutes) * 60);
  }

  // Get random speed for simulation
  private getRandomSpeed(): number {
    return 20 + Math.random() * 15; // 20-35 km/h
  }

  // Get random traffic conditions
  private getRandomTrafficConditions(): 'light' | 'medium' | 'heavy' {
    const rand = Math.random();
    if (rand < 0.6) return 'light';
    if (rand < 0.85) return 'medium';
    return 'heavy';
  }

  // Get traffic multiplier
  private getTrafficMultiplier(): number {
    const conditions = this.getRandomTrafficConditions();
    switch (conditions) {
      case 'light': return 1.0;
      case 'medium': return 0.7;
      case 'heavy': return 0.4;
      default: return 1.0;
    }
  }

  // Generate route polyline (simplified)
  private generateRoutePolyline(start: Location, end: Location): string {
    // This would normally use Google Directions API
    // For simulation, we create a simple polyline
    const points = [];
    const steps = 10;
    
    for (let i = 0; i <= steps; i++) {
      const progress = i / steps;
      const lat = start.lat + (end.lat - start.lat) * progress;
      const lng = start.lng + (end.lng - start.lng) * progress;
      points.push(`${lat},${lng}`);
    }
    
    return points.join('|');
  }

  // Get address from coordinates (simplified)
  private getAddressFromCoordinates(lat: number, lng: number): string {
    // This would normally use Google Geocoding API
    // For simulation, we return a generic address
    return `Location near ${lat.toFixed(4)}, ${lng.toFixed(4)}`;
  }

  // Get nearby valeters (for customer view)
  getNearbyValeters(customerLocation: Location, radius: number = 5): Location[] {
    const valeters: Location[] = [];
    const cityNames = Object.keys(this.ukCities);
    
    // Simulate 3-5 nearby valeters
    const numValeters = 3 + Math.floor(Math.random() * 3);
    
    for (let i = 0; i < numValeters; i++) {
      const city = cityNames[Math.floor(Math.random() * cityNames.length)];
      const cityCoords = this.ukCities[city as keyof typeof this.ukCities];
      
      // Add some random offset within the city
      const offsetLat = (Math.random() - 0.5) * 0.01;
      const offsetLng = (Math.random() - 0.5) * 0.01;
      
      valeters.push({
        lat: cityCoords.lat + offsetLat,
        lng: cityCoords.lng + offsetLng,
        address: `${city} Area`,
        timestamp: new Date()
      });
    }
    
    return valeters;
  }

  // Get movement simulation
  getMovementSimulation(jobId: string): MovementSimulation | undefined {
    return this.movementSimulations.get(jobId);
  }

  // Get all active tracking jobs
  getActiveTrackingJobs(): TrackingData[] {
    return Array.from(this.trackingData.values())
      .filter(tracking => tracking.status !== 'completed');
  }

  // Clean up completed jobs
  cleanupCompletedJobs(): void {
    const completedJobs = Array.from(this.trackingData.entries())
      .filter(([_, tracking]) => tracking.status === 'completed');
    
    completedJobs.forEach(([jobId, _]) => {
      this.stopTracking(jobId);
      this.trackingData.delete(jobId);
    });
  }
}

export const liveTrackingService = LiveTrackingService.getInstance();
