export interface UploadedFile {
  id: string;
  fileName: string;
  fileType: 'image' | 'document' | 'pdf';
  fileSize: number; // in bytes
  uploadDate: Date;
  status: 'uploading' | 'uploaded' | 'verified' | 'rejected';
  filePath: string;
  thumbnailPath?: string;
  metadata?: {
    width?: number;
    height?: number;
    pages?: number;
    mimeType: string;
  };
}

export interface DocumentUpload {
  id: string;
  userId: string;
  documentType: 'profile_photo' | 'driving_license' | 'dbs_check' | 'public_liability_insurance' | 'vehicle_insurance' | 'vehicle_registration' | 'id_proof';
  file: UploadedFile;
  verificationStatus: 'pending' | 'approved' | 'rejected';
  verificationNotes?: string;
  verifiedBy?: string;
  verifiedAt?: Date;
  uploadedAt: Date;
}

export class FileUploadService {
  private static instance: FileUploadService;
  private uploadedFiles: Map<string, UploadedFile> = new Map();
  private documentUploads: Map<string, DocumentUpload> = new Map();
  private userDocuments: Map<string, DocumentUpload[]> = new Map(); // userId -> DocumentUpload[]

  static getInstance(): FileUploadService {
    if (!FileUploadService.instance) {
      FileUploadService.instance = new FileUploadService();
    }
    return FileUploadService.instance;
  }

  // Simulate file upload (in real app, this would handle actual file upload)
  async uploadFile(
    fileUri: string,
    fileName: string,
    fileType: UploadedFile['fileType'],
    userId: string,
    documentType?: DocumentUpload['documentType']
  ): Promise<{ success: boolean; fileId?: string; error?: string }> {
    try {
      // Simulate upload delay
      await new Promise(resolve => setTimeout(resolve, 2000));

      const fileId = `file_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      
      // Simulate file size (1MB - 10MB)
      const fileSize = Math.floor(Math.random() * 9000000) + 1000000;
      
      const uploadedFile: UploadedFile = {
        id: fileId,
        fileName,
        fileType,
        fileSize,
        uploadDate: new Date(),
        status: 'uploaded',
        filePath: fileUri,
        metadata: {
          mimeType: this.getMimeType(fileType, fileName),
          width: fileType === 'image' ? Math.floor(Math.random() * 1000) + 500 : undefined,
          height: fileType === 'image' ? Math.floor(Math.random() * 800) + 400 : undefined,
          pages: fileType === 'pdf' ? Math.floor(Math.random() * 10) + 1 : undefined
        }
      };

      this.uploadedFiles.set(fileId, uploadedFile);

      // If this is a document upload, create document record
      if (documentType) {
        const documentUpload: DocumentUpload = {
          id: `doc_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          userId,
          documentType,
          file: uploadedFile,
          verificationStatus: 'pending',
          uploadedAt: new Date()
        };

        this.documentUploads.set(documentUpload.id, documentUpload);
        
        // Add to user's documents
        const userDocs = this.userDocuments.get(userId) || [];
        userDocs.push(documentUpload);
        this.userDocuments.set(userId, userDocs);
      }

      return { success: true, fileId };
    } catch (error) {
      return { success: false, error: 'Upload failed' };
    }
  }

  // Upload profile picture
  async uploadProfilePicture(
    imageUri: string,
    userId: string
  ): Promise<{ success: boolean; fileId?: string; error?: string }> {
    return this.uploadFile(imageUri, 'profile_picture.jpg', 'image', userId, 'profile_photo');
  }

  // Upload valeter document
  async uploadValeterDocument(
    fileUri: string,
    fileName: string,
    documentType: DocumentUpload['documentType'],
    userId: string
  ): Promise<{ success: boolean; fileId?: string; error?: string }> {
    const fileType = this.getFileTypeFromDocumentType(documentType);
    return this.uploadFile(fileUri, fileName, fileType, userId, documentType);
  }

  // Get user's documents
  getUserDocuments(userId: string): DocumentUpload[] {
    return this.userDocuments.get(userId) || [];
  }

  // Get document by ID
  getDocument(documentId: string): DocumentUpload | undefined {
    return this.documentUploads.get(documentId);
  }

  // Get file by ID
  getFile(fileId: string): UploadedFile | undefined {
    return this.uploadedFiles.get(fileId);
  }

  // Verify document (admin function)
  verifyDocument(
    documentId: string,
    status: 'approved' | 'rejected',
    verifiedBy: string,
    notes?: string
  ): boolean {
    const document = this.documentUploads.get(documentId);
    if (!document) return false;

    document.verificationStatus = status;
    document.verifiedBy = verifiedBy;
    document.verifiedAt = new Date();
    if (notes) {
      document.verificationNotes = notes;
    }

    // Update file status
    const file = this.uploadedFiles.get(document.file.id);
    if (file) {
      file.status = status === 'approved' ? 'verified' : 'rejected';
    }

    return true;
  }

  // Get pending documents for verification
  getPendingDocuments(): DocumentUpload[] {
    return Array.from(this.documentUploads.values())
      .filter(doc => doc.verificationStatus === 'pending')
      .sort((a, b) => a.uploadedAt.getTime() - b.uploadedAt.getTime());
  }

  // Delete file
  deleteFile(fileId: string): boolean {
    const file = this.uploadedFiles.get(fileId);
    if (!file) return false;

    // Remove from uploaded files
    this.uploadedFiles.delete(fileId);

    // Remove from document uploads
    const documentToRemove = Array.from(this.documentUploads.values())
      .find(doc => doc.file.id === fileId);
    
    if (documentToRemove) {
      this.documentUploads.delete(documentToRemove.id);
      
      // Remove from user documents
      const userDocs = this.userDocuments.get(documentToRemove.userId) || [];
      const updatedUserDocs = userDocs.filter(doc => doc.id !== documentToRemove.id);
      this.userDocuments.set(documentToRemove.userId, updatedUserDocs);
    }

    return true;
  }

  // Get user's profile picture
  getUserProfilePicture(userId: string): UploadedFile | undefined {
    const userDocs = this.userDocuments.get(userId) || [];
    const profileDoc = userDocs.find(doc => doc.documentType === 'profile_photo');
    return profileDoc?.file;
  }

  // Check if user has all required documents
  hasAllRequiredDocuments(userId: string): {
    hasAll: boolean;
    missing: string[];
    pending: string[];
    approved: string[];
  } {
    const userDocs = this.userDocuments.get(userId) || [];
    const requiredTypes = [
      'profile_photo',
      'driving_license',
      'dbs_check',
      'public_liability_insurance',
      'vehicle_insurance',
      'vehicle_registration',
      'id_proof'
    ];

    const approved = userDocs
      .filter(doc => doc.verificationStatus === 'approved')
      .map(doc => doc.documentType);

    const pending = userDocs
      .filter(doc => doc.verificationStatus === 'pending')
      .map(doc => doc.documentType);

    const missing = requiredTypes.filter(type => 
      !approved.includes(type) && !pending.includes(type)
    );

    return {
      hasAll: missing.length === 0 && pending.length === 0,
      missing,
      pending,
      approved
    };
  }

  // Get document upload progress
  getUploadProgress(fileId: string): number {
    // Simulate upload progress
    const file = this.uploadedFiles.get(fileId);
    if (!file) return 0;
    
    if (file.status === 'uploaded' || file.status === 'verified' || file.status === 'rejected') {
      return 100;
    }
    
    // Simulate progress for uploading files
    return Math.floor(Math.random() * 100);
  }

  // Validate file before upload
  validateFile(
    fileName: string,
    fileSize: number,
    fileType: UploadedFile['fileType']
  ): { isValid: boolean; error?: string } {
    // Check file size (max 10MB)
    if (fileSize > 10 * 1024 * 1024) {
      return { isValid: false, error: 'File size must be less than 10MB' };
    }

    // Check file extension
    const allowedExtensions = {
      image: ['.jpg', '.jpeg', '.png', '.gif'],
      document: ['.doc', '.docx', '.pdf'],
      pdf: ['.pdf']
    };

    const extension = fileName.toLowerCase().substring(fileName.lastIndexOf('.'));
    if (!allowedExtensions[fileType].includes(extension)) {
      return { 
        isValid: false, 
        error: `Invalid file type. Allowed: ${allowedExtensions[fileType].join(', ')}` 
      };
    }

    return { isValid: true };
  }

  // Helper methods
  private getMimeType(fileType: UploadedFile['fileType'], fileName: string): string {
    const extension = fileName.toLowerCase().substring(fileName.lastIndexOf('.'));
    
    const mimeTypes: { [key: string]: string } = {
      '.jpg': 'image/jpeg',
      '.jpeg': 'image/jpeg',
      '.png': 'image/png',
      '.gif': 'image/gif',
      '.pdf': 'application/pdf',
      '.doc': 'application/msword',
      '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    };

    return mimeTypes[extension] || 'application/octet-stream';
  }

  private getFileTypeFromDocumentType(documentType: DocumentUpload['documentType']): UploadedFile['fileType'] {
    switch (documentType) {
      case 'profile_photo':
        return 'image';
      case 'driving_license':
      case 'dbs_check':
      case 'public_liability_insurance':
      case 'vehicle_insurance':
      case 'vehicle_registration':
      case 'id_proof':
        return 'document';
      default:
        return 'document';
    }
  }

  // Get storage usage for user
  getUserStorageUsage(userId: string): {
    totalSize: number;
    fileCount: number;
    breakdown: { [key in UploadedFile['fileType']]: number };
  } {
    const userDocs = this.userDocuments.get(userId) || [];
    let totalSize = 0;
    const breakdown = { image: 0, document: 0, pdf: 0 };

    userDocs.forEach(doc => {
      totalSize += doc.file.fileSize;
      breakdown[doc.file.fileType] += doc.file.fileSize;
    });

    return {
      totalSize,
      fileCount: userDocs.length,
      breakdown
    };
  }
}

export const fileUploadService = FileUploadService.getInstance();
