export interface PerformanceMetric {
  id: string;
  name: string;
  value: number;
  unit: string;
  timestamp: Date;
  context?: any;
}

export interface PerformanceEvent {
  id: string;
  type: 'navigation' | 'api_call' | 'render' | 'interaction' | 'error';
  name: string;
  startTime: number;
  endTime?: number;
  duration?: number;
  success: boolean;
  context?: any;
}

export interface PerformanceStats {
  averageLoadTime: number;
  averageApiResponseTime: number;
  errorRate: number;
  userInteractions: number;
  navigationCount: number;
  slowestOperations: PerformanceEvent[];
}

export class PerformanceMonitoringService {
  private static instance: PerformanceMonitoringService;
  private metrics: Map<string, PerformanceMetric> = new Map();
  private events: Map<string, PerformanceEvent> = new Map();
  private activeEvents: Map<string, PerformanceEvent> = new Map();
  private listeners: ((event: PerformanceEvent) => void)[] = [];

  static getInstance(): PerformanceMonitoringService {
    if (!PerformanceMonitoringService.instance) {
      PerformanceMonitoringService.instance = new PerformanceMonitoringService();
    }
    return PerformanceMonitoringService.instance;
  }

  // Start timing an event
  startEvent(type: PerformanceEvent['type'], name: string, context?: any): string {
    const eventId = `event_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const event: PerformanceEvent = {
      id: eventId,
      type,
      name,
      startTime: performance.now(),
      success: true,
      context
    };

    this.activeEvents.set(eventId, event);
    return eventId;
  }

  // End timing an event
  endEvent(eventId: string, success: boolean = true, context?: any): void {
    const event = this.activeEvents.get(eventId);
    if (!event) return;

    event.endTime = performance.now();
    event.duration = event.endTime - event.startTime;
    event.success = success;
    if (context) {
      event.context = { ...event.context, ...context };
    }

    this.activeEvents.delete(eventId);
    this.events.set(eventId, event);
    this.notifyListeners(event);

    // Log slow operations
    if (event.duration > 1000) { // 1 second threshold
      console.warn('Slow operation detected:', {
        name: event.name,
        type: event.type,
        duration: `${event.duration.toFixed(2)}ms`,
        context: event.context
      });
    }
  }

  // Record a metric
  recordMetric(name: string, value: number, unit: string, context?: any): void {
    const metric: PerformanceMetric = {
      id: `metric_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      name,
      value,
      unit,
      timestamp: new Date(),
      context
    };

    this.metrics.set(metric.id, metric);
  }

  // Monitor API calls
  async monitorApiCall<T>(
    apiCall: () => Promise<T>,
    endpoint: string,
    context?: any
  ): Promise<T> {
    const eventId = this.startEvent('api_call', `API: ${endpoint}`, context);
    
    try {
      const result = await apiCall();
      this.endEvent(eventId, true, { endpoint, status: 'success' });
      return result;
    } catch (error) {
      this.endEvent(eventId, false, { endpoint, status: 'error', error: error.message });
      throw error;
    }
  }

  // Monitor navigation
  monitorNavigation(from: string, to: string, duration?: number): void {
    const eventId = this.startEvent('navigation', `Navigation: ${from} → ${to}`);
    
    if (duration) {
      // If duration is provided, end immediately
      this.endEvent(eventId, true, { from, to, duration });
    } else {
      // Otherwise, end after a short delay to capture actual navigation time
      setTimeout(() => {
        this.endEvent(eventId, true, { from, to });
      }, 100);
    }
  }

  // Monitor component render
  monitorRender(componentName: string, props?: any): string {
    return this.startEvent('render', `Render: ${componentName}`, { componentName, props });
  }

  // Monitor user interaction
  monitorInteraction(interactionType: string, target: string, context?: any): void {
    const eventId = this.startEvent('interaction', `Interaction: ${interactionType}`, {
      interactionType,
      target,
      ...context
    });
    
    // Interactions are typically very fast, so end immediately
    this.endEvent(eventId, true);
  }

  // Monitor errors
  monitorError(error: Error, context?: any): void {
    const eventId = this.startEvent('error', `Error: ${error.name}`, {
      error: error.message,
      stack: error.stack,
      ...context
    });
    
    this.endEvent(eventId, false, { error: error.message });
  }

  // Get performance statistics
  getPerformanceStats(): PerformanceStats {
    const allEvents = Array.from(this.events.values());
    const now = Date.now();
    const oneHourAgo = now - (60 * 60 * 1000);
    
    // Filter recent events
    const recentEvents = allEvents.filter(event => 
      event.startTime > (now - oneHourAgo)
    );

    // Calculate averages
    const navigationEvents = recentEvents.filter(e => e.type === 'navigation');
    const apiEvents = recentEvents.filter(e => e.type === 'api_call');
    const interactionEvents = recentEvents.filter(e => e.type === 'interaction');
    const errorEvents = recentEvents.filter(e => e.type === 'error');

    const averageLoadTime = navigationEvents.length > 0 
      ? navigationEvents.reduce((sum, e) => sum + (e.duration || 0), 0) / navigationEvents.length
      : 0;

    const averageApiResponseTime = apiEvents.length > 0
      ? apiEvents.reduce((sum, e) => sum + (e.duration || 0), 0) / apiEvents.length
      : 0;

    const errorRate = recentEvents.length > 0
      ? (errorEvents.length / recentEvents.length) * 100
      : 0;

    // Get slowest operations
    const slowestOperations = allEvents
      .filter(e => e.duration && e.duration > 500) // 500ms threshold
      .sort((a, b) => (b.duration || 0) - (a.duration || 0))
      .slice(0, 10);

    return {
      averageLoadTime,
      averageApiResponseTime,
      errorRate,
      userInteractions: interactionEvents.length,
      navigationCount: navigationEvents.length,
      slowestOperations
    };
  }

  // Get metrics by name
  getMetricsByName(name: string): PerformanceMetric[] {
    return Array.from(this.metrics.values()).filter(metric => metric.name === name);
  }

  // Get events by type
  getEventsByType(type: PerformanceEvent['type']): PerformanceEvent[] {
    return Array.from(this.events.values()).filter(event => event.type === type);
  }

  // Get recent events
  getRecentEvents(minutes: number = 60): PerformanceEvent[] {
    const cutoff = Date.now() - (minutes * 60 * 1000);
    return Array.from(this.events.values()).filter(event => event.startTime > cutoff);
  }

  // Add event listener
  addEventListener(listener: (event: PerformanceEvent) => void): void {
    this.listeners.push(listener);
  }

  // Remove event listener
  removeEventListener(listener: (event: PerformanceEvent) => void): void {
    const index = this.listeners.indexOf(listener);
    if (index > -1) {
      this.listeners.splice(index, 1);
    }
  }

  private notifyListeners(event: PerformanceEvent): void {
    this.listeners.forEach(listener => {
      try {
        listener(event);
      } catch (error) {
        console.error('Error in performance listener:', error);
      }
    });
  }

  // Clear old data
  clearOldData(hours: number = 24): void {
    const cutoff = Date.now() - (hours * 60 * 60 * 1000);
    
    // Clear old events
    for (const [id, event] of this.events.entries()) {
      if (event.startTime < cutoff) {
        this.events.delete(id);
      }
    }

    // Clear old metrics
    for (const [id, metric] of this.metrics.entries()) {
      if (metric.timestamp.getTime() < cutoff) {
        this.metrics.delete(id);
      }
    }
  }

  // Export performance data
  exportData(): {
    metrics: PerformanceMetric[];
    events: PerformanceEvent[];
    stats: PerformanceStats;
  } {
    return {
      metrics: Array.from(this.metrics.values()),
      events: Array.from(this.events.values()),
      stats: this.getPerformanceStats()
    };
  }

  // Reset all data
  reset(): void {
    this.metrics.clear();
    this.events.clear();
    this.activeEvents.clear();
  }

  // Performance monitoring decorator for React components
  static withPerformanceMonitoring<P extends object>(
    WrappedComponent: React.ComponentType<P>,
    componentName: string
  ): React.ComponentType<P> {
    return class PerformanceMonitoredComponent extends React.Component<P> {
      private renderEventId?: string;

      componentDidMount() {
        this.renderEventId = PerformanceMonitoringService.getInstance()
          .monitorRender(componentName, this.props);
      }

      componentDidUpdate() {
        if (this.renderEventId) {
          PerformanceMonitoringService.getInstance()
            .endEvent(this.renderEventId, true);
        }
        this.renderEventId = PerformanceMonitoringService.getInstance()
          .monitorRender(componentName, this.props);
      }

      componentWillUnmount() {
        if (this.renderEventId) {
          PerformanceMonitoringService.getInstance()
            .endEvent(this.renderEventId, true);
        }
      }

      render() {
        return <WrappedComponent {...this.props} />;
      }
    };
  }
}

export const performanceMonitoringService = PerformanceMonitoringService.getInstance();
