import { supabase, Booking, User } from '../lib/supabase';

export interface BookingStats {
  totalBookings: number;
  completedBookings: number;
  pendingBookings: number;
  totalSpent: number;
  averageRating: number;
}

export interface BookingUpdate {
  id: string;
  status?: Booking['status'];
  valeter_id?: string;
  rating?: number;
  review?: string;
  completed_at?: string;
}

class SupabaseBookingService {
  private static instance: SupabaseBookingService;
  private subscribers: Map<string, (bookings: Booking[]) => void> = new Map();

  private constructor() {}

  public static getInstance(): SupabaseBookingService {
    if (!SupabaseBookingService.instance) {
      SupabaseBookingService.instance = new SupabaseBookingService();
    }
    return SupabaseBookingService.instance;
  }

  /**
   * Create a new booking
   */
  async createBooking(bookingData: Omit<Booking, 'id' | 'created_at' | 'updated_at'>): Promise<{ data: Booking | null; error: any }> {
    try {
      const { data, error } = await supabase
        .from('bookings')
        .insert([bookingData])
        .select()
        .single();

      if (error) {
        console.error('Error creating booking:', error);
        return { data: null, error };
      }

      // Notify subscribers
      this.notifySubscribers(bookingData.customer_id);

      return { data, error: null };
    } catch (error) {
      console.error('Error creating booking:', error);
      return { data: null, error };
    }
  }

  /**
   * Get all bookings for a user
   */
  async getUserBookings(userId: string): Promise<Booking[]> {
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .or(`customer_id.eq.${userId},valeter_id.eq.${userId}`)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching user bookings:', error);
        return [];
      }

      return data || [];
    } catch (error) {
      console.error('Error fetching user bookings:', error);
      return [];
    }
  }

  /**
   * Get active booking for a user
   */
  async getActiveBooking(userId: string): Promise<Booking | null> {
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .or(`customer_id.eq.${userId},valeter_id.eq.${userId}`)
        .not('status', 'in', '(completed,cancelled)')
        .order('created_at', { ascending: false })
        .limit(1)
        .single();

      if (error) {
        if (error.code === 'PGRST116') {
          // No active booking found
          return null;
        }
        console.error('Error fetching active booking:', error);
        return null;
      }

      return data;
    } catch (error) {
      console.error('Error fetching active booking:', error);
      return null;
    }
  }

  /**
   * Get booking statistics for a user
   */
  async getBookingStats(userId: string): Promise<BookingStats> {
    try {
      const { data, error } = await supabase
        .rpc('get_booking_stats', { user_uuid: userId });

      if (error) {
        console.error('Error fetching booking stats:', error);
        return {
          totalBookings: 0,
          completedBookings: 0,
          pendingBookings: 0,
          totalSpent: 0,
          averageRating: 0,
        };
      }

      const stats = data?.[0] || {};
      return {
        totalBookings: stats.total_bookings || 0,
        completedBookings: stats.completed_bookings || 0,
        pendingBookings: stats.pending_bookings || 0,
        totalSpent: parseFloat(stats.total_spent || '0'),
        averageRating: parseFloat(stats.average_rating || '0'),
      };
    } catch (error) {
      console.error('Error fetching booking stats:', error);
      return {
        totalBookings: 0,
        completedBookings: 0,
        pendingBookings: 0,
        totalSpent: 0,
        averageRating: 0,
      };
    }
  }

  /**
   * Update booking status
   */
  async updateBooking(updateData: BookingUpdate): Promise<{ data: Booking | null; error: any }> {
    try {
      const { data, error } = await supabase
        .from('bookings')
        .update({
          ...updateData,
          updated_at: new Date().toISOString(),
        })
        .eq('id', updateData.id)
        .select()
        .single();

      if (error) {
        console.error('Error updating booking:', error);
        return { data: null, error };
      }

      // Notify subscribers for both customer and valeter
      if (data) {
        this.notifySubscribers(data.customer_id);
        if (data.valeter_id) {
          this.notifySubscribers(data.valeter_id);
        }
      }

      return { data, error: null };
    } catch (error) {
      console.error('Error updating booking:', error);
      return { data: null, error };
    }
  }

  /**
   * Get available wash requests for valeters
   */
  async getAvailableWashRequests(valeterId: string, radius: number): Promise<Booking[]> {
    try {
      // Get valeter's current location
      const { data: valeterProfile } = await supabase
        .from('valeter_profiles')
        .select('current_location')
        .eq('user_id', valeterId)
        .single();

      if (!valeterProfile?.current_location) {
        return [];
      }

      // Get pending bookings within radius
      const { data, error } = await supabase
        .from('bookings')
        .select(`
          *,
          customer:users!bookings_customer_id_fkey (
            id,
            name,
            email,
            phone
          )
        `)
        .eq('status', 'pending')
        .is('valeter_id', null);

      if (error) {
        console.error('Error fetching available wash requests:', error);
        return [];
      }

      // Filter by distance (simplified - in production use proper geospatial queries)
      return data?.filter(booking => {
        const bookingLocation = booking.location;
        const valeterLocation = valeterProfile.current_location;
        
        if (!bookingLocation || !valeterLocation) return false;
        
        const distance = this.calculateDistance(
          valeterLocation.latitude,
          valeterLocation.longitude,
          bookingLocation.latitude,
          bookingLocation.longitude
        );
        
        return distance <= radius;
      }) || [];
    } catch (error) {
      console.error('Error fetching available wash requests:', error);
      return [];
    }
  }

  /**
   * Accept a wash request
   */
  async acceptWashRequest(bookingId: string, valeterId: string): Promise<{ data: Booking | null; error: any }> {
    try {
      const { data, error } = await supabase
        .from('bookings')
        .update({
          valeter_id: valeterId,
          status: 'confirmed',
          updated_at: new Date().toISOString(),
        })
        .eq('id', bookingId)
        .eq('status', 'pending')
        .is('valeter_id', null)
        .select()
        .single();

      if (error) {
        console.error('Error accepting wash request:', error);
        return { data: null, error };
      }

      // Notify subscribers
      if (data) {
        this.notifySubscribers(data.customer_id);
        this.notifySubscribers(valeterId);
      }

      return { data, error: null };
    } catch (error) {
      console.error('Error accepting wash request:', error);
      return { data: null, error };
    }
  }

  /**
   * Subscribe to booking updates
   */
  subscribeToBookings(userId: string, callback: (bookings: Booking[]) => void): () => void {
    this.subscribers.set(userId, callback);

    // Initial load
    this.getUserBookings(userId).then(callback);

    // Set up real-time subscription
    const subscription = supabase
      .channel(`bookings:${userId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'bookings',
          filter: `customer_id=eq.${userId} OR valeter_id=eq.${userId}`,
        },
        () => {
          this.getUserBookings(userId).then(callback);
        }
      )
      .subscribe();

    // Return unsubscribe function
    return () => {
      this.subscribers.delete(userId);
      subscription.unsubscribe();
    };
  }

  /**
   * Notify subscribers of updates
   */
  private notifySubscribers(userId: string) {
    const callback = this.subscribers.get(userId);
    if (callback) {
      this.getUserBookings(userId).then(callback);
    }
  }

  /**
   * Calculate distance between two points (Haversine formula)
   */
  private calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371; // Earth's radius in kilometers
    const dLat = this.deg2rad(lat2 - lat1);
    const dLon = this.deg2rad(lon2 - lon1);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(this.deg2rad(lat1)) * Math.cos(this.deg2rad(lat2)) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }

  private deg2rad(deg: number): number {
    return deg * (Math.PI / 180);
  }
}

export default SupabaseBookingService;
