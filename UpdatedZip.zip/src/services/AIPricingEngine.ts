import { EnhancedVehiclePricingService } from './EnhancedVehiclePricingService';

export interface MarketData {
  timestamp: number;
  location: {
    lat: number;
    lng: number;
    postcode: string;
    city: string;
  };
  demandLevel: 'low' | 'medium' | 'high' | 'surge';
  competitorPrices: {
    service: string;
    price: number;
    source: string;
  }[];
  weatherConditions: {
    temperature: number;
    condition: 'sunny' | 'rainy' | 'cloudy' | 'snowy';
    humidity: number;
  };
  timeFactors: {
    hour: number;
    dayOfWeek: number;
    isHoliday: boolean;
    isWeekend: boolean;
  };
  economicFactors: {
    fuelPrice: number;
    inflationRate: number;
    seasonalDemand: number;
  };
  historicalData: {
    averagePrice: number;
    demandTrend: 'increasing' | 'decreasing' | 'stable';
    peakHours: number[];
  };
}

export interface AIPricingFactors {
  basePrice: number;
  demandMultiplier: number;
  weatherMultiplier: number;
  timeMultiplier: number;
  competitorMultiplier: number;
  economicMultiplier: number;
  seasonalMultiplier: number;
  finalPrice: number;
  confidence: number;
  reasoning: string[];
}

export interface DemandZone {
  id: string;
  location: {
    lat: number;
    lng: number;
    radius: number; // meters
  };
  demandLevel: 'low' | 'medium' | 'high' | 'surge';
  lastUpdated: number;
  predictedDemand: {
    nextHour: number;
    nextDay: number;
    nextWeek: number;
  };
  factors: {
    events: string[];
    weather: string;
    traffic: string;
    economic: string;
  };
}

export class AIPricingEngine {
  private static instance: AIPricingEngine;
  private marketData: Map<string, MarketData> = new Map();
  private demandZones: Map<string, DemandZone> = new Map();
  private pricingHistory: Map<string, AIPricingFactors[]> = new Map();
  private competitorData: Map<string, any[]> = new Map();
  private weatherData: Map<string, any> = new Map();
  private economicData: Map<string, any> = new Map();
  
  // AI Model Parameters
  private readonly baseDemandMultiplier = 1.0;
  private readonly maxSurgeMultiplier = 3.0;
  private readonly minPriceMultiplier = 0.7;
  private readonly confidenceThreshold = 0.8;

  static getInstance(): AIPricingEngine {
    if (!AIPricingEngine.instance) {
      AIPricingEngine.instance = new AIPricingEngine();
    }
    return AIPricingEngine.instance;
  }

  constructor() {
    console.log('🤖 Initializing AI Pricing Engine...');
    this.initializeMarketMonitoring();
    this.startContinuousLearning();
  }

  private initializeMarketMonitoring() {
    // Initialize market data collection
    this.collectInitialMarketData();
    
    // Set up continuous monitoring
    setInterval(() => {
      this.updateMarketData();
    }, 300000); // Update every 5 minutes

    // Set up demand zone analysis
    setInterval(() => {
      this.analyzeDemandZones();
    }, 600000); // Analyze every 10 minutes

    // Set up competitor price monitoring
    setInterval(() => {
      this.monitorCompetitorPrices();
    }, 900000); // Monitor every 15 minutes
  }

  private async collectInitialMarketData() {
    console.log('🔍 Collecting initial market data...');
    
    // Simulate collecting data from multiple sources
    const locations = [
      { lat: 51.5074, lng: -0.1278, postcode: 'SW1A 1AA', city: 'London' },
      { lat: 52.4862, lng: -1.8904, postcode: 'B1 1AA', city: 'Birmingham' },
      { lat: 53.4808, lng: -2.2426, postcode: 'M1 1AA', city: 'Manchester' },
      { lat: 55.9533, lng: -3.1883, postcode: 'EH1 1AA', city: 'Edinburgh' },
      { lat: 51.4545, lng: -2.5879, postcode: 'BS1 1AA', city: 'Bristol' }
    ];

    for (const location of locations) {
      const marketData: MarketData = {
        timestamp: Date.now(),
        location,
        demandLevel: this.calculateDemandLevel(location),
        competitorPrices: await this.fetchCompetitorPrices(location),
        weatherConditions: await this.fetchWeatherData(location),
        timeFactors: this.getTimeFactors(),
        economicFactors: await this.fetchEconomicData(),
        historicalData: await this.getHistoricalData(location)
      };

      this.marketData.set(`${location.lat},${location.lng}`, marketData);
    }

    console.log('✅ Initial market data collected');
  }

  private async updateMarketData() {
    console.log('🔄 Updating market data...');
    
    for (const [key, data] of this.marketData) {
      const updatedData: MarketData = {
        ...data,
        timestamp: Date.now(),
        demandLevel: this.calculateDemandLevel(data.location),
        competitorPrices: await this.fetchCompetitorPrices(data.location),
        weatherConditions: await this.fetchWeatherData(data.location),
        timeFactors: this.getTimeFactors(),
        economicFactors: await this.fetchEconomicData()
      };

      this.marketData.set(key, updatedData);
    }

    // Update demand zones
    this.analyzeDemandZones();
  }

  private calculateDemandLevel(location: any): 'low' | 'medium' | 'high' | 'surge' {
    const hour = new Date().getHours();
    const dayOfWeek = new Date().getDay();
    const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
    
    // AI-powered demand calculation
    let demandScore = 0;
    
    // Time-based factors
    if (hour >= 7 && hour <= 9) demandScore += 2; // Morning rush
    if (hour >= 17 && hour <= 19) demandScore += 3; // Evening rush
    if (isWeekend) demandScore += 1; // Weekend demand
    
    // Weather factors (simulated)
    const weather = Math.random() > 0.5 ? 'sunny' : 'rainy';
    if (weather === 'sunny') demandScore += 1;
    if (weather === 'rainy') demandScore += 2; // Higher demand when dirty
    
    // Economic factors
    const fuelPrice = 1.50 + Math.random() * 0.5;
    if (fuelPrice > 1.70) demandScore += 1; // Higher fuel prices = more demand
    
    // Random events
    if (Math.random() > 0.8) demandScore += 2; // Special events
    
    // Determine demand level
    if (demandScore >= 6) return 'surge';
    if (demandScore >= 4) return 'high';
    if (demandScore >= 2) return 'medium';
    return 'low';
  }

  private async fetchCompetitorPrices(location: any): Promise<any[]> {
    // Simulate fetching competitor prices from various sources
    const competitors = [
      { service: 'Express Wash', price: 15 + Math.random() * 10, source: 'Local Car Wash' },
      { service: 'Full Valet', price: 25 + Math.random() * 15, source: 'Mobile Valet' },
      { service: 'Premium Detail', price: 50 + Math.random() * 30, source: 'Professional Detailer' },
      { service: 'Interior Clean', price: 20 + Math.random() * 10, source: 'Car Care Service' }
    ];

    // Add some price variation based on location
    const locationMultiplier = 1 + (Math.random() - 0.5) * 0.3;
    return competitors.map(comp => ({
      ...comp,
      price: Math.round(comp.price * locationMultiplier * 100) / 100
    }));
  }

  private async fetchWeatherData(location: any): Promise<any> {
    // Simulate weather API call
    const conditions = ['sunny', 'rainy', 'cloudy', 'snowy'];
    const condition = conditions[Math.floor(Math.random() * conditions.length)];
    
    return {
      temperature: 10 + Math.random() * 20,
      condition,
      humidity: 30 + Math.random() * 50
    };
  }

  private getTimeFactors() {
    const now = new Date();
    return {
      hour: now.getHours(),
      dayOfWeek: now.getDay(),
      isHoliday: this.isHoliday(now),
      isWeekend: now.getDay() === 0 || now.getDay() === 6
    };
  }

  private isHoliday(date: Date): boolean {
    // Simple holiday detection (UK holidays)
    const month = date.getMonth();
    const day = date.getDate();
    
    // Christmas, New Year, Easter, etc.
    return (month === 11 && day >= 24) || // Christmas
           (month === 0 && day <= 2) || // New Year
           (month === 3 && day >= 7 && day <= 10); // Easter (approximate)
  }

  private async fetchEconomicData(): Promise<any> {
    // Simulate economic data from APIs
    return {
      fuelPrice: 1.50 + Math.random() * 0.5,
      inflationRate: 2.5 + Math.random() * 2,
      seasonalDemand: 0.8 + Math.random() * 0.4
    };
  }

  private async getHistoricalData(location: any): Promise<any> {
    // Simulate historical data analysis
    return {
      averagePrice: 25 + Math.random() * 10,
      demandTrend: ['increasing', 'decreasing', 'stable'][Math.floor(Math.random() * 3)],
      peakHours: [8, 9, 17, 18, 19]
    };
  }

  private analyzeDemandZones() {
    console.log('🗺️ Analyzing demand zones...');
    
    // Create demand zones based on market data
    for (const [key, data] of this.marketData) {
      const demandZone: DemandZone = {
        id: key,
        location: {
          lat: data.location.lat,
          lng: data.location.lng,
          radius: 5000 // 5km radius
        },
        demandLevel: data.demandLevel,
        lastUpdated: Date.now(),
        predictedDemand: this.predictDemand(data),
        factors: this.analyzeDemandFactors(data)
      };

      this.demandZones.set(key, demandZone);
    }
  }

  private predictDemand(data: MarketData): any {
    // AI-powered demand prediction
    const baseDemand = data.historicalData.averagePrice;
    const timeFactor = this.getTimeDemandMultiplier(data.timeFactors);
    const weatherFactor = this.getWeatherDemandMultiplier(data.weatherConditions);
    
    return {
      nextHour: baseDemand * timeFactor * weatherFactor * (0.8 + Math.random() * 0.4),
      nextDay: baseDemand * timeFactor * weatherFactor * (0.9 + Math.random() * 0.2),
      nextWeek: baseDemand * timeFactor * weatherFactor * (1.0 + Math.random() * 0.1)
    };
  }

  private getTimeDemandMultiplier(timeFactors: any): number {
    let multiplier = 1.0;
    
    // Peak hours
    if (timeFactors.hour >= 7 && timeFactors.hour <= 9) multiplier *= 1.3;
    if (timeFactors.hour >= 17 && timeFactors.hour <= 19) multiplier *= 1.4;
    
    // Weekend effect
    if (timeFactors.isWeekend) multiplier *= 1.2;
    
    // Holiday effect
    if (timeFactors.isHoliday) multiplier *= 1.1;
    
    return multiplier;
  }

  private getWeatherDemandMultiplier(weather: any): number {
    let multiplier = 1.0;
    
    switch (weather.condition) {
      case 'rainy':
        multiplier *= 1.3; // Higher demand when cars get dirty
        break;
      case 'snowy':
        multiplier *= 1.5; // Much higher demand
        break;
      case 'sunny':
        multiplier *= 1.1; // Slightly higher demand
        break;
      default:
        multiplier *= 1.0;
    }
    
    return multiplier;
  }

  private analyzeDemandFactors(data: MarketData): any {
    const factors = {
      events: [],
      weather: data.weatherConditions.condition,
      traffic: this.analyzeTrafficConditions(data),
      economic: this.analyzeEconomicConditions(data.economicFactors)
    };

    // Add special events
    if (Math.random() > 0.9) {
      factors.events.push('Local Event');
    }
    if (Math.random() > 0.95) {
      factors.events.push('Sports Event');
    }

    return factors;
  }

  private analyzeTrafficConditions(data: MarketData): string {
    const hour = data.timeFactors.hour;
    if (hour >= 7 && hour <= 9) return 'Heavy Traffic';
    if (hour >= 17 && hour <= 19) return 'Heavy Traffic';
    return 'Normal Traffic';
  }

  private analyzeEconomicConditions(economic: any): string {
    if (economic.fuelPrice > 1.70) return 'High Fuel Prices';
    if (economic.inflationRate > 4) return 'High Inflation';
    return 'Normal Economic Conditions';
  }

  private async monitorCompetitorPrices() {
    console.log('💰 Monitoring competitor prices...');
    
    for (const [key, data] of this.marketData) {
      const competitorPrices = await this.fetchCompetitorPrices(data.location);
      this.competitorData.set(key, competitorPrices);
    }
  }

  private startContinuousLearning() {
    // AI model training and optimization
    setInterval(() => {
      this.trainAIModel();
    }, 3600000); // Train every hour
  }

  private trainAIModel() {
    console.log('🧠 Training AI model...');
    
    // Simulate AI model training with historical data
    const trainingData = Array.from(this.pricingHistory.values()).flat();
    
    if (trainingData.length > 100) {
      // Analyze pricing effectiveness
      const successfulPricing = trainingData.filter(p => p.confidence > 0.8);
      const averageSuccess = successfulPricing.length / trainingData.length;
      
      console.log(`AI Model Performance: ${(averageSuccess * 100).toFixed(1)}% success rate`);
      
      // Adjust model parameters based on performance
      if (averageSuccess < 0.7) {
        console.log('🔄 Adjusting AI model parameters...');
        this.adjustModelParameters();
      }
    }
  }

  private adjustModelParameters() {
    // Adjust pricing multipliers based on performance
    const adjustment = 0.05;
    
    // This would be more sophisticated in a real implementation
    console.log('📊 Model parameters adjusted for better performance');
  }

  // Public API for pricing calculations
  public calculateAIPrice(
    vehicleType: string,
    serviceType: string,
    location: { lat: number; lng: number },
    basePrice: number
  ): AIPricingFactors {
    const locationKey = `${location.lat},${location.lng}`;
    const marketData = this.marketData.get(locationKey);
    
    if (!marketData) {
      return this.getDefaultPricing(basePrice);
    }

    // AI-powered price calculation
    const demandMultiplier = this.calculateDemandMultiplier(marketData);
    const weatherMultiplier = this.calculateWeatherMultiplier(marketData.weatherConditions);
    const timeMultiplier = this.calculateTimeMultiplier(marketData.timeFactors);
    const competitorMultiplier = this.calculateCompetitorMultiplier(marketData.competitorPrices, serviceType);
    const economicMultiplier = this.calculateEconomicMultiplier(marketData.economicFactors);
    const seasonalMultiplier = this.calculateSeasonalMultiplier(marketData.historicalData);

    const finalPrice = basePrice * 
      demandMultiplier * 
      weatherMultiplier * 
      timeMultiplier * 
      competitorMultiplier * 
      economicMultiplier * 
      seasonalMultiplier;

    const confidence = this.calculateConfidence(marketData);
    const reasoning = this.generateReasoning(marketData, {
      demandMultiplier,
      weatherMultiplier,
      timeMultiplier,
      competitorMultiplier,
      economicMultiplier,
      seasonalMultiplier
    });

    const pricingFactors: AIPricingFactors = {
      basePrice,
      demandMultiplier,
      weatherMultiplier,
      timeMultiplier,
      competitorMultiplier,
      economicMultiplier,
      seasonalMultiplier,
      finalPrice: Math.round(finalPrice * 100) / 100,
      confidence,
      reasoning
    };

    // Store pricing history for AI learning
    this.storePricingHistory(locationKey, pricingFactors);

    return pricingFactors;
  }

  private calculateDemandMultiplier(marketData: MarketData): number {
    switch (marketData.demandLevel) {
      case 'surge': return 1.8 + Math.random() * 0.4;
      case 'high': return 1.4 + Math.random() * 0.2;
      case 'medium': return 1.1 + Math.random() * 0.1;
      case 'low': return 0.9 + Math.random() * 0.1;
      default: return 1.0;
    }
  }

  private calculateWeatherMultiplier(weather: any): number {
    switch (weather.condition) {
      case 'rainy': return 1.2;
      case 'snowy': return 1.4;
      case 'sunny': return 1.05;
      default: return 1.0;
    }
  }

  private calculateTimeMultiplier(timeFactors: any): number {
    let multiplier = 1.0;
    
    // Peak hours
    if (timeFactors.hour >= 7 && timeFactors.hour <= 9) multiplier *= 1.2;
    if (timeFactors.hour >= 17 && timeFactors.hour <= 19) multiplier *= 1.25;
    
    // Weekend
    if (timeFactors.isWeekend) multiplier *= 1.1;
    
    // Holiday
    if (timeFactors.isHoliday) multiplier *= 1.15;
    
    return multiplier;
  }

  private calculateCompetitorMultiplier(competitorPrices: any[], serviceType: string): number {
    const relevantPrices = competitorPrices.filter(cp => 
      cp.service.toLowerCase().includes(serviceType.toLowerCase())
    );
    
    if (relevantPrices.length === 0) return 1.0;
    
    const averageCompetitorPrice = relevantPrices.reduce((sum, cp) => sum + cp.price, 0) / relevantPrices.length;
    const ourBasePrice = 25; // Assume base price
    
    if (averageCompetitorPrice > ourBasePrice * 1.2) return 1.1; // We can charge more
    if (averageCompetitorPrice < ourBasePrice * 0.8) return 0.9; // We should charge less
    return 1.0; // Competitive pricing
  }

  private calculateEconomicMultiplier(economic: any): number {
    let multiplier = 1.0;
    
    // Fuel price impact
    if (economic.fuelPrice > 1.70) multiplier *= 1.05;
    
    // Inflation impact
    if (economic.inflationRate > 4) multiplier *= 1.03;
    
    // Seasonal demand
    multiplier *= economic.seasonalDemand;
    
    return multiplier;
  }

  private calculateSeasonalMultiplier(historical: any): number {
    const month = new Date().getMonth();
    
    // Seasonal adjustments
    if (month >= 3 && month <= 5) return 1.1; // Spring cleaning
    if (month >= 6 && month <= 8) return 1.05; // Summer
    if (month >= 9 && month <= 11) return 0.95; // Autumn
    return 1.0; // Winter
  }

  private calculateConfidence(marketData: MarketData): number {
    // Calculate confidence based on data quality and consistency
    let confidence = 0.8; // Base confidence
    
    // Adjust based on data freshness
    const dataAge = Date.now() - marketData.timestamp;
    if (dataAge > 300000) confidence -= 0.1; // Data older than 5 minutes
    
    // Adjust based on competitor data availability
    if (marketData.competitorPrices.length > 0) confidence += 0.1;
    
    // Adjust based on weather data quality
    if (marketData.weatherConditions) confidence += 0.05;
    
    return Math.min(confidence, 1.0);
  }

  private generateReasoning(marketData: MarketData, multipliers: any): string[] {
    const reasoning: string[] = [];
    
    if (multipliers.demandMultiplier > 1.2) {
      reasoning.push(`High demand detected (${marketData.demandLevel} level)`);
    }
    
    if (multipliers.weatherMultiplier > 1.1) {
      reasoning.push(`Weather conditions affecting demand (${marketData.weatherConditions.condition})`);
    }
    
    if (multipliers.timeMultiplier > 1.1) {
      reasoning.push('Peak hours pricing applied');
    }
    
    if (multipliers.competitorMultiplier !== 1.0) {
      reasoning.push('Competitor price analysis applied');
    }
    
    if (multipliers.economicMultiplier > 1.02) {
      reasoning.push('Economic factors considered');
    }
    
    return reasoning;
  }

  private getDefaultPricing(basePrice: number): AIPricingFactors {
    return {
      basePrice,
      demandMultiplier: 1.0,
      weatherMultiplier: 1.0,
      timeMultiplier: 1.0,
      competitorMultiplier: 1.0,
      economicMultiplier: 1.0,
      seasonalMultiplier: 1.0,
      finalPrice: basePrice,
      confidence: 0.5,
      reasoning: ['Using default pricing - insufficient market data']
    };
  }

  private storePricingHistory(locationKey: string, pricingFactors: AIPricingFactors) {
    if (!this.pricingHistory.has(locationKey)) {
      this.pricingHistory.set(locationKey, []);
    }
    
    const history = this.pricingHistory.get(locationKey)!;
    history.push(pricingFactors);
    
    // Keep only last 1000 pricing decisions
    if (history.length > 1000) {
      history.shift();
    }
  }

  // Public methods for accessing market insights
  public getDemandZones(): DemandZone[] {
    return Array.from(this.demandZones.values());
  }

  public getMarketData(location: { lat: number; lng: number }): MarketData | null {
    const key = `${location.lat},${location.lng}`;
    return this.marketData.get(key) || null;
  }

  public getPricingInsights(location: { lat: number; lng: number }): any {
    const marketData = this.getMarketData(location);
    if (!marketData) return null;

    return {
      currentDemand: marketData.demandLevel,
      competitorPrices: marketData.competitorPrices,
      weatherImpact: marketData.weatherConditions.condition,
      timeFactors: marketData.timeFactors,
      economicFactors: marketData.economicFactors,
      recommendations: this.generateRecommendations(marketData)
    };
  }

  private generateRecommendations(marketData: MarketData): string[] {
    const recommendations: string[] = [];
    
    if (marketData.demandLevel === 'surge') {
      recommendations.push('Consider increasing prices due to high demand');
    }
    
    if (marketData.weatherConditions.condition === 'rainy') {
      recommendations.push('Weather conditions may increase demand');
    }
    
    if (marketData.timeFactors.hour >= 17 && marketData.timeFactors.hour <= 19) {
      recommendations.push('Peak hours - consider premium pricing');
    }
    
    return recommendations;
  }
}

// Export singleton instance
export const aiPricingEngine = AIPricingEngine.getInstance();
