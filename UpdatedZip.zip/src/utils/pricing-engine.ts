// Dynamic Pricing Engine for UK Vehicle Washing Services

export interface PricingFactors {
  location: string;
  timeOfDay: 'morning' | 'afternoon' | 'evening' | 'night';
  dayOfWeek: 'monday' | 'tuesday' | 'wednesday' | 'thursday' | 'friday' | 'saturday' | 'sunday';
  demand: 'low' | 'medium' | 'high' | 'peak';
  weather: 'sunny' | 'cloudy' | 'rainy' | 'snowy';
  vehicleSize: 'small' | 'medium' | 'large' | 'commercial';
  serviceType: 'wash' | 'valet' | 'priority_wash';
}

export interface PriceBreakdown {
  basePrice: number;
  locationMultiplier: number;
  timeMultiplier: number;
  dayMultiplier: number;
  demandMultiplier: number;
  weatherMultiplier: number;
  totalPrice: number;
}

export class DynamicPricingEngine {
  // Base prices for UK vehicle washing (in £)
  private basePrices = {
    small: { wash: 15, valet: 25, priority_wash: 35 },
    medium: { wash: 20, valet: 30, priority_wash: 45 },
    large: { wash: 25, valet: 40, priority_wash: 55 },
    commercial: { wash: 35, valet: 50, priority_wash: 70 }
  };

  // Location-based multipliers (UK cities)
  private locationMultipliers = {
    'London': 1.4,
    'Manchester': 1.2,
    'Birmingham': 1.1,
    'Leeds': 1.1,
    'Liverpool': 1.0,
    'Sheffield': 1.0,
    'Edinburgh': 1.2,
    'Bristol': 1.1,
    'Glasgow': 1.1,
    'Cardiff': 1.0,
    'default': 1.0
  };

  // Time-based multipliers
  private timeMultipliers = {
    morning: 1.0,    // 6AM-12PM
    afternoon: 1.1,  // 12PM-6PM
    evening: 1.2,    // 6PM-10PM
    night: 1.3       // 10PM-6AM
  };

  // Day-based multipliers
  private dayMultipliers = {
    monday: 1.0,
    tuesday: 1.0,
    wednesday: 1.0,
    thursday: 1.0,
    friday: 1.1,
    saturday: 1.2,
    sunday: 1.3
  };

  // Demand-based multipliers
  private demandMultipliers = {
    low: 0.9,
    medium: 1.0,
    high: 1.2,
    peak: 1.4
  };

  // Weather-based multipliers
  private weatherMultipliers = {
    sunny: 1.0,
    cloudy: 1.0,
    rainy: 1.1,
    snowy: 1.2
  };

  calculatePrice(factors: PricingFactors): PriceBreakdown {
    const basePrice = this.basePrices[factors.vehicleSize][factors.serviceType];
    
    const locationMultiplier = this.locationMultipliers[factors.location as keyof typeof this.locationMultipliers] || this.locationMultipliers.default;
    const timeMultiplier = this.timeMultipliers[factors.timeOfDay];
    const dayMultiplier = this.dayMultipliers[factors.dayOfWeek];
    const demandMultiplier = this.demandMultipliers[factors.demand];
    const weatherMultiplier = this.weatherMultipliers[factors.weather];

    const totalPrice = basePrice * locationMultiplier * timeMultiplier * dayMultiplier * demandMultiplier * weatherMultiplier;

    return {
      basePrice,
      locationMultiplier,
      timeMultiplier,
      dayMultiplier,
      demandMultiplier,
      weatherMultiplier,
      totalPrice: Math.round(totalPrice * 100) / 100 // Round to 2 decimal places
    };
  }

  getDemandLevel(location: string, timeOfDay: string, dayOfWeek: string): 'low' | 'medium' | 'high' | 'peak' {
    // Simulate demand based on location and time
    const isWeekend = dayOfWeek === 'saturday' || dayOfWeek === 'sunday';
    const isRushHour = timeOfDay === 'morning' || timeOfDay === 'evening';
    const isMajorCity = ['London', 'Manchester', 'Birmingham'].includes(location);

    if (isWeekend && isMajorCity) return 'peak';
    if (isRushHour && isMajorCity) return 'high';
    if (isWeekend) return 'high';
    if (isRushHour) return 'medium';
    return 'low';
  }

  getTimeOfDay(): 'morning' | 'afternoon' | 'evening' | 'night' {
    const hour = new Date().getHours();
    if (hour >= 6 && hour < 12) return 'morning';
    if (hour >= 12 && hour < 18) return 'afternoon';
    if (hour >= 18 && hour < 22) return 'evening';
    return 'night';
  }

  getDayOfWeek(): 'monday' | 'tuesday' | 'wednesday' | 'thursday' | 'friday' | 'saturday' | 'sunday' {
    const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    return days[new Date().getDay()] as any;
  }

  getPriceSuggestions(factors: PricingFactors): { time: string; price: number; savings: number }[] {
    const currentPrice = this.calculatePrice(factors).totalPrice;
    const suggestions = [];

    // Suggest different times
    const timeSlots = ['morning', 'afternoon', 'evening', 'night'];
    for (const time of timeSlots) {
      if (time !== factors.timeOfDay) {
        const newFactors = { ...factors, timeOfDay: time as any };
        const newPrice = this.calculatePrice(newFactors).totalPrice;
        const savings = currentPrice - newPrice;
        if (savings > 0) {
          suggestions.push({
            time: time.charAt(0).toUpperCase() + time.slice(1),
            price: newPrice,
            savings: Math.round(savings * 100) / 100
          });
        }
      }
    }

    return suggestions.sort((a, b) => b.savings - a.savings);
  }
}

// Export a singleton instance
export const pricingEngine = new DynamicPricingEngine();

export default pricingEngine;
