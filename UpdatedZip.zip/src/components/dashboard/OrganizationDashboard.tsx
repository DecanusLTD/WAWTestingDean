import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Dimensions,
  SafeAreaView,
  Alert,
  Modal,
  TextInput,
  Image,
  ActivityIndicator,
  FlatList,
  ScrollView,
  RefreshControl,
  Platform,
} from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '../../providers/enhanced-auth-context';
import {
  organizationVerificationService,
  Organization,
  OrganizationValeter,
} from '../../services/OrganizationVerificationService';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import LoadingScreen from '../LoadingScreen';
import { supabase } from '../../lib/supabase';

const { width } = Dimensions.get('window');

// Responsive breakpoints
const isSmallScreen = width < 375;

// TODO: Add your Google Maps API key here
const GOOGLE_MAPS_API_KEY = 'YOUR_GOOGLE_MAPS_API_KEY';

/** ---------- Locations table wiring ---------- */
const LOCATIONS_TABLE = 'car_wash_locations';
type OrgIdColumn = 'organization_id' | 'org_id';

/**
 * Geocode an address to lat/lng using Google Maps Geocoding API
 * Returns { latitude, longitude } or null if failed
 */
const geocodeAddress = async (address: string): Promise<{ latitude: number; longitude: number } | null> => {
  try {
    const encodedAddress = encodeURIComponent(address);
    const url = `https://maps.googleapis.com/maps/api/geocode/json?address=${encodedAddress}&key=${GOOGLE_MAPS_API_KEY}`;

    const response = await fetch(url);
    const data = await response.json();

    if (data.status === 'OK' && data.results && data.results.length > 0) {
      const location = data.results[0].geometry.location;
      return {
        latitude: location.lat,
        longitude: location.lng,
      };
    }

    console.warn('Geocoding failed:', data.status);
    return null;
  } catch (error) {
    console.error('Geocoding error:', error);
    return null;
  }
};

interface ValeterCardProps {
  valeter: OrganizationValeter;
  onViewDetails: (valeterId: string) => void;
}

const ValeterCard: React.FC<ValeterCardProps> = ({ valeter, onViewDetails }) => {
  const getStatusColor = () => {
    switch (valeter.status) {
      case 'active':
        return '#10B981';
      case 'approved':
        return '#3B82F6';
      case 'pending':
        return '#F59E0B';
      case 'rejected':
        return '#EF4444';
      default:
        return '#6B7280';
    }
  };

  const getStatusText = () => {
    switch (valeter.status) {
      case 'active':
        return '🟢 Active';
      case 'approved':
        return '🔵 Approved';
      case 'pending':
        return '🟡 Pending';
      case 'rejected':
        return '🔴 Rejected';
      default:
        return '⚪ Unknown';
    }
  };

  return (
    <TouchableOpacity
      style={[styles.valeterCard, { borderColor: getStatusColor() }]}
      onPress={() => onViewDetails(valeter.id)}
    >
      <View style={styles.valeterHeader}>
        <View style={styles.valeterInfo}>
          <Text style={styles.valeterName}>{valeter.name}</Text>
          <Text style={styles.valeterEmail}>{valeter.email}</Text>
        </View>
        <View style={[styles.statusBadge, { backgroundColor: getStatusColor() }]}>
          <Text style={styles.statusText}>{getStatusText()}</Text>
        </View>
      </View>
      <View style={styles.valeterDetails}>
        <Text style={styles.valeterPhone}>📞 {valeter.phone}</Text>
        <Text style={styles.valeterJoined}>
          Joined: {valeter.joinedAt.toLocaleDateString()}
        </Text>
      </View>
      <View style={styles.documentsStatus}>
        <Text style={styles.documentsTitle}>Documents:</Text>
        <View style={styles.documentChecks}>
          <Text
            style={[
              styles.documentCheck,
              valeter.documents.idProof && styles.documentComplete,
            ]}
          >
            {valeter.documents.idProof ? '✓' : '○'} ID Proof
          </Text>
          <Text
            style={[
              styles.documentCheck,
              valeter.documents.selfie && styles.documentComplete,
            ]}
          >
            {valeter.documents.selfie ? '✓' : '○'} Selfie
          </Text>
          <Text
            style={[
              styles.documentCheck,
              valeter.documents.detailsCompleted && styles.documentComplete,
            ]}
          >
            {valeter.documents.detailsCompleted ? '✓' : '○'} Details
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  );
};

/** ---------- UPDATED: Locations Types ---------- */
type CarWashLocation = {
  id: string;
  organization_id?: string;
  org_id?: string;
  name: string;
  address: string | null;
  latitude: number | null;
  longitude: number | null;
  base_price: number;
  priority_price: number;
  status?: string | null;
  wait_time_minutes?: number | null;
  created_at: string;
};

export default function OrganizationDashboard() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();

  const [organization, setOrganization] = useState<Organization | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [showAddValeter, setShowAddValeter] = useState(false);

  // Valeter search state
  type ValeterProfile = {
    id: string;
    full_name: string | null;
    email: string | null;
    phone: string | null;
    user_type: string | null;
    organization_id: string | null;
  };

  const [searchTerm, setSearchTerm] = useState('');
  const [searching, setSearching] = useState(false);
  const [searchResults, setSearchResults] = useState<ValeterProfile[]>([]);
  const [selectedValeterId, setSelectedValeterId] = useState<string | null>(null);
  const [linking, setLinking] = useState(false);
  const searchDebounceRef = useRef<NodeJS.Timeout | null>(null);

  /** ---------- Locations State ---------- */
  const [locations, setLocations] = useState<CarWashLocation[]>([]);
  const [locationsLoading, setLocationsLoading] = useState(false);
  const [showAddLocation, setShowAddLocation] = useState(false);
  const [creatingLocation, setCreatingLocation] = useState(false);
  const [geocoding, setGeocoding] = useState(false);
  const [orgIdColumn, setOrgIdColumn] = useState<OrgIdColumn | null>(null);
  const [locationForm, setLocationForm] = useState({
    name: '',
    address: '',
    basePrice: '',
    priorityPrice: '',
  });

  /** ---------- Edit Location State ---------- */
  const [showEditLocation, setShowEditLocation] = useState(false);
  const [editingLocation, setEditingLocation] = useState<CarWashLocation | null>(null);
  const [editForm, setEditForm] = useState({
    name: '',
    address: '',
    basePrice: '',
    priorityPrice: '',
    status: 'green',
    waitTime: '',
  });
  const [savingEdit, setSavingEdit] = useState(false);
  const [deleting, setDeleting] = useState(false);

  // Scroll animation
  const scrollY = useRef(new Animated.Value(0)).current;
  const headerHeight = scrollY.interpolate({
    inputRange: [0, 160],
    outputRange: [insets.top + 180, insets.top + 120],
    extrapolate: 'clamp',
  });
  const headerOpacity = scrollY.interpolate({
    inputRange: [0, 80, 160],
    outputRange: [1, 0.95, 0.9],
    extrapolate: 'clamp',
  });

  // Decorative bubbles
  const bubble1 = useRef(new Animated.Value(0)).current;
  const bubble2 = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const loop = (a: Animated.Value, d: number) =>
      Animated.loop(
        Animated.sequence([
          Animated.timing(a, { toValue: 1, duration: d, useNativeDriver: true }),
          Animated.timing(a, { toValue: 0, duration: d, useNativeDriver: true }),
        ])
      ).start();
    loop(bubble1, 4200);
    loop(bubble2, 5400);
  }, []);

  useEffect(() => {
    loadOrganizationData();
  }, []);

  useEffect(() => {
    (async () => {
      const oid = await resolveOrgId();
      if (oid) await loadLocations(oid);
    })();
  }, [user?.organizationId, organization?.id]);

  const resolveOrgId = async (): Promise<string | null> => {
    if (user?.organizationId) return user.organizationId;
    if (organization?.id) return organization.id;

    try {
      if (!user?.id) return null;
      const { data, error } = await supabase
        .from('profiles')
        .select('organization_id')
        .eq('id', user.id)
        .maybeSingle();
      if (error) throw error;
      return data?.organization_id ?? null;
    } catch (e) {
      console.warn('[Org] resolveOrgId failed:', (e as any)?.message || e);
      return null;
    }
  };

  const loadOrganizationData = async () => {
    try {
      const orgId = await resolveOrgId();
      if (!orgId) {
        setLoading(false);
        Alert.alert('No Organization', 'Your account is not linked to an organization yet.');
        return;
      }

      let org = await organizationVerificationService.getOrganization(orgId);

      if (!org) {
        org = await organizationVerificationService.createOrganization({
          name: 'Professional Valeting Co.',
          email: user?.email ?? 'admin@provaleting.co.uk',
          phone: user?.phone ?? '+44 800 123 4567',
          address: '123 Business Street, London, UK',
          businessType: 'valeting',
        });
      }

      setOrganization(org);
      await loadLocations(orgId);
    } catch (error) {
      console.error('Error loading organization data:', error);
      Alert.alert('Error', 'Failed to load organization data');
    } finally {
      setLoading(false);
    }
  };

  const loadLocations = async (orgId: string) => {
    try {
      setLocationsLoading(true);

      let { data, error } = await supabase
        .from(LOCATIONS_TABLE)
        .select('*')
        .eq('organization_id', orgId)
        .order('created_at', { ascending: false });

      if (error && /organization_id/.test(error.message || '')) {
        const res2 = await supabase
          .from(LOCATIONS_TABLE)
          .select('*')
          .eq('org_id', orgId)
          .order('created_at', { ascending: false });

        if (!res2.error) setOrgIdColumn('org_id');
        if (res2.error) throw res2.error;
        setLocations((res2.data || []) as CarWashLocation[]);
        return;
      }

      if (error) throw error;

      setOrgIdColumn('organization_id');
      setLocations((data || []) as CarWashLocation[]);
    } catch (e: any) {
      console.warn('[Locations] load error:', e?.message || e);
      Alert.alert('Error', 'Failed to load locations.');
    } finally {
      setLocationsLoading(false);
    }
  };

  const handleCreateLocation = async () => {
    const oid = await resolveOrgId();
    if (!oid) return;

    const name = locationForm.name.trim();
    const address = locationForm.address.trim();
    const bpStr = locationForm.basePrice.trim();
    const ppStr = locationForm.priorityPrice.trim();

    if (!name || !address || !bpStr || !ppStr) {
      Alert.alert('Missing fields', 'All fields are required.');
      return;
    }

    const basePrice = Number(bpStr);
    const priorityPrice = Number(ppStr);

    if ([basePrice, priorityPrice].some((n) => Number.isNaN(n))) {
      Alert.alert('Invalid values', 'Please enter valid numbers for prices.');
      return;
    }

    try {
      setGeocoding(true);

      // Geocode the address
      const coords = await geocodeAddress(address);

      if (!coords) {
        Alert.alert('Invalid Address', 'Could not find coordinates for this address. Please check the address and try again.');
        setGeocoding(false);
        return;
      }

      setGeocoding(false);
      setCreatingLocation(true);

      let fk: OrgIdColumn | null = orgIdColumn;
      if (!fk) {
        const probe = await supabase.from(LOCATIONS_TABLE).select('organization_id').limit(1);
        fk = probe.error ? 'org_id' : 'organization_id';
        setOrgIdColumn(fk);
      }

      const payload: Record<string, any> = {
        name,
        address,
        latitude: coords.latitude,
        longitude: coords.longitude,
        base_price: basePrice,
        priority_price: priorityPrice,
      };
      payload[fk] = oid;

      const { error } = await supabase.from(LOCATIONS_TABLE).insert(payload);
      if (error) throw error;

      hapticFeedback('success');
      setShowAddLocation(false);
      setLocationForm({ name: '', address: '', basePrice: '', priorityPrice: '' });
      await loadLocations(oid);
      Alert.alert('Success', 'Location created.');
    } catch (e: any) {
      console.warn('[Locations] create error:', e?.message || e);
      Alert.alert('Error', 'Failed to create location.');
    } finally {
      setCreatingLocation(false);
      setGeocoding(false);
    }
  };

  const openEditLocation = (loc: CarWashLocation) => {
    setEditingLocation(loc);
    setEditForm({
      name: loc.name || '',
      address: loc.address || '',
      basePrice: Number(loc.base_price).toFixed(2),
      priorityPrice: Number(loc.priority_price).toFixed(2),
      status: (loc.status as string) || 'green',
      waitTime: loc.wait_time_minutes != null ? String(loc.wait_time_minutes) : '',
    });
    setShowEditLocation(true);
  };

  const handleUpdateLocation = async () => {
    if (!editingLocation) return;
    const name = editForm.name.trim();
    const address = editForm.address.trim();
    const bpStr = editForm.basePrice.trim();
    const ppStr = editForm.priorityPrice.trim();
    const status = editForm.status.trim() || 'green';
    const waitStr = editForm.waitTime.trim();

    if (!name || !address || !bpStr || !ppStr) {
      Alert.alert('Missing fields', 'Name, address and both prices are required.');
      return;
    }

    const basePrice = Number(bpStr);
    const priorityPrice = Number(ppStr);
    const wait = waitStr ? Number(waitStr) : null;

    if (
      [basePrice, priorityPrice].some((n) => Number.isNaN(n)) ||
      (waitStr && Number.isNaN(wait))
    ) {
      Alert.alert('Invalid values', 'Please enter valid numbers.');
      return;
    }

    try {
      // Check if address changed
      const addressChanged = address !== editingLocation.address;
      let coords = {
        latitude: editingLocation.latitude,
        longitude: editingLocation.longitude,
      };

      if (addressChanged) {
        setGeocoding(true);
        const newCoords = await geocodeAddress(address);

        if (!newCoords) {
          Alert.alert('Invalid Address', 'Could not find coordinates for this address. Please check the address and try again.');
          setGeocoding(false);
          return;
        }

        coords = newCoords;
        setGeocoding(false);
      }

      setSavingEdit(true);
      const { error } = await supabase
        .from(LOCATIONS_TABLE)
        .update({
          name,
          address,
          latitude: coords.latitude,
          longitude: coords.longitude,
          base_price: basePrice,
          priority_price: priorityPrice,
          status,
          wait_time_minutes: wait,
        })
        .eq('id', editingLocation.id);
      if (error) throw error;

      hapticFeedback('success');
      setShowEditLocation(false);
      setEditingLocation(null);
      const oid = await resolveOrgId();
      if (oid) await loadLocations(oid);
      Alert.alert('Updated', 'Location saved.');
    } catch (e: any) {
      console.warn('[Locations] update error:', e?.message || e);
      Alert.alert('Error', 'Failed to update location.');
    } finally {
      setSavingEdit(false);
      setGeocoding(false);
    }
  };

  const handleDeleteLocation = async () => {
    if (!editingLocation) return;
    Alert.alert('Delete location?', 'This cannot be undone.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          try {
            setDeleting(true);
            const { error } = await supabase
              .from(LOCATIONS_TABLE)
              .delete()
              .eq('id', editingLocation.id);
            if (error) throw error;
            hapticFeedback('success');
            setShowEditLocation(false);
            setEditingLocation(null);
            const oid = await resolveOrgId();
            if (oid) await loadLocations(oid);
            Alert.alert('Deleted', 'Location removed.');
          } catch (e: any) {
            console.warn('[Locations] delete error:', e?.message || e);
            Alert.alert('Error', 'Failed to delete location.');
          } finally {
            setDeleting(false);
          }
        },
      },
    ]);
  };

  useEffect(() => {
    if (!showAddValeter || !organization) return;

    setSelectedValeterId(null);

    if (searchDebounceRef.current) clearTimeout(searchDebounceRef.current);

    const term = searchTerm.trim();
    if (term.length < 2) {
      setSearching(false);
      setSearchResults([]);
      return;
    }

    searchDebounceRef.current = setTimeout(async () => {
      try {
        setSearching(true);

        const { data, error } = await supabase
          .from('profiles')
          .select('id, full_name, email, phone, user_type, organization_id')
          .eq('user_type', 'valeter')
          .or(`full_name.ilike.%${term}%,email.ilike.%${term}%`)
          .order('full_name', { ascending: true })
          .limit(25);

        if (error) throw error;

        const filtered = (data || []).filter(
          (v) => !v.organization_id || v.organization_id === organization.id
        );

        setSearchResults(filtered as ValeterProfile[]);
      } catch (e) {
        console.error('Valeter search failed', e);
        Alert.alert('Search failed', 'Could not search valeters right now.');
        setSearchResults([]);
      } finally {
        setSearching(false);
      }
    }, 300);

    return () => {
      if (searchDebounceRef.current) clearTimeout(searchDebounceRef.current);
    };
  }, [searchTerm, showAddValeter, organization]);

  const linkExistingValeter = async () => {
    if (!organization || !selectedValeterId) return;

    try {
      setLinking(true);

      const { data: updated, error: updErr } = await supabase
        .from('profiles')
        .update({ organization_id: organization.id })
        .eq('id', selectedValeterId)
        .is('organization_id', null)
        .eq('user_type', 'valeter')
        .select('id');

      if (updErr) throw updErr;

      if (!updated || updated.length === 0) {
        const { data: v, error: fetchErr } = await supabase
          .from('profiles')
          .select('organization_id')
          .eq('id', selectedValeterId)
          .eq('user_type', 'valeter')
          .single();

        if (fetchErr) throw fetchErr;

        if (v?.organization_id === organization.id) {
          hapticFeedback('success');
          Alert.alert('Already linked', 'This valeter is already linked to your organization.');
        } else if (v?.organization_id) {
          Alert.alert('Cannot link', 'This valeter is already linked to another organization.');
          return;
        } else {
          Alert.alert('Linking blocked', 'Could not link this valeter due to a permission or constraint issue.');
          return;
        }
      } else {
        hapticFeedback('success');
        Alert.alert('Linked', 'Valeter linked to your organization.');
      }

      setShowAddValeter(false);
      setSearchTerm('');
      setSearchResults([]);
      setSelectedValeterId(null);
      await loadOrganizationData();
    } catch (e) {
      console.error('Link valeter error', e);
      Alert.alert('Error', 'Failed to link valeter.');
    } finally {
      setLinking(false);
    }
  };

  const handleViewValeterDetails = (valeterId: string) => {
    router.push(`/valeter-details/${valeterId}`);
  };

  const onRefresh = async () => {
    setRefreshing(true);
    try {
      await loadOrganizationData();
    } finally {
      setRefreshing(false);
    }
  };

  if (loading) {
    return <LoadingScreen message="Loading organization dashboard..." />;
  }

  if (!organization) {
    return (
      <View style={styles.errorContainer}>
        <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />
        <Text style={styles.errorText}>Organization not found</Text>
        <TouchableOpacity style={styles.errorButton} onPress={() => router.back()}>
          <Text style={styles.errorButtonText}>Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  // Bubble transforms
  const bubble1Style = {
    transform: [
      { translateY: bubble1.interpolate({ inputRange: [0, 1], outputRange: [0, -8] }) },
      { translateX: bubble1.interpolate({ inputRange: [0, 1], outputRange: [0, 6] }) },
    ],
    opacity: bubble1.interpolate({ inputRange: [0, 1], outputRange: [0.15, 0.35] }),
  };
  const bubble2Style = {
    transform: [
      { translateY: bubble2.interpolate({ inputRange: [0, 1], outputRange: [0, -10] }) },
      { translateX: bubble2.interpolate({ inputRange: [0, 1], outputRange: [0, -6] }) },
    ],
    opacity: bubble2.interpolate({ inputRange: [0, 1], outputRange: [0.12, 0.3] }),
  };

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />

        {/* Decorative bubbles */}
        <Animated.View style={[styles.bubble, styles.bubble1, bubble1Style]} />
        <Animated.View style={[styles.bubble, styles.bubble2, bubble2Style]} />

        {/* Curved Header */}
        <Animated.View
          style={[
            styles.headerWrap,
            {
              paddingTop: insets.top + 8,
              height: headerHeight,
              opacity: headerOpacity,
            },
          ]}
        >
          <View style={styles.headerRow}>
            <TouchableOpacity
              style={styles.profileTapArea}
              onPress={() => router.push('/organisation/organisation-profile')}
              activeOpacity={0.8}
            >
              <View style={styles.avatarWrap}>
                {user?.profilePicture ? (
                  <Image source={{ uri: user.profilePicture }} style={styles.profileImage} />
                ) : (
                  <View style={styles.profileButton}>
                    <Text style={styles.profileIcon}>🏢</Text>
                  </View>
                )}
              </View>

              <View style={styles.titleWrap}>
                <Text style={styles.greeting}>
                  {new Date().getHours() < 12
                    ? 'Good morning'
                    : new Date().getHours() < 17
                    ? 'Good afternoon'
                    : 'Good evening'}
                </Text>
                <Text style={styles.organizationName} numberOfLines={1}>
                  {organization.name}
                </Text>
                <Text style={styles.subtitle}>
                  Status:{' '}
                  {organization.status === 'active'
                    ? '🟢 Active'
                    : organization.status === 'verified'
                    ? '🔵 Verified'
                    : organization.status === 'pending'
                    ? '🟡 Pending'
                    : '🔴 Suspended'}
                </Text>
              </View>
            </TouchableOpacity>
          </View>

          {/* Header chips */}
          <View style={styles.headerChipsRow}>
            <View style={styles.headerChip}>
              <Text style={styles.headerChipText}>👥 {organization.valeters.length} valeters</Text>
            </View>
            <View style={styles.headerChip}>
              <Text style={styles.headerChipText}>📍 {locations.length} locations</Text>
            </View>
          </View>
        </Animated.View>

        <Animated.ScrollView
          style={styles.scrollView}
          onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], {
            useNativeDriver: false,
          })}
          scrollEventThrottle={16}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl tintColor="#CBE3FF" refreshing={refreshing} onRefresh={onRefresh} />
          }
          contentContainerStyle={{ paddingTop: 8 }}
        >
          {/* Action Buttons */}
          <View style={styles.section}>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.actionButtonsScroll}
            >
              <TouchableOpacity style={styles.actionButton} onPress={() => setShowAddValeter(true)}>
                <LinearGradient colors={['#8B5CF6', '#7C3AED']} style={styles.actionButtonGradient}>
                  <Text style={styles.actionButtonIcon}>👥</Text>
                  <Text style={styles.actionButtonText}>Add Valeter</Text>
                </LinearGradient>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.actionButton}
                onPress={() => router.push('/organization-rewards-system')}
              >
                <LinearGradient colors={['#F59E0B', '#D97706']} style={styles.actionButtonGradient}>
                  <Text style={styles.actionButtonIcon}>🎁</Text>
                  <Text style={styles.actionButtonText}>Rewards</Text>
                </LinearGradient>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.actionButton}
                onPress={() => setShowAddLocation(true)}
              >
                <LinearGradient colors={['#3B82F6', '#1D4ED8']} style={styles.actionButtonGradient}>
                  <Text style={styles.actionButtonIcon}>📍</Text>
                  <Text style={styles.actionButtonText}>Add Location</Text>
                </LinearGradient>
              </TouchableOpacity>
            </ScrollView>
          </View>

          {/* Locations Section */}
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>
                Locations {locations.length ? `(${locations.length})` : ''}
              </Text>
            </View>

            {locationsLoading ? (
              <View style={{ paddingVertical: 16 }}>
                <ActivityIndicator color="#87CEEB" />
              </View>
            ) : locations.length === 0 ? (
              <View style={styles.emptyState}>
                <Text style={styles.emptyStateIcon}>📍</Text>
                <Text style={styles.emptyStateText}>No locations yet</Text>
                <TouchableOpacity
                  style={styles.emptyStateButton}
                  onPress={() => setShowAddLocation(true)}
                >
                  <Text style={styles.emptyStateButtonText}>Create your first location</Text>
                </TouchableOpacity>
              </View>
            ) : (
              <View>
                {locations.map((loc) => (
                  <TouchableOpacity
                    key={loc.id}
                    style={styles.locationCard}
                    onPress={() => openEditLocation(loc)}
                    activeOpacity={0.7}
                  >
                    <View style={{ flex: 1 }}>
                      <Text style={styles.locationName}>{loc.name}</Text>
                      {!!loc.address && <Text style={styles.locationAddress}>{loc.address}</Text>}
                      <Text style={styles.locationMeta}>
                        💷 Base £{Number(loc.base_price).toFixed(2)} • Priority £
                        {Number(loc.priority_price).toFixed(2)}
                      </Text>
                      {(typeof loc.wait_time_minutes === 'number' || loc.status) && (
                        <Text style={styles.locationMeta}>
                          {loc.status ? `Status: ${String(loc.status).toUpperCase()}` : ''}
                          {typeof loc.wait_time_minutes === 'number'
                            ? `${loc.status ? ' • ' : ''}Wait: ${loc.wait_time_minutes}m`
                            : ''}
                        </Text>
                      )}
                    </View>
                    <Text style={styles.locationChevron}>›</Text>
                  </TouchableOpacity>
                ))}
              </View>
            )}
          </View>

          {/* Valeters List */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Valeters ({organization.valeters.length})</Text>
            {organization.valeters.length === 0 ? (
              <View style={styles.emptyState}>
                <Text style={styles.emptyStateIcon}>👥</Text>
                <Text style={styles.emptyStateText}>No valeters added yet</Text>
                <TouchableOpacity
                  style={styles.emptyStateButton}
                  onPress={() => setShowAddValeter(true)}
                >
                  <Text style={styles.emptyStateButtonText}>Add Your First Valeter</Text>
                </TouchableOpacity>
              </View>
            ) : (
              organization.valeters.map((valeter) => (
                <ValeterCard
                  key={valeter.id}
                  valeter={valeter}
                  onViewDetails={handleViewValeterDetails}
                />
              ))
            )}
          </View>
        </Animated.ScrollView>

        {/* Add Valeter Modal */}
        <Modal
          visible={showAddValeter}
          animationType="slide"
          presentationStyle="pageSheet"
        >
          <View style={styles.modalContainer}>
            <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Link Existing Valeter</Text>
              <TouchableOpacity
                onPress={() => {
                  setShowAddValeter(false);
                  setSearchTerm('');
                  setSearchResults([]);
                  setSelectedValeterId(null);
                }}
              >
                <Text style={styles.modalClose}>✕</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.modalContent}>
              <Text style={styles.inputLabel}>Search by name or email</Text>
              <TextInput
                style={styles.textInput}
                value={searchTerm}
                onChangeText={setSearchTerm}
                placeholder="e.g. Jane Doe or jane@valet.co"
                placeholderTextColor="#6B7280"
                autoCapitalize="none"
                autoCorrect={false}
              />

              {searching ? (
                <View style={{ paddingVertical: 12 }}>
                  <ActivityIndicator color="#87CEEB" />
                </View>
              ) : (
                searchTerm.trim().length >= 2 && (
                  <FlatList
                    data={searchResults}
                    keyExtractor={(item) => item.id}
                    ListEmptyComponent={
                      <Text style={{ color: '#87CEEB', marginTop: 8 }}>
                        No matching valeters found (or they're linked to another org).
                      </Text>
                    }
                    renderItem={({ item }) => {
                      const selected = item.id === selectedValeterId;
                      const alreadyLinkedHere = item.organization_id === organization.id;

                      return (
                        <TouchableOpacity
                          onPress={() => setSelectedValeterId(selected ? null : item.id)}
                          style={[
                            styles.searchResultRow,
                            selected && styles.searchResultRowSelected,
                          ]}
                        >
                          <View style={{ flex: 1 }}>
                            <Text style={styles.searchResultName}>
                              {item.full_name || 'Unnamed user'}
                            </Text>
                            <Text style={styles.searchResultEmail}>{item.email || ''}</Text>
                            {item.phone ? (
                              <Text style={styles.searchResultPhone}>{item.phone}</Text>
                            ) : null}
                            {alreadyLinkedHere ? (
                              <Text style={styles.alreadyLinkedText}>
                                Already linked to this organization
                              </Text>
                            ) : null}
                          </View>
                          <Text style={styles.searchResultTick}>{selected ? '✓' : ''}</Text>
                        </TouchableOpacity>
                      );
                    }}
                  />
                )
              )}
            </View>

            <View style={styles.modalActions}>
              <TouchableOpacity
                style={[
                  styles.modalButton,
                  (!selectedValeterId || linking) && { opacity: 0.6 },
                ]}
                disabled={!selectedValeterId || linking}
                onPress={linkExistingValeter}
              >
                <LinearGradient colors={['#10B981', '#059669']} style={styles.modalButtonGradient}>
                  <Text style={styles.modalButtonText}>
                    {linking ? 'Linking…' : 'Link Valeter'}
                  </Text>
                </LinearGradient>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>

        {/* Add Location Modal */}
        <Modal
          visible={showAddLocation}
          animationType="slide"
          presentationStyle="pageSheet"
        >
          <View style={styles.modalContainer}>
            <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Add Location</Text>
              <TouchableOpacity onPress={() => setShowAddLocation(false)}>
                <Text style={styles.modalClose}>✕</Text>
              </TouchableOpacity>
            </View>

            <ScrollView style={styles.modalContent}>
              <Text style={styles.inputLabel}>Location Name</Text>
              <TextInput
                style={styles.textInput}
                value={locationForm.name}
                onChangeText={(t) => setLocationForm((p) => ({ ...p, name: t }))}
                placeholder="e.g. Trafford Park"
                placeholderTextColor="#6B7280"
              />

              <Text style={styles.inputLabel}>Full Address</Text>
              <TextInput
                style={[styles.textInput, styles.multilineInput]}
                value={locationForm.address}
                onChangeText={(t) => setLocationForm((p) => ({ ...p, address: t }))}
                placeholder="123 Business Street, Manchester, M17 1XX, UK"
                placeholderTextColor="#6B7280"
                multiline
                numberOfLines={3}
              />
              <Text style={styles.helperText}>
                💡 Enter a complete address. We'll automatically find the coordinates.
              </Text>

              <Text style={styles.inputLabel}>Base Price (£)</Text>
              <TextInput
                style={styles.textInput}
                value={locationForm.basePrice}
                onChangeText={(t) => setLocationForm((p) => ({ ...p, basePrice: t }))}
                placeholder="15.00"
                placeholderTextColor="#6B7280"
                keyboardType="decimal-pad"
              />

              <Text style={styles.inputLabel}>Priority Price (£)</Text>
              <TextInput
                style={styles.textInput}
                value={locationForm.priorityPrice}
                onChangeText={(t) => setLocationForm((p) => ({ ...p, priorityPrice: t }))}
                placeholder="20.00"
                placeholderTextColor="#6B7280"
                keyboardType="decimal-pad"
              />
            </ScrollView>

            <View style={styles.modalActions}>
              <TouchableOpacity
                style={[styles.modalButton, (creatingLocation || geocoding) && { opacity: 0.6 }]}
                disabled={creatingLocation || geocoding}
                onPress={handleCreateLocation}
              >
                <LinearGradient colors={['#10B981', '#059669']} style={styles.modalButtonGradient}>
                  <Text style={styles.modalButtonText}>
                    {geocoding ? 'Finding location…' : creatingLocation ? 'Creating…' : 'Create Location'}
                  </Text>
                </LinearGradient>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>

        {/* Edit Location Modal */}
        <Modal
          visible={showEditLocation}
          animationType="slide"
          presentationStyle="pageSheet"
        >
          <View style={styles.modalContainer}>
            <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Edit Location</Text>
              <TouchableOpacity onPress={() => setShowEditLocation(false)}>
                <Text style={styles.modalClose}>✕</Text>
              </TouchableOpacity>
            </View>

            <ScrollView style={styles.modalContent}>
              <Text style={styles.inputLabel}>Location Name</Text>
              <TextInput
                style={styles.textInput}
                value={editForm.name}
                onChangeText={(t) => setEditForm((p) => ({ ...p, name: t }))}
                placeholder="Name"
                placeholderTextColor="#6B7280"
              />

              <Text style={styles.inputLabel}>Full Address</Text>
              <TextInput
                style={[styles.textInput, styles.multilineInput]}
                value={editForm.address}
                onChangeText={(t) => setEditForm((p) => ({ ...p, address: t }))}
                placeholder="Address"
                placeholderTextColor="#6B7280"
                multiline
                numberOfLines={3}
              />
              <Text style={styles.helperText}>
                💡 Update the address and we'll automatically update the coordinates.
              </Text>

              <Text style={styles.inputLabel}>Base Price (£)</Text>
              <TextInput
                style={styles.textInput}
                value={editForm.basePrice}
                onChangeText={(t) => setEditForm((p) => ({ ...p, basePrice: t }))}
                placeholder="15.00"
                placeholderTextColor="#6B7280"
                keyboardType="decimal-pad"
              />

              <Text style={styles.inputLabel}>Priority Price (£)</Text>
              <TextInput
                style={styles.textInput}
                value={editForm.priorityPrice}
                onChangeText={(t) => setEditForm((p) => ({ ...p, priorityPrice: t }))}
                placeholder="20.00"
                placeholderTextColor="#6B7280"
                keyboardType="decimal-pad"
              />

              <Text style={styles.inputLabel}>Status</Text>
              <View style={styles.statusButtons}>
                {['green', 'amber', 'red'].map((s) => (
                  <TouchableOpacity
                    key={s}
                    style={[
                      styles.statusButton,
                      editForm.status === s && styles.statusButtonActive,
                      {
                        backgroundColor: s === 'green' ? '#10B981' : s === 'amber' ? '#F59E0B' : '#EF4444',
                        opacity: editForm.status === s ? 1 : 0.4
                      }
                    ]}
                    onPress={() => setEditForm((p) => ({ ...p, status: s }))}
                  >
                    <Text style={styles.statusButtonText}>{s.toUpperCase()}</Text>
                  </TouchableOpacity>
                ))}
              </View>

              <Text style={styles.inputLabel}>Wait Time (minutes)</Text>
              <TextInput
                style={styles.textInput}
                value={editForm.waitTime}
                onChangeText={(t) => setEditForm((p) => ({ ...p, waitTime: t }))}
                placeholder="15"
                placeholderTextColor="#6B7280"
                keyboardType="number-pad"
              />
            </ScrollView>

            <View style={[styles.modalActions, { flexDirection: 'row', gap: 12 }]}>
              <TouchableOpacity
                style={[styles.modalButton, { flex: 1 }, (savingEdit || deleting || geocoding) && { opacity: 0.6 }]}
                disabled={savingEdit || deleting || geocoding}
                onPress={handleDeleteLocation}
              >
                <LinearGradient colors={['#EF4444', '#DC2626']} style={styles.modalButtonGradient}>
                  <Text style={styles.modalButtonText}>{deleting ? 'Deleting…' : 'Delete'}</Text>
                </LinearGradient>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, { flex: 2 }, (savingEdit || deleting || geocoding) && { opacity: 0.6 }]}
                disabled={savingEdit || deleting || geocoding}
                onPress={handleUpdateLocation}
              >
                <LinearGradient colors={['#10B981', '#059669']} style={styles.modalButtonGradient}>
                  <Text style={styles.modalButtonText}>
                    {geocoding ? 'Finding location…' : savingEdit ? 'Saving…' : 'Save Changes'}
                  </Text>
                </LinearGradient>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      </SafeAreaView>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#0A1929',
  },
  errorText: {
    color: '#F9FAFB',
    fontSize: 16,
    marginBottom: 20,
  },
  errorButton: {
    backgroundColor: '#87CEEB',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
  },
  errorButtonText: {
    color: '#0A1929',
    fontSize: 14,
    fontWeight: '600',
  },

  // Decorative bubbles
  bubble: {
    position: 'absolute',
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  bubble1: { top: -20, right: -20 },
  bubble2: { top: 80, left: -40 },

  // Curved header
  headerWrap: {
    backgroundColor: 'transparent',
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
    paddingHorizontal: isSmallScreen ? 16 : 20,
    paddingBottom: 12,
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  profileTapArea: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  avatarWrap: { marginRight: 12 },
  profileButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(255,255,255,0.18)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileIcon: { fontSize: 20, color: '#F9FAFB' },
  profileImage: { width: 48, height: 48, borderRadius: 24 },
  titleWrap: { flex: 1 },
  greeting: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 14 : 16,
    marginBottom: 4,
    opacity: 0.9,
  },
  organizationName: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 22 : 26,
    fontWeight: '800',
    marginBottom: 2,
  },
  subtitle: {
    color: '#87CEEB',
    fontSize: isSmallScreen ? 12 : 14,
  },

  headerChipsRow: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 12,
  },
  headerChip: {
    paddingHorizontal: 12,
    paddingVertical: Platform.OS === 'ios' ? 6 : 7,
    backgroundColor: 'rgba(255,255,255,0.10)',
    borderRadius: 14,
  },
  headerChipText: { color: '#E8F2FF', fontSize: 12, fontWeight: '600' },

  scrollView: {
    flex: 1,
  },

  section: {
    paddingHorizontal: isSmallScreen ? 12 : 20,
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 8,
  },

  // Action buttons with gradients
  actionButtonsScroll: {
    paddingRight: 20,
    gap: 14,
  },
  actionButton: {
    width: isSmallScreen ? 140 : 150,
    height: isSmallScreen ? 140 : 150,
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
  },
  actionButtonGradient: {
    flex: 1,
    padding: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  actionButtonIcon: {
    fontSize: isSmallScreen ? 32 : 36,
    marginBottom: 10,
  },
  actionButtonText: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 14 : 16,
    fontWeight: '700',
    textAlign: 'center',
  },

  // Valeter cards
  valeterCard: {
    backgroundColor: '#102B6A',
    padding: 16,
    borderRadius: 14,
    marginBottom: 12,
    borderWidth: 2,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  valeterHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  valeterInfo: {
    flex: 1,
  },
  valeterName: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
  valeterEmail: {
    color: '#87CEEB',
    fontSize: 12,
  },
  valeterDetails: {
    marginBottom: 8,
  },
  valeterPhone: {
    color: '#87CEEB',
    fontSize: 14,
    marginBottom: 4,
  },
  valeterJoined: {
    color: '#9CA3AF',
    fontSize: 12,
  },
  documentsStatus: {
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
    paddingTop: 8,
  },
  documentsTitle: {
    color: '#F9FAFB',
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 4,
  },
  documentChecks: {
    flexDirection: 'row',
    gap: 16,
  },
  documentCheck: {
    color: '#9CA3AF',
    fontSize: 12,
  },
  documentComplete: {
    color: '#10B981',
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  statusText: {
    color: '#FFFFFF',
    fontSize: 11,
    fontWeight: '600',
  },

  // Location cards
  locationCard: {
    backgroundColor: '#102B6A',
    borderRadius: 14,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.15)',
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  locationName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
  },
  locationAddress: {
    color: '#87CEEB',
    fontSize: 13,
    marginTop: 2,
  },
  locationMeta: {
    color: '#9CA3AF',
    fontSize: 12,
    marginTop: 2,
  },
  locationChevron: {
    fontSize: 28,
    color: '#87CEEB',
    fontWeight: '300',
  },

  // Empty states
  emptyState: {
    alignItems: 'center',
    padding: 40,
    backgroundColor: '#102B6A',
    borderRadius: 14,
  },
  emptyStateIcon: {
    fontSize: 48,
    marginBottom: 16,
  },
  emptyStateText: {
    color: '#87CEEB',
    fontSize: 14,
    marginBottom: 16,
  },
  emptyStateButton: {
    backgroundColor: '#87CEEB',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 8,
  },
  emptyStateButtonText: {
    color: '#0A1929',
    fontSize: 12,
    fontWeight: '600',
  },

  // Modals
  modalContainer: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  modalTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
  },
  modalClose: {
    color: '#F9FAFB',
    fontSize: 24,
  },
  modalContent: {
    padding: 20,
    flex: 1,
  },
  inputLabel: {
    color: '#F9FAFB',
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 8,
    marginTop: 8,
  },
  textInput: {
    backgroundColor: '#102B6A',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 10,
    padding: 14,
    color: '#F9FAFB',
    fontSize: 14,
    marginBottom: 12,
  },
  multilineInput: {
    minHeight: 80,
    textAlignVertical: 'top',
  },
  helperText: {
    color: '#87CEEB',
    fontSize: 12,
    marginTop: -8,
    marginBottom: 12,
    fontStyle: 'italic',
  },
  statusButtons: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 12,
  },
  statusButton: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  statusButtonActive: {
    borderWidth: 2,
    borderColor: '#F9FAFB',
  },
  statusButtonText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '700',
  },
  modalActions: {
    padding: 20,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
  },
  modalButton: {
    borderRadius: 12,
    overflow: 'hidden',
  },
  modalButtonGradient: {
    paddingVertical: 16,
    alignItems: 'center',
  },
  modalButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },

  // Search results
  searchResultRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#102B6A',
    padding: 14,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.15)',
    marginBottom: 10,
  },
  searchResultRowSelected: {
    borderColor: '#87CEEB',
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
  },
  searchResultName: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
  searchResultEmail: {
    color: '#87CEEB',
    fontSize: 12,
  },
  searchResultPhone: {
    color: '#9CA3AF',
    fontSize: 12,
  },
  searchResultTick: {
    color: '#87CEEB',
    fontSize: 20,
    fontWeight: '700',
    paddingLeft: 8,
  },
  alreadyLinkedText: {
    color: '#10B981',
    fontSize: 11,
    marginTop: 2,
  },
});