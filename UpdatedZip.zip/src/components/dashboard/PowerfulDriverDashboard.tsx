// app/valeter/PowerfulDriverDashboard.tsx
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  View, Text, StyleSheet, TouchableOpacity, Animated, Dimensions,
  SafeAreaView, StatusBar, ScrollView, Modal, Image, Alert, ActivityIndicator,
  RefreshControl
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { useAuth } from '../../providers/enhanced-auth-context';
import AIChatComponent from '../chat/AIChatComponent';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import * as Location from 'expo-location';
import { supabase } from '../../lib/supabase';

const { width } = Dimensions.get('window');

// Responsive breakpoints
const isSmallScreen = width < 375;
const isMediumScreen = width >= 375 && width < 414;

const CARD_W = isSmallScreen ? 170 : isMediumScreen ? 180 : 190;

interface QuickAction {
  id: string;
  icon: string;
  title: string;
  subtitle: string;
  route: string;
  gradient: string[];
}

interface JobRequest {
  id: string;
  serviceName: string;
  distance: number;
  price: number;
  customerName: string;
  address: string;
  timeRemaining: number;
}

interface TodayStats {
  hoursOnline: string;
  jobsCompleted: number;
  earnings: number;
}

/** Animated count-up text for stats */
const CountUpNumber = ({
  value,
  prefix = '',
  suffix = '',
  decimals = 0,
  duration = 650,
  style,
}: {
  value: number;
  prefix?: string;
  suffix?: string;
  decimals?: number;
  duration?: number;
  style?: any;
}) => {
  const anim = useRef(new Animated.Value(0)).current;
  const [display, setDisplay] = useState(0);

  useEffect(() => {
    anim.stopAnimation();
    anim.setValue(0);
    const listenerId = anim.addListener(({ value: v }) => setDisplay(v));
    Animated.timing(anim, { toValue: value, duration, useNativeDriver: false }).start(() => {
      anim.removeListener(listenerId);
      setDisplay(value);
    });
    return () => anim.removeListener(listenerId);
  }, [value]);

  const shown = useMemo(() => Number(display).toFixed(decimals), [display, decimals]);
  return <Text style={style}>{`${prefix}${shown}${suffix}`}</Text>;
};

export default function PowerfulDriverDashboard() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();

  const [showChat, setShowChat] = useState(false);
  const [isOnline, setIsOnline] = useState(false);
  const [loadingPresence, setLoadingPresence] = useState(true);
  const [toggling, setToggling] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  // Job requests and stats
  const [jobRequests, setJobRequests] = useState<JobRequest[]>([]);
  const [todayStats, setTodayStats] = useState<TodayStats>({
    hoursOnline: '0h 0m',
    jobsCompleted: 0,
    earnings: 0
  });
  const [notificationsExpanded, setNotificationsExpanded] = useState(true);
  const [profileName, setProfileName] = useState<string>('');

  const scrollY = useRef(new Animated.Value(0)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;

  // Curved header that compresses gently
  const headerHeight = scrollY.interpolate({
    inputRange: [0, 160],
    outputRange: [insets.top + 120, insets.top + 100],
    extrapolate: 'clamp',
  });
  const headerOpacity = scrollY.interpolate({
    inputRange: [0, 80, 160],
    outputRange: [1, 0.95, 0.9],
    extrapolate: 'clamp',
  });

  // Quick action press scale
  const scaleFor = () => new Animated.Value(1);
  const pressIn = (v: Animated.Value) =>
    Animated.spring(v, { toValue: 0.97, useNativeDriver: true }).start();
  const pressOut = (v: Animated.Value) =>
    Animated.spring(v, { toValue: 1, friction: 3, useNativeDriver: true }).start();

  // Subtle decorative bubbles
  const bubble1 = useRef(new Animated.Value(0)).current;
  const bubble2 = useRef(new Animated.Value(0)).current;

  // Pulsing animation for online indicator
  useEffect(() => {
    if (isOnline) {
      Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnim, { toValue: 1.2, duration: 1000, useNativeDriver: true }),
          Animated.timing(pulseAnim, { toValue: 1, duration: 1000, useNativeDriver: true }),
        ])
      ).start();
    } else {
      pulseAnim.setValue(1);
    }
  }, [isOnline]);

  // decorative bubbles
  useEffect(() => {
    const loop = (a: Animated.Value, d: number) =>
      Animated.loop(
        Animated.sequence([
          Animated.timing(a, { toValue: 1, duration: d, useNativeDriver: true }),
          Animated.timing(a, { toValue: 0, duration: d, useNativeDriver: true }),
        ])
      ).start();
    loop(bubble1, 4200);
    loop(bubble2, 5400);
  }, []);

  // Load initial online status + subscribe to realtime
  useEffect(() => {
    if (!user?.id) return;
    let mounted = true;

    (async () => {
      setLoadingPresence(true);

      // Fetch profile name
      const { data: profileData } = await supabase
        .from('profiles')
        .select('full_name')
        .eq('id', user.id)
        .maybeSingle();

      if (mounted && profileData) {
        setProfileName(profileData.full_name || user.name || 'Valeter');
      } else if (mounted) {
        setProfileName(user.name || 'Valeter');
      }

      // Fetch online status
      const { data, error } = await supabase
        .from('valeter_presence')
        .select('is_online')
        .eq('user_id', user.id)
        .maybeSingle();
      if (!mounted) return;
      if (error) console.warn('[presence] read error', error);
      setIsOnline(!!data?.is_online);
      setLoadingPresence(false);
    })();

    const channel = supabase
      .channel('presence-self')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'valeter_presence',
        filter: `user_id=eq.${user.id}`
      }, (payload) => {
        const row: any = payload.new ?? payload.old;
        if (row && typeof row.is_online === 'boolean') setIsOnline(row.is_online);
      })
      .subscribe();

    return () => {
      mounted = false;
      supabase.removeChannel(channel);
    };
  }, [user?.id]);

  // Subscribe to job requests for this valeter
  useEffect(() => {
    if (!user?.id || !isOnline) return;

    const channel = supabase
      .channel('job-requests')
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'bookings',
        filter: `valeter_id=eq.${user.id}`
      }, (payload) => {
        const booking = payload.new;
        if (booking.status === 'pending_valeter_acceptance') {
          const newRequest: JobRequest = {
            id: booking.id,
            serviceName: booking.service_name || 'Car Wash',
            distance: 0,
            price: Number(booking.price),
            customerName: 'Customer',
            address: booking.location_address || '',
            timeRemaining: 300, // 5 minutes
          };
          setJobRequests(prev => [...prev, newRequest]);
        }
      })
      .on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'bookings',
        filter: `valeter_id=eq.${user.id}`
      }, (payload) => {
        const booking = payload.new;
        if (booking.status !== 'pending_valeter_acceptance') {
          setJobRequests(prev => prev.filter(r => r.id !== booking.id));
        }
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id, isOnline]);

  // Countdown timer for job requests
  useEffect(() => {
    if (jobRequests.length === 0) return;

    const interval = setInterval(() => {
      setJobRequests(prev => prev.map(req => {
        if (req.timeRemaining <= 1) {
          handleJobTimeout(req.id);
          return { ...req, timeRemaining: 0 };
        }
        return { ...req, timeRemaining: req.timeRemaining - 1 };
      }).filter(req => req.timeRemaining > 0));
    }, 1000);

    return () => clearInterval(interval);
  }, [jobRequests]);

  const goOnlineWithLocation = async () => {
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission needed', 'Location permission is required to go online so customers can find you.');
      throw new Error('location-permission-denied');
    }
    const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
    const lat = Number(loc.coords.latitude.toFixed(6));
    const lng = Number(loc.coords.longitude.toFixed(6));

    const { error } = await supabase.rpc('update_my_presence', {
      p_is_online: true,
      p_last_lat: lat,
      p_last_lng: lng,
    });
    if (error) throw error;
  };

  const goOffline = async () => {
    const { error } = await supabase.rpc('set_online', { p_is_online: false });
    if (error) throw error;
  };

  const toggleOnline = async () => {
    try {
      if (!user?.id) return;
      setToggling(true);
      await hapticFeedback('medium');

      if (!isOnline) {
        await goOnlineWithLocation();
      } else {
        await goOffline();
      }
      setIsOnline(!isOnline);
    } catch (e) {
      console.error('[presence] toggle error', e);
      Alert.alert('Error', 'Could not update your online status. Try again.');
    } finally {
      setToggling(false);
    }
  };

  const handleAcceptJob = async (jobId: string) => {
    try {
      await hapticFeedback('medium');
      const { error } = await supabase
        .from('bookings')
        .update({
          status: 'confirmed',
          valeter_response_at: new Date().toISOString(),
        })
        .eq('id', jobId);

      if (error) throw error;

      Alert.alert('Job Accepted', 'Customer will complete payment. You\'ll be notified when ready.');
      setJobRequests(prev => prev.filter(r => r.id !== jobId));
      router.push('/current-trip');
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Failed to accept job');
    }
  };

  const handleDeclineJob = async (jobId: string) => {
    try {
      await hapticFeedback('light');
      const { error } = await supabase
        .from('bookings')
        .update({
          status: 'valeter_declined',
          valeter_response_at: new Date().toISOString(),
        })
        .eq('id', jobId);

      if (error) throw error;
      setJobRequests(prev => prev.filter(r => r.id !== jobId));
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Failed to decline job');
    }
  };

  const handleJobTimeout = async (jobId: string) => {
    try {
      await supabase
        .from('bookings')
        .update({ status: 'valeter_timeout' })
        .eq('id', jobId);
    } catch (e) {
      console.error('Timeout update failed:', e);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleQuickAction = async (action: QuickAction) => {
    await hapticFeedback('light');
    router.push(action.route as any);
  };

  const onRefresh = async () => {
    setRefreshing(true);
    try {
      // Refresh stats logic here
      await new Promise(resolve => setTimeout(resolve, 1000));
    } finally {
      setRefreshing(false);
    }
  };

  const quickActions: QuickAction[] = useMemo(() => [
    {
      id: 'current-trip',
      icon: '📍',
      title: 'Current Trip',
      subtitle: 'View active job',
      route: '/current-trip',
      gradient: ['#3B82F6', '#1D4ED8'],
    },
    {
      id: 'jobs',
      icon: '🚗',
      title: 'Job Queue',
      subtitle: 'Pending requests',
      route: '/wash-requests',
      gradient: ['#10B981', '#059669'],
    },
    {
      id: 'radius',
      icon: '✈️',
      title: 'Work Radius',
      subtitle: 'Set coverage area',
      route: '/distance-covering',
      gradient: ['#06B6D4', '#0891B2'],
    },
    {
      id: 'earnings',
      icon: '💰',
      title: 'Earnings',
      subtitle: `£${todayStats.earnings} today`,
      route: '/valeter/valeter-earnings',
      gradient: ['#F59E0B', '#D97706'],
    },
    {
      id: 'wash-history',
      icon: '📋',
      title: 'History',
      subtitle: `${todayStats.jobsCompleted} jobs`,
      route: '/valeter/valeter-wash-history',
      gradient: ['#8B5CF6', '#7C3AED'],
    },
    {
      id: 'rewards',
      icon: '🎁',
      title: 'Rewards',
      subtitle: 'Points & bonuses',
      route: '/valeter/valeter-rewards-system',
      gradient: ['#EC4899', '#DB2777'],
    },
  ], [todayStats]);

  // bubble transforms
  const bubble1Style = {
    transform: [
      { translateY: bubble1.interpolate({ inputRange: [0, 1], outputRange: [0, -8] }) },
      { translateX: bubble1.interpolate({ inputRange: [0, 1], outputRange: [0, 6] }) },
    ],
    opacity: bubble1.interpolate({ inputRange: [0, 1], outputRange: [0.15, 0.35] }),
  };
  const bubble2Style = {
    transform: [
      { translateY: bubble2.interpolate({ inputRange: [0, 1], outputRange: [0, -10] }) },
      { translateX: bubble2.interpolate({ inputRange: [0, 1], outputRange: [0, -6] }) },
    ],
    opacity: bubble2.interpolate({ inputRange: [0, 1], outputRange: [0.12, 0.3] }),
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0A1929" />
      <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />

      {/* decorative bubbles */}
      <Animated.View style={[styles.bubble, styles.bubble1, bubble1Style]} />
      <Animated.View style={[styles.bubble, styles.bubble2, bubble2Style]} />

      {/* HERO HEADER (curved, roomy) */}
      <Animated.View style={[styles.headerWrap, { paddingTop: insets.top + 8, height: headerHeight, opacity: headerOpacity }]}>
        <View style={styles.headerRow}>
          <TouchableOpacity
            style={styles.profileTapArea}
            onPress={() => router.push('/valeter/valeter-profile')}
            activeOpacity={0.8}
            hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
          >
            <View style={styles.avatarWrap}>
              <View style={styles.profileButton}>
                {user?.profilePicture ? (
                  <Image source={{ uri: user.profilePicture }} style={styles.profileImage} />
                ) : (
                  <Text style={styles.profileIcon}>👤</Text>
                )}
              </View>
            </View>

            <View style={styles.titleWrap}>
              <Text style={styles.greeting}>
                {new Date().getHours() < 12
                  ? 'Good morning'
                  : new Date().getHours() < 17
                  ? 'Good afternoon'
                  : 'Good evening'}
              </Text>
              <Text style={styles.userName} numberOfLines={1}>{profileName || 'Valeter'}</Text>
              <Text style={styles.subtitle}>Valeter Dashboard</Text>
            </View>
          </TouchableOpacity>

          {/* Online Status Indicator */}
          <View style={styles.statusBadge}>
            <Animated.View
              style={[
                styles.statusDot,
                {
                  backgroundColor: isOnline ? '#10B981' : '#EF4444',
                  transform: [{ scale: pulseAnim }],
                }
              ]}
            />
            <Text style={styles.statusText}>
              {loadingPresence || toggling ? '...' : isOnline ? 'ONLINE' : 'OFFLINE'}
            </Text>
          </View>
        </View>
      </Animated.View>

      <Animated.ScrollView
        style={styles.scrollView}
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], { useNativeDriver: false })}
        scrollEventThrottle={16}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl tintColor="#CBE3FF" refreshing={refreshing} onRefresh={onRefresh} />}
        contentContainerStyle={{ paddingTop: 8 }}
      >
        {/* Online Toggle Card */}
        <View style={styles.toggleSection}>
          <LinearGradient
            colors={isOnline ? ['#10B981', '#059669'] : ['#374151', '#1F2937']}
            style={styles.toggleCard}
          >
            <View style={styles.toggleContent}>
              <View style={styles.toggleLeft}>
                <Text style={styles.toggleTitle}>
                  {isOnline ? '✅ You\'re Online' : '⏸️ You\'re Offline'}
                </Text>
                <Text style={styles.toggleSubtitle}>
                  {isOnline
                    ? 'Accepting job requests'
                    : 'Tap to start accepting jobs'}
                </Text>
              </View>

              <TouchableOpacity
                style={styles.toggleButton}
                onPress={toggleOnline}
                disabled={loadingPresence || toggling}
                activeOpacity={0.8}
              >
                <View style={[
                  styles.toggleTrack,
                  { backgroundColor: isOnline ? '#fff' : 'rgba(255,255,255,0.3)' }
                ]}>
                  <Animated.View
                    style={[
                      styles.toggleThumb,
                      {
                        backgroundColor: isOnline ? '#10B981' : '#EF4444',
                        transform: [{ translateX: isOnline ? 30 : 0 }],
                      }
                    ]}
                  />
                </View>
              </TouchableOpacity>
            </View>
          </LinearGradient>
        </View>

        {/* Incoming Job Requests */}
        {jobRequests.length > 0 && (
          <View style={styles.notificationsSection}>
            <TouchableOpacity
              style={styles.notificationHeader}
              onPress={() => setNotificationsExpanded(!notificationsExpanded)}
              activeOpacity={0.7}
            >
              <View style={styles.notificationHeaderLeft}>
                <View style={styles.notificationBadge}>
                  <Text style={styles.notificationBadgeText}>{jobRequests.length}</Text>
                </View>
                <Text style={styles.notificationTitle}>Incoming Requests</Text>
              </View>
              <Text style={styles.notificationExpand}>
                {notificationsExpanded ? '▼' : '▶'}
              </Text>
            </TouchableOpacity>

            {notificationsExpanded && jobRequests.map((request) => (
              <View key={request.id} style={styles.jobRequestCard}>
                <LinearGradient
                  colors={['#3B82F6', '#1D4ED8']}
                  style={styles.jobRequestGradient}
                >
                  <View style={styles.jobRequestHeader}>
                    <View style={styles.jobRequestInfo}>
                      <Text style={styles.jobRequestService}>{request.serviceName}</Text>
                      <Text style={styles.jobRequestDetails}>
                        📍 {request.distance.toFixed(1)}mi • £{request.price}
                      </Text>
                      <Text style={styles.jobRequestAddress} numberOfLines={1}>
                        {request.address}
                      </Text>
                    </View>
                    <View style={styles.jobRequestTimer}>
                      <Text style={styles.jobRequestTimerText}>
                        {formatTime(request.timeRemaining)}
                      </Text>
                    </View>
                  </View>

                  <View style={styles.jobRequestActions}>
                    <TouchableOpacity
                      style={[styles.jobRequestButton, styles.acceptButton]}
                      onPress={() => handleAcceptJob(request.id)}
                      activeOpacity={0.8}
                    >
                      <Text style={styles.jobRequestButtonText}>✓ Accept</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={[styles.jobRequestButton, styles.declineButton]}
                      onPress={() => handleDeclineJob(request.id)}
                      activeOpacity={0.8}
                    >
                      <Text style={styles.jobRequestButtonText}>✕ Decline</Text>
                    </TouchableOpacity>
                  </View>
                </LinearGradient>
              </View>
            ))}
          </View>
        )}

        {/* Quick Actions */}
        <View style={styles.quickActionsSection}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.quickActionsContainer}
          >
            {quickActions.map((action) => {
              const s = scaleFor();
              return (
                <Animated.View key={action.id} style={{ transform: [{ scale: s }], marginRight: 14 }}>
                  <TouchableOpacity
                    style={styles.quickActionCard}
                    activeOpacity={0.9}
                    onPressIn={() => pressIn(s)}
                    onPressOut={() => pressOut(s)}
                    onPress={() => handleQuickAction(action)}
                  >
                    <LinearGradient colors={action.gradient} style={styles.quickActionGradient}>
                      <Text style={styles.quickActionIcon}>{action.icon}</Text>
                      <Text style={styles.quickActionTitle}>{action.title}</Text>
                      <Text style={styles.quickActionSubtitle}>{action.subtitle}</Text>
                    </LinearGradient>
                  </TouchableOpacity>
                </Animated.View>
              );
            })}
          </ScrollView>
        </View>

        {/* Stats Overview */}
        <View style={styles.statsSection}>
          <Text style={styles.sectionTitle}>Today's Overview</Text>
          <View style={styles.statsGrid}>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{todayStats.hoursOnline}</Text>
              <Text style={styles.statLabel}>Hours Online</Text>
            </View>
            <View style={styles.statCard}>
              <CountUpNumber value={todayStats.jobsCompleted} style={styles.statNumber} />
              <Text style={styles.statLabel}>Jobs Completed</Text>
            </View>
            <View style={styles.statCard}>
              <CountUpNumber value={todayStats.earnings} prefix="£" style={styles.statNumber} />
              <Text style={styles.statLabel}>Earnings Today</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>
                {todayStats.jobsCompleted > 0
                  ? `£${(todayStats.earnings / todayStats.jobsCompleted).toFixed(2)}`
                  : '£0'}
              </Text>
              <Text style={styles.statLabel}>Avg per Job</Text>
            </View>
          </View>
        </View>

        <View style={{ height: 40 }} />
      </Animated.ScrollView>

      {/* AI Chat Modal */}
      <Modal visible={showChat} animationType="slide" presentationStyle="fullScreen">
        <AIChatComponent userType="valeter" onClose={() => setShowChat(false)} />
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A1929' },

  /* decorative bubbles */
  bubble: {
    position: 'absolute',
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  bubble1: { top: -20, right: -20 },
  bubble2: { top: 80, left: -40 },

  /* HERO header wrapper */
  headerWrap: {
    backgroundColor: 'transparent',
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
    paddingHorizontal: isSmallScreen ? 16 : 20,
    paddingBottom: 16,
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  profileTapArea: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  avatarWrap: { marginRight: 12 },
  profileButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(255,255,255,0.18)',
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  profileIcon: { fontSize: 20, color: '#F9FAFB' },
  profileImage: { width: 48, height: 48, borderRadius: 24 },

  titleWrap: { flex: 1 },
  greeting: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 14 : 16,
    marginBottom: 4,
    opacity: 0.9
  },
  userName: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 22 : 26,
    fontWeight: '800',
    marginBottom: 2
  },
  subtitle: { color: '#87CEEB', fontSize: isSmallScreen ? 12 : 14 },

  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.16)',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
  },
  statusDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginRight: 6,
  },
  statusText: {
    color: '#F9FAFB',
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 0.5,
  },

  scrollView: { flex: 1 },

  /* Toggle Section */
  toggleSection: {
    marginHorizontal: isSmallScreen ? 12 : 20,
    marginBottom: 20,
  },
  toggleCard: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  toggleContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
  },
  toggleLeft: {
    flex: 1,
  },
  toggleTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  toggleSubtitle: {
    color: '#FFFFFF',
    fontSize: 14,
    opacity: 0.9,
  },
  toggleButton: {
    marginLeft: 12,
  },
  toggleTrack: {
    width: 70,
    height: 40,
    borderRadius: 20,
    padding: 4,
    justifyContent: 'center',
  },
  toggleThumb: {
    width: 32,
    height: 32,
    borderRadius: 16,
  },

  /* Notifications Section */
  notificationsSection: {
    marginHorizontal: isSmallScreen ? 12 : 20,
    marginBottom: 20,
  },
  notificationHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    backgroundColor: 'rgba(59, 130, 246, 0.1)',
    borderRadius: 12,
    marginBottom: 12,
  },
  notificationHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  notificationBadge: {
    backgroundColor: '#EF4444',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  notificationBadgeText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '900',
  },
  notificationTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#F9FAFB',
  },
  notificationExpand: {
    fontSize: 12,
    color: '#87CEEB',
  },

  jobRequestCard: {
    marginBottom: 12,
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
  },
  jobRequestGradient: {
    padding: 16,
  },
  jobRequestHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  jobRequestInfo: {
    flex: 1,
  },
  jobRequestService: {
    fontSize: 18,
    fontWeight: '900',
    color: '#fff',
    marginBottom: 4,
  },
  jobRequestDetails: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.9)',
    marginBottom: 4,
  },
  jobRequestAddress: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.7)',
  },
  jobRequestTimer: {
    backgroundColor: 'rgba(239, 68, 68, 0.9)',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 12,
    height: 40,
    justifyContent: 'center',
  },
  jobRequestTimerText: {
    fontSize: 16,
    fontWeight: '900',
    color: '#fff',
  },
  jobRequestActions: {
    flexDirection: 'row',
    gap: 12,
  },
  jobRequestButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 12,
    alignItems: 'center',
  },
  acceptButton: {
    backgroundColor: '#10B981',
  },
  declineButton: {
    backgroundColor: 'rgba(255,255,255,0.2)',
  },
  jobRequestButtonText: {
    fontSize: 14,
    fontWeight: '900',
    color: '#fff',
  },

  /* Quick Actions */
  quickActionsSection: { marginBottom: 24 },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 16,
    marginHorizontal: isSmallScreen ? 12 : 20
  },
  quickActionsContainer: { paddingHorizontal: isSmallScreen ? 12 : 20 },
  quickActionCard: {
    width: CARD_W,
    height: CARD_W,
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
  },
  quickActionGradient: {
    flex: 1,
    padding: 18,
    alignItems: 'center',
    justifyContent: 'center'
  },
  quickActionIcon: { fontSize: isSmallScreen ? 34 : 38, marginBottom: 10 },
  quickActionTitle: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 16 : 18,
    fontWeight: '700',
    marginBottom: 6,
    textAlign: 'center'
  },
  quickActionSubtitle: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 11 : 12,
    opacity: 0.9,
    textAlign: 'center'
  },

  /* Stats */
  statsSection: { marginBottom: 24 },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    gap: 12,
    paddingHorizontal: isSmallScreen ? 12 : 20,
  },
  statCard: {
    width: (width - (isSmallScreen ? 36 : 40)) / 2 - 6,
    backgroundColor: '#102B6A',
    padding: 18,
    borderRadius: 14,
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  statNumber: {
    fontSize: isSmallScreen ? 20 : 24,
    fontWeight: 'bold',
    color: '#F9FAFB',
    marginBottom: 4
  },
  statLabel: { fontSize: 12, color: '#87CEEB', textAlign: 'center' },
});