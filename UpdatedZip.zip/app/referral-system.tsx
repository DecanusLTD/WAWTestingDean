import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Alert,
  Dimensions,
  Share,
  Clipboard,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuth } from '../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../src/services/HapticFeedbackService';

const { width, height } = Dimensions.get('window');
const isSmallScreen = width < 375;
const isMediumScreen = width >= 375 && width < 414;
const isLargeScreen = width >= 414;

export default function ReferralSystem() {
  const { user } = useAuth();
  const [referralCode] = useState(`${user?.name?.replace(/\s+/g, '') || 'User'}WaW2024`);
  const [referrals, setReferrals] = useState([
    {
      id: '1',
      name: 'Sarah Johnson',
      email: 'sarah.j@email.com',
      date: '2024-01-15',
      status: 'completed',
      reward: 'Free Basic Wash'
    },
    {
      id: '2',
      name: 'Mike Wilson',
      email: 'mike.w@email.com',
      date: '2024-01-12',
      status: 'pending',
      reward: 'Free Basic Wash'
    },
    {
      id: '3',
      name: 'Emma Davis',
      email: 'emma.d@email.com',
      date: '2024-01-10',
      status: 'completed',
      reward: 'Free Basic Wash'
    }
  ]);

  const referralStats = {
    totalReferrals: referrals.length,
    completedReferrals: referrals.filter(r => r.status === 'completed').length,
    pendingReferrals: referrals.filter(r => r.status === 'pending').length,
    totalRewards: referrals.filter(r => r.status === 'completed').length,
    maxReferrals: 5
  };

  const handleShareReferral = async () => {
    try {
      await hapticFeedback('light');
      
      const shareMessage = `🚗 Get a FREE car wash! Use my referral code "${referralCode}" when you sign up for Wish a Wash. Download the app and get your first wash completely free! 🎉\n\nDownload here: https://wishawash.com/download`;
      
      await Share.share({
        message: shareMessage,
        title: 'Get a Free Car Wash!'
      });
    } catch (error) {
      console.error('Error sharing referral:', error);
    }
  };

  const handleCopyCode = async () => {
    try {
      await hapticFeedback('light');
      await Clipboard.setString(referralCode);
      
      Alert.alert(
        'Code Copied! 📋',
        'Your referral code has been copied to clipboard.',
        [{ text: 'OK' }]
      );
    } catch (error) {
      console.error('Error copying code:', error);
      Alert.alert('Error', 'Failed to copy code. Please try again.');
    }
  };

  const handleViewRewards = async () => {
    try {
      await hapticFeedback('light');
      router.push('/rewards-system');
    } catch (error) {
      console.error('Error navigating to rewards:', error);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return '#10B981';
      case 'pending': return '#F59E0B';
      default: return '#6B7280';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'completed': return 'Completed';
      case 'pending': return 'Pending';
      default: return 'Unknown';
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#0A1929', '#1E3A8A']}
        style={StyleSheet.absoluteFill}
      />
      
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity 
            onPress={async () => {
              await hapticFeedback('light');
              router.back();
            }} 
            style={styles.backButton}
          >
            <Text style={styles.backButtonText}>←</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Refer Friends</Text>
          <View style={styles.headerSpacer} />
        </View>

        {/* Referral Banner */}
        <View style={styles.section}>
          <LinearGradient
            colors={['#10B981', '#059669']}
            style={styles.bannerCard}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
          >
            <Text style={styles.bannerIcon}>🎉</Text>
            <Text style={styles.bannerTitle}>Earn Free Washes!</Text>
            <Text style={styles.bannerDescription}>
              Refer friends and both of you get a free exterior wash. Refer up to 5 friends!
            </Text>
          </LinearGradient>
        </View>

        {/* Referral Code */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Your Referral Code</Text>
          <View style={styles.codeCard}>
            <View style={styles.codeContainer}>
              <Text style={styles.codeLabel}>Share this code with friends:</Text>
              <Text style={styles.referralCode}>{referralCode}</Text>
            </View>
            
            <View style={styles.codeActions}>
              <TouchableOpacity style={styles.copyButton} onPress={handleCopyCode}>
                <Text style={styles.copyButtonText}>📋 Copy</Text>
              </TouchableOpacity>
              
              <TouchableOpacity style={styles.shareButton} onPress={handleShareReferral}>
                <Text style={styles.shareButtonText}>📤 Share</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        {/* Referral Stats */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Your Referral Stats</Text>
          <View style={styles.statsGrid}>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{referralStats.totalReferrals}</Text>
              <Text style={styles.statLabel}>Total Referrals</Text>
            </View>
            
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{referralStats.completedReferrals}</Text>
              <Text style={styles.statLabel}>Completed</Text>
            </View>
            
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{referralStats.pendingReferrals}</Text>
              <Text style={styles.statLabel}>Pending</Text>
            </View>
            
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{referralStats.totalRewards}</Text>
              <Text style={styles.statLabel}>Rewards Earned</Text>
            </View>
          </View>
          
          <View style={styles.progressCard}>
            <Text style={styles.progressTitle}>Progress to Max Referrals</Text>
            <View style={styles.progressBar}>
              <View 
                style={[
                  styles.progressFill, 
                  { width: `${(referralStats.totalReferrals / referralStats.maxReferrals) * 100}%` }
                ]} 
              />
            </View>
            <Text style={styles.progressText}>
              {referralStats.totalReferrals}/{referralStats.maxReferrals} referrals
            </Text>
          </View>
        </View>

        {/* How It Works */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>How It Works</Text>
          <View style={styles.howItWorksCard}>
            <View style={styles.stepItem}>
              <View style={styles.stepNumber}>
                <Text style={styles.stepNumberText}>1</Text>
              </View>
              <View style={styles.stepInfo}>
                <Text style={styles.stepTitle}>Share Your Code</Text>
                <Text style={styles.stepDescription}>
                  Share your unique referral code with friends via message, social media, or email
                </Text>
              </View>
            </View>
            
            <View style={styles.stepItem}>
              <View style={styles.stepNumber}>
                <Text style={styles.stepNumberText}>2</Text>
              </View>
              <View style={styles.stepInfo}>
                <Text style={styles.stepTitle}>Friend Signs Up</Text>
                <Text style={styles.stepDescription}>
                  Your friend downloads the app and enters your referral code during signup
                </Text>
              </View>
            </View>
            
            <View style={styles.stepItem}>
              <View style={styles.stepNumber}>
                <Text style={styles.stepNumberText}>3</Text>
              </View>
              <View style={styles.stepInfo}>
                <Text style={styles.stepTitle}>Both Get Rewards</Text>
                <Text style={styles.stepDescription}>
                  When your friend completes their first wash, both of you get a free exterior wash!
                </Text>
              </View>
            </View>
          </View>
        </View>

        {/* Referral List */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Your Referrals</Text>
          <View style={styles.referralsList}>
            {referrals.length > 0 ? (
              referrals.map((referral) => (
                <View key={referral.id} style={styles.referralItem}>
                  <View style={styles.referralInfo}>
                    <Text style={styles.referralName}>{referral.name}</Text>
                    <Text style={styles.referralEmail}>{referral.email}</Text>
                    <Text style={styles.referralDate}>{referral.date}</Text>
                  </View>
                  
                  <View style={styles.referralStatus}>
                    <View style={[styles.statusBadge, { backgroundColor: getStatusColor(referral.status) }]}>
                      <Text style={styles.statusText}>{getStatusText(referral.status)}</Text>
                    </View>
                    <Text style={styles.referralReward}>{referral.reward}</Text>
                  </View>
                </View>
              ))
            ) : (
              <View style={styles.emptyState}>
                <Text style={styles.emptyIcon}>👥</Text>
                <Text style={styles.emptyTitle}>No Referrals Yet</Text>
                <Text style={styles.emptyDescription}>
                  Start sharing your referral code to earn free washes!
                </Text>
              </View>
            )}
          </View>
        </View>

        {/* Rewards Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Your Rewards</Text>
          <View style={styles.rewardsCard}>
            <View style={styles.rewardItem}>
              <Text style={styles.rewardIcon}>🚿</Text>
              <View style={styles.rewardInfo}>
                <Text style={styles.rewardTitle}>Free Exterior Wash</Text>
                <Text style={styles.rewardDescription}>
                  Available for your next booking
                </Text>
              </View>
              <Text style={styles.rewardCount}>x{referralStats.totalRewards}</Text>
            </View>
            
            <TouchableOpacity style={styles.viewRewardsButton} onPress={handleViewRewards}>
              <Text style={styles.viewRewardsText}>View All Rewards</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Terms & Conditions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Terms & Conditions</Text>
          <View style={styles.termsCard}>
            <Text style={styles.termsText}>
              • Maximum 5 referrals per account{'\n'}
              • Referral must be a new user{'\n'}
              • Friend must complete their first wash{'\n'}
              • Rewards are valid for 6 months{'\n'}
              • Cannot refer existing users{'\n'}
              • One reward per successful referral
            </Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: isSmallScreen ? 16 : 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backButtonText: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
  },
  headerSpacer: {
    width: 40,
  },
  section: {
    padding: isSmallScreen ? 16 : 20,
  },
  bannerCard: {
    borderRadius: 16,
    padding: 24,
    alignItems: 'center',
    marginBottom: 16,
  },
  bannerIcon: {
    fontSize: 48,
    marginBottom: 16,
  },
  bannerTitle: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 24 : 28,
    fontWeight: 'bold',
    marginBottom: 8,
    textAlign: 'center',
  },
  bannerDescription: {
    color: '#E5E7EB',
    fontSize: isSmallScreen ? 14 : 16,
    textAlign: 'center',
  },
  codeCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 20,
    marginBottom: 16,
  },
  codeContainer: {
    marginBottom: 12,
  },
  codeLabel: {
    color: '#87CEEB',
    fontSize: isSmallScreen ? 12 : 14,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  referralCode: {
    color: '#87CEEB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  codeActions: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  copyButton: {
    backgroundColor: '#87CEEB',
    borderRadius: 8,
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  copyButtonText: {
    color: '#0A1929',
    fontSize: isSmallScreen ? 12 : 14,
    fontWeight: 'bold',
  },
  shareButton: {
    backgroundColor: '#F59E0B',
    borderRadius: 8,
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  shareButtonText: {
    color: '#0A1929',
    fontSize: isSmallScreen ? 12 : 14,
    fontWeight: 'bold',
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  statsGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 12,
    marginBottom: 16,
  },
  statCard: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  statNumber: {
    color: '#F59E0B',
    fontSize: isSmallScreen ? 24 : 28,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  statLabel: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 12 : 14,
    fontWeight: 'bold',
  },
  progressCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    marginTop: 16,
  },
  progressTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 14 : 16,
    fontWeight: 'bold',
    marginBottom: 8,
    textAlign: 'center',
  },
  progressBar: {
    height: 8,
    backgroundColor: '#4B5563',
    borderRadius: 4,
    marginBottom: 8,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#F59E0B',
    borderRadius: 4,
  },
  progressText: {
    color: '#87CEEB',
    fontSize: isSmallScreen ? 12 : 14,
    textAlign: 'center',
  },
  howItWorksCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
  },
  stepItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  stepNumber: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#F59E0B',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  stepNumberText: {
    color: '#0A1929',
    fontSize: 16,
    fontWeight: 'bold',
  },
  stepInfo: {
    flex: 1,
  },
  stepTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 14 : 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  stepDescription: {
    color: '#E5E7EB',
    fontSize: isSmallScreen ? 12 : 14,
  },
  referralsList: {
    gap: 12,
  },
  referralItem: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  referralInfo: {
    flex: 1,
  },
  referralName: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 14 : 16,
    fontWeight: 'bold',
    marginBottom: 2,
  },
  referralEmail: {
    color: '#87CEEB',
    fontSize: isSmallScreen ? 12 : 14,
    marginBottom: 2,
  },
  referralDate: {
    color: '#87CEEB',
    fontSize: isSmallScreen ? 10 : 12,
  },
  referralStatus: {
    alignItems: 'flex-end',
  },
  statusBadge: {
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 4,
    marginBottom: 4,
  },
  statusText: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 10 : 12,
    fontWeight: 'bold',
  },
  referralReward: {
    color: '#F59E0B',
    fontSize: isSmallScreen ? 10 : 12,
    fontWeight: 'bold',
  },
  rewardsCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
  },
  rewardItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  rewardIcon: {
    fontSize: 28,
    marginRight: 12,
  },
  rewardInfo: {
    flex: 1,
  },
  rewardTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 14 : 16,
    fontWeight: 'bold',
    marginBottom: 2,
  },
  rewardDescription: {
    color: '#E5E7EB',
    fontSize: isSmallScreen ? 10 : 12,
  },
  rewardCount: {
    color: '#F59E0B',
    fontSize: isSmallScreen ? 14 : 16,
    fontWeight: 'bold',
  },
  viewRewardsButton: {
    backgroundColor: '#F59E0B',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
  },
  viewRewardsText: {
    color: '#0A1929',
    fontSize: isSmallScreen ? 16 : 18,
    fontWeight: 'bold',
  },
  termsCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
  },
  termsText: {
    color: '#E5E7EB',
    fontSize: isSmallScreen ? 12 : 14,
    lineHeight: 20,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  emptyIcon: {
    fontSize: 48,
    marginBottom: 12,
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  emptyDescription: {
    color: '#87CEEB',
    fontSize: isSmallScreen ? 12 : 14,
    textAlign: 'center',
    paddingHorizontal: 20,
  },
});
