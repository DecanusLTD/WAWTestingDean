// app/detailed-stats.tsx (or your current path)
import React, { useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Dimensions,
  RefreshControl,
  ActivityIndicator,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useAuth } from '../src/providers/enhanced-auth-context';
import { rewardSystem } from '../src/services/RewardSystem';
import { supabase } from '../src/lib/supabase';
import * as FileSystem from 'expo-file-system/legacy';
import * as Sharing from 'expo-sharing';
import { Alert, Platform } from 'react-native';

const { width } = Dimensions.get('window');

type Period = 'week' | 'month' | 'year';

type TopService = { name: string; count: number; revenue: number };
type PeakHour = { hour: string; jobs: number };
type TopLocation = { name: string; jobs: number; revenue: number };

type Detailed = {
  earnings: number;
  jobs: number;
  rating: number;
  hours: number; // for valeter
  points: number;
  topServices: TopService[];
  peakHours: PeakHour[];
  locations: TopLocation[];
};

const PEAK_BUCKETS: { label: string; start: number; end: number }[] = [
  { label: '6-9 AM', start: 6, end: 9 },
  { label: '9-12 AM', start: 9, end: 12 },
  { label: '12-3 PM', start: 12, end: 15 },
  { label: '3-6 PM', start: 15, end: 18 },
  { label: '6-9 PM', start: 18, end: 21 },
];

function startOfTodayMinus(days: number) {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() - days);
  return d;
}
function startOfMonthMinus(months: number) {
  const d = new Date();
  d.setDate(1);
  d.setHours(0, 0, 0, 0);
  d.setMonth(d.getMonth() - months);
  return d;
}
function startOfYearMinus(years: number) {
  const d = new Date();
  d.setMonth(0, 1);
  d.setHours(0, 0, 0, 0);
  d.setFullYear(d.getFullYear() - years);
  return d;
}

export default function DetailedStats() {
  const router = useRouter();
  const { user } = useAuth();
  const [selectedPeriod, setSelectedPeriod] = useState<Period>('week');
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [currentStats, setCurrentStats] = useState<Detailed>({
    earnings: 0,
    jobs: 0,
    rating: 0,
    hours: 0,
    points: 0,
    topServices: [],
    peakHours: PEAK_BUCKETS.map(b => ({ hour: b.label, jobs: 0 })),
    locations: [],
  });

  const userRewards = rewardSystem.getUserRewards(user?.id || '', user?.userType || 'customer');

  const periods = [
    { id: 'week' as Period, label: 'This Week' },
    { id: 'month' as Period, label: 'This Month' },
    { id: 'year' as Period, label: 'This Year' },
  ];

  /** derive time range */
  const [fromISO, toISO] = useMemo(() => {
    const to = new Date();
    let from: Date;
    if (selectedPeriod === 'week') from = startOfTodayMinus(6);
    else if (selectedPeriod === 'month') from = startOfMonthMinus(0); // current month
    else from = startOfYearMinus(0); // current year
    return [from.toISOString(), to.toISOString()];
  }, [selectedPeriod]);

const buildCsv = () => {
  const esc = (v: any) => `"${String(v ?? '').replace(/"/g, '""')}"`;

  const lines: string[] = [];

  // Overview
  lines.push('Section,Metric,Value');
  lines.push(`Overview,Period,${selectedPeriod}`);
  lines.push(`Overview,${user?.userType === 'valeter' ? 'Total Earnings' : 'Total Spent'},£${currentStats.earnings}`);
  lines.push(`Overview,${user?.userType === 'valeter' ? 'Jobs Completed' : 'Services Booked'},${currentStats.jobs}`);
  lines.push(`Overview,Average Rating,${currentStats.rating}`);
  if (user?.userType === 'valeter') lines.push(`Overview,Hours Worked,${currentStats.hours}h`);

  // Rewards
  lines.push(`Rewards,Level,${userRewards.level}`);
  lines.push(`Rewards,Points,${userRewards.points}`);
  lines.push(`Rewards,Points to Next,${userRewards.pointsToNextLevel}`);
  lines.push('');

  // Top Services
  lines.push('Top Services,Count,Revenue');
  currentStats.topServices.forEach(s =>
    lines.push(`${esc(s.name)},${s.count},£${s.revenue}`)
  );
  lines.push('');

  // Peak Hours
  lines.push('Peak Hours,Jobs');
  currentStats.peakHours.forEach(p =>
    lines.push(`${esc(p.hour)},${p.jobs}`)
  );
  lines.push('');

  // Locations
  lines.push('Top Locations,Jobs,Revenue');
  currentStats.locations.forEach(l =>
    lines.push(`${esc(l.name)},${l.jobs},£${l.revenue}`)
  );

  return lines.join('\n');
};

const handleExportReport = async () => {
  try {
    const csv = buildCsv();
    const fileName = `detailed_analytics_${selectedPeriod}_${Date.now()}.csv`;
    const uri = (FileSystem.cacheDirectory ?? FileSystem.documentDirectory!) + fileName;

    // SAFEST: omit encoding (defaults to UTF-8 across platforms)
    await FileSystem.writeAsStringAsync(uri, csv /* , { encoding: 'utf8' } */);

    const shareOptions =
      Platform.OS === 'ios'
        ? { mimeType: 'text/csv', UTI: 'public.comma-separated-values-text', dialogTitle: 'Export Analytics' }
        : { mimeType: 'text/csv', dialogTitle: 'Export Analytics' };

    if (await Sharing.isAvailableAsync()) {
      await Sharing.shareAsync(uri, shareOptions as any);
    } else {
      Alert.alert(
        'Export saved',
        `File saved here:\n${uri}\n\nSharing isn’t available on this device.`
      );
    }
  } catch (e) {
    console.error('Export error', e);
    Alert.alert('Export failed', 'Something went wrong while creating the report.');
  }
};

  /** load stats from backend */
  const loadStats = async () => {
    if (!user?.id) return;
    setLoading(true);
    try {
      // We support both roles by filtering different columns:
      // - customers: bookings.user_id === user.id
      // - valeters : bookings.valeter_id === user.id
      const role = user.userType === 'valeter' ? 'valeter' : 'customer';
      const col = role === 'valeter' ? 'valeter_id' : 'user_id';

      // Expected columns (best effort): price, payout_amount, rating, service_type, created_at,
      // location_area OR location_name OR city (any of these), duration_minutes (optional for hours)
      let query = supabase
        .from('bookings')
        .select('status, price, service_type, created_at')
        .gte('created_at', fromISO)
        .lte('created_at', toISO);

      // @ts-ignore – dynamic eq
      query = (query as any).eq(col, user.id);

      const { data: bookings, error } = await query;
      if (error) console.warn('[DetailedStats] bookings error:', error);

      const rows = (bookings || []) as any[];

      // Jobs count (exclude cancelled for most metrics)
      const nonCancelled = rows.filter(r => r.status !== 'cancelled');
      const completed = rows.filter(r => r.status === 'completed');

      // Earnings:
      // - customer: sum(price) of non-cancelled
      // - valeter : sum(payout_amount if present else price * 0.8 as a safe fallback)
      const earnings = nonCancelled.reduce((sum, r) => {
        if (role === 'customer') return sum + (Number(r.price) || 0);
        const payout = Number(r.payout_amount);
        if (Number.isFinite(payout)) return sum + payout;
        const price = Number(r.price) || 0;
        return sum + Math.round(price * 0.8);
      }, 0);

      // Avg rating from completed
      const rating =
        completed.length > 0
          ? +(completed.reduce((s, r) => s + (Number(r.rating) || 0), 0) / completed.length).toFixed(1)
          : 0;

      // Hours (only valeter): sum of duration_minutes/60 if available, else estimate 1h per completed job
      const hours =
        role === 'valeter'
          ? completed.reduce((sum, r) => {
              const mins = Number(r.duration_minutes);
              if (Number.isFinite(mins) && mins > 0) return sum + mins / 60;
              return sum + 1;
            }, 0)
          : 0;

      // Top services (by completed)
      const svcMap: Record<string, { count: number; revenue: number }> = {};
      completed.forEach(r => {
        const key = (r.service_type || 'Unknown') as string;
        const price = Number(role === 'valeter' ? r.payout_amount ?? r.price : r.price) || 0;
        svcMap[key] = svcMap[key] || { count: 0, revenue: 0 };
        svcMap[key].count += 1;
        svcMap[key].revenue += price;
      });
      const topServices: TopService[] = Object.entries(svcMap)
        .map(([name, v]) => ({ name, count: v.count, revenue: Math.round(v.revenue) }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 5);

      // Peak hours (by job count across buckets)
      const peaks = PEAK_BUCKETS.map(b => ({ hour: b.label, jobs: 0 }));
      nonCancelled.forEach(r => {
        const dt = new Date(r.created_at);
        const h = dt.getHours();
        const bucketIdx = PEAK_BUCKETS.findIndex(b => h >= b.start && h < b.end);
        if (bucketIdx >= 0) peaks[bucketIdx].jobs += 1;
      });

      // Locations (best effort across multiple possible fields)
      const locMap: Record<string, { jobs: number; revenue: number }> = {};
      nonCancelled.forEach(r => {
        const name = (r.location_area || r.location_name || r.city || 'Unknown') as string;
        const price = Number(role === 'valeter' ? r.payout_amount ?? r.price : r.price) || 0;
        locMap[name] = locMap[name] || { jobs: 0, revenue: 0 };
        locMap[name].jobs += 1;
        locMap[name].revenue += price;
      });
      const locations: TopLocation[] = Object.entries(locMap)
        .map(([name, v]) => ({ name, jobs: v.jobs, revenue: Math.round(v.revenue) }))
        .sort((a, b) => b.jobs - a.jobs)
        .slice(0, 5);

      setCurrentStats({
        earnings: Math.round(earnings),
        jobs: nonCancelled.length,
        rating,
        hours: Math.round(hours),
        points: userRewards.points ?? 0,
        topServices,
        peakHours: peaks,
        locations,
      });
    } catch (e) {
      console.error('[DetailedStats] unexpected error:', e);
      // leave defaults in state
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadStats();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id, selectedPeriod, fromISO, toISO]);

  const onRefresh = async () => {
    setRefreshing(true);
    await loadStats();
    setRefreshing(false);
  };

  const StatCard = ({ title, value, subtitle, icon, color }: any) => (
    <View style={[styles.statCard, { borderLeftColor: color }]}>
      <View style={styles.statHeader}>
        <Text style={styles.statIcon}>{icon}</Text>
        <Text style={styles.statTitle}>{title}</Text>
      </View>
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statSubtitle}>{subtitle}</Text>
    </View>
  );

  const ProgressBar = ({ value, max, color }: any) => (
    <View style={styles.progressContainer}>
      <View style={[styles.progressBar, { backgroundColor: 'rgba(255, 255, 255, 0.1)' }]}>
        <View
          style={[
            styles.progressFill,
            {
              width: `${Math.max(0, Math.min(100, (value / Math.max(1, max)) * 100))}%`,
              backgroundColor: color,
            },
          ]}
        />
      </View>
      <Text style={styles.progressText}>{value}/{max}</Text>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView
        style={styles.scrollView}
        refreshControl={<RefreshControl tintColor="#CBE3FF" refreshing={refreshing} onRefresh={onRefresh} />}
      >
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Detailed Analytics</Text>
          <View style={styles.placeholder} />
        </View>

        {/* Period Selector */}
        <View style={styles.periodSelector}>
          {periods.map((period) => (
            <TouchableOpacity
              key={period.id}
              style={[
                styles.periodButton,
                selectedPeriod === period.id && styles.selectedPeriodButton,
              ]}
              onPress={() => setSelectedPeriod(period.id)}
            >
              <Text
                style={[
                  styles.periodText,
                  selectedPeriod === period.id && styles.selectedPeriodText,
                ]}
              >
                {period.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {loading ? (
          <View style={{ padding: 24, alignItems: 'center' }}>
            <ActivityIndicator color="#CBE3FF" />
            <Text style={{ color: '#CBE3FF', marginTop: 8 }}>Loading…</Text>
          </View>
        ) : (
          <>
            {/* Main Stats Grid */}
            <View style={styles.statsGrid}>
              <StatCard
                title={user?.userType === 'valeter' ? 'Total Earnings' : 'Total Spent'}
                value={`£${currentStats.earnings}`}
                subtitle={`${selectedPeriod} total`}
                icon="💰"
                color="#4CAF50"
              />
              <StatCard
                title={user?.userType === 'valeter' ? 'Jobs Completed' : 'Services Booked'}
                value={currentStats.jobs}
                subtitle="services"
                icon="✅"
                color="#2196F3"
              />
              <StatCard
                title="Average Rating"
                value={currentStats.rating}
                subtitle="out of 5 stars"
                icon="⭐"
                color="#FF9800"
              />
              {user?.userType === 'valeter' && (
                <StatCard
                  title="Hours Worked"
                  value={`${currentStats.hours}h`}
                  subtitle="total hours"
                  icon="⏰"
                  color="#9C27B0"
                />
              )}
            </View>

            {/* Rewards Progress */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Rewards Progress</Text>
              <View style={styles.rewardsCard}>
                <View style={styles.rewardsHeader}>
                  <Text style={styles.rewardsLevel}>{userRewards.level} Level</Text>
                  <Text style={styles.rewardsPoints}>{userRewards.points} Points</Text>
                </View>
                <ProgressBar
                  value={userRewards.points}
                  max={userRewards.points + userRewards.pointsToNextLevel}
                  color="#87CEEB"
                />
                <Text style={styles.rewardsNext}>
                  {userRewards.pointsToNextLevel} points to {userRewards.nextLevel}
                </Text>
              </View>
            </View>

            {/* Top Services */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Top Services</Text>
              <View style={styles.servicesCard}>
                {currentStats.topServices.length === 0 ? (
                  <Text style={{ color: '#B8D2F3' }}>No services in this period.</Text>
                ) : (
                  currentStats.topServices.map((service) => (
                    <View key={service.name} style={styles.serviceRow}>
                      <View style={styles.serviceInfo}>
                        <Text style={styles.serviceName}>{service.name}</Text>
                        <Text style={styles.serviceCount}>{service.count} services</Text>
                      </View>
                      <Text style={styles.serviceRevenue}>£{service.revenue}</Text>
                    </View>
                  ))
                )}
              </View>
            </View>

            {/* Peak Hours */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Peak Hours</Text>
              <View style={styles.peakHoursCard}>
                {currentStats.peakHours.map((peak, index) => {
                  const max = Math.max(1, ...currentStats.peakHours.map(p => p.jobs));
                  return (
                    <View key={peak.hour} style={styles.peakRow}>
                      <Text style={styles.peakHour}>{peak.hour}</Text>
                      <View style={styles.peakBarContainer}>
                        <View
                          style={[
                            styles.peakBar,
                            {
                              width: `${(peak.jobs / max) * 100}%`,
                              backgroundColor: index === 0 ? '#4CAF50' : index === 1 ? '#2196F3' : '#FF9800',
                            },
                          ]}
                        />
                      </View>
                      <Text style={styles.peakJobs}>{peak.jobs} jobs</Text>
                    </View>
                  );
                })}
              </View>
            </View>

            {/* Top Locations */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Top Locations</Text>
              <View style={styles.locationsCard}>
                {currentStats.locations.length === 0 ? (
                  <Text style={{ color: '#B8D2F3' }}>No location data for this period.</Text>
                ) : (
                  currentStats.locations.map((location) => (
                    <View key={location.name} style={styles.locationRow}>
                      <View style={styles.locationInfo}>
                        <Text style={styles.locationName}>{location.name}</Text>
                        <Text style={styles.locationJobs}>{location.jobs} jobs</Text>
                      </View>
                      <Text style={styles.locationRevenue}>£{location.revenue}</Text>
                    </View>
                  ))
                )}
              </View>
            </View>

            {/* Recent Rewards Activity */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Recent Activity</Text>
              <View style={styles.activityCard}>
                {userRewards.recentEarnings.slice(0, 5).map((earning: any) => (
                  <View key={earning.id} style={styles.activityRow}>
                    <Text style={styles.activityIcon}>🎁</Text>
                    <View style={styles.activityInfo}>
                      <Text style={styles.activityReason}>{earning.reason}</Text>
                      <Text style={styles.activityDate}>{earning.date}</Text>
                    </View>
                    <Text style={styles.activityPoints}>+{earning.amount} pts</Text>
                  </View>
                ))}
              </View>
            </View>

            {/* Export Options */}
            <View style={styles.section}>
              <TouchableOpacity style={styles.exportButton} onPress={handleExportReport}>
                <Text style={styles.exportButtonText}>📊 Export Report</Text>
              </TouchableOpacity>
            </View>
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A1929' },
  scrollView: { flex: 1 },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    padding: 20, borderBottomWidth: 1, borderBottomColor: '#1E3A8A',
  },
  backButton: { padding: 8 },
  backButtonText: { color: '#87CEEB', fontSize: 16 },
  headerTitle: { color: '#F9FAFB', fontSize: 20, fontWeight: 'bold' },
  placeholder: { width: 60 },

  periodSelector: { flexDirection: 'row', padding: 20, gap: 12 },
  periodButton: {
    flex: 1, paddingVertical: 12, paddingHorizontal: 16, borderRadius: 8,
    backgroundColor: 'rgba(255,255,255,0.05)', alignItems: 'center',
  },
  selectedPeriodButton: { backgroundColor: '#87CEEB' },
  periodText: { color: '#E5E7EB', fontSize: 14, fontWeight: '600' },
  selectedPeriodText: { color: '#0A1929' },

  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', padding: 20, gap: 12 },
  statCard: {
    width: (width - 52) / 2,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12, padding: 16, borderLeftWidth: 4,
  },
  statHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  statIcon: { fontSize: 20, marginRight: 8 },
  statTitle: { color: '#E5E7EB', fontSize: 12, fontWeight: '600' },
  statValue: { color: '#F9FAFB', fontSize: 24, fontWeight: 'bold', marginBottom: 4 },
  statSubtitle: { color: '#87CEEB', fontSize: 12 },

  section: { padding: 20 },
  sectionTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: 'bold', marginBottom: 16 },

  rewardsCard: { backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: 12, padding: 16 },
  rewardsHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  rewardsLevel: { color: '#87CEEB', fontSize: 16, fontWeight: '600' },
  rewardsPoints: { color: '#F9FAFB', fontSize: 18, fontWeight: 'bold' },

  progressContainer: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  progressBar: { flex: 1, height: 8, borderRadius: 4, marginRight: 12 },
  progressFill: { height: '100%', borderRadius: 4 },
  progressText: { color: '#87CEEB', fontSize: 12, fontWeight: '600' },
  rewardsNext: { color: '#E5E7EB', fontSize: 12 },

  servicesCard: { backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: 12, padding: 16 },
  serviceRow: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.1)',
  },
  serviceInfo: { flex: 1 },
  serviceName: { color: '#F9FAFB', fontSize: 16, fontWeight: '600' },
  serviceCount: { color: '#87CEEB', fontSize: 12 },
  serviceRevenue: { color: '#4CAF50', fontSize: 16, fontWeight: 'bold' },

  peakHoursCard: { backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: 12, padding: 16 },
  peakRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 12 },
  peakHour: { color: '#F9FAFB', fontSize: 14, width: 80 },
  peakBarContainer: {
    flex: 1, height: 20, backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 10, marginHorizontal: 12, overflow: 'hidden',
  },
  peakBar: { height: '100%', borderRadius: 10 },
  peakJobs: { color: '#87CEEB', fontSize: 12, width: 60, textAlign: 'right' },

  locationsCard: { backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: 12, padding: 16 },
  locationRow: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.1)',
  },
  locationInfo: { flex: 1 },
  locationName: { color: '#F9FAFB', fontSize: 16, fontWeight: '600' },
  locationJobs: { color: '#87CEEB', fontSize: 12 },
  locationRevenue: { color: '#4CAF50', fontSize: 16, fontWeight: 'bold' },

  activityCard: { backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: 12, padding: 16 },
  activityRow: {
    flexDirection: 'row', alignItems: 'center', paddingVertical: 8,
    borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.1)',
  },
  activityIcon: { fontSize: 20, marginRight: 12 },
  activityInfo: { flex: 1 },
  activityReason: { color: '#F9FAFB', fontSize: 14, fontWeight: '600' },
  activityDate: { color: '#87CEEB', fontSize: 12 },
  activityPoints: { color: '#4CAF50', fontSize: 14, fontWeight: 'bold' },

  exportButton: { backgroundColor: '#87CEEB', paddingVertical: 16, paddingHorizontal: 24, borderRadius: 12, alignItems: 'center' },
  exportButtonText: { color: '#0A1929', fontSize: 16, fontWeight: 'bold' },
});