// app/jobs.tsx
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  View, Text, ScrollView, StyleSheet, TouchableOpacity, SafeAreaView,
  FlatList, RefreshControl, Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import { useAuth } from '../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../src/services/HapticFeedbackService';
import AsyncStorage from '@react-native-async-storage/async-storage';
import BookingService from '../src/services/BookingService';
import * as Location from 'expo-location';
import { supabase } from '../src/lib/supabase';

type Job = {
  id: string;
  user_id?: string;
  service_type?: string;
  service_name?: string;
  serviceName?: string;
  price: number;
  location_address?: string | null;
  location_lat?: number | null;
  location_lng?: number | null;
  location?: { address?: string | null; latitude?: number | null; longitude?: number | null };
  scheduled_at?: string | null;
  scheduledAt?: string | null;
  status?: string;
  valeter_id?: string | null;
  vehicleType?: string | null;
  vehicleInfo?: string | null;
  specialInstructions?: string | null;
  _distanceKm?: number | null;
};

export default function Jobs() {
  const router = useRouter();
  const { user } = useAuth();

  const [jobs, setJobs] = useState<Job[]>([]);
  const [workingRadius, setWorkingRadius] = useState(15);
  const [refreshing, setRefreshing] = useState(false);
  const [myLoc, setMyLoc] = useState<{ lat: number; lng: number } | null>(null);

  // Active job enforcement
  const [activeJobId, setActiveJobId] = useState<string | null>(null);

  // Helper functions
  const kmBetween = (a: {lat:number;lng:number}, b: {lat:number;lng:number}) => {
    const R = 6371; // km
    const dLat = (b.lat - a.lat) * Math.PI / 180;
    const dLng = (b.lng - a.lng) * Math.PI / 180;
    const la1 = a.lat * Math.PI / 180;
    const la2 = b.lat * Math.PI / 180;
    const sinDLat = Math.sin(dLat/2), sinDLng = Math.sin(dLng/2);
    const h = sinDLat*sinDLat + Math.cos(la1)*Math.cos(la2)*sinDLng*sinDLng;
    return 2 * R * Math.asin(Math.min(1, Math.sqrt(h)));
  };

  const pickServiceLabel = (row: any) =>
    row?.service_name || row?.serviceName || row?.service_type || row?.serviceType || 'Service';

  const pickAddress = (row: any) =>
    row?.location_address ?? row?.location?.address ?? null;

  const pickCoords = (row: any): { lat: number; lng: number } | null => {
    const lat =
      typeof row?.location_lat === 'number' ? row.location_lat :
      typeof row?.location?.latitude === 'number' ? row.location.latitude :
      null;
    const lng =
      typeof row?.location_lng === 'number' ? row.location_lng :
      typeof row?.location?.longitude === 'number' ? row.location.longitude :
      null;
    if (typeof lat === 'number' && typeof lng === 'number') return { lat, lng };
    return null;
  };

  const pickScheduledAt = (row: any) =>
    row?.scheduled_at || row?.scheduledAt || null;

  const pickVehicleInfo = (row: any) =>
    row?.vehicleInfo || row?.vehicle_type || row?.vehicleType || null;

  const withDistance = (rows: Job[], origin: {lat:number;lng:number}|null) =>
    rows.map(r => {
      const coords = pickCoords(r);
      const d = origin && coords ? kmBetween(origin, coords) : null;
      return { ...r, _distanceKm: d as number | null };
    });

  const fetchMyLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      const pos = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      setMyLoc({ lat: pos.coords.latitude, lng: pos.coords.longitude });
    } catch {
      // ignore
    }
  };

  const loadWorkingRadius = async () => {
    try {
      const radius = await AsyncStorage.getItem('workingRadius');
      if (radius) setWorkingRadius(parseInt(radius, 10));
    } catch {}
  };

  const fetchJobs = async () => {
    try {
      // Fetch open jobs that any valeter can accept
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .is('valeter_id', null)
        .eq('status', 'pending')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setJobs((data as Job[]) || []);
    } catch (e) {
      console.error('Error fetching jobs:', e);
    }
  };

  // NEW: Fetch jobs specifically assigned to this valeter awaiting response
  const [pendingRequests, setPendingRequests] = useState<Job[]>([]);
  const fetchPendingRequests = async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('valeter_id', user.id)
        .eq('status', 'pending_valeter_acceptance')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setPendingRequests((data as Job[]) || []);
    } catch (e) {
      console.error('Error fetching pending requests:', e);
    }
  };

  const fetchActiveValeterJob = useCallback(async () => {
    if (!user?.id) {
      setActiveJobId(null);
      return;
    }
    try {
      // Active statuses: Valeter is considered busy only when they have:
      // - pending_payment (waiting for customer payment after acceptance)
      // - confirmed (payment complete, ready to start)
      // - en_route, arrived, in_progress (actively working)
      // NOTE: pending_valeter_acceptance is NOT considered active - it's just a request
      const { data, error } = await supabase
        .from('bookings')
        .select('id')
        .eq('valeter_id', user.id)
        .in('status', [
          'pending_payment',
          'confirmed',
          'en_route',
          'arrived',
          'in_progress'
        ])
        .order('created_at', { ascending: false })
        .limit(1);

      if (error) throw error;
      const row = data?.[0] ?? null;
      setActiveJobId(row?.id ?? null);
    } catch (e) {
      console.warn('[Jobs] fetchActiveValeterJob error:', (e as any)?.message || e);
      setActiveJobId(null);
    }
  }, [user?.id]);

  useEffect(() => {
    loadWorkingRadius();
    fetchMyLocation();
    fetchJobs();
    fetchPendingRequests();
    fetchActiveValeterJob();
  }, [fetchActiveValeterJob]);

  const onRefresh = async () => {
    setRefreshing(true);
    await Promise.all([fetchMyLocation(), fetchJobs(), fetchPendingRequests(), fetchActiveValeterJob()]);
    setRefreshing(false);
  };

  // Compute distance + filter + sort
  const jobsWithDistance = useMemo(() => withDistance(jobs, myLoc), [jobs, myLoc]);

  const visibleJobs = useMemo(() => {
    return jobsWithDistance
      .filter(j => {
        if (j._distanceKm == null) return true;
        return j._distanceKm <= workingRadius;
      })
      .sort((a, b) => {
        const da = a._distanceKm ?? Infinity;
        const db = b._distanceKm ?? Infinity;
        return da - db;
      });
  }, [jobsWithDistance, workingRadius]);

  const canAccept = !activeJobId;

  const warnActiveJob = (existingId: string) => {
    Alert.alert(
      'You already have an active job',
      'Finish your current job before accepting a new one.',
      [
        { text: 'View Current Job', onPress: () => router.push(`/current-trip?bookingId=${existingId}`) },
        { text: 'OK' },
      ]
    );
  };

  const handleAcceptAssignedJob = async (job: any) => {
    if (!user) return;
    await hapticFeedback('medium');

    const label = pickServiceLabel(job);
    Alert.alert(
      'Accept Assigned Job',
      `Accept this ${label} for £${job.price}?`,
      [
        { text: 'Decline', style: 'destructive', onPress: () => handleDeclineAssignedJob(job) },
        {
          text: 'Accept',
          onPress: async () => {
            try {
              // Update status to trigger customer payment flow
              const { error } = await supabase
                .from('bookings')
                .update({
                  status: 'confirmed', // This triggers customer payment
                  valeter_response_at: new Date().toISOString(),
                })
                .eq('id', job.id)
                .eq('valeter_id', user.id)
                .eq('status', 'pending_valeter_acceptance');

              if (error) throw error;

              Alert.alert('Accepted! 🎉', 'The customer will complete payment and you\'ll be notified when to start.');
              fetchPendingRequests();
              fetchActiveValeterJob();
            } catch (e: any) {
              Alert.alert('Error', e?.message || 'Could not accept job, please retry.');
            }
          },
        },
      ]
    );
  };

  const handleDeclineAssignedJob = async (job: any) => {
    try {
      const { error } = await supabase
        .from('bookings')
        .update({
          status: 'valeter_declined',
          valeter_response_at: new Date().toISOString(),
        })
        .eq('id', job.id)
        .eq('valeter_id', user.id)
        .eq('status', 'pending_valeter_acceptance');

      if (error) throw error;

      Alert.alert('Declined', 'The customer will be notified.');
      fetchPendingRequests();
    } catch (e: any) {
      Alert.alert('Error', e?.message || 'Could not decline job, please retry.');
    }
  };

  const handleAccept = async (job: any) => {
    if (!user) return;
    await hapticFeedback('medium');

    // Re-check just before attempting to claim
    await fetchActiveValeterJob();
    if (activeJobId) {
      warnActiveJob(activeJobId);
      return;
    }

    const label = pickServiceLabel(job);
    Alert.alert(
      'Accept Job',
      `Accept this ${label} for £${job.price}?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Accept',
          onPress: async () => {
            try {
              // NEW: Instead of assigning directly, we update to pending_valeter_acceptance
              // This triggers the customer's flow where they see the valeter and pay
              const { data, error } = await supabase
                .from('bookings')
                .update({
                  valeter_id: user.id,
                  status: 'pending_valeter_acceptance',
                  request_sent_at: new Date().toISOString(),
                })
                .eq('id', job.id)
                .is('valeter_id', null) // Only if not already claimed
                .eq('status', 'pending') // Only if still pending
                .select()
                .single();

              if (error) {
                // Job was likely already claimed
                if (error.code === 'PGRST116') {
                  Alert.alert('Already Taken', 'Another valeter accepted this job.');
                } else {
                  throw error;
                }
                return;
              }

              setActiveJobId(data.id);
              Alert.alert(
                'Request Sent! ⏳',
                'The customer will review your request and complete payment. You\'ll be notified when they accept.',
                [{ text: 'OK' }]
              );
              fetchJobs();
              fetchPendingRequests();
              fetchActiveValeterJob();
            } catch (e: any) {
              Alert.alert('Error', e?.message || 'Could not accept job, please retry.');
              await fetchActiveValeterJob();
            }
          },
        },
      ]
    );
  };

  const renderJob = ({ item }: { item: any }) => {
    const label = pickServiceLabel(item);
    const address = pickAddress(item);
    const scheduledAt = pickScheduledAt(item);
    const vehicleInfo = pickVehicleInfo(item);

    return (
      <View style={styles.card}>
        <LinearGradient
          colors={['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.04)']}
          style={styles.cardGrad}
        >
          <View style={styles.cardHeader}>
            <Text style={styles.service}>{label}</Text>
            <Text style={styles.price}>£{item.price}</Text>
          </View>

          {address ? (
            <View style={styles.infoRow}>
              <Text style={styles.infoIcon}>📍</Text>
              <Text style={styles.infoText}>{address}</Text>
            </View>
          ) : null}

          {typeof item._distanceKm === 'number' ? (
            <View style={styles.infoRow}>
              <Text style={styles.infoIcon}>📏</Text>
              <Text style={styles.infoText}>
                {item._distanceKm < 1
                  ? `${Math.round(item._distanceKm * 1000)} m away`
                  : `${item._distanceKm.toFixed(1)} km away`}
              </Text>
            </View>
          ) : null}

          {vehicleInfo ? (
            <View style={styles.infoRow}>
              <Text style={styles.infoIcon}>🚗</Text>
              <Text style={styles.infoText}>{vehicleInfo}</Text>
            </View>
          ) : null}

          {scheduledAt ? (
            <View style={styles.infoRow}>
              <Text style={styles.infoIcon}>⏰</Text>
              <Text style={styles.infoText}>{new Date(scheduledAt).toLocaleString()}</Text>
            </View>
          ) : null}

          <TouchableOpacity
            style={[styles.acceptBtn, !canAccept && styles.acceptBtnDisabled]}
            onPress={() => (canAccept ? handleAccept(item) : warnActiveJob(activeJobId!))}
            activeOpacity={canAccept ? 0.8 : 1}
          >
            <LinearGradient
              colors={canAccept ? ['#10B981', '#059669'] : ['#6B7280', '#4B5563']}
              style={styles.acceptGrad}
            >
              <Text style={styles.acceptTxt}>
                {canAccept ? 'Accept Job' : 'Finish current job first'}
              </Text>
            </LinearGradient>
          </TouchableOpacity>
        </LinearGradient>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView
        style={{ flex: 1 }}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor="#10B981"
          />
        }
      >
        <View style={styles.header}>
          <TouchableOpacity
            onPress={() => router.back()}
            style={styles.backBtn}
            activeOpacity={0.7}
          >
            <Text style={styles.backText}>←</Text>
          </TouchableOpacity>
          <Text style={styles.title}>Available Jobs</Text>
          <View style={{ width: 40 }} />
        </View>

        {/* Banner if the valeter already has an active job */}
        {activeJobId ? (
          <View style={styles.banner}>
            <Text style={styles.bannerIcon}>⚠️</Text>
            <View style={styles.bannerContent}>
              <Text style={styles.bannerTitle}>Active Job in Progress</Text>
              <Text style={styles.bannerText}>
                Complete your current job before accepting another.
              </Text>
            </View>
            <TouchableOpacity
              style={styles.bannerBtn}
              onPress={() => router.push(`/current-trip?bookingId=${activeJobId}`)}
              activeOpacity={0.8}
            >
              <Text style={styles.bannerBtnText}>View Job</Text>
            </TouchableOpacity>
          </View>
        ) : null}

        {/* Pending requests assigned to this valeter */}
        {pendingRequests.length > 0 ? (
          <View style={styles.pendingSection}>
            <Text style={styles.pendingTitle}>⏳ Pending Requests ({pendingRequests.length})</Text>
            <Text style={styles.pendingSubtitle}>Customers waiting for your response</Text>
            {pendingRequests.map(request => {
              const label = pickServiceLabel(request);
              const address = pickAddress(request);
              const vehicleInfo = pickVehicleInfo(request);

              return (
                <View key={request.id} style={styles.pendingCard}>
                  <LinearGradient
                    colors={['rgba(251, 191, 36, 0.1)', 'rgba(245, 158, 11, 0.05)']}
                    style={styles.pendingCardGrad}
                  >
                    <View style={styles.cardHeader}>
                      <Text style={[styles.service, { color: '#FCD34D' }]}>{label}</Text>
                      <Text style={[styles.price, { color: '#F59E0B' }]}>£{request.price}</Text>
                    </View>

                    {address ? (
                      <View style={styles.infoRow}>
                        <Text style={styles.infoIcon}>📍</Text>
                        <Text style={styles.infoText}>{address}</Text>
                      </View>
                    ) : null}

                    {vehicleInfo ? (
                      <View style={styles.infoRow}>
                        <Text style={styles.infoIcon}>🚗</Text>
                        <Text style={styles.infoText}>{vehicleInfo}</Text>
                      </View>
                    ) : null}

                    <View style={styles.pendingActions}>
                      <TouchableOpacity
                        style={styles.declineBtn}
                        onPress={() => handleDeclineAssignedJob(request)}
                        activeOpacity={0.8}
                      >
                        <Text style={styles.declineBtnText}>Decline</Text>
                      </TouchableOpacity>

                      <TouchableOpacity
                        style={styles.acceptAssignedBtn}
                        onPress={() => handleAcceptAssignedJob(request)}
                        activeOpacity={0.8}
                      >
                        <LinearGradient colors={['#10B981', '#059669']} style={styles.acceptGrad}>
                          <Text style={styles.acceptTxt}>Accept Job</Text>
                        </LinearGradient>
                      </TouchableOpacity>
                    </View>
                  </LinearGradient>
                </View>
              );
            })}
          </View>
        ) : null}

        <View style={styles.statsBar}>
          <View style={styles.statItem}>
            <Text style={styles.statValue}>{visibleJobs.length}</Text>
            <Text style={styles.statLabel}>Available</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={styles.statValue}>{pendingRequests.length}</Text>
            <Text style={styles.statLabel}>Pending</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={styles.statValue}>{workingRadius} km</Text>
            <Text style={styles.statLabel}>Radius</Text>
          </View>
        </View>

        <FlatList
          data={visibleJobs}
          renderItem={renderJob}
          keyExtractor={(i) => i.id}
          scrollEnabled={false}
          contentContainerStyle={styles.listContent}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Text style={styles.emptyIcon}>🚗</Text>
              <Text style={styles.emptyTitle}>No Available Jobs</Text>
              <Text style={styles.emptyText}>
                No wash requests in your {workingRadius} km radius right now.
              </Text>
              <Text style={styles.emptyHint}>
                Pull down to refresh or increase your radius in settings.
              </Text>
            </View>
          }
        />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },

  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.1)',
  },
  backBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backText: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  title: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '900',
  },

  banner: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 20,
    marginTop: 16,
    padding: 16,
    borderRadius: 16,
    backgroundColor: 'rgba(239, 68, 68, 0.1)',
    borderWidth: 1,
    borderColor: 'rgba(239, 68, 68, 0.3)',
    gap: 12,
  },
  bannerIcon: {
    fontSize: 24,
  },
  bannerContent: {
    flex: 1,
  },
  bannerTitle: {
    color: '#FCA5A5',
    fontSize: 14,
    fontWeight: '700',
    marginBottom: 4,
  },
  bannerText: {
    color: '#FEE2E2',
    fontSize: 12,
  },
  bannerBtn: {
    backgroundColor: '#EF4444',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  bannerBtnText: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 12,
  },

  statsBar: {
    flexDirection: 'row',
    marginHorizontal: 20,
    marginTop: 16,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  statItem: {
    flex: 1,
    alignItems: 'center',
  },
  statValue: {
    color: '#10B981',
    fontSize: 24,
    fontWeight: '900',
    marginBottom: 4,
  },
  statLabel: {
    color: '#E5E7EB',
    fontSize: 12,
    opacity: 0.8,
  },
  statDivider: {
    width: 1,
    backgroundColor: 'rgba(255,255,255,0.1)',
    marginHorizontal: 16,
  },

  listContent: {
    padding: 20,
  },

  card: {
    marginBottom: 16,
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  cardGrad: {
    padding: 16,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  service: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    flex: 1,
  },
  price: {
    color: '#10B981',
    fontSize: 20,
    fontWeight: '900',
  },

  infoRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  infoIcon: {
    fontSize: 16,
    marginRight: 8,
    marginTop: 2,
  },
  infoText: {
    color: '#E5E7EB',
    fontSize: 14,
    flex: 1,
    lineHeight: 20,
  },

  acceptBtn: {
    marginTop: 12,
    borderRadius: 12,
    overflow: 'hidden',
  },
  acceptBtnDisabled: {
    opacity: 0.5,
  },
  acceptGrad: {
    paddingVertical: 14,
    alignItems: 'center',
  },
  acceptTxt: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '900',
  },

  empty: {
    alignItems: 'center',
    paddingVertical: 60,
    paddingHorizontal: 40,
  },
  emptyIcon: {
    fontSize: 64,
    marginBottom: 16,
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 8,
  },
  emptyText: {
    color: '#E5E7EB',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 8,
  },
  emptyHint: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
    fontStyle: 'italic',
  },

  // Pending requests styles
  pendingSection: {
    marginHorizontal: 20,
    marginTop: 16,
    marginBottom: 8,
  },
  pendingTitle: {
    color: '#FCD34D',
    fontSize: 18,
    fontWeight: '900',
    marginBottom: 4,
  },
  pendingSubtitle: {
    color: '#F59E0B',
    fontSize: 12,
    marginBottom: 12,
    opacity: 0.8,
  },
  pendingCard: {
    marginBottom: 12,
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(251, 191, 36, 0.3)',
  },
  pendingCardGrad: {
    padding: 16,
  },
  pendingActions: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 12,
  },
  declineBtn: {
    flex: 1,
    backgroundColor: 'rgba(239, 68, 68, 0.2)',
    borderWidth: 1,
    borderColor: 'rgba(239, 68, 68, 0.5)',
    borderRadius: 12,
    paddingVertical: 12,
    alignItems: 'center',
  },
  declineBtnText: {
    color: '#FCA5A5',
    fontWeight: '700',
    fontSize: 14,
  },
  acceptAssignedBtn: {
    flex: 2,
    borderRadius: 12,
    overflow: 'hidden',
  },
});