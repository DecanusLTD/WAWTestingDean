// app/valeter/wash-history.tsx
import React, { useEffect, useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, SafeAreaView,
  StatusBar, ActivityIndicator, Alert, RefreshControl,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';

type BookingRow = {
  id: string;
  status: string;
  service_type: string;
  service_name: string | null;
  price: number | null;
  location_address: string | null;
  created_at: string;
  updated_at: string | null;
};

const PAGE_SIZE = 25;

export default function ValeterWashHistoryScreen() {
  const { user } = useAuth();

  const [rows, setRows] = useState<BookingRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [page, setPage] = useState(0);
  const [hasMore, setHasMore] = useState(true);

  const [stats, setStats] = useState({
    totalWashes: 0,
    totalEarnings: 0,
  });

  useEffect(() => {
    if (!user) return;
    freshLoad();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  const freshLoad = async () => {
    setLoading(true);
    setPage(0);
    setHasMore(true);
    try {
      const first = await fetchPage(0);
      setRows(first);
      setHasMore(first.length === PAGE_SIZE);
      recomputeStats(first);
    } catch (e) {
      console.error('load error', e);
      Alert.alert('Error', 'Failed to load wash history');
    } finally {
      setLoading(false);
    }
  };

  const fetchPage = async (pageIndex: number) => {
    if (!user) return [];
    const from = pageIndex * PAGE_SIZE;
    const to = from + PAGE_SIZE - 1;

    // Only select columns that exist in your DB
    const { data, error } = await supabase
      .from('bookings')
      .select('id, status, service_type, service_name, price, location_address, created_at, updated_at')
      .eq('valeter_id', user.id)
      .eq('status', 'completed')
      .order('updated_at', { ascending: false, nullsFirst: false })
      .range(from, to);

    if (error) throw error;
    return (data ?? []) as BookingRow[];
  };

  const onRefresh = useCallback(async () => {
    if (!user) return;
    setRefreshing(true);
    try {
      const first = await fetchPage(0);
      setRows(first);
      setPage(0);
      setHasMore(first.length === PAGE_SIZE);
      recomputeStats(first);
    } catch (e) {
      console.error('refresh error', e);
    } finally {
      setRefreshing(false);
    }
  }, [user?.id]);

  const onLoadMore = async () => {
    if (loadingMore || !hasMore) return;
    setLoadingMore(true);
    try {
      const nextPage = page + 1;
      const next = await fetchPage(nextPage);
      setRows(prev => {
        const seen = new Set(prev.map(p => p.id));
        const merged = [...prev];
        next.forEach(r => { if (!seen.has(r.id)) merged.push(r); });
        return merged;
      });
      setPage(nextPage);
      setHasMore(next.length === PAGE_SIZE);
      recomputeStats(); // on merged rows
    } catch (e) {
      console.error('load more error', e);
    } finally {
      setLoadingMore(false);
    }
  };

  const recomputeStats = (known?: BookingRow[]) => {
    const list = known ?? rows;
    const totalWashes = list.length;
    const totalEarnings = list.reduce((sum, r) => sum + (Number(r.price ?? 0) || 0), 0);

    setStats({
      totalWashes,
      totalEarnings,
    });
  };

  const formatDate = (dateLike?: string | null) => {
    const d = dateLike ? new Date(dateLike) : null;
    return (d ?? new Date()).toLocaleString('en-GB', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
    });
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#10B981" />
        <Text style={styles.loadingText}>Loading wash history...</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0A1929" />

      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Text style={styles.backButtonText}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Wash History</Text>
        <View style={styles.placeholder} />
      </View>

      <ScrollView
        style={styles.content}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor="#10B981"
          />
        }
        onMomentumScrollEnd={async (e: any) => {
          const target = e.nativeEvent;
          const bottom = target.contentOffset.y + target.layoutMeasurement.height >= target.contentSize.height - 64;
          if (bottom) await onLoadMore();
        }}
      >
        {rows.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyIcon}>🧽</Text>
            <Text style={styles.emptyTitle}>No Completed Washes</Text>
            <Text style={styles.emptyText}>
              Your completed washes will appear here. Accept jobs from the dashboard to get started!
            </Text>
          </View>
        ) : (
          <>
            {/* Stats Cards */}
            <View style={styles.statsContainer}>
              <View style={styles.statCard}>
                <LinearGradient
                  colors={['#10B981', '#059669']}
                  style={styles.statGradient}
                >
                  <Text style={styles.statIcon}>🧽</Text>
                  <Text style={styles.statNumber}>{stats.totalWashes}</Text>
                  <Text style={styles.statLabel}>Total Washes</Text>
                </LinearGradient>
              </View>

              <View style={styles.statCard}>
                <LinearGradient
                  colors={['#F59E0B', '#D97706']}
                  style={styles.statGradient}
                >
                  <Text style={styles.statIcon}>💰</Text>
                  <Text style={styles.statNumber}>£{stats.totalEarnings.toFixed(0)}</Text>
                  <Text style={styles.statLabel}>Total Earned</Text>
                </LinearGradient>
              </View>
            </View>

            <Text style={styles.sectionTitle}>Completed Jobs</Text>

            {rows.map((b) => (
              <View key={b.id} style={styles.washCard}>
                <LinearGradient
                  colors={['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.04)']}
                  style={styles.washGradient}
                >
                  <View style={styles.washHeader}>
                    <View style={styles.washInfo}>
                      <Text style={styles.washService}>
                        {b.service_name || b.service_type}
                      </Text>
                      <Text style={styles.washDate}>
                        {formatDate(b.updated_at)}
                      </Text>
                    </View>
                    <View style={styles.washPrice}>
                      <Text style={styles.washPriceAmount}>
                        £{Number(b.price ?? 0).toFixed(2)}
                      </Text>
                      <View style={styles.statusBadge}>
                        <Text style={styles.statusText}>✓ Completed</Text>
                      </View>
                    </View>
                  </View>

                  {b.location_address ? (
                    <View style={styles.locationRow}>
                      <Text style={styles.locationIcon}>📍</Text>
                      <Text style={styles.locationText}>{b.location_address}</Text>
                    </View>
                  ) : null}

                  <View style={styles.washFooter}>
                    <Text style={styles.washId}>ID: #{b.id.slice(-8)}</Text>
                  </View>
                </LinearGradient>
              </View>
            ))}

            {hasMore && (
              <View style={styles.loadMoreContainer}>
                {loadingMore ? (
                  <ActivityIndicator color="#10B981" />
                ) : (
                  <TouchableOpacity style={styles.loadMoreBtn} onPress={onLoadMore}>
                    <Text style={styles.loadMoreText}>Load More</Text>
                  </TouchableOpacity>
                )}
              </View>
            )}
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },

  loadingContainer: {
    flex: 1,
    backgroundColor: '#0A1929',
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: '#E5E7EB',
    fontSize: 16,
    marginTop: 16,
  },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backButtonText: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '900',
  },
  placeholder: {
    width: 40,
  },

  content: {
    flex: 1,
    paddingHorizontal: 20,
  },

  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 80,
    paddingHorizontal: 40,
  },
  emptyIcon: {
    fontSize: 64,
    marginBottom: 16,
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '800',
    marginBottom: 8,
    textAlign: 'center',
  },
  emptyText: {
    color: '#E5E7EB',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
  },

  statsContainer: {
    flexDirection: 'row',
    gap: 12,
    marginVertical: 20,
  },
  statCard: {
    flex: 1,
    borderRadius: 16,
    overflow: 'hidden',
  },
  statGradient: {
    padding: 20,
    alignItems: 'center',
  },
  statIcon: {
    fontSize: 32,
    marginBottom: 8,
  },
  statNumber: {
    color: '#fff',
    fontSize: 28,
    fontWeight: '900',
    marginBottom: 4,
  },
  statLabel: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 12,
    fontWeight: '600',
  },

  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 16,
  },

  washCard: {
    marginBottom: 12,
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  washGradient: {
    padding: 16,
  },
  washHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  washInfo: {
    flex: 1,
  },
  washService: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 4,
  },
  washDate: {
    color: '#E5E7EB',
    fontSize: 12,
  },
  washPrice: {
    alignItems: 'flex-end',
  },
  washPriceAmount: {
    color: '#10B981',
    fontSize: 20,
    fontWeight: '900',
    marginBottom: 4,
  },
  statusBadge: {
    backgroundColor: 'rgba(16, 185, 129, 0.15)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  statusText: {
    color: '#10B981',
    fontSize: 11,
    fontWeight: '700',
  },

  locationRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.05)',
  },
  locationIcon: {
    fontSize: 14,
    marginRight: 8,
    marginTop: 2,
  },
  locationText: {
    color: '#E5E7EB',
    fontSize: 13,
    flex: 1,
    lineHeight: 18,
  },

  washFooter: {
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.05)',
  },
  washId: {
    color: '#87CEEB',
    fontSize: 11,
    opacity: 0.7,
  },

  loadMoreContainer: {
    alignItems: 'center',
    marginTop: 8,
    marginBottom: 24,
  },
  loadMoreBtn: {
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.15)',
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 12,
  },
  loadMoreText: {
    color: '#F9FAFB',
    fontWeight: '700',
    fontSize: 14,
  },
});