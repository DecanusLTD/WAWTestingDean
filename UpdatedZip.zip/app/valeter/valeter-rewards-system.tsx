import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Alert,
  Dimensions,
  Image,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { washCompletionService } from '../../src/services/WashCompletionService';

const { width, height } = Dimensions.get('window');
const isSmallScreen = width < 375;
const isMediumScreen = width >= 375 && width < 414;
const isLargeScreen = width >= 414;

export default function ValeterRewardsSystem() {
  const { user } = useAuth();
  const [selectedReward, setSelectedReward] = useState('');

  // Valeter-specific rewards data
  const rewards = [
    {
      id: 'bonus-earnings',
      title: 'Earnings Bonus',
      description: 'Get 10% bonus on your next 5 washes',
      points: 500,
      icon: '💰',
      category: 'earnings',
      available: (user?.tierPoints || 0) >= 500
    },
    {
      id: 'priority-jobs',
      title: 'Priority Job Access',
      description: 'Get first access to premium jobs for 7 days',
      points: 300,
      icon: '⭐',
      category: 'jobs',
      available: (user?.tierPoints || 0) >= 300
    },
    {
      id: 'equipment-upgrade',
      title: 'Equipment Upgrade',
      description: 'Free professional equipment kit upgrade',
      points: 1000,
      icon: '🛠️',
      category: 'equipment',
      available: (user?.tierPoints || 0) >= 1000
    },
    {
      id: 'training-course',
      title: 'Advanced Training',
      description: 'Free advanced valeting techniques course',
      points: 800,
      icon: '📚',
      category: 'training',
      available: (user?.tierPoints || 0) >= 800
    },
    {
      id: 'insurance-discount',
      title: 'Insurance Discount',
      description: '20% off professional liability insurance',
      points: 1200,
      icon: '🛡️',
      category: 'insurance',
      available: (user?.tierPoints || 0) >= 1200
    },
    {
      id: 'marketing-boost',
      title: 'Profile Boost',
      description: 'Featured valeter status for 14 days',
      points: 600,
      icon: '📈',
      category: 'marketing',
      available: (user?.tierPoints || 0) >= 600
    },
    {
      id: 'support-priority',
      title: 'Priority Support',
      description: 'Direct line to valeter support team',
      points: 400,
      icon: '🎯',
      category: 'support',
      available: (user?.tierPoints || 0) >= 400
    },
    {
      id: 'certification',
      title: 'Professional Certification',
      description: 'Official Wish a Wash valeter certification',
      points: 1500,
      icon: '🏆',
      category: 'certification',
      available: (user?.tierPoints || 0) >= 1500
    },
    {
      id: 'vehicle-maintenance',
      title: 'Vehicle Maintenance',
      description: 'Free vehicle maintenance check-up',
      points: 700,
      icon: '🚗',
      category: 'maintenance',
      available: (user?.tierPoints || 0) >= 700
    },
    {
      id: 'networking-event',
      title: 'Networking Event',
      description: 'Access to exclusive valeter networking events',
      points: 900,
      icon: '🤝',
      category: 'networking',
      available: (user?.tierPoints || 0) >= 900
    }
  ];

  const handleRewardSelect = (rewardId: string) => {
    setSelectedReward(rewardId);
    hapticFeedback('light');
  };

  const handleRedeemReward = async () => {
    if (!selectedReward) {
      Alert.alert('No Reward Selected', 'Please select a reward to redeem');
      return;
    }

    const reward = rewards.find(r => r.id === selectedReward);
    if (!reward) return;

    if (!reward.available) {
      Alert.alert('Insufficient Points', `You need ${reward.points} points to redeem this reward`);
      return;
    }

    Alert.alert(
      'Redeem Reward',
      `Are you sure you want to redeem "${reward.title}" for ${reward.points} points?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Redeem',
          onPress: () => {
            // Here you would typically call an API to redeem the reward
            Alert.alert(
              'Reward Redeemed!',
              `Congratulations! You've successfully redeemed "${reward.title}". Check your email for redemption details.`,
              [{ text: 'OK', onPress: () => setSelectedReward('') }]
            );
          }
        }
      ]
    );
  };

  const getValeterStats = async () => {
    if (!user) return { totalWashes: 0, averageRating: 0, totalTips: 0 };
    
    try {
      const completions = await washCompletionService.getValeterWashCompletions(user.id);
      const totalTips = await washCompletionService.getValeterTotalTips(user.id);
      const averageRating = await washCompletionService.getValeterAverageRating(user.id);
      
      return {
        totalWashes: completions.length,
        averageRating,
        totalTips
      };
    } catch (error) {
      return { totalWashes: 0, averageRating: 0, totalTips: 0 };
    }
  };

  const [stats, setStats] = useState({ totalWashes: 0, averageRating: 0, totalTips: 0 });

  React.useEffect(() => {
    getValeterStats().then(setStats);
  }, []);

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#0A1929', '#1E3A8A']}
        style={StyleSheet.absoluteFill}
      />

      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Text style={styles.backButtonText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Valeter Rewards</Text>
        <View style={styles.placeholder} />
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Stats Section */}
        <View style={styles.statsContainer}>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{user?.tierPoints || 0}</Text>
            <Text style={styles.statLabel}>Reward Points</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{stats.totalWashes}</Text>
            <Text style={styles.statLabel}>Washes</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{stats.averageRating.toFixed(1)}</Text>
            <Text style={styles.statLabel}>Avg Rating</Text>
          </View>
        </View>

        {/* Tier Info */}
        <View style={styles.tierContainer}>
          <Text style={styles.tierTitle}>Professional Tier: {user?.tier || 'Bronze'}</Text>
          <Text style={styles.tierDescription}>
            Earn points for every completed wash, positive rating, and tip received
          </Text>
          <View style={styles.progressBar}>
            <View 
              style={[
                styles.progressFill, 
                { width: `${Math.min((user?.tierPoints || 0) / 1000 * 100, 100)}%` }
              ]} 
            />
          </View>
          <Text style={styles.progressText}>
            {user?.tierPoints || 0} / 1000 points to next tier
          </Text>
        </View>

        {/* Rewards Grid */}
        <Text style={styles.sectionTitle}>Available Rewards</Text>
        
        <View style={styles.rewardsGrid}>
          {rewards.map((reward) => (
            <TouchableOpacity
              key={reward.id}
              style={[
                styles.rewardCard,
                selectedReward === reward.id && styles.selectedRewardCard,
                !reward.available && styles.unavailableRewardCard
              ]}
              onPress={() => handleRewardSelect(reward.id)}
              disabled={!reward.available}
            >
              <Text style={styles.rewardIcon}>{reward.icon}</Text>
              <Text style={styles.rewardTitle}>{reward.title}</Text>
              <Text style={styles.rewardDescription}>{reward.description}</Text>
              <View style={styles.rewardPoints}>
                <Text style={styles.pointsText}>{reward.points} points</Text>
              </View>
              {!reward.available && (
                <View style={styles.unavailableOverlay}>
                  <Text style={styles.unavailableText}>Need {reward.points} points</Text>
                </View>
              )}
            </TouchableOpacity>
          ))}
        </View>

        {/* Redeem Button */}
        {selectedReward && (
          <TouchableOpacity
            style={styles.redeemButton}
            onPress={handleRedeemReward}
          >
            <Text style={styles.redeemButtonText}>
              Redeem Selected Reward
            </Text>
          </TouchableOpacity>
        )}

        {/* How to Earn */}
        <View style={styles.earnSection}>
          <Text style={styles.earnTitle}>How to Earn Points</Text>
          <View style={styles.earnItem}>
            <Text style={styles.earnIcon}>🚗</Text>
            <Text style={styles.earnText}>Complete a wash: 50 points</Text>
          </View>
          <View style={styles.earnItem}>
            <Text style={styles.earnIcon}>⭐</Text>
            <Text style={styles.earnText}>5-star rating: 25 points</Text>
          </View>
          <View style={styles.earnItem}>
            <Text style={styles.earnIcon}>💰</Text>
            <Text style={styles.earnText}>Receive a tip: 10 points per £1</Text>
          </View>
          <View style={styles.earnItem}>
            <Text style={styles.earnIcon}>📝</Text>
            <Text style={styles.earnText}>Customer review: 15 points</Text>
          </View>
          <View style={styles.earnItem}>
            <Text style={styles.earnIcon}>🎯</Text>
            <Text style={styles.earnText}>Weekly goal achieved: 100 points</Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderBottomColor: 'rgba(255, 255, 255, 0.2)',
    borderBottomWidth: 1,
  },
  backButton: {
    paddingVertical: 8,
    paddingHorizontal: 12,
  },
  backButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  headerTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  placeholder: {
    width: 60,
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 20,
  },
  statCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    flex: 1,
    marginHorizontal: 4,
  },
  statNumber: {
    color: '#FFFFFF',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  statLabel: {
    color: '#87CEEB',
    fontSize: 12,
  },
  tierContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 20,
    marginBottom: 20,
  },
  tierTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  tierDescription: {
    color: '#87CEEB',
    fontSize: 14,
    marginBottom: 16,
  },
  progressBar: {
    height: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 4,
    marginBottom: 8,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#4CAF50',
    borderRadius: 4,
  },
  progressText: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
  },
  sectionTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
    marginVertical: 20,
  },
  rewardsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  rewardCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    width: '48%',
    marginBottom: 16,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'transparent',
  },
  selectedRewardCard: {
    borderColor: '#4CAF50',
    backgroundColor: 'rgba(76, 175, 80, 0.2)',
  },
  unavailableRewardCard: {
    opacity: 0.5,
  },
  rewardIcon: {
    fontSize: 32,
    marginBottom: 8,
  },
  rewardTitle: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 4,
  },
  rewardDescription: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
    marginBottom: 8,
  },
  rewardPoints: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  pointsText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '600',
  },
  unavailableOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  unavailableText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '600',
    textAlign: 'center',
  },
  redeemButton: {
    backgroundColor: '#4CAF50',
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 24,
    alignItems: 'center',
    marginVertical: 20,
  },
  redeemButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  earnSection: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 20,
    marginVertical: 20,
  },
  earnTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  earnItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  earnIcon: {
    fontSize: 20,
    marginRight: 12,
  },
  earnText: {
    color: '#FFFFFF',
    fontSize: 16,
  },
});
