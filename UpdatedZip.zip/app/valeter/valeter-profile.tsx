import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Alert,
  Image,
  TextInput,
  Modal,
  Dimensions,
  ActivityIndicator,
} from 'react-native';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { ValeterStatsService, ValeterPerformanceStats } from '../../src/services/Valeterstatsservice';
import { ValeterTierService, ValeterTier } from '../../src/services/ValeterTierService';
import * as ImagePicker from 'expo-image-picker';
import { supabase } from '../../src/lib/supabase';

const { width, height } = Dimensions.get('window');
const isSmallScreen = width < 375;
const isMediumScreen = width >= 375 && width < 414;
const isLargeScreen = width >= 414;

interface ValeterDocument {
  id: string;
  type: 'id_proof' | 'selfie' | 'profile_photo' | 'disclaimer_signed';
  name: string;
  description: string;
  status: 'pending' | 'approved' | 'rejected' | 'not_uploaded';
  file_url?: string;
  uploaded_at?: string;
  approved_at?: string;
  rejection_reason?: string;
}

interface ValeterProfileData {
  user_id: string;
  full_name: string;
  bio?: string;
  experience?: string;
  profile_photo_url?: string;
  vehicle_make?: string;
  vehicle_model?: string;
  vehicle_registration?: string;
  verification_status: 'pending' | 'verified' | 'rejected';
  verification_badge: boolean;
}

export default function ValeterProfile() {
  const router = useRouter();
  const { user, logout } = useAuth();
  const [profile, setProfile] = useState<ValeterProfileData | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [showDocumentModal, setShowDocumentModal] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState<ValeterDocument | null>(null);
  const [profilePicture, setProfilePicture] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [statsLoading, setStatsLoading] = useState(true);
  const [uploadingDocument, setUploadingDocument] = useState(false);

  const [valeterStats, setValeterStats] = useState<ValeterPerformanceStats>({
    totalJobs: 0,
    experienceMonths: 1,
    averageRating: 0,
    totalEarnings: 0,
    jobsThisMonth: 0,
    customerReviews: 0,
    onTimePercentage: 100,
    cancellationRate: 0
  });
  const [currentTier, setCurrentTier] = useState<ValeterTier | null>(null);
  const [documents, setDocuments] = useState<ValeterDocument[]>([]);
  const [isOrganizationMember, setIsOrganizationMember] = useState(false);
  const [organizationName, setOrganizationName] = useState<string | undefined>();

  // Fetch real stats data
  useEffect(() => {
    const fetchStats = async () => {
      if (user) {
        try {
          setStatsLoading(true);
          const stats = await ValeterStatsService.getValeterStats(user.id);
          setValeterStats(stats);

          // Calculate current tier based on stats
          const tier = ValeterTierService.calculateTier(stats);
          setCurrentTier(tier);
        } catch (error) {
          console.error('Error fetching valeter stats:', error);
        } finally {
          setStatsLoading(false);
        }
      }
    };

    fetchStats();
  }, [user]);

  // Fetch profile and documents from Supabase
  useEffect(() => {
    if (user?.id) {
      loadProfile();
      loadDocuments();
    }
  }, [user?.id]);

  const loadProfile = async () => {
    try {
      setIsLoading(true);

      // Fetch from valeter_profiles table
      const { data, error } = await supabase
        .from('valeter_profiles')
        .select('*')
        .eq('user_id', user!.id)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') {
        throw error;
      }

      if (data) {
        setProfile(data);
        setProfilePicture(data.profile_photo_url || null);
      } else {
        // Create default profile if doesn't exist
        const newProfile: Partial<ValeterProfileData> = {
          user_id: user!.id,
          full_name: user!.name || 'Valeter',
          bio: 'Professional mobile valeter',
          experience: '0 years',
          verification_status: 'pending',
          verification_badge: false,
        };

        const { data: created, error: createError } = await supabase
          .from('valeter_profiles')
          .insert(newProfile)
          .select()
          .single();

        if (createError) throw createError;
        setProfile(created);
      }
    } catch (error) {
      console.error('Error loading profile:', error);
      Alert.alert('Error', 'Failed to load profile');
    } finally {
      setIsLoading(false);
    }
  };

  const loadDocuments = async () => {
    try {
      const { data, error } = await supabase
        .from('valeter_documents')
        .select('*')
        .eq('user_id', user!.id);

      if (error) throw error;

      if (data && data.length > 0) {
        setDocuments(data);
      } else {
        // Initialize with required documents
        const requiredDocs: Partial<ValeterDocument>[] = [
          {
            user_id: user!.id,
            type: 'id_proof',
            name: 'Proof of Identity',
            description: 'Valid government-issued ID (passport, driving license, or national ID)',
            status: 'not_uploaded',
          },
          {
            user_id: user!.id,
            type: 'selfie',
            name: 'Selfie Photo',
            description: 'Clear selfie for identity verification',
            status: 'not_uploaded',
          },
          {
            user_id: user!.id,
            type: 'profile_photo',
            name: 'Profile Photo',
            description: 'Professional headshot for customer trust',
            status: 'not_uploaded',
          },
          {
            user_id: user!.id,
            type: 'disclaimer_signed',
            name: 'Terms & Conditions',
            description: 'Signed agreement to Wish a Wash terms and conditions',
            status: 'not_uploaded',
          },
        ];

        const { data: created, error: createError } = await supabase
          .from('valeter_documents')
          .insert(requiredDocs)
          .select();

        if (createError) throw createError;
        setDocuments(created || []);
      }
    } catch (error) {
      console.error('Error loading documents:', error);
    }
  };

  const handleSaveProfile = async () => {
    if (!profile || !user) return;

    try {
      setIsSaving(true);
      await hapticFeedback('medium');

      const { error } = await supabase
        .from('valeter_profiles')
        .update({
          full_name: profile.full_name,
          bio: profile.bio,
          experience: profile.experience,
          vehicle_make: profile.vehicle_make,
          vehicle_model: profile.vehicle_model,
          vehicle_registration: profile.vehicle_registration,
        })
        .eq('user_id', user.id);

      if (error) throw error;

      setIsEditing(false);
      Alert.alert('Success', 'Profile updated successfully!');
    } catch (error) {
      console.error('Error saving profile:', error);
      Alert.alert('Error', 'Failed to save profile');
    } finally {
      setIsSaving(false);
    }
  };

  const BUCKET = 'valeter_documents';

  async function uploadUriToSupabase(
    uri: string,
    path: string,
    contentType = 'image/jpeg'
  ) {
    const file = {
      uri,
      name: path.split('/').pop() || 'upload.jpg',
      type: contentType,
    } as any;

    const { data, error } = await supabase
      .storage
      .from(BUCKET)
      .upload(path, file, {
        contentType,
        upsert: false,
      });

    if (error) throw error;

    const { data: pub } = supabase.storage.from(BUCKET).getPublicUrl(path);
    const publicUrl = pub?.publicUrl ?? null;

    return { path: data?.path ?? path, publicUrl };
  }

  function extFromMime(m?: string | null) {
    if (!m) return 'jpg';
    if (m.includes('png')) return 'png';
    if (m.includes('heic')) return 'heic';
    if (m.includes('webp')) return 'webp';
    if (m.includes('jpeg')) return 'jpg';
    return 'jpg';
  }

  const handleLogout = async () => {
    try {
      await hapticFeedback('medium');
      Alert.alert(
        'Logout',
        'Are you sure you want to logout?',
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Logout',
            style: 'destructive',
            onPress: async () => {
              try {
                await logout();
                router.replace('/');
              } catch (error) {
                console.error('Logout error:', error);
                Alert.alert('Logout Error', 'Failed to logout. Please try again.');
              }
            }
          }
        ]
      );
    } catch (error) {
      console.log('Haptic feedback not available');
    }
  };

  const handleDeleteAccount = async () => {
    try {
      await hapticFeedback('heavy');
      Alert.alert(
        'Delete Account',
        'This action cannot be undone. Are you sure you want to delete your account?',
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Delete',
            style: 'destructive',
            onPress: () => {
              // TODO: Implement account deletion
              Alert.alert('Account Deleted', 'Your account has been deleted.');
            }
          }
        ]
      );
    } catch (error) {
      console.log('Haptic feedback not available');
    }
  };

  const handleUploadProfilePicture = async () => {
    try {
      await hapticFeedback('light');

      Alert.alert(
        'Upload Profile Picture',
        'Choose how you want to add your profile picture:',
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: '📸 Take Photo',
            onPress: () => takePhoto()
          },
          {
            text: '🖼️ Choose from Gallery',
            onPress: () => pickImage()
          }
        ]
      );
    } catch (error) {
      console.log('Haptic feedback not available');
    }
  };

  const takePhoto = async () => {
    try {
      setIsLoading(true);

      const { status } = await ImagePicker.requestCameraPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission Required', 'Camera permission is required to take a photo.');
        return;
      }

      const result = await ImagePicker.launchCameraAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]) {
        await uploadProfilePhoto(result.assets[0].uri);
      }
    } catch (error) {
      console.error('Error taking photo:', error);
      Alert.alert('Error', 'Failed to take photo. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const pickImage = async () => {
    try {
      setIsLoading(true);

      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission Required', 'Gallery permission is required to select a photo.');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]) {
        await uploadProfilePhoto(result.assets[0].uri);
      }
    } catch (error) {
      console.error('Error picking image:', error);
      Alert.alert('Error', 'Failed to select image. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const uploadProfilePhoto = async (uri: string) => {
    try {
      const ext = uri.split('.').pop() || 'jpg';
      const fileName = `profile_${user!.id}_${Date.now()}.${ext}`;
      const storagePath = `profiles/${user!.id}/${fileName}`;

      const { publicUrl } = await uploadUriToSupabase(uri, storagePath, `image/${ext}`);

      // Update profile in database
      const { error } = await supabase
        .from('valeter_profiles')
        .update({ profile_photo_url: publicUrl })
        .eq('user_id', user!.id);

      if (error) throw error;

      setProfilePicture(publicUrl);
      setProfile(prev => prev ? { ...prev, profile_photo_url: publicUrl } : null);

      await hapticFeedback('medium');
      Alert.alert('Success', 'Profile picture uploaded successfully!');
    } catch (error: any) {
      console.error('Error uploading profile photo:', error);
      Alert.alert('Upload Failed', error?.message || 'Please try again.');
    }
  };

  const handleUploadDocument = async (document: ValeterDocument) => {
    try {
      await hapticFeedback('light');
      setSelectedDocument(document);
      setShowDocumentModal(true);
    } catch (error) {
      console.log('Haptic feedback not available');
    }
  };

 const chooseAndUploadDocument = async (source: 'camera' | 'gallery') => {
   if (!selectedDocument || !user) return;

   try {
     setUploadingDocument(true);

     console.log('=== DEBUG START ===');
     console.log('User:', user?.id);
     console.log('Selected document:', selectedDocument?.id);
     console.log('Selected document type:', selectedDocument?.type);

     // Check permissions
     let permStatus = { status: 'granted' as const };
     if (source === 'camera') {
       permStatus = await ImagePicker.requestCameraPermissionsAsync();
     } else {
       permStatus = await ImagePicker.requestMediaLibraryPermissionsAsync();
     }

     if (permStatus.status !== 'granted') {
       Alert.alert('Permission Required', 'Permission is required to continue.');
       return;
     }

     console.log('=== PERMISSIONS OK ===');

     const pickerFn = source === 'camera'
       ? ImagePicker.launchCameraAsync
       : ImagePicker.launchImageLibraryAsync;

     const result = await pickerFn({
       mediaTypes: ImagePicker.MediaTypeOptions.Images,
       allowsEditing: true,
       aspect: [4, 3],
       quality: 0.9,
     });

     if (result.canceled || !result.assets?.[0]) return;

     console.log('=== IMAGE PICKED ===');

     const asset = result.assets[0];
     const contentType = (asset as any).mimeType ?? 'image/jpeg';
     const ext = extFromMime((asset as any).mimeType);
     const fileName = `${selectedDocument.type}_${Date.now()}.${ext}`;
     const storagePath = `documents/${user.id}/${selectedDocument.type}/${fileName}`;

     console.log('=== ABOUT TO UPLOAD TO STORAGE ===');
     console.log('Storage path:', storagePath);

     // Upload to Supabase Storage
     const { publicUrl } = await uploadUriToSupabase(asset.uri, storagePath, contentType);

     console.log('=== STORAGE UPLOAD SUCCESS ===');
     console.log('Public URL:', publicUrl);

     console.log('=== ABOUT TO UPDATE DATABASE ===');
     console.log('Updating document ID:', selectedDocument.id);

     // Update document in database
     const { data, error } = await supabase
       .from('valeter_documents')
       .update({
         file_url: publicUrl,
         status: 'pending',
         uploaded_at: new Date().toISOString(),
       })
       .eq('id', selectedDocument.id)
       .select(); // Add select to see what gets returned

     console.log('=== DATABASE UPDATE RESULT ===');
     console.log('Data:', data);
     console.log('Error:', error);

     if (error) {
       console.log('=== ERROR DETAILS ===');
       console.log('Error code:', error.code);
       console.log('Error message:', error.message);
       console.log('Error details:', error.details);
       console.log('Error hint:', error.hint);
       throw error;
     }

     console.log('=== SUCCESS - RELOADING DOCUMENTS ===');
     await loadDocuments();

     // ... rest of success code

   } catch (e: any) {
     console.log('=== CAUGHT ERROR ===');
     console.log('Error type:', typeof e);
     console.log('Error message:', e?.message);
     console.log('Error code:', e?.code);
     console.log('Full error object:', JSON.stringify(e, null, 2));
     Alert.alert('Upload Failed', e?.message ?? 'Please try again.');
   } finally {
     setUploadingDocument(false);
   }
 };

  const getVerificationProgress = () => {
    const total = documents.length;
    const completed = documents.filter(doc => doc.status === 'approved').length;
    const percentage = total > 0 ? Math.round((completed / total) * 100) : 0;
    const missing = documents
      .filter(doc => doc.status !== 'approved')
      .map(doc => doc.name);

    return { total, completed, percentage, missing };
  };

  const getComplianceStatus = () => {
    const issues: string[] = [];
    const recommendations: string[] = [];

    const missingDocs = documents.filter(d => d.status !== 'approved');
    if (missingDocs.length > 0) {
      issues.push(`${missingDocs.length} document(s) need attention`);
      recommendations.push('Upload all required documents for verification');
    }

    if (!profile?.profile_photo_url) {
      issues.push('Profile photo required');
      recommendations.push('Upload a clear profile photo');
    }

    return {
      compliant: issues.length === 0,
      issues,
      recommendations
    };
  };

  if (isLoading) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient
          colors={['#0A1929', '#1E3A8A']}
          style={StyleSheet.absoluteFill}
        />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#87CEEB" />
          <Text style={styles.loadingText}>Loading profile...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!profile) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient
          colors={['#0A1929', '#1E3A8A']}
          style={StyleSheet.absoluteFill}
        />
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Failed to load profile</Text>
        </View>
      </SafeAreaView>
    );
  }

  const progress = getVerificationProgress();
  const compliance = getComplianceStatus();

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#0A1929', '#1E3A8A']}
        style={StyleSheet.absoluteFill}
      />

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              router.back();
            }}
            style={styles.backButton}
          >
            <Text style={styles.backButtonText}>←</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Valeter Profile</Text>
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              setIsEditing(!isEditing);
            }}
            style={styles.editButton}
          >
            <Text style={styles.editButtonText}>{isEditing ? 'Cancel' : 'Edit'}</Text>
          </TouchableOpacity>
        </View>

        {/* Profile Hero Section */}
        <View style={styles.heroSection}>
          <View style={styles.profilePictureContainer}>
            {profilePicture ? (
              <View style={styles.profilePicture}>
                <Image source={{ uri: profilePicture }} style={styles.profileImage} />
                {profile.verification_badge && (
                  <View style={styles.verificationBadge}>
                    <Text style={styles.verificationIcon}>✓</Text>
                  </View>
                )}
              </View>
            ) : (
              <View style={styles.profilePicturePlaceholder}>
                <Text style={styles.profilePictureText}>👤</Text>
                {profile.verification_badge && (
                  <View style={styles.verificationBadge}>
                    <Text style={styles.verificationIcon}>✓</Text>
                  </View>
                )}
              </View>
            )}
            <TouchableOpacity
              style={[styles.uploadButton, isLoading && styles.uploadButtonDisabled]}
              onPress={handleUploadProfilePicture}
              disabled={isLoading}
            >
              <Text style={styles.uploadButtonText}>
                {isLoading ? '⏳' : '📷'}
              </Text>
            </TouchableOpacity>
          </View>

          <View style={styles.profileInfo}>
            <View style={styles.nameRow}>
              <Text style={styles.userName}>{profile.full_name || 'Valeter Name'}</Text>
              {profile.verification_badge && (
                <View style={styles.verificationBadgeSmall}>
                  <Text style={styles.verificationIconSmall}>✓</Text>
                </View>
              )}
            </View>
            <Text style={styles.userEmail}>{user?.email || 'valeter@example.com'}</Text>
            {profile.experience && (
              <Text style={styles.userExperience}>{profile.experience} experience</Text>
            )}
          </View>
        </View>

        {/* Tier & Stats Section */}
        {currentTier && (
          <View style={styles.tierSection}>
            <LinearGradient
              colors={[currentTier.color, currentTier.color + '80']}
              style={styles.tierCard}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
            >
              <View style={styles.tierContent}>
                <Text style={styles.tierIcon}>{currentTier.icon}</Text>
                <View style={styles.tierInfo}>
                  <Text style={styles.tierText}>{currentTier.name} Valeter</Text>
                  <Text style={styles.tierStats}>
                    {valeterStats.totalJobs} jobs • {valeterStats.experienceMonths} months • ⭐ {valeterStats.averageRating}
                  </Text>
                  {currentTier.nextTierProgress > 0 && (
                    <View style={styles.progressToNext}>
                      <Text style={styles.progressText}>
                        {currentTier.nextTierProgress}% to next tier
                      </Text>
                      <View style={styles.progressBar}>
                        <View
                          style={[
                            styles.progressFill,
                            { width: `${currentTier.nextTierProgress}%` }
                          ]}
                        />
                      </View>
                    </View>
                  )}
                </View>
              </View>
            </LinearGradient>

            <View style={styles.tierBenefits}>
              <Text style={styles.benefitsTitle}>🎁 {currentTier.name} Benefits:</Text>
              {currentTier.benefits.map((benefit, index) => (
                <Text key={index} style={styles.benefitText}>• {benefit}</Text>
              ))}
            </View>
          </View>
        )}

        {/* Valeter Stats Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Performance Stats</Text>
          {statsLoading ? (
            <View style={styles.statsLoadingContainer}>
              <ActivityIndicator size="small" color="#87CEEB" />
              <Text style={styles.statsLoadingText}>Loading stats...</Text>
            </View>
          ) : (
            <View style={styles.statsGrid}>
              <View style={styles.statCard}>
                <Text style={styles.statNumber}>{valeterStats.totalJobs}</Text>
                <Text style={styles.statLabel}>Total Jobs</Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statNumber}>£{valeterStats.totalEarnings}</Text>
                <Text style={styles.statLabel}>Total Earnings</Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statNumber}>{valeterStats.jobsThisMonth}</Text>
                <Text style={styles.statLabel}>This Month</Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statNumber}>{valeterStats.customerReviews}</Text>
                <Text style={styles.statLabel}>Reviews</Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statNumber}>{valeterStats.onTimePercentage}%</Text>
                <Text style={styles.statLabel}>On Time</Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statNumber}>{valeterStats.cancellationRate}%</Text>
                <Text style={styles.statLabel}>Cancellation</Text>
              </View>
            </View>
          )}
        </View>

        {/* Verification Progress */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Verification Progress</Text>
          <View style={styles.verificationCard}>
            <View style={styles.progressHeader}>
              <Text style={styles.progressText}>
                {progress.completed} of {progress.total} completed
              </Text>
              <Text style={styles.progressPercentage}>{progress.percentage}%</Text>
            </View>
            <View style={styles.progressBar}>
              <View
                style={[
                  styles.progressFill,
                  { width: `${progress.percentage}%` }
                ]}
              />
            </View>
            {progress.missing.length > 0 && (
              <Text style={styles.missingText}>
                Pending: {progress.missing.join(', ')}
              </Text>
            )}
          </View>
        </View>

        {/* Personal Information */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Personal Information</Text>
          <View style={styles.settingsContainer}>
            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Text style={styles.settingIcon}>👤</Text>
                <Text style={styles.settingText}>Name</Text>
              </View>
              {isEditing ? (
                <TextInput
                  style={styles.settingInput}
                  value={profile.full_name}
                  onChangeText={(text) => setProfile({ ...profile, full_name: text })}
                  placeholder="Enter your name"
                  placeholderTextColor="#87CEEB"
                />
              ) : (
                <Text style={styles.settingValue}>{profile.full_name}</Text>
              )}
            </View>

            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Text style={styles.settingIcon}>📝</Text>
                <Text style={styles.settingText}>Bio</Text>
              </View>
              {isEditing ? (
                <TextInput
                  style={[styles.settingInput, styles.bioInput]}
                  value={profile.bio || ''}
                  onChangeText={(text) => setProfile({ ...profile, bio: text })}
                  placeholder="Tell customers about yourself"
                  placeholderTextColor="#87CEEB"
                  multiline
                />
              ) : (
                <Text style={styles.settingValue}>{profile.bio || 'No bio added'}</Text>
              )}
            </View>

            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Text style={styles.settingIcon}>⏱️</Text>
                <Text style={styles.settingText}>Experience</Text>
              </View>
              {isEditing ? (
                <TextInput
                  style={styles.settingInput}
                  value={profile.experience || ''}
                  onChangeText={(text) => setProfile({ ...profile, experience: text })}
                  placeholder="e.g., 3+ years"
                  placeholderTextColor="#87CEEB"
                />
              ) : (
                <Text style={styles.settingValue}>{profile.experience || 'Not specified'}</Text>
              )}
            </View>
          </View>
        </View>

        {/* Vehicle Information */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Vehicle Information</Text>
          <View style={styles.settingsContainer}>
            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Text style={styles.settingIcon}>🚗</Text>
                <Text style={styles.settingText}>Make</Text>
              </View>
              {isEditing ? (
                <TextInput
                  style={styles.settingInput}
                  value={profile.vehicle_make || ''}
                  onChangeText={(text) => setProfile({ ...profile, vehicle_make: text })}
                  placeholder="e.g., Ford"
                  placeholderTextColor="#87CEEB"
                />
              ) : (
                <Text style={styles.settingValue}>{profile.vehicle_make || 'Not set'}</Text>
              )}
            </View>

            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Text style={styles.settingIcon}>🚙</Text>
                <Text style={styles.settingText}>Model</Text>
              </View>
              {isEditing ? (
                <TextInput
                  style={styles.settingInput}
                  value={profile.vehicle_model || ''}
                  onChangeText={(text) => setProfile({ ...profile, vehicle_model: text })}
                  placeholder="e.g., Transit"
                  placeholderTextColor="#87CEEB"
                />
              ) : (
                <Text style={styles.settingValue}>{profile.vehicle_model || 'Not set'}</Text>
              )}
            </View>

            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Text style={styles.settingIcon}>🔢</Text>
                <Text style={styles.settingText}>Registration</Text>
              </View>
              {isEditing ? (
                <TextInput
                  style={styles.settingInput}
                  value={profile.vehicle_registration || ''}
                  onChangeText={(text) => setProfile({ ...profile, vehicle_registration: text })}
                  placeholder="e.g., AB12 CDE"
                  placeholderTextColor="#87CEEB"
                />
              ) : (
                <Text style={styles.settingValue}>{profile.vehicle_registration || 'Not set'}</Text>
              )}
            </View>
          </View>
        </View>

       {/* Required Documents */}
       <View style={styles.section}>
         <Text style={styles.sectionTitle}>Required Documents</Text>
         <View style={styles.settingsContainer}>
           {documents.map((document) => (
             <TouchableOpacity
               key={document.id}
               style={styles.settingItem}
               onPress={() => handleUploadDocument(document)}
             >
               <View style={styles.settingLeft}>
                 <Text style={styles.settingIcon}>📄</Text>
                 <View style={styles.documentInfo}>
                   <Text style={styles.settingText}>{document.name}</Text>
                   <Text style={styles.documentDescription}>{document.description}</Text>
                 </View>
               </View>
               <View
                 style={[
                   styles.documentStatus,
                   {
                     backgroundColor:
                       document.status === 'approved'
                         ? '#4CAF50'
                         : document.status === 'pending'
                         ? '#FF9800'
                         : document.status === 'rejected'
                         ? '#EF4444'
                         : '#666',
                   },
                 ]}
               >
                 <Text style={styles.documentStatusText}>
                   {document.status === 'approved'
                     ? '✓'
                     : document.status === 'pending'
                     ? '⏳'
                     : document.status === 'rejected'
                     ? '✗'
                     : '📄'}
                 </Text>
               </View>
             </TouchableOpacity>
           ))}
         </View>
       </View>

        {/* Legal Compliance */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Legal Compliance</Text>
          <View style={[
            styles.complianceCard,
            { backgroundColor: compliance.compliant ? 'rgba(76, 175, 80, 0.1)' : 'rgba(239, 68, 68, 0.1)' }
          ]}>
            <View style={styles.complianceHeader}>
              <Text style={styles.complianceIcon}>
                {compliance.compliant ? '✅' : '⚠️'}
              </Text>
              <Text style={styles.complianceTitle}>
                {compliance.compliant ? 'Fully Compliant' : 'Action Required'}
              </Text>
            </View>

            {compliance.issues.length > 0 && (
              <View style={styles.complianceIssues}>
                <Text style={styles.complianceSubtitle}>Issues to resolve:</Text>
                {compliance.issues.map((issue, index) => (
                  <Text key={index} style={styles.complianceIssue}>• {issue}</Text>
                ))}
              </View>
            )}

            {compliance.recommendations.length > 0 && (
              <View style={styles.complianceRecommendations}>
                <Text style={styles.complianceSubtitle}>Recommendations:</Text>
                {compliance.recommendations.map((rec, index) => (
                  <Text key={index} style={styles.complianceRecommendation}>• {rec}</Text>
                ))}
              </View>
            )}
          </View>
        </View>

        {/* Save Button */}
        {isEditing && (
          <View style={styles.section}>
            <TouchableOpacity
              style={[styles.saveButton, isSaving && { opacity: 0.6 }]}
              onPress={handleSaveProfile}
              disabled={isSaving}
            >
              {isSaving ? (
                <ActivityIndicator color="#FFFFFF" />
              ) : (
                <Text style={styles.saveButtonText}>Save Changes</Text>
              )}
            </TouchableOpacity>
          </View>
        )}

        {/* Account Settings */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Account Settings</Text>

          <View style={styles.settingsContainer}>
            <TouchableOpacity
              style={styles.settingItem}
              onPress={async () => {
                await hapticFeedback('light');
                router.push('/organization-dashboard');
              }}
            >
              <View style={styles.settingLeft}>
                <Text style={styles.settingIcon}>🏢</Text>
                <Text style={styles.settingText}>Organizations</Text>
              </View>
              <Text style={styles.settingArrow}>›</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.settingItem}
              onPress={async () => {
                await hapticFeedback('light');
                router.push('/privacy-settings');
              }}
            >
              <View style={styles.settingLeft}>
                <Text style={styles.settingIcon}>⚙️</Text>
                <Text style={styles.settingText}>Privacy & Security</Text>
              </View>
              <Text style={styles.settingArrow}>›</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Account Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Account Actions</Text>

          <TouchableOpacity style={[styles.settingItem, styles.logoutItem]} onPress={handleLogout}>
            <View style={styles.settingLeft}>
              <Text style={styles.settingIcon}>🚪</Text>
              <Text style={[styles.settingText, styles.logoutText]}>Logout</Text>
            </View>
            <Text style={styles.settingArrow}>›</Text>
          </TouchableOpacity>

          <TouchableOpacity style={[styles.settingItem, styles.deleteItem]} onPress={handleDeleteAccount}>
            <View style={styles.settingLeft}>
              <Text style={styles.settingIcon}>🗑️</Text>
              <Text style={[styles.settingText, styles.deleteText]}>Delete Account</Text>
            </View>
            <Text style={styles.settingArrow}>›</Text>
          </TouchableOpacity>
        </View>

        {/* App Info */}
        <View style={styles.appInfoSection}>
          <Text style={styles.appInfoText}>Wish a Wash v1.0.0</Text>
          <Text style={styles.appInfoText}>© 2024 Wish a Wash. All rights reserved.</Text>
        </View>
      </ScrollView>

      {/* Document Upload Modal */}
      <Modal
        visible={showDocumentModal}
        transparent={true}
        animationType="slide"
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Upload {selectedDocument?.name}</Text>
            <Text style={styles.modalDescription}>{selectedDocument?.description}</Text>

          <View style={styles.modalActions}>
            <TouchableOpacity
              style={[styles.modalButton, uploadingDocument && { opacity: 0.6 }]}
              disabled={uploadingDocument}
              onPress={() => chooseAndUploadDocument('camera')}
            >
              <Text style={styles.modalButtonText}>
                {uploadingDocument ? 'Uploading…' : '📸 Take Photo'}
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.modalButton, uploadingDocument && { opacity: 0.6 }]}
              disabled={uploadingDocument}
              onPress={() => chooseAndUploadDocument('gallery')}
            >
              <Text style={styles.modalButtonText}>
                {uploadingDocument ? 'Uploading…' : '🖼️ Choose from Gallery'}
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.modalButton, styles.modalButtonCancel]}
              onPress={() => setShowDocumentModal(false)}
              disabled={uploadingDocument}
            >
              <Text style={styles.modalButtonText}>Cancel</Text>
            </TouchableOpacity>
          </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: isSmallScreen ? 16 : 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backButtonText: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : 22,
    fontWeight: 'bold',
  },
  editButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: 'rgba(135, 206, 235, 0.2)',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(135, 206, 235, 0.3)',
  },
  editButtonText: {
    color: '#87CEEB',
    fontSize: 14,
    fontWeight: '600',
  },
  heroSection: {
    padding: isSmallScreen ? 20 : 24,
    alignItems: 'center',
    marginBottom: 0,
  },
  profilePictureContainer: {
    alignItems: 'center',
    marginBottom: 20,
    position: 'relative',
  },
  profilePicture: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    borderWidth: 3,
    borderColor: 'rgba(135, 206, 235, 0.3)',
  },
  profilePicturePlaceholder: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    borderWidth: 3,
    borderColor: 'rgba(135, 206, 235, 0.3)',
  },
  profilePictureText: {
    fontSize: 48,
  },
  profileImage: {
    width: '100%',
    height: '100%',
    borderRadius: 60,
  },
  uploadButton: {
    position: 'absolute',
    bottom: 12,
    right: 0,
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#87CEEB',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#0A1929',
  },
  uploadButtonDisabled: {
    opacity: 0.7,
    backgroundColor: '#6B7280',
  },
  uploadButtonText: {
    color: '#0A1929',
    fontSize: 16,
    fontWeight: 'bold',
  },
  profileInfo: {
    alignItems: 'center',
  },
  nameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  userName: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 24 : 28,
    fontWeight: 'bold',
  },
  userEmail: {
    color: '#87CEEB',
    fontSize: isSmallScreen ? 14 : 16,
    marginBottom: 4,
  },
  userExperience: {
    color: '#87CEEB',
    fontSize: isSmallScreen ? 14 : 16,
    fontStyle: 'italic',
  },
  tierSection: {
    paddingHorizontal: isSmallScreen ? 16 : 20,
    paddingVertical: 0,
    marginBottom: 20,
  },
  tierCard: {
    padding: 20,
    borderRadius: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  tierContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  tierIcon: {
    fontSize: 48,
    marginRight: 16,
  },
  tierInfo: {
    flexDirection: 'column',
  },
  tierText: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  section: {
    paddingHorizontal: isSmallScreen ? 16 : 20,
    paddingVertical: 20,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.05)',
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  verificationCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.03)',
    borderRadius: 12,
    padding: 20,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.05)',
  },
  progressHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  progressText: {
    color: '#E5E7EB',
    fontSize: 14,
  },
  progressPercentage: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: 'bold',
  },
  progressBar: {
    height: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 4,
    marginBottom: 8,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#87CEEB',
    borderRadius: 4,
  },
  missingText: {
    color: '#FF9800',
    fontSize: 12,
  },
  settingsContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.03)',
    borderRadius: 12,
    overflow: 'hidden',
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.05)',
  },
  settingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  settingIcon: {
    fontSize: 20,
    marginRight: 12,
    width: 24,
    textAlign: 'center',
  },
  settingText: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 16 : 18,
    fontWeight: '500',
  },
  settingValue: {
    color: '#87CEEB',
    fontSize: isSmallScreen ? 14 : 16,
    textAlign: 'right',
    flex: 1,
  },
  settingInput: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 14 : 16,
    textAlign: 'right',
    flex: 1,
    borderBottomWidth: 1,
    borderBottomColor: '#87CEEB',
    paddingVertical: 4,
  },
  bioInput: {
    height: 60,
    textAlignVertical: 'top',
    textAlign: 'left',
  },
  documentInfo: {
    flex: 1,
  },
  documentDescription: {
    color: '#87CEEB',
    fontSize: 12,
    marginTop: 2,
  },
  documentStatus: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  documentStatusText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  complianceCard: {
    borderRadius: 12,
    padding: 16,
    borderLeftWidth: 4,
    borderLeftColor: '#87CEEB',
  },
  complianceHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  complianceIcon: {
    fontSize: 24,
    marginRight: 12,
  },
  complianceTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
  },
  complianceSubtitle: {
    color: '#87CEEB',
    fontSize: 14,
    fontWeight: '600',
    marginTop: 8,
    marginBottom: 4,
  },
  complianceIssues: {
    marginBottom: 12,
  },
  complianceIssue: {
    color: '#EF4444',
    fontSize: 12,
    marginBottom: 2,
  },
  complianceRecommendations: {
    marginBottom: 8,
  },
  complianceRecommendation: {
    color: '#4CAF50',
    fontSize: 12,
    marginBottom: 2,
  },
  saveButton: {
    backgroundColor: '#4CAF50',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 12,
    alignItems: 'center',
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  logoutItem: {
    borderBottomWidth: 0,
    backgroundColor: 'rgba(239, 68, 68, 0.1)',
  },
  deleteItem: {
    borderBottomWidth: 0,
    backgroundColor: 'rgba(239, 68, 68, 0.1)',
  },
  logoutText: {
    color: '#EF4444',
  },
  deleteText: {
    color: '#EF4444',
  },
  settingArrow: {
    color: '#87CEEB',
    fontSize: 18,
    fontWeight: 'bold',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: '#F9FAFB',
    fontSize: 18,
    marginTop: 12,
  },
  statsLoadingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  statsLoadingText: {
    color: '#87CEEB',
    fontSize: 14,
    marginLeft: 12,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#1E3A8A',
    borderRadius: 20,
    padding: 24,
    margin: 20,
    width: '90%',
    maxWidth: 400,
  },
  modalTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  modalDescription: {
    color: '#E5E7EB',
    fontSize: 14,
    marginBottom: 20,
  },
  modalActions: {
    flexDirection: 'row',
    gap: 12,
  },
  modalButton: {
    flex: 1,
    backgroundColor: '#87CEEB',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  modalButtonCancel: {
    backgroundColor: '#666',
  },
  modalButtonText: {
    color: '#0A1929',
    fontSize: 14,
    fontWeight: '600',
  },
  appInfoSection: {
    padding: 20,
  },
  tierStats: {
    color: '#E0E7FF',
    fontSize: 14,
    marginTop: 4,
  },
  progressToNext: {
    marginTop: 8,
  },
  tierBenefits: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    marginTop: 12,
  },
  benefitsTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  benefitText: {
    color: '#E0E7FF',
    fontSize: 14,
    marginBottom: 4,
    lineHeight: 18,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  statCard: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  statNumber: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  statLabel: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
  },
  appInfoText: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
    marginBottom: 4,
    opacity: 0.7,
  },
  verificationBadge: {
    position: 'absolute',
    top: -5,
    right: -5,
    backgroundColor: '#10B981',
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 3,
    borderColor: '#0A1929',
  },
  verificationIcon: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  verificationBadgeSmall: {
    backgroundColor: '#10B981',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    marginLeft: 8,
  },
  verificationIconSmall: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
});