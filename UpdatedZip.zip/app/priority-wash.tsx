import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Alert,
  ActivityIndicator,
  Dimensions,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useAuth } from '../src/providers/enhanced-auth-context';
import { supabase } from '../src/lib/supabase';

const { width } = Dimensions.get('window');

/** Supabase-backed Location type (no wait time) */
export type CarWashLocation = {
  id: string;
  name: string;
  address: string;
  latitude: number;
  longitude: number;
  rating: number;        // 0–5
  totalReviews: number;
  basePrice: number;     // £
  priorityPrice: number; // £
  status: 'green' | 'yellow' | 'orange' | 'red';
};

interface VehicleType {
  id: string;
  name: string;
  icon: string;
  description: string;
  baseMultiplier: number;
}

interface ServiceType {
  id: string;
  name: string;
  description: string;
  duration: string;
  multiplier: number;
}

/** Minimal shape for a created booking row */
type BookingRow = {
  id: string;
  status: string;
  user_id: string;
  price: number;
  service_type: string;
  service_name: string | null;
  scheduled_at: string;
  location_address: string | null;
  location_lat: number | null;
  location_lng: number | null;
  vehicle_type: string | null;
  time_slot: string | null;
  special_instructions: string | null;
};

export default function PriorityWash() {
  const router = useRouter();
  const { user } = useAuth();

  // Step management
  const [currentStep, setCurrentStep] = useState(1);
  const totalSteps = 4;

  const [carWashLocations, setCarWashLocations] = useState<CarWashLocation[]>([]);
  const [selectedLocation, setSelectedLocation] = useState<CarWashLocation | null>(null);
  const [selectedVehicleType, setSelectedVehicleType] = useState<string>('');
  const [selectedServiceType, setSelectedServiceType] = useState<string>('');
  const [priorityLevel, setPriorityLevel] = useState<'standard' | 'priority'>('standard');
  const [isLoading, setIsLoading] = useState(false);

  // Pricing (wait time removed)
  const [pricing, setPricing] = useState<{
    basePrice: number;
    priorityFee: number;
    totalPrice: number;
    canSkipQueue: boolean;
  } | null>(null);

  // Booking state (no ETA countdown)
  const [isBooked, setIsBooked] = useState(false);
  const [currentBooking, setCurrentBooking] = useState<BookingRow | null>(null);

  // Step navigation
  const nextStep = () => { if (currentStep < totalSteps) setCurrentStep(currentStep + 1); };
  const prevStep = () => { if (currentStep > 1) setCurrentStep(currentStep - 1); };

  const canProceedToNextStep = () => {
    switch (currentStep) {
      case 1: return selectedLocation !== null;
      case 2: return selectedVehicleType !== '';
      case 3: return selectedServiceType !== '';
      case 4: return true;
      default: return false;
    }
  };

  // Auto-progression
  const handleLocationSelect = (location: CarWashLocation) => {
    setSelectedLocation(location);
    setTimeout(() => nextStep(), 500);
  };
  const handleVehicleTypeSelect = (vehicleType: string) => {
    setSelectedVehicleType(vehicleType);
    setTimeout(() => nextStep(), 500);
  };
  const handleServiceTypeSelect = (serviceType: string) => {
    setSelectedServiceType(serviceType);
    setTimeout(() => nextStep(), 500);
  };

  const vehicleTypes: VehicleType[] = [
    { id: 'bike',       name: 'Motorcycle',   icon: '🏍️', description: 'Motorcycles and scooters',       baseMultiplier: 0.6 },
    { id: 'small_car',  name: 'Small Car',    icon: '🚗',  description: 'Hatchbacks and small sedans',    baseMultiplier: 1.0 },
    { id: 'large_car',  name: 'Large Car',    icon: '🚙',  description: 'Saloon cars and estates',        baseMultiplier: 1.3 },
    { id: 'suv',        name: 'SUV',          icon: '🚙',  description: 'Sports Utility Vehicles',        baseMultiplier: 1.5 },
    { id: 'van',        name: 'Van',          icon: '🚐',  description: 'Commercial vans and minibuses',  baseMultiplier: 1.8 },
    { id: 'coach',      name: 'Coach',        icon: '🚌',  description: 'Large coaches and buses',         baseMultiplier: 3.0 },
    { id: 'luxury',     name: 'Luxury Vehicle', icon: '🏎️', description: 'High-end and sports cars',     baseMultiplier: 2.0 },
  ];

  const serviceTypes: ServiceType[] = [
    { id: 'exterior_only', name: 'Exterior Only',  description: 'Wash exterior only',         duration: '15 min', multiplier: 0.7 },
    { id: 'standard',      name: 'Standard Wash',  description: 'Exterior and interior clean', duration: '30 min', multiplier: 1.0 },
    { id: 'premium',       name: 'Premium Wash',   description: 'Deep clean with wax',         duration: '45 min', multiplier: 1.4 },
    { id: 'luxury',        name: 'Luxury Detail',  description: 'Full detail and protection',  duration: '90 min', multiplier: 2.0 },
  ];

  useEffect(() => { loadCarWashLocations(); }, []);

  useEffect(() => {
    if (selectedLocation && selectedVehicleType && selectedServiceType) {
      calculatePricing();
    }
  }, [selectedLocation, selectedVehicleType, selectedServiceType, priorityLevel]);

  /** Load real locations from Supabase */
  const loadCarWashLocations = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id,name,address,latitude,longitude,rating,total_reviews,base_price,priority_price,status')
        .order('name', { ascending: true });

      if (error) throw error;

      const mapped: CarWashLocation[] = (data ?? []).map((row: any) => ({
        id: row.id,
        name: row.name,
        address: row.address,
        latitude: Number(row.latitude),
        longitude: Number(row.longitude),
        rating: Number(row.rating ?? 0),
        totalReviews: Number(row.total_reviews ?? 0),
        basePrice: Number(row.base_price ?? 0),
        priorityPrice: Number(row.priority_price ?? 0),
        status: (row.status ?? 'green') as CarWashLocation['status'],
      }));

      setCarWashLocations(mapped);
    } catch (error: any) {
      console.error('Error loading locations:', error?.message || error);
      Alert.alert('Error', 'Failed to load car wash locations');
    } finally {
      setIsLoading(false);
    }
  };

  /** Pricing calc (no wait-time) */
  const calculatePricing = () => {
    if (!selectedLocation || !selectedVehicleType || !selectedServiceType) return;

    const vehicleType = vehicleTypes.find(vt => vt.id === selectedVehicleType);
    const serviceType = serviceTypes.find(st => st.id === selectedServiceType);
    if (!vehicleType || !serviceType) return;

    const basePrice = selectedLocation.basePrice * vehicleType.baseMultiplier * serviceType.multiplier;
    const priorityFee = selectedLocation.priorityPrice;
    const totalPrice = basePrice + priorityFee;

    setPricing({
      basePrice,
      priorityFee,
      totalPrice,
      canSkipQueue: priorityLevel === 'priority',
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'green':  return '#FFD700';
      case 'yellow': return '#FFA500';
      case 'orange': return '#FF8C00';
      case 'red':    return '#FF4500';
      default:       return '#FFD700';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'green':  return 'Low Wait';
      case 'yellow': return 'Moderate Wait';
      case 'orange': return 'High Wait';
      case 'red':    return 'Very Busy';
      default:       return 'Unknown';
    }
  };

  /** Create booking directly in Supabase */
  const handleBookPriorityWash = async () => {
    if (!user?.id) {
      Alert.alert('Login required', 'Please sign in to create a booking.');
      return;
    }
    if (!selectedLocation || !selectedVehicleType || !selectedServiceType || !pricing) {
      Alert.alert('Error', 'Please complete all selections');
      return;
    }

    setIsLoading(true);
    try {
      const service = serviceTypes.find(st => st.id === selectedServiceType);
      const scheduledAtIso = new Date().toISOString(); // now; change if you add time slots

      const insertPayload = {
        user_id: user.id,
        service_type: selectedServiceType,                 // e.g. 'standard'
        service_name: service?.name ?? null,               // human label
        scheduled_at: scheduledAtIso,                      // timestamptz
        // status uses default 'scheduled'
        price: Number(pricing.totalPrice.toFixed(2)),      // numeric(10,2)
        // valeter_* left null on creation
        location_address: selectedLocation.address,
        location_lat: selectedLocation.latitude,
        location_lng: selectedLocation.longitude,
        eta_minutes: null,                                 // not used yet
        driver_lat: null,
        driver_lng: null,
        driver_location: null,
        progress_percent: null,
        vehicle_type: selectedVehicleType,
        vehicle_info: null,                                // plug in your stored vehicle string later
        time_slot: null,                                   // add later if you support slots
        special_instructions: null,
      };

      const { data, error } = await supabase
        .from('bookings')
        .insert(insertPayload)
        .select('*')
        .single();

      if (error) throw error;

      const created = data as BookingRow;
      setCurrentBooking(created);
      setIsBooked(true);

      // go to tracking with the booking id
      setTimeout(() => {
        router.push({ pathname: '/priority-wash-tracking', params: { bookingId: created.id } });
      }, 2000);
    } catch (error: any) {
      console.error('Booking insert error:', error?.message || error);
      Alert.alert('Error', error?.message || 'Failed to create booking. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  /** Booking confirmation (no ETA) */
  const renderBookingConfirmation = () => {
    if (!isBooked || !currentBooking) return null;
    return (
      <View style={styles.confirmationContainer}>
        <View style={styles.confirmationContent}>
          <Text style={styles.confirmationTitle}>🎉 Booking Confirmed!</Text>
          <Text style={styles.confirmationSubtitle}>Your priority wash is scheduled</Text>

          <View style={styles.confirmationDetails}>
            <Text style={styles.confirmationDetail}>📍 {selectedLocation?.name}</Text>
            <Text style={styles.confirmationDetail}>🚗 {vehicleTypes.find(vt => vt.id === selectedVehicleType)?.name}</Text>
            <Text style={styles.confirmationDetail}>✨ {serviceTypes.find(st => st.id === selectedServiceType)?.name}</Text>
            <Text style={styles.confirmationDetail}>💰 £{pricing?.totalPrice.toFixed(2)}</Text>
            <Text style={styles.confirmationDetail}>🆔 {currentBooking.id}</Text>
          </View>

          <TouchableOpacity
            style={styles.trackButton}
            onPress={() => router.push({ pathname: '/priority-wash-tracking', params: { bookingId: currentBooking.id } })}
          >
            <Text style={styles.trackButtonText}>Live GPS Tracking</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Priority Wash</Text>
          <TouchableOpacity onPress={() => router.push('/owner-dashboard')} style={styles.dashboardButton}>
            <Text style={styles.dashboardButtonText}>🏠</Text>
          </TouchableOpacity>
        </View>

        {/* Step Progress Bar */}
        <View style={styles.stepProgressContainer}>
          <View style={styles.stepProgressBar}>
            {Array.from({ length: totalSteps }, (_, index) => (
              <View key={index} style={styles.stepProgressItem}>
                <View style={[
                  styles.stepProgressDot,
                  currentStep > index + 1 && styles.stepProgressDotCompleted,
                  currentStep === index + 1 && styles.stepProgressDotActive
                ]}>
                  <Text style={[
                    styles.stepProgressNumber,
                    currentStep > index + 1 && styles.stepProgressNumberCompleted,
                    currentStep === index + 1 && styles.stepProgressNumberActive
                  ]}>
                    {currentStep > index + 1 ? '✓' : index + 1}
                  </Text>
                </View>
                {index < totalSteps - 1 && (
                  <View style={[
                    styles.stepProgressLine,
                    currentStep > index + 1 && styles.stepProgressLineCompleted
                  ]} />
                )}
              </View>
            ))}
          </View>
          <Text style={styles.stepTitle}>
            {currentStep === 1 && 'Step 1: Choose Location'}
            {currentStep === 2 && 'Step 2: Select Vehicle Type'}
            {currentStep === 3 && 'Step 3: Pick Service'}
            {currentStep === 4 && 'Step 4: Confirm & Book'}
          </Text>
        </View>

        {/* Step Content */}
        <View style={styles.stepContent}>
          {/* Step 1: Location Selection */}
          {currentStep === 1 && (
            <View style={styles.stepSection}>
              <Text style={styles.stepSectionTitle}>🏢 Choose Your Location</Text>
              <Text style={styles.stepSectionSubtitle}>Select from our premium car wash partners</Text>

              {isLoading ? (
                <ActivityIndicator size="large" color="#87CEEB" />
              ) : (
                carWashLocations.map((location) => (
                  <TouchableOpacity
                    key={location.id}
                    style={[
                      styles.locationCard,
                      selectedLocation?.id === location.id && styles.selectedLocationCard
                    ]}
                    onPress={() => handleLocationSelect(location)}
                  >
                    <View style={styles.locationHeader}>
                      <View style={styles.locationInfo}>
                        <Text style={styles.locationName}>{location.name}</Text>
                        <Text style={styles.locationAddress}>{location.address}</Text>
                        <View style={styles.locationRating}>
                          <Text style={styles.ratingText}>⭐ {location.rating} ({location.totalReviews} reviews)</Text>
                        </View>
                      </View>

                      <View style={styles.statusContainer}>
                        <View style={[styles.statusDot, { backgroundColor: getStatusColor(location.status) }]} />
                        <Text style={styles.statusText}>{getStatusText(location.status)}</Text>
                      </View>
                    </View>

                    <View style={styles.locationDetails}>
                      <View style={styles.detailRow}>
                        <Text style={styles.detailLabel}>Priority Fee:</Text>
                        <Text style={styles.detailValue}>£{location.priorityPrice}</Text>
                      </View>
                      <View style={styles.detailRow}>
                        <Text style={styles.detailLabel}>Base Price:</Text>
                        <Text style={styles.detailValue}>£{location.basePrice}</Text>
                      </View>
                    </View>
                  </TouchableOpacity>
                ))
              )}
            </View>
          )}

          {/* Step 2: Vehicle Type Selection */}
          {currentStep === 2 && (
            <View style={styles.stepSection}>
              <Text style={styles.stepSectionTitle}>🚗 Select Vehicle Type</Text>
              <Text style={styles.stepSectionSubtitle}>Choose your vehicle category for accurate pricing</Text>

              {vehicleTypes.map((vehicleType) => (
                <TouchableOpacity
                  key={vehicleType.id}
                  style={[
                    styles.vehicleTypeCard,
                    selectedVehicleType === vehicleType.id && styles.selectedVehicleTypeCard
                  ]}
                  onPress={() => handleVehicleTypeSelect(vehicleType.id)}
                >
                  <View style={styles.vehicleTypeHeader}>
                    <Text style={styles.vehicleTypeIcon}>{vehicleType.icon}</Text>
                    <View style={styles.vehicleTypeInfo}>
                      <Text style={styles.vehicleTypeName}>{vehicleType.name}</Text>
                      <Text style={styles.vehicleTypeDescription}>{vehicleType.description}</Text>
                    </View>
                    <View style={styles.vehicleTypeMultiplier}>
                      <Text style={styles.multiplierText}>{vehicleType.baseMultiplier}x</Text>
                    </View>
                  </View>
                </TouchableOpacity>
              ))}
            </View>
          )}

          {/* Step 3: Service Type Selection */}
          {currentStep === 3 && (
            <View style={styles.stepSection}>
              <Text style={styles.stepSectionTitle}>✨ Choose Your Service</Text>
              <Text style={styles.stepSectionSubtitle}>Select the level of service you need</Text>

              {serviceTypes.map((serviceType) => (
                <TouchableOpacity
                  key={serviceType.id}
                  style={[
                    styles.serviceTypeCard,
                    selectedServiceType === serviceType.id && styles.selectedServiceTypeCard
                  ]}
                  onPress={() => handleServiceTypeSelect(serviceType.id)}
                >
                  <View style={styles.serviceTypeHeader}>
                    <View style={styles.serviceTypeInfo}>
                      <Text style={styles.serviceTypeName}>{serviceType.name}</Text>
                      <Text style={styles.serviceTypeDescription}>{serviceType.description}</Text>
                      <Text style={styles.serviceTypeDuration}>⏱️ {serviceType.duration}</Text>
                    </View>
                    <View style={styles.serviceTypeMultiplier}>
                      <Text style={styles.multiplierText}>{serviceType.multiplier}x</Text>
                    </View>
                  </View>
                </TouchableOpacity>
              ))}
            </View>
          )}

          {/* Step 4: Confirmation and Booking */}
          {currentStep === 4 && (
            <View style={styles.stepSection}>
              <Text style={styles.stepSectionTitle}>📋 Booking Summary</Text>
              <Text style={styles.stepSectionSubtitle}>Review your selections and confirm booking</Text>

              {pricing && (
                <View style={styles.bookingSummaryCard}>
                  <View style={styles.summaryHeader}>
                    <Text style={styles.summaryTitle}>Booking Details</Text>
                  </View>

                  <View style={styles.summaryRow}>
                    <Text style={styles.summaryLabel}>Location:</Text>
                    <Text style={styles.summaryValue}>{selectedLocation?.name}</Text>
                  </View>

                  <View style={styles.summaryRow}>
                    <Text style={styles.summaryLabel}>Vehicle:</Text>
                    <Text style={styles.summaryValue}>{vehicleTypes.find(vt => vt.id === selectedVehicleType)?.name}</Text>
                  </View>

                  <View style={styles.summaryRow}>
                    <Text style={styles.summaryLabel}>Service:</Text>
                    <Text style={styles.summaryValue}>{serviceTypes.find(st => st.id === selectedServiceType)?.name}</Text>
                  </View>

                  <View style={styles.summaryRow}>
                    <Text style={styles.summaryLabel}>Base Price:</Text>
                    <Text style={styles.summaryValue}>£{pricing.basePrice.toFixed(2)}</Text>
                  </View>

                  <View style={styles.summaryRow}>
                    <Text style={styles.summaryLabel}>Priority Fee:</Text>
                    <Text style={styles.summaryValue}>£{pricing.priorityFee.toFixed(2)}</Text>
                  </View>

                  <View style={[styles.summaryRow, styles.totalRow]}>
                    <Text style={styles.totalLabel}>Total:</Text>
                    <Text style={styles.totalValue}>£{pricing.totalPrice.toFixed(2)}</Text>
                  </View>
                </View>
              )}

              <TouchableOpacity
                style={[styles.confirmButton, isLoading && styles.confirmButtonDisabled]}
                onPress={handleBookPriorityWash}
                disabled={isLoading}
              >
                {isLoading ? (
                  <ActivityIndicator size="small" color="#FFFFFF" />
                ) : (
                  <Text style={styles.confirmButtonText}>Confirm Booking & Track</Text>
                )}
              </TouchableOpacity>
            </View>
          )}
        </View>
      </ScrollView>

      {/* Booking Confirmation Overlay */}
      {renderBookingConfirmation()}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A1929' },
  scrollView: { flex: 1 },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    padding: 20, backgroundColor: 'rgba(255, 255, 255, 0.1)', borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.2)',
  },
  backButton: { padding: 8 },
  backButtonText: {
    fontSize: 16, color: '#FFFFFF', fontWeight: '600',
    textShadowColor: 'rgba(0, 0, 0, 0.3)', textShadowOffset: { width: 1, height: 1 }, textShadowRadius: 2,
  },
  headerTitle: {
    fontSize: 20, fontWeight: 'bold', color: '#FFFFFF',
    textShadowColor: 'rgba(0, 0, 0, 0.3)', textShadowOffset: { width: 1, height: 1 }, textShadowRadius: 2,
  },
  dashboardButton: {
    padding: 6, width: 32, height: 32, borderRadius: 16, backgroundColor: 'rgba(135, 206, 235, 0.2)',
    justifyContent: 'center', alignItems: 'center',
  },
  dashboardButtonText: { fontSize: 16, color: '#87CEEB', fontWeight: '600' },

  stepProgressContainer: {
    padding: 20, backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderBottomWidth: 1, borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  stepProgressBar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16,
  },
  stepProgressItem: { flexDirection: 'row', alignItems: 'center', flex: 1 },
  stepProgressDot: {
    width: 32, height: 32, borderRadius: 16,
    backgroundColor: 'rgba(255, 255, 255, 0.2)', justifyContent: 'center', alignItems: 'center',
    borderWidth: 2, borderColor: 'rgba(255, 255, 255, 0.3)',
  },
  stepProgressDotActive: { backgroundColor: '#FFFFFF', borderColor: '#FFFFFF' },
  stepProgressDotCompleted: { backgroundColor: '#87CEEB', borderColor: '#87CEEB' },
  stepProgressNumber: { fontSize: 14, fontWeight: 'bold', color: 'rgba(255, 255, 255, 0.7)' },
  stepProgressNumberActive: { color: '#0A1929' },
  stepProgressNumberCompleted: { color: '#0A1929' },
  stepProgressLine: { flex: 1, height: 2, backgroundColor: 'rgba(255, 255, 255, 0.2)', marginHorizontal: 8 },
  stepProgressLineCompleted: { backgroundColor: '#87CEEB' },
  stepTitle: {
    fontSize: 18, fontWeight: 'bold', color: '#FFFFFF', textAlign: 'center',
    textShadowColor: 'rgba(0, 0, 0, 0.3)', textShadowOffset: { width: 1, height: 1 }, textShadowRadius: 2,
  },

  stepContent: { flex: 1 },
  stepSection: { padding: 20 },
  stepSectionTitle: {
    fontSize: 24, fontWeight: 'bold', color: '#FFFFFF', marginBottom: 8, textAlign: 'center',
    textShadowColor: 'rgba(0, 0, 0, 0.3)', textShadowOffset: { width: 1, height: 1 }, textShadowRadius: 2,
  },
  stepSectionSubtitle: { fontSize: 16, color: '#FFFFFF', marginBottom: 24, textAlign: 'center', opacity: 0.9 },

  locationCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.15)', borderRadius: 12, marginBottom: 12, padding: 16,
    borderWidth: 1, borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  selectedLocationCard: { borderWidth: 2, borderColor: '#FFFFFF', backgroundColor: 'rgba(255, 255, 255, 0.25)' },
  locationHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 },
  locationInfo: { flex: 1 },
  locationName: {
    fontSize: 16, fontWeight: 'bold', color: '#FFFFFF', marginBottom: 4,
    textShadowColor: 'rgba(0, 0, 0, 0.3)', textShadowOffset: { width: 1, height: 1 }, textShadowRadius: 2,
  },
  locationAddress: { fontSize: 14, color: '#FFFFFF', marginBottom: 4, opacity: 0.9 },
  locationRating: { flexDirection: 'row', alignItems: 'center' },
  ratingText: { fontSize: 12, color: '#FFFFFF', opacity: 0.9 },
  statusContainer: { alignItems: 'center' },
  statusDot: { width: 12, height: 12, borderRadius: 6, marginBottom: 4 },
  statusText: { fontSize: 12, fontWeight: '600', color: '#FFFFFF' },
  locationDetails: { borderTopWidth: 1, borderTopColor: 'rgba(255, 255, 255, 0.1)', paddingTop: 12 },
  detailRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 },
  detailLabel: { fontSize: 14, color: '#CBD5E1' },
  detailValue: { fontSize: 14, fontWeight: '600', color: '#F9FAFB' },

  vehicleTypeCard: {
    backgroundColor: '#334155', borderRadius: 12, padding: 16, marginBottom: 12,
    borderWidth: 1, borderColor: 'rgba(135, 206, 235, 0.2)',
  },
  selectedVehicleTypeCard: { borderColor: '#87CEEB', backgroundColor: 'rgba(135, 206, 235, 0.1)' },
  vehicleTypeHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  vehicleTypeIcon: { fontSize: 32, marginRight: 12 },
  vehicleTypeInfo: { flex: 1 },
  vehicleTypeName: { fontSize: 16, fontWeight: 'bold', color: '#F9FAFB', marginBottom: 2 },
  vehicleTypeDescription: { fontSize: 13, color: '#CBD5E1' },
  vehicleTypeMultiplier: { backgroundColor: 'rgba(135, 206, 235, 0.2)', borderRadius: 8, paddingVertical: 4, paddingHorizontal: 8 },
  multiplierText: { fontSize: 14, fontWeight: '600', color: '#87CEEB' },

  serviceTypeCard: {
    backgroundColor: '#334155', borderRadius: 12, padding: 16, marginBottom: 12,
    borderWidth: 1, borderColor: 'rgba(135, 206, 235, 0.2)',
  },
  selectedServiceTypeCard: { borderColor: '#87CEEB', backgroundColor: 'rgba(135, 206, 235, 0.1)' },
  serviceTypeHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  serviceTypeInfo: { flex: 1 },
  serviceTypeName: { fontSize: 16, fontWeight: 'bold', color: '#F9FAFB', marginBottom: 2 },
  serviceTypeDescription: { fontSize: 13, color: '#CBD5E1', marginBottom: 4 },
  serviceTypeDuration: { fontSize: 12, color: '#87CEEB', fontWeight: '600' },
  serviceTypeMultiplier: { backgroundColor: 'rgba(135, 206, 235, 0.2)', borderRadius: 8, paddingVertical: 4, paddingHorizontal: 8 },

  bookingSummaryCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.15)', borderRadius: 16, padding: 20, marginBottom: 20,
    borderWidth: 1, borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  summaryHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  summaryTitle: { fontSize: 20, fontWeight: 'bold', color: '#FFFFFF' },
  summaryRow: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  totalRow: { borderBottomWidth: 0 },
  totalLabel: { fontSize: 18, fontWeight: 'bold', color: '#FFFFFF' },
  totalValue: { fontSize: 18, fontWeight: 'bold', color: '#87CEEB' },
  confirmButton: { backgroundColor: '#87CEEB', borderRadius: 12, padding: 16, alignItems: 'center' },
  confirmButtonDisabled: { opacity: 0.5 },
  confirmButtonText: { fontSize: 18, fontWeight: 'bold', color: '#0A1929' },

  confirmationContainer: {
    position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.7)', justifyContent: 'center', alignItems: 'center', zIndex: 10,
  },
  confirmationContent: {
    backgroundColor: '#1E293B', borderRadius: 20, padding: 30, alignItems: 'center', width: '80%',
    borderWidth: 1, borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  confirmationTitle: {
    fontSize: 28, fontWeight: 'bold', color: '#FFFFFF', marginBottom: 8, textAlign: 'center',
    textShadowColor: 'rgba(0, 0, 0, 0.3)', textShadowOffset: { width: 1, height: 1 }, textShadowRadius: 2,
  },
  confirmationSubtitle: { fontSize: 16, color: '#FFFFFF', marginBottom: 20, textAlign: 'center', opacity: 0.9 },
  confirmationDetails: {
    backgroundColor: 'rgba(255, 255, 255, 0.15)', borderRadius: 12, padding: 16, marginBottom: 20, width: '100%',
    borderWidth: 1, borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  confirmationDetail: { fontSize: 16, color: '#FFFFFF', marginBottom: 8 },
  trackButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)', borderRadius: 12, padding: 16, flexDirection: 'row',
    alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: 'rgba(255, 255, 255, 0.3)',
  },
  trackButtonText: { fontSize: 16, fontWeight: '600', color: '#87CEEB' },
});