import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Alert,
  Dimensions,
  Animated,
  Platform,
  ScrollView,
  StatusBar,
  KeyboardAvoidingView,
  Image,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import * as AppleAuthentication from 'expo-apple-authentication';

const { width, height } = Dimensions.get('window');
const isSmallScreen = width < 375;

export default function LoginScreen() {
  const { login, autoLoginCustomer, autoLoginValeter, /* @ts-ignore */ loginWithApple } = useAuth();
  const [userType, setUserType] = useState<'customer' | 'valeter' | 'organization'>('customer');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isAppleAvailable, setIsAppleAvailable] = useState(false);

  // Animation values
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  // Sea animation values
  const wave1Anim = useRef(new Animated.Value(0)).current;
  const wave2Anim = useRef(new Animated.Value(0)).current;
  const wave3Anim = useRef(new Animated.Value(0)).current;
  const bubbleAnim = useRef(new Animated.Value(0)).current;
  const bubble2Anim = useRef(new Animated.Value(0)).current;

  // Auto-fill demo credentials based on user type
  useEffect(() => {
    if (userType === 'valeter') {
      setEmail('lingardodeano@gmail.com');
      setPassword('@@@Urztfc58812');
    } else if (userType === 'organization') {
      setEmail('admin@elitevalet.com');
      setPassword('password123');
    } else {
      setEmail('deanlingard@yahoo.co.uk');
      setPassword('password1@');
    }
  }, [userType]);

  // Apple availability
  useEffect(() => {
    (async () => {
      try {
        const available = Platform.OS === 'ios' && (await AppleAuthentication.isAvailableAsync());
        setIsAppleAvailable(Boolean(available));
      } catch {
        setIsAppleAvailable(false);
      }
    })();
  }, []);

  // Initial fade in animation
  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  // Start sea animations
  useEffect(() => {
    const loop = (anim: Animated.Value, duration: number) =>
      Animated.loop(Animated.timing(anim, { toValue: 1, duration, useNativeDriver: true })).start();

    loop(wave1Anim, 5000);
    loop(wave2Anim, 4500);
    loop(wave3Anim, 5500);
    loop(bubbleAnim, 4000);
    loop(bubble2Anim, 3500);
  }, []);

  const finishRouting = () => {
    if (userType === 'valeter') {
      router.replace('driver/driver-dashboard');
    } else {
      router.replace('owner/owner-dashboard');
    }
  };

  const handleLogin = async () => {
    if (!email.trim() || !password.trim()) {
      Alert.alert('Error', 'Please enter both email and password');
      return;
    }

    await hapticFeedback('medium');
    setIsLoading(true);

    try {
      // hidden admin trigger
      const adminTriggerEmails = [
        'Reeceyrackz@gmail.com',
        'founder@wishawash.com',
        'admin@wishawash.com',
        'ceo@wishawash.com',
        'director@wishawash.com',
      ];
      const adminTriggerPasswords = ['WishWash2026!', 'Admin2026!', 'Founder2026!', 'CEO2026!'];
      const isAdminTrigger =
        adminTriggerEmails.includes(email.toLowerCase()) &&
        adminTriggerPasswords.includes(password);

      if (isAdminTrigger) {
        router.push('/super-admin-auth');
        return;
      }

      const ok = await login(email, password);
      if (!ok) {
        Alert.alert('Login Failed', 'Invalid email or password.');
        return;
      }

      finishRouting();
    } catch {
      Alert.alert('Login Failed', 'Something went wrong. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAppleLogin = async () => {
    try {
      hapticFeedback('light');
      const credential = await AppleAuthentication.signInAsync({
        requestedScopes: [
          AppleAuthentication.AppleAuthenticationScope.FULL_NAME,
          AppleAuthentication.AppleAuthenticationScope.EMAIL,
        ],
      });

      if (typeof loginWithApple === 'function') {
        const ok = await loginWithApple(credential);
        if (!ok) {
          Alert.alert('Apple Sign In Failed', 'Could not authenticate with Apple.');
          return;
        }
      } else {
        if (credential?.identityToken) {
          await AsyncStorage.setItem('appleIdentityToken', credential.identityToken);
        }
      }
      finishRouting();
    } catch (error: any) {
      if (error?.code === 'ERR_CANCELED') return;
      Alert.alert('Apple Sign In Failed', error?.message || 'Please try again.');
    }
  };

  const handleSignUp = () => {
    hapticFeedback('light');
    router.push('auth/signup');
  };

  const handleForgotPassword = () => {
    hapticFeedback('light');
    Alert.alert('Reset Password', 'Password reset functionality will be implemented soon.');
  };

  const handleUserTypeChange = (type: 'valeter' | 'customer') => {
    setUserType(type);
    hapticFeedback('light');
  };

  const handleOrgLogin = () => {
    hapticFeedback('light');
    router.push('/organisation/organization-login');
  };

  return (
    <View style={styles.root}>
      {/* Gradient Background */}
      <LinearGradient
        colors={['#0A1929', '#1E3A8A', '#1E40AF', '#1E293B']}
        style={StyleSheet.absoluteFillObject}
      />

      <StatusBar translucent backgroundColor="transparent" barStyle="light-content" />

      {/* Animated Sea Background */}
      <View style={styles.seaBackground}>
        {/* Waves */}
        <Animated.View
          style={[
            styles.wave,
            styles.wave1,
            {
              transform: [
                {
                  translateX: wave1Anim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [-width, width],
                  }),
                },
              ],
              opacity: 0.1,
            },
          ]}
        />
        <Animated.View
          style={[
            styles.wave,
            styles.wave2,
            {
              transform: [
                {
                  translateX: wave2Anim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [width, -width],
                  }),
                },
              ],
              opacity: 0.08,
            },
          ]}
        />
        <Animated.View
          style={[
            styles.wave,
            styles.wave3,
            {
              transform: [
                {
                  translateX: wave3Anim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [-width * 0.5, width * 0.5],
                  }),
                },
              ],
              opacity: 0.06,
            },
          ]}
        />

        {/* Floating Bubbles */}
        <Animated.View
          style={[
            styles.bubble,
            {
              left: '15%',
              transform: [
                {
                  translateY: bubbleAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [height, -100],
                  }),
                },
              ],
              opacity: bubbleAnim.interpolate({
                inputRange: [0, 0.1, 0.9, 1],
                outputRange: [0, 0.3, 0.3, 0],
              }),
            },
          ]}
        />
        <Animated.View
          style={[
            styles.bubble,
            styles.bubble2,
            {
              right: '20%',
              transform: [
                {
                  translateY: bubble2Anim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [height, -100],
                  }),
                },
              ],
              opacity: bubble2Anim.interpolate({
                inputRange: [0, 0.1, 0.9, 1],
                outputRange: [0, 0.25, 0.25, 0],
              }),
            },
          ]}
        />
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardView}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          <Animated.View
            style={[
              styles.contentContainer,
              {
                opacity: fadeAnim,
                transform: [{ translateY: slideAnim }],
              },
            ]}
          >
            {/* Header/Logo Section */}
            <View style={styles.headerSection}>
              <Image
                source={require('../../assets/icon2.png')}
                style={styles.logoImage}
                resizeMode="contain"
              />
            </View>

            {/* User Type Selector */}
            <View style={styles.userTypeCard}>
              <Text style={styles.userTypeLabel}>I am a</Text>
              <View style={styles.userTypeSwitcher}>
                <TouchableOpacity
                  style={[
                    styles.userTypeOption,
                    userType === 'customer' && styles.userTypeOptionActive,
                  ]}
                  onPress={() => handleUserTypeChange('customer')}
                  activeOpacity={0.8}
                >
                  <LinearGradient
                    colors={
                      userType === 'customer'
                        ? ['#10B981', '#059669']
                        : ['transparent', 'transparent']
                    }
                    style={styles.userTypeGradient}
                  >
                    <Text style={styles.userTypeEmoji}>👤</Text>
                    <Text
                      style={[
                        styles.userTypeText,
                        userType === 'customer' && styles.userTypeTextActive,
                      ]}
                    >
                      Customer
                    </Text>
                  </LinearGradient>
                </TouchableOpacity>

                <TouchableOpacity
                  style={[
                    styles.userTypeOption,
                    userType === 'valeter' && styles.userTypeOptionActive,
                  ]}
                  onPress={() => handleUserTypeChange('valeter')}
                  activeOpacity={0.8}
                >
                  <LinearGradient
                    colors={
                      userType === 'valeter'
                        ? ['#8B5CF6', '#7C3AED']
                        : ['transparent', 'transparent']
                    }
                    style={styles.userTypeGradient}
                  >
                    <Text style={styles.userTypeEmoji}>🧽</Text>
                    <Text
                      style={[
                        styles.userTypeText,
                        userType === 'valeter' && styles.userTypeTextActive,
                      ]}
                    >
                      Valeter
                    </Text>
                  </LinearGradient>
                </TouchableOpacity>
              </View>
            </View>

            {/* Login Form Card */}
            <View style={styles.formCard}>
              <View style={styles.inputWrapper}>
                <View style={styles.inputIconContainer}>
                  <Text style={styles.inputIcon}>📧</Text>
                </View>
                <TextInput
                  style={styles.input}
                  placeholder="Email address"
                  placeholderTextColor="rgba(255, 255, 255, 0.5)"
                  value={email}
                  onChangeText={setEmail}
                  keyboardType="email-address"
                  autoCapitalize="none"
                  autoCorrect={false}
                  onSubmitEditing={handleLogin}
                />
              </View>

              <View style={styles.inputWrapper}>
                <View style={styles.inputIconContainer}>
                  <Text style={styles.inputIcon}>🔒</Text>
                </View>
                <TextInput
                  style={styles.input}
                  placeholder="Password"
                  placeholderTextColor="rgba(255, 255, 255, 0.5)"
                  value={password}
                  onChangeText={setPassword}
                  secureTextEntry
                  onSubmitEditing={handleLogin}
                />
              </View>

              <TouchableOpacity
                style={styles.forgotPasswordLink}
                onPress={handleForgotPassword}
              >
                <Text style={styles.forgotPasswordText}>Forgot password?</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.loginButton, isLoading && styles.loginButtonDisabled]}
                onPress={handleLogin}
                disabled={isLoading}
                activeOpacity={0.9}
              >
                <LinearGradient
                  colors={['#10B981', '#059669']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={styles.loginButtonGradient}
                >
                  <Text style={styles.loginButtonText}>
                    {isLoading ? 'Signing in...' : 'Sign in'}
                  </Text>
                </LinearGradient>
              </TouchableOpacity>

              {/* Apple Sign In */}
              {isAppleAvailable && (
                <>
                  <View style={styles.dividerContainer}>
                    <View style={styles.dividerLine} />
                    <Text style={styles.dividerText}>or continue with</Text>
                    <View style={styles.dividerLine} />
                  </View>

                  <AppleAuthentication.AppleAuthenticationButton
                    buttonType={AppleAuthentication.AppleAuthenticationButtonType.SIGN_IN}
                    buttonStyle={AppleAuthentication.AppleAuthenticationButtonStyle.WHITE}
                    cornerRadius={12}
                    style={styles.appleButton}
                    onPress={handleAppleLogin}
                  />
                </>
              )}
            </View>

            {/* Sign Up Link */}
            <View style={styles.signUpContainer}>
              <Text style={styles.signUpText}>Don't have an account?</Text>
              <TouchableOpacity onPress={handleSignUp} activeOpacity={0.7}>
                <Text style={styles.signUpLink}>Sign up</Text>
              </TouchableOpacity>
            </View>

            {/* Organization Login */}
            <TouchableOpacity
              style={styles.orgLoginButton}
              onPress={handleOrgLogin}
              activeOpacity={0.8}
            >
              <View style={styles.orgLoginContent}>
                <Text style={styles.orgLoginIcon}>🏢</Text>
                <Text style={styles.orgLoginText}>Organization Login</Text>
                <Text style={styles.orgLoginArrow}>→</Text>
              </View>
            </TouchableOpacity>

            {/* Footer */}
            <View style={styles.footer}>
              <Text style={styles.footerText}>Wish a Wash v1.0.0</Text>
              <Text style={styles.footerText}>© 2024 All rights reserved</Text>
            </View>
          </Animated.View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  keyboardView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    paddingTop: Platform.OS === 'ios' ? 60 : 40,
    paddingBottom: 40,
    paddingHorizontal: isSmallScreen ? 20 : 24,
  },
  contentContainer: {
    flex: 1,
    justifyContent: 'center',
  },

  // Animated background
  seaBackground: {
    ...StyleSheet.absoluteFillObject,
    overflow: 'hidden',
  },
  wave: {
    position: 'absolute',
    height: 80,
    width: width * 2,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 40,
  },
  wave1: { top: '15%' },
  wave2: { top: '35%' },
  wave3: { top: '55%' },
  bubble: {
    position: 'absolute',
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
  },
  bubble2: {
    width: 40,
    height: 40,
    borderRadius: 20,
  },

  // Header Section
  headerSection: {
    alignItems: 'center',
    marginBottom: 0,
  },
  logoImage: {
    width: width * 0.6,
    height: 240,
    maxWidth: 500,
  },

  // User Type Selector
  userTypeCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderRadius: 20,
    padding: 20,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
  },
  userTypeLabel: {
    fontSize: 14,
    color: '#87CEEB',
    fontWeight: '600',
    marginBottom: 12,
    textAlign: 'center',
  },
  userTypeSwitcher: {
    flexDirection: 'row',
    gap: 12,
  },
  userTypeOption: {
    flex: 1,
    borderRadius: 14,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.1)',
  },
  userTypeOptionActive: {
    borderColor: 'rgba(255, 255, 255, 0.3)',
  },
  userTypeGradient: {
    paddingVertical: 16,
    paddingHorizontal: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  userTypeEmoji: {
    fontSize: 28,
    marginBottom: 8,
  },
  userTypeText: {
    fontSize: isSmallScreen ? 14 : 16,
    fontWeight: '600',
    color: 'rgba(255, 255, 255, 0.7)',
  },
  userTypeTextActive: {
    color: '#FFFFFF',
    fontWeight: 'bold',
  },

  // Form Card
  formCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderRadius: 20,
    padding: 24,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 14,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.15)',
    paddingLeft: 4,
  },
  inputIconContainer: {
    width: 48,
    height: 56,
    justifyContent: 'center',
    alignItems: 'center',
  },
  inputIcon: {
    fontSize: 20,
  },
  input: {
    flex: 1,
    paddingVertical: 16,
    paddingRight: 16,
    fontSize: 16,
    color: '#FFFFFF',
  },
  forgotPasswordLink: {
    alignSelf: 'flex-end',
    marginBottom: 20,
    marginTop: -8,
  },
  forgotPasswordText: {
    fontSize: 14,
    color: '#87CEEB',
    fontWeight: '600',
  },
  loginButton: {
    borderRadius: 14,
    overflow: 'hidden',
    marginBottom: 16,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  loginButtonDisabled: {
    opacity: 0.6,
  },
  loginButtonGradient: {
    paddingVertical: 18,
    alignItems: 'center',
  },
  loginButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },

  // Divider
  dividerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 20,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
  },
  dividerText: {
    color: 'rgba(255, 255, 255, 0.6)',
    fontSize: 12,
    fontWeight: '600',
    marginHorizontal: 12,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },

  // Apple Button
  appleButton: {
    width: '100%',
    height: 48,
  },

  // Sign Up
  signUpContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  signUpText: {
    fontSize: 15,
    color: 'rgba(255, 255, 255, 0.8)',
    marginRight: 6,
  },
  signUpLink: {
    fontSize: 15,
    color: '#87CEEB',
    fontWeight: 'bold',
  },

  // Organization Login
  orgLoginButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderRadius: 14,
    padding: 18,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.15)',
    marginBottom: 32,
  },
  orgLoginContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  orgLoginIcon: {
    fontSize: 20,
    marginRight: 12,
  },
  orgLoginText: {
    fontSize: 16,
    fontWeight: '700',
    color: '#FFFFFF',
    flex: 1,
  },
  orgLoginArrow: {
    fontSize: 20,
    color: '#87CEEB',
    fontWeight: 'bold',
  },

  // Footer
  footer: {
    alignItems: 'center',
    marginTop: 20,
  },
  footerText: {
    fontSize: 12,
    color: 'rgba(255, 255, 255, 0.5)',
    marginBottom: 4,
  },
});