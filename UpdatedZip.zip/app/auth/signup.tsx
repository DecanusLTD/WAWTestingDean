import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  Animated,
  KeyboardAvoidingView,
  Platform,
  Alert,
  ScrollView,
  SafeAreaView,
  StatusBar,
  Image
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import * as AppleAuthentication from 'expo-apple-authentication';

const { width, height } = Dimensions.get('window');
const isSmallScreen = width < 375;

export default function SignupScreen() {
  const { register, /* @ts-ignore */ registerWithApple } = useAuth();
  const [userType, setUserType] = useState<'customer' | 'valeter'>('customer');
  const [formData, setFormData] = useState({ name: '', email: '', password: '' });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isAppleAvailable, setIsAppleAvailable] = useState(false);

  // Animations
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  // Sea animation values
  const wave1Anim = useRef(new Animated.Value(0)).current;
  const wave2Anim = useRef(new Animated.Value(0)).current;
  const wave3Anim = useRef(new Animated.Value(0)).current;
  const bubbleAnim = useRef(new Animated.Value(0)).current;
  const bubble2Anim = useRef(new Animated.Value(0)).current;

  // Initial fade in animation
  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  // Apple availability
  useEffect(() => {
    (async () => {
      try {
        const available = Platform.OS === 'ios' && (await AppleAuthentication.isAvailableAsync());
        setIsAppleAvailable(Boolean(available));
      } catch {
        setIsAppleAvailable(false);
      }
    })();
  }, []);

  // Start sea animations
  useEffect(() => {
    const loop = (anim: Animated.Value, duration: number) =>
      Animated.loop(Animated.timing(anim, { toValue: 1, duration, useNativeDriver: true })).start();

    loop(wave1Anim, 5000);
    loop(wave2Anim, 4500);
    loop(wave3Anim, 5500);
    loop(bubbleAnim, 4000);
    loop(bubble2Anim, 3500);
  }, []);

  const updateFormData = (field: keyof typeof formData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    setError(null); // Clear error when user types
  };

  const validateForm = () => {
    if (!formData.name || !formData.email || !formData.password) {
      setError('Please fill in all required fields');
      return false;
    }
    if (!formData.email.includes('@')) {
      setError('Please enter a valid email address');
      return false;
    }
    if (formData.password.length < 6) {
      setError('Password must be at least 6 characters');
      return false;
    }
    return true;
  };

  const handleSignup = async () => {
    if (!validateForm()) return;

    await hapticFeedback('medium');
    setIsLoading(true);
    setError(null);

    try {
      const success = await register({
        email: formData.email,
        name: formData.name,
        userType,
        password: formData.password,
      });

      if (success) {
        Alert.alert('Success!', 'Account created! Please verify your email.', [
          { text: 'OK', onPress: () => router.replace('/auth/login') },
        ]);
      } else {
        setError('Failed to create account. Please try again.');
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to create account. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const gotoOrganizationSignup = () => {
    hapticFeedback('light');
    router.push('/organisation/organisation-signup');
  };

  const handleAppleSignup = async () => {
    try {
      hapticFeedback('light');
      const cred = await AppleAuthentication.signInAsync({
        requestedScopes: [
          AppleAuthentication.AppleAuthenticationScope.FULL_NAME,
          AppleAuthentication.AppleAuthenticationScope.EMAIL,
        ],
      });

      if (typeof registerWithApple === 'function') {
        const ok = await registerWithApple(cred, { userType });
        if (!ok) {
          Alert.alert('Apple Sign Up Failed', 'Could not create your account with Apple.');
          return;
        }
      } else {
        Alert.alert(
          'Apple Sign Up',
          'Apple credential received. Wire this to your backend via registerWithApple to finish sign up.'
        );
        return;
      }

      router.replace('/login');
    } catch (error: any) {
      if (error?.code === 'ERR_CANCELED') return;
      Alert.alert('Apple Sign Up Failed', error?.message || 'Please try again.');
    }
  };

  const handleUserTypeChange = (type: 'customer' | 'valeter') => {
    setUserType(type);
    hapticFeedback('light');
  };

  const handleLogin = () => {
    hapticFeedback('light');
    router.replace('/auth/login');
  };

  return (
    <View style={styles.root}>
      {/* Gradient Background */}
      <LinearGradient
        colors={['#0A1929', '#1E3A8A', '#1E40AF', '#1E293B']}
        style={StyleSheet.absoluteFillObject}
      />

      <StatusBar translucent backgroundColor="transparent" barStyle="light-content" />

      {/* Animated Sea Background */}
      <View style={styles.seaBackground}>
        {/* Waves */}
        <Animated.View
          style={[
            styles.wave,
            styles.wave1,
            {
              transform: [
                {
                  translateX: wave1Anim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [-width, width],
                  }),
                },
              ],
              opacity: 0.1,
            },
          ]}
        />
        <Animated.View
          style={[
            styles.wave,
            styles.wave2,
            {
              transform: [
                {
                  translateX: wave2Anim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [width, -width],
                  }),
                },
              ],
              opacity: 0.08,
            },
          ]}
        />
        <Animated.View
          style={[
            styles.wave,
            styles.wave3,
            {
              transform: [
                {
                  translateX: wave3Anim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [-width * 0.5, width * 0.5],
                  }),
                },
              ],
              opacity: 0.06,
            },
          ]}
        />

        {/* Floating Bubbles */}
        <Animated.View
          style={[
            styles.bubble,
            {
              left: '15%',
              transform: [
                {
                  translateY: bubbleAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [height, -100],
                  }),
                },
              ],
              opacity: bubbleAnim.interpolate({
                inputRange: [0, 0.1, 0.9, 1],
                outputRange: [0, 0.3, 0.3, 0],
              }),
            },
          ]}
        />
        <Animated.View
          style={[
            styles.bubble,
            styles.bubble2,
            {
              right: '20%',
              transform: [
                {
                  translateY: bubble2Anim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [height, -100],
                  }),
                },
              ],
              opacity: bubble2Anim.interpolate({
                inputRange: [0, 0.1, 0.9, 1],
                outputRange: [0, 0.25, 0.25, 0],
              }),
            },
          ]}
        />
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardView}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          <Animated.View
            style={[
              styles.contentContainer,
              {
                opacity: fadeAnim,
                transform: [{ translateY: slideAnim }],
              },
            ]}
          >
            {/* Header/Logo Section */}
                       <View style={styles.headerSection}>
                         <Image
                           source={require('../../assets/icon2.png')}
                           style={styles.logoImage}
                           resizeMode="contain"
                         />
                       </View>

            {/* User Type Selector */}
            <View style={styles.userTypeCard}>
              <Text style={styles.userTypeLabel}>I am a</Text>
              <View style={styles.userTypeSwitcher}>
                <TouchableOpacity
                  style={[
                    styles.userTypeOption,
                    userType === 'customer' && styles.userTypeOptionActive,
                  ]}
                  onPress={() => handleUserTypeChange('customer')}
                  activeOpacity={0.8}
                >
                  <LinearGradient
                    colors={
                      userType === 'customer'
                        ? ['#10B981', '#059669']
                        : ['transparent', 'transparent']
                    }
                    style={styles.userTypeGradient}
                  >
                    <Text style={styles.userTypeEmoji}>👤</Text>
                    <Text
                      style={[
                        styles.userTypeText,
                        userType === 'customer' && styles.userTypeTextActive,
                      ]}
                    >
                      Customer
                    </Text>
                  </LinearGradient>
                </TouchableOpacity>

                <TouchableOpacity
                  style={[
                    styles.userTypeOption,
                    userType === 'valeter' && styles.userTypeOptionActive,
                  ]}
                  onPress={() => handleUserTypeChange('valeter')}
                  activeOpacity={0.8}
                >
                  <LinearGradient
                    colors={
                      userType === 'valeter'
                        ? ['#8B5CF6', '#7C3AED']
                        : ['transparent', 'transparent']
                    }
                    style={styles.userTypeGradient}
                  >
                    <Text style={styles.userTypeEmoji}>🧽</Text>
                    <Text
                      style={[
                        styles.userTypeText,
                        userType === 'valeter' && styles.userTypeTextActive,
                      ]}
                    >
                      Valeter
                    </Text>
                  </LinearGradient>
                </TouchableOpacity>
              </View>
            </View>

            {/* Signup Form Card */}
            <View style={styles.formCard}>
              <View style={styles.inputWrapper}>
                <View style={styles.inputIconContainer}>
                  <Text style={styles.inputIcon}>👤</Text>
                </View>
                <TextInput
                  style={styles.input}
                  placeholder="Full name"
                  placeholderTextColor="rgba(255, 255, 255, 0.5)"
                  value={formData.name}
                  onChangeText={(v) => updateFormData('name', v)}
                  autoCapitalize="words"
                />
              </View>

              <View style={styles.inputWrapper}>
                <View style={styles.inputIconContainer}>
                  <Text style={styles.inputIcon}>📧</Text>
                </View>
                <TextInput
                  style={styles.input}
                  placeholder="Email address"
                  placeholderTextColor="rgba(255, 255, 255, 0.5)"
                  value={formData.email}
                  onChangeText={(v) => updateFormData('email', v)}
                  keyboardType="email-address"
                  autoCapitalize="none"
                  autoCorrect={false}
                />
              </View>

              <View style={styles.inputWrapper}>
                <View style={styles.inputIconContainer}>
                  <Text style={styles.inputIcon}>🔒</Text>
                </View>
                <TextInput
                  style={styles.input}
                  placeholder="Password (min. 6 characters)"
                  placeholderTextColor="rgba(255, 255, 255, 0.5)"
                  value={formData.password}
                  onChangeText={(v) => updateFormData('password', v)}
                  secureTextEntry
                />
              </View>

              {/* Error Message */}
              {error && (
                <View style={styles.errorContainer}>
                  <Text style={styles.errorIcon}>⚠️</Text>
                  <Text style={styles.errorText}>{error}</Text>
                </View>
              )}

              <TouchableOpacity
                style={[styles.signupButton, isLoading && styles.signupButtonDisabled]}
                onPress={handleSignup}
                disabled={isLoading}
                activeOpacity={0.9}
              >
                <LinearGradient
                  colors={['#10B981', '#059669']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={styles.signupButtonGradient}
                >
                  <Text style={styles.signupButtonText}>
                    {isLoading ? 'Creating account...' : 'Create account'}
                  </Text>
                </LinearGradient>
              </TouchableOpacity>

              {/* Apple Sign Up */}
              {isAppleAvailable && (
                <>
                  <View style={styles.dividerContainer}>
                    <View style={styles.dividerLine} />
                    <Text style={styles.dividerText}>or continue with</Text>
                    <View style={styles.dividerLine} />
                  </View>

                  <AppleAuthentication.AppleAuthenticationButton
                    buttonType={AppleAuthentication.AppleAuthenticationButtonType.SIGN_UP}
                    buttonStyle={AppleAuthentication.AppleAuthenticationButtonStyle.WHITE}
                    cornerRadius={12}
                    style={styles.appleButton}
                    onPress={handleAppleSignup}
                  />
                </>
              )}

              {/* Terms */}
              <View style={styles.termsContainer}>
                <Text style={styles.termsText}>
                  By creating an account, you agree to our{' '}
                  <Text style={styles.termsLink}>Terms of Service</Text> and{' '}
                  <Text style={styles.termsLink}>Privacy Policy</Text>
                </Text>
              </View>
            </View>

            {/* Login Link */}
            <View style={styles.loginContainer}>
              <Text style={styles.loginText}>Already have an account?</Text>
              <TouchableOpacity onPress={handleLogin} activeOpacity={0.7}>
                <Text style={styles.loginLink}>Sign in</Text>
              </TouchableOpacity>
            </View>

            {/* Organization Signup */}
            <TouchableOpacity
              style={styles.orgSignupButton}
              onPress={gotoOrganizationSignup}
              activeOpacity={0.8}
            >
              <View style={styles.orgSignupContent}>
                <Text style={styles.orgSignupIcon}>🏢</Text>
                <View style={styles.orgSignupTextContainer}>
                  <Text style={styles.orgSignupTitle}>Are you an organization?</Text>
                  <Text style={styles.orgSignupSubtitle}>Create an organization account</Text>
                </View>
                <Text style={styles.orgSignupArrow}>→</Text>
              </View>
            </TouchableOpacity>

            {/* Footer */}
            <View style={styles.footer}>
              <Text style={styles.footerText}>Wish a Wash v1.0.0</Text>
              <Text style={styles.footerText}>© 2024 All rights reserved</Text>
            </View>
          </Animated.View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  keyboardView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    paddingTop: Platform.OS === 'ios' ? 60 : 40,
    paddingBottom: 40,
    paddingHorizontal: isSmallScreen ? 20 : 24,
  },
  contentContainer: {
    flex: 1,
    justifyContent: 'center',
  },

  // Animated background
  seaBackground: {
    ...StyleSheet.absoluteFillObject,
    overflow: 'hidden',
  },
  wave: {
    position: 'absolute',
    height: 80,
    width: width * 2,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 40,
  },
  wave1: { top: '15%' },
  wave2: { top: '35%' },
  wave3: { top: '55%' },
  bubble: {
    position: 'absolute',
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
  },
  bubble2: {
    width: 40,
    height: 40,
    borderRadius: 20,
  },

  // Header Section
    headerSection: {
      alignItems: 'center',
      marginBottom: 0,
    },
    logoImage: {
      width: width * 0.6,
      height: 240,
      maxWidth: 500,
    },
  logoCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderWidth: 3,
    borderColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  logoEmoji: {
    fontSize: 40,
  },
  titleContainer: {
    alignItems: 'center',
  },
  titleText: {
    fontSize: isSmallScreen ? 32 : 36,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 8,
    textShadowColor: 'rgba(0, 0, 0, 0.3)',
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 4,
  },
  subtitleText: {
    fontSize: isSmallScreen ? 14 : 16,
    color: '#87CEEB',
    fontWeight: '600',
  },

  // User Type Selector
  userTypeCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderRadius: 20,
    padding: 20,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
  },
  userTypeLabel: {
    fontSize: 14,
    color: '#87CEEB',
    fontWeight: '600',
    marginBottom: 12,
    textAlign: 'center',
  },
  userTypeSwitcher: {
    flexDirection: 'row',
    gap: 12,
  },
  userTypeOption: {
    flex: 1,
    borderRadius: 14,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.1)',
  },
  userTypeOptionActive: {
    borderColor: 'rgba(255, 255, 255, 0.3)',
  },
  userTypeGradient: {
    paddingVertical: 16,
    paddingHorizontal: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  userTypeEmoji: {
    fontSize: 28,
    marginBottom: 8,
  },
  userTypeText: {
    fontSize: isSmallScreen ? 14 : 16,
    fontWeight: '600',
    color: 'rgba(255, 255, 255, 0.7)',
  },
  userTypeTextActive: {
    color: '#FFFFFF',
    fontWeight: 'bold',
  },

  // Form Card
  formCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderRadius: 20,
    padding: 24,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 14,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.15)',
    paddingLeft: 4,
  },
  inputIconContainer: {
    width: 48,
    height: 56,
    justifyContent: 'center',
    alignItems: 'center',
  },
  inputIcon: {
    fontSize: 20,
  },
  input: {
    flex: 1,
    paddingVertical: 16,
    paddingRight: 16,
    fontSize: 16,
    color: '#FFFFFF',
  },

  // Error
  errorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(239, 68, 68, 0.1)',
    borderRadius: 12,
    padding: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: 'rgba(239, 68, 68, 0.3)',
  },
  errorIcon: {
    fontSize: 18,
    marginRight: 8,
  },
  errorText: {
    flex: 1,
    color: '#FCA5A5',
    fontSize: 14,
    fontWeight: '500',
  },

  // Signup Button
  signupButton: {
    borderRadius: 14,
    overflow: 'hidden',
    marginBottom: 16,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  signupButtonDisabled: {
    opacity: 0.6,
  },
  signupButtonGradient: {
    paddingVertical: 18,
    alignItems: 'center',
  },
  signupButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },

  // Divider
  dividerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 20,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
  },
  dividerText: {
    color: 'rgba(255, 255, 255, 0.6)',
    fontSize: 12,
    fontWeight: '600',
    marginHorizontal: 12,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },

  // Apple Button
  appleButton: {
    width: '100%',
    height: 48,
    marginBottom: 20,
  },

  // Terms
  termsContainer: {
    marginTop: 4,
  },
  termsText: {
    fontSize: 12,
    color: 'rgba(255, 255, 255, 0.6)',
    textAlign: 'center',
    lineHeight: 18,
  },
  termsLink: {
    color: '#87CEEB',
    fontWeight: '600',
  },

  // Login Link
  loginContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  loginText: {
    fontSize: 15,
    color: 'rgba(255, 255, 255, 0.8)',
    marginRight: 6,
  },
  loginLink: {
    fontSize: 15,
    color: '#87CEEB',
    fontWeight: 'bold',
  },

  // Organization Signup
  orgSignupButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderRadius: 14,
    padding: 18,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.15)',
    marginBottom: 32,
  },
  orgSignupContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  orgSignupIcon: {
    fontSize: 24,
    marginRight: 16,
  },
  orgSignupTextContainer: {
    flex: 1,
  },
  orgSignupTitle: {
    fontSize: 15,
    fontWeight: '700',
    color: '#FFFFFF',
    marginBottom: 2,
  },
  orgSignupSubtitle: {
    fontSize: 13,
    color: '#87CEEB',
    fontWeight: '500',
  },
  orgSignupArrow: {
    fontSize: 20,
    color: '#87CEEB',
    fontWeight: 'bold',
  },

  // Footer
  footer: {
    alignItems: 'center',
    marginTop: 20,
  },
  footerText: {
    fontSize: 12,
    color: 'rgba(255, 255, 255, 0.5)',
    marginBottom: 4,
  },
});