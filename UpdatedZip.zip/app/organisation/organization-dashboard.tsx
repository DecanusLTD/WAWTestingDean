import OrganizationDashboard from '../../src/components/dashboard/OrganizationDashboard';

export default function OrganizationDashboardRoute() {
  return <OrganizationDashboard />;
}
