// app/organisation/OrganizationProfile.tsx
import React, { useEffect, useMemo, useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  Switch,
  Image,
  SafeAreaView,
  Animated,
  Dimensions,
  ActivityIndicator,
  Modal,
  Platform,
  RefreshControl,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as ImagePicker from 'expo-image-picker';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;

type DbOrganization = {
  id: string;
  name: string;
  registration_number?: string | null;
  address?: string | null;
  contact_email: string;
  contact_phone?: string | null;
  status: 'pending' | 'verified' | 'suspended' | string;
  is_verified: boolean;
  insurance_verified: boolean;
  license_verified: boolean;
  owner_user_id: string | null;
  created_at: string;
  updated_at: string;
};

interface OrganizationDocument {
  id: string;
  organization_id: string;
  type: 'business_license' | 'insurance_certificate' | 'tax_registration' | 'disclaimer_signed';
  name: string;
  description: string;
  status: 'pending' | 'approved' | 'rejected' | 'not_uploaded';
  file_url?: string;
  uploaded_at?: string;
  approved_at?: string;
  rejection_reason?: string;
}

export default function OrganizationProfile() {
  const { user, logout } = useAuth();
  const insets = useSafeAreaInsets();

  const [isEditing, setIsEditing] = useState(false);
  const [org, setOrg] = useState<DbOrganization | null>(null);
  const [loading, setLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  // Documents state
  const [documents, setDocuments] = useState<OrganizationDocument[]>([]);
  const [showDocumentModal, setShowDocumentModal] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState<OrganizationDocument | null>(null);
  const [uploadingDocument, setUploadingDocument] = useState(false);

  // Settings toggles
  const [notifications, setNotifications] = useState(true);
  const [locationSharing, setLocationSharing] = useState(true);

  // Logo
  const [logoUri, setLogoUri] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    name: '',
    registration_number: '',
    address: '',
    contact_email: '',
    contact_phone: '',
  });

  // Animations
  const scrollY = useRef(new Animated.Value(0)).current;
  const bubble1 = useRef(new Animated.Value(0)).current;
  const bubble2 = useRef(new Animated.Value(0)).current;

  const headerHeight = scrollY.interpolate({
    inputRange: [0, 100],
    outputRange: [insets.top + 120, insets.top + 80],
    extrapolate: 'clamp',
  });

  useEffect(() => {
    const loop = (a: Animated.Value, d: number) =>
      Animated.loop(
        Animated.sequence([
          Animated.timing(a, { toValue: 1, duration: d, useNativeDriver: true }),
          Animated.timing(a, { toValue: 0, duration: d, useNativeDriver: true }),
        ])
      ).start();
    loop(bubble1, 4200);
    loop(bubble2, 5400);
  }, []);

  const initials = useMemo(() => {
    const n = formData.name?.trim() || 'Org';
    const parts = n.split(/\s+/);
    if (parts.length >= 2) return `${parts[0][0] ?? ''}${parts[1][0] ?? ''}`.toUpperCase();
    return n.slice(0, 2).toUpperCase();
  }, [formData.name]);

  useEffect(() => {
    loadOrganizationData();
  }, [user?.id, user?.organizationId]);

  const loadOrganizationData = async () => {
    if (!user?.id) {
      setLoading(false);
      return;
    }
    try {
      setLoading(true);

      // Load organization
      let q = supabase
        .from('organizations')
        .select('*')
        .eq('owner_user_id', user.id)
        .maybeSingle();

      let { data, error } = await q;
      if (error) throw error;

      if (!data && user.organizationId) {
        const res = await supabase
          .from('organizations')
          .select('*')
          .eq('id', user.organizationId)
          .maybeSingle();
        if (res.error) throw res.error;
        data = res.data;
      }

      if (!data) {
        setOrg(null);
        setLoading(false);
        return;
      }

      setOrg(data as DbOrganization);
      setFormData({
        name: data.name ?? '',
        registration_number: data.registration_number ?? '',
        address: data.address ?? '',
        contact_email: data.contact_email ?? '',
        contact_phone: data.contact_phone ?? '',
      });

      // Load documents
      await loadDocuments(data.id);
    } catch (e: any) {
      console.warn('[OrgProfile] load error:', e?.message || e);
      Alert.alert('Error', 'Failed to load organization.');
    } finally {
      setLoading(false);
    }
  };

  const loadDocuments = async (orgId: string) => {
    try {
      const { data, error } = await supabase
        .from('organization_documents')
        .select('*')
        .eq('organization_id', orgId);

      if (error) throw error;

      if (data && data.length > 0) {
        setDocuments(data);
      } else {
        // Initialize with required documents
        const requiredDocs: Partial<OrganizationDocument>[] = [
          {
            organization_id: orgId,
            type: 'business_license',
            name: 'Business License',
            description: 'Valid business registration or license',
            status: 'not_uploaded',
          },
          {
            organization_id: orgId,
            type: 'insurance_certificate',
            name: 'Insurance Certificate',
            description: 'Proof of business insurance coverage',
            status: 'not_uploaded',
          },
          {
            organization_id: orgId,
            type: 'tax_registration',
            name: 'Tax Registration',
            description: 'VAT or tax registration documents',
            status: 'not_uploaded',
          },
          {
            organization_id: orgId,
            type: 'disclaimer_signed',
            name: 'Terms & Conditions',
            description: 'Signed agreement to Wish a Wash terms',
            status: 'not_uploaded',
          },
        ];

        const { data: created, error: createError } = await supabase
          .from('organization_documents')
          .insert(requiredDocs)
          .select();

        if (createError) throw createError;
        setDocuments(created || []);
      }
    } catch (error) {
      console.error('Error loading documents:', error);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadOrganizationData();
    setRefreshing(false);
  };

  const updateFormData = (field: keyof typeof formData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSave = async () => {
    if (!org) return;
    try {
      setIsSaving(true);
      await hapticFeedback('medium');

      const patch: Partial<DbOrganization> = {
        name: formData.name.trim(),
        registration_number: formData.registration_number.trim() || null,
        address: formData.address.trim() || null,
        contact_email: formData.contact_email.trim(),
        contact_phone: formData.contact_phone.trim() || null,
      };

      const { error } = await supabase
        .from('organizations')
        .update(patch)
        .eq('id', org.id);

      if (error) throw error;

      setOrg(prev => (prev ? { ...prev, ...patch } as DbOrganization : prev));
      setIsEditing(false);
      Alert.alert('Success', 'Organization updated successfully!');
    } catch (e: any) {
      console.warn('[OrgProfile] save error:', e?.message || e);
      Alert.alert('Error', 'Failed to update organization. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleCancel = () => {
    if (!org) return;
    setFormData({
      name: org.name ?? '',
      registration_number: org.registration_number ?? '',
      address: org.address ?? '',
      contact_email: org.contact_email ?? '',
      contact_phone: org.contact_phone ?? '',
    });
    setIsEditing(false);
  };

  const handleLogout = async () => {
    await hapticFeedback('medium');
    Alert.alert('Logout', 'Are you sure you want to logout?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Logout',
        style: 'destructive',
        onPress: async () => {
          try {
            await logout();
            router.replace('../organisation/organization-login');
          } catch {
            router.replace('../organisation/organization-login');
          }
        },
      },
    ]);
  };

  const handleUploadLogo = async () => {
    await hapticFeedback('light');
    Alert.alert(
      'Upload Logo',
      'Choose how you want to add your organization logo:',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: '📸 Take Photo',
          onPress: () => takeLogoPhoto(),
        },
        {
          text: '🖼️ Choose from Gallery',
          onPress: () => pickLogoImage(),
        },
      ]
    );
  };

  const takeLogoPhoto = async () => {
    try {
      const { status } = await ImagePicker.requestCameraPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission Required', 'Camera permission is required to take a photo.');
        return;
      }

      const result = await ImagePicker.launchCameraAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]) {
        await uploadLogo(result.assets[0].uri);
      }
    } catch (error) {
      console.error('Error taking photo:', error);
      Alert.alert('Error', 'Failed to take photo. Please try again.');
    }
  };

  const pickLogoImage = async () => {
    try {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission Required', 'Gallery permission is required to select a photo.');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]) {
        await uploadLogo(result.assets[0].uri);
      }
    } catch (error) {
      console.error('Error picking image:', error);
      Alert.alert('Error', 'Failed to select image. Please try again.');
    }
  };

  const uploadLogo = async (uri: string) => {
    if (!org) return;
    try {
      const ext = uri.split('.').pop() || 'jpg';
      const fileName = `logo_${org.id}_${Date.now()}.${ext}`;
      const storagePath = `organizations/${org.id}/${fileName}`;

      const { publicUrl } = await uploadUriToSupabase(uri, storagePath, `image/${ext}`);

      // Update organization logo in database (you may need to add this column)
      setLogoUri(publicUrl);

      await hapticFeedback('success');
      Alert.alert('Success', 'Logo uploaded successfully!');
    } catch (error: any) {
      console.error('Error uploading logo:', error);
      Alert.alert('Upload Failed', error?.message || 'Please try again.');
    }
  };

  const handleUploadDocument = async (document: OrganizationDocument) => {
    await hapticFeedback('light');
    setSelectedDocument(document);
    setShowDocumentModal(true);
  };

  const BUCKET = 'organization_documents';

  async function uploadUriToSupabase(
    uri: string,
    path: string,
    contentType = 'image/jpeg'
  ) {
    const file = {
      uri,
      name: path.split('/').pop() || 'upload.jpg',
      type: contentType,
    } as any;

    const { data, error } = await supabase
      .storage
      .from(BUCKET)
      .upload(path, file, {
        contentType,
        upsert: false,
      });

    if (error) throw error;

    const { data: pub } = supabase.storage.from(BUCKET).getPublicUrl(path);
    const publicUrl = pub?.publicUrl ?? null;

    return { path: data?.path ?? path, publicUrl };
  }

  function extFromMime(m?: string | null) {
    if (!m) return 'jpg';
    if (m.includes('png')) return 'png';
    if (m.includes('heic')) return 'heic';
    if (m.includes('webp')) return 'webp';
    if (m.includes('jpeg')) return 'jpg';
    return 'jpg';
  }

  const chooseAndUploadDocument = async (source: 'camera' | 'gallery') => {
    if (!selectedDocument || !org) return;

    try {
      setUploadingDocument(true);

      let permStatus = { status: 'granted' as const };
      if (source === 'camera') {
        permStatus = await ImagePicker.requestCameraPermissionsAsync();
      } else {
        permStatus = await ImagePicker.requestMediaLibraryPermissionsAsync();
      }

      if (permStatus.status !== 'granted') {
        Alert.alert('Permission Required', 'Permission is required to continue.');
        return;
      }

      const pickerFn = source === 'camera'
        ? ImagePicker.launchCameraAsync
        : ImagePicker.launchImageLibraryAsync;

      const result = await pickerFn({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.9,
      });

      if (result.canceled || !result.assets?.[0]) return;

      const asset = result.assets[0];
      const contentType = (asset as any).mimeType ?? 'image/jpeg';
      const ext = extFromMime((asset as any).mimeType);
      const fileName = `${selectedDocument.type}_${Date.now()}.${ext}`;
      const storagePath = `documents/${org.id}/${selectedDocument.type}/${fileName}`;

      const { publicUrl } = await uploadUriToSupabase(asset.uri, storagePath, contentType);

      const { error } = await supabase
        .from('organization_documents')
        .update({
          file_url: publicUrl,
          status: 'pending',
          uploaded_at: new Date().toISOString(),
        })
        .eq('id', selectedDocument.id);

      if (error) throw error;

      await loadDocuments(org.id);
      setShowDocumentModal(false);
      setSelectedDocument(null);

      await hapticFeedback('success');
      Alert.alert('Success', `${selectedDocument.name} uploaded successfully! It will be reviewed shortly.`);
    } catch (e: any) {
      console.error('Upload error:', e);
      Alert.alert('Upload Failed', e?.message ?? 'Please try again.');
    } finally {
      setUploadingDocument(false);
    }
  };

  const getVerificationProgress = () => {
    const total = documents.length;
    const completed = documents.filter(doc => doc.status === 'approved').length;
    const percentage = total > 0 ? Math.round((completed / total) * 100) : 0;
    const missing = documents
      .filter(doc => doc.status !== 'approved')
      .map(doc => doc.name);

    return { total, completed, percentage, missing };
  };

  const handleChangePassword = () => {
    Alert.alert('Change Password', 'Password change functionality will be implemented');
  };

  const handleTermsOfService = () => router.push('/terms-of-service');
  const handlePrivacyPolicy = () => router.push('/privacy-policy');
  const handleHelpSupport = () => router.push('/help-support');

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#87CEEB" />
          <Text style={styles.loadingText}>Loading organization profile...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!org) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />
        <View style={styles.loadingContainer}>
          <Text style={styles.errorText}>No organization found for this account.</Text>
          <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
            <Text style={styles.backButtonText}>Go Back</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const progress = getVerificationProgress();

  const bubble1Style = {
    transform: [
      { translateY: bubble1.interpolate({ inputRange: [0, 1], outputRange: [0, -8] }) },
      { translateX: bubble1.interpolate({ inputRange: [0, 1], outputRange: [0, 6] }) },
    ],
    opacity: bubble1.interpolate({ inputRange: [0, 1], outputRange: [0.15, 0.35] }),
  };
  const bubble2Style = {
    transform: [
      { translateY: bubble2.interpolate({ inputRange: [0, 1], outputRange: [0, -10] }) },
      { translateX: bubble2.interpolate({ inputRange: [0, 1], outputRange: [0, -6] }) },
    ],
    opacity: bubble2.interpolate({ inputRange: [0, 1], outputRange: [0.12, 0.3] }),
  };

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />

      {/* Decorative bubbles */}
      <Animated.View style={[styles.bubble, styles.bubble1, bubble1Style]} />
      <Animated.View style={[styles.bubble, styles.bubble2, bubble2Style]} />

      {/* Header */}
      <Animated.View style={[styles.headerWrap, { paddingTop: insets.top + 8, height: headerHeight }]}>
        <View style={styles.headerRow}>
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              router.back();
            }}
            style={styles.backButtonCircle}
          >
            <Text style={styles.backIcon}>←</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Organization Profile</Text>
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              setIsEditing(!isEditing);
            }}
            style={styles.editButtonCircle}
          >
            <Text style={styles.editIcon}>{isEditing ? '✕' : '✏️'}</Text>
          </TouchableOpacity>
        </View>
      </Animated.View>

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
        refreshControl={
          <RefreshControl tintColor="#CBE3FF" refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {/* Hero Section */}
        <View style={styles.heroSection}>
          <View style={styles.profilePictureContainer}>
            <TouchableOpacity style={styles.logoCircle} onPress={handleUploadLogo}>
              {logoUri ? (
                <Image source={{ uri: logoUri }} style={styles.logoImage} />
              ) : (
                <View style={styles.logoPlaceholder}>
                  <Text style={styles.logoInitials}>{initials}</Text>
                </View>
              )}
              {(org.is_verified || org.status === 'verified') && (
                <View style={styles.verificationBadge}>
                  <Text style={styles.verificationIcon}>✓</Text>
                </View>
              )}
            </TouchableOpacity>
            <TouchableOpacity style={styles.uploadButton} onPress={handleUploadLogo}>
              <Text style={styles.uploadButtonText}>📷</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.profileInfo}>
            <View style={styles.nameRow}>
              <Text style={styles.orgName}>{formData.name || 'Organization'}</Text>
              {(org.is_verified || org.status === 'verified') && (
                <View style={styles.verificationBadgeSmall}>
                  <Text style={styles.verificationIconSmall}>✓</Text>
                </View>
              )}
            </View>
            <Text style={styles.orgEmail}>{formData.contact_email}</Text>
            <Text style={styles.orgStatus}>
              {org.status === 'verified' || org.is_verified
                ? '🟢 Verified Organization'
                : org.status === 'pending'
                ? '🟡 Pending Verification'
                : '🔴 Suspended'}
            </Text>
          </View>
        </View>

        {/* Verification Progress */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Verification Progress</Text>
          <View style={styles.verificationCard}>
            <View style={styles.progressHeader}>
              <Text style={styles.progressText}>
                {progress.completed} of {progress.total} completed
              </Text>
              <Text style={styles.progressPercentage}>{progress.percentage}%</Text>
            </View>
            <View style={styles.progressBar}>
              <LinearGradient
                colors={['#10B981', '#059669']}
                style={[styles.progressFill, { width: `${progress.percentage}%` }]}
              />
            </View>
            {progress.missing.length > 0 && (
              <Text style={styles.missingText}>Pending: {progress.missing.join(', ')}</Text>
            )}
          </View>
        </View>

        {/* Organization Details */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Organization Details</Text>

          <View style={styles.formContainer}>
            <LabeledInput
              label="Organization Name"
              value={formData.name}
              onChangeText={(t) => updateFormData('name', t)}
              editable={isEditing}
              icon="🏢"
            />
            <LabeledInput
              label="Registration Number"
              value={formData.registration_number}
              onChangeText={(t) => updateFormData('registration_number', t)}
              editable={isEditing}
              placeholder="(optional)"
              icon="🔢"
            />
            <LabeledInput
              label="Address"
              value={formData.address}
              onChangeText={(t) => updateFormData('address', t)}
              editable={isEditing}
              placeholder="(optional)"
              icon="📍"
            />
            <LabeledInput
              label="Contact Email"
              value={formData.contact_email}
              onChangeText={(t) => updateFormData('contact_email', t)}
              editable={isEditing}
              keyboardType="email-address"
              autoCapitalize="none"
              icon="📧"
            />
            <LabeledInput
              label="Contact Phone"
              value={formData.contact_phone}
              onChangeText={(t) => updateFormData('contact_phone', t)}
              editable={isEditing}
              keyboardType="phone-pad"
              placeholder="(optional)"
              icon="📞"
            />
          </View>

          {isEditing && (
            <View style={styles.saveButtons}>
              <TouchableOpacity
                style={[styles.saveButton, isSaving && { opacity: 0.6 }]}
                onPress={handleSave}
                disabled={isSaving}
              >
                <LinearGradient colors={['#10B981', '#059669']} style={styles.saveButtonGradient}>
                  {isSaving ? (
                    <ActivityIndicator color="#FFFFFF" />
                  ) : (
                    <Text style={styles.saveButtonText}>Save Changes</Text>
                  )}
                </LinearGradient>
              </TouchableOpacity>
              <TouchableOpacity style={styles.cancelButton} onPress={handleCancel}>
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>

        {/* Required Documents */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Required Documents</Text>
          <View style={styles.documentsContainer}>
            {documents.map((document) => (
              <TouchableOpacity
                key={document.id}
                style={styles.documentItem}
                onPress={() => handleUploadDocument(document)}
              >
                <View style={styles.documentLeft}>
                  <Text style={styles.documentIcon}>
                    {document.type === 'business_license'
                      ? '🏢'
                      : document.type === 'insurance_certificate'
                      ? '🛡️'
                      : document.type === 'tax_registration'
                      ? '💰'
                      : '📋'}
                  </Text>
                  <View style={styles.documentInfo}>
                    <Text style={styles.documentName}>{document.name}</Text>
                    <Text style={styles.documentDescription}>{document.description}</Text>
                  </View>
                </View>
                <View
                  style={[
                    styles.documentStatus,
                    {
                      backgroundColor:
                        document.status === 'approved'
                          ? '#10B981'
                          : document.status === 'pending'
                          ? '#F59E0B'
                          : document.status === 'rejected'
                          ? '#EF4444'
                          : '#6B7280',
                    },
                  ]}
                >
                  <Text style={styles.documentStatusText}>
                    {document.status === 'approved'
                      ? '✓'
                      : document.status === 'pending'
                      ? '⏳'
                      : document.status === 'rejected'
                      ? '✗'
                      : '📄'}
                  </Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Verification Status */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Verification Status</Text>
          <View style={styles.badgeRow}>
            <StatusBadge label="Organization" ok={!!org.is_verified} />
            <StatusBadge label="Insurance" ok={!!org.insurance_verified} />
            <StatusBadge label="License" ok={!!org.license_verified} />
          </View>
        </View>

        {/* Account Information */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Account Information</Text>
          <View style={styles.accountInfoCard}>
            <InfoRow label="Organization ID" value={org.id.substring(0, 8) + '...'} />
            <InfoRow label="Owner Email" value={user?.email || ''} />
            <InfoRow
              label="Member Since"
              value={new Date(org.created_at).toLocaleDateString()}
            />
          </View>
        </View>

        {/* Settings */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Settings</Text>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingIcon}>🔔</Text>
              <View style={styles.settingText}>
                <Text style={styles.settingTitle}>Notifications</Text>
                <Text style={styles.settingDescription}>Receive organization updates</Text>
              </View>
            </View>
            <Switch
              value={notifications}
              onValueChange={setNotifications}
              trackColor={{ false: 'rgba(255,255,255,0.1)', true: '#87CEEB' }}
              thumbColor={notifications ? '#0A1929' : '#f4f3f4'}
            />
          </View>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingIcon}>📍</Text>
              <View style={styles.settingText}>
                <Text style={styles.settingTitle}>Location Sharing</Text>
                <Text style={styles.settingDescription}>
                  Share org location with customers
                </Text>
              </View>
            </View>
            <Switch
              value={locationSharing}
              onValueChange={setLocationSharing}
              trackColor={{ false: 'rgba(255,255,255,0.1)', true: '#87CEEB' }}
              thumbColor={locationSharing ? '#0A1929' : '#f4f3f4'}
            />
          </View>
        </View>

        {/* Account Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Account</Text>

          <TouchableOpacity style={styles.actionButton} onPress={handleChangePassword}>
            <Text style={styles.actionIcon}>🔒</Text>
            <Text style={styles.actionText}>Change Password</Text>
            <Text style={styles.actionArrow}>›</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.actionButton} onPress={handleTermsOfService}>
            <Text style={styles.actionIcon}>📄</Text>
            <Text style={styles.actionText}>Terms of Service</Text>
            <Text style={styles.actionArrow}>›</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.actionButton} onPress={handlePrivacyPolicy}>
            <Text style={styles.actionIcon}>🛡️</Text>
            <Text style={styles.actionText}>Privacy Policy</Text>
            <Text style={styles.actionArrow}>›</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.actionButton} onPress={handleHelpSupport}>
            <Text style={styles.actionIcon}>❓</Text>
            <Text style={styles.actionText}>Help & Support</Text>
            <Text style={styles.actionArrow}>›</Text>
          </TouchableOpacity>
        </View>

        {/* Logout Section */}
        <View style={styles.logoutSection}>
          <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
            <Text style={styles.logoutButtonText}>🚪 Log Out</Text>
          </TouchableOpacity>
        </View>

        {/* App Info */}
        <View style={styles.appInfoSection}>
          <Text style={styles.appInfoText}>Wish a Wash v1.0.0</Text>
          <Text style={styles.appInfoText}>© 2024 Wish a Wash. All rights reserved.</Text>
        </View>
      </Animated.ScrollView>

      {/* Document Upload Modal */}
      <Modal visible={showDocumentModal} transparent={true} animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Upload {selectedDocument?.name}</Text>
            <Text style={styles.modalDescription}>{selectedDocument?.description}</Text>

            <View style={styles.modalActions}>
              <TouchableOpacity
                style={[styles.modalButton, uploadingDocument && { opacity: 0.6 }]}
                disabled={uploadingDocument}
                onPress={() => chooseAndUploadDocument('camera')}
              >
                <LinearGradient colors={['#10B981', '#059669']} style={styles.modalButtonGradient}>
                  <Text style={styles.modalButtonText}>
                    {uploadingDocument ? 'Uploading…' : '📸 Take Photo'}
                  </Text>
                </LinearGradient>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.modalButton, uploadingDocument && { opacity: 0.6 }]}
                disabled={uploadingDocument}
                onPress={() => chooseAndUploadDocument('gallery')}
              >
                <LinearGradient colors={['#3B82F6', '#1D4ED8']} style={styles.modalButtonGradient}>
                  <Text style={styles.modalButtonText}>
                    {uploadingDocument ? 'Uploading…' : '🖼️ Choose from Gallery'}
                  </Text>
                </LinearGradient>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.modalButton, styles.modalButtonCancel]}
                onPress={() => setShowDocumentModal(false)}
                disabled={uploadingDocument}
              >
                <Text style={[styles.modalButtonText, { color: '#F9FAFB' }]}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

/* ---------------- Presentational Components ---------------- */

const LabeledInput = ({
  label,
  value,
  onChangeText,
  editable,
  placeholder,
  keyboardType,
  autoCapitalize,
  icon,
}: {
  label: string;
  value: string;
  onChangeText: (t: string) => void;
  editable: boolean;
  placeholder?: string;
  keyboardType?: 'default' | 'email-address' | 'numeric' | 'phone-pad';
  autoCapitalize?: 'none' | 'sentences' | 'words' | 'characters';
  icon?: string;
}) => (
  <View style={styles.inputGroup}>
    <View style={styles.inputLabelRow}>
      {icon && <Text style={styles.inputIcon}>{icon}</Text>}
      <Text style={styles.inputLabel}>{label}</Text>
    </View>
    <TextInput
      style={[styles.input, !editable && styles.inputDisabled]}
      value={value}
      onChangeText={onChangeText}
      editable={editable}
      placeholder={placeholder}
      placeholderTextColor="rgba(135, 206, 235, 0.4)"
      keyboardType={keyboardType}
      autoCapitalize={autoCapitalize}
    />
  </View>
);

const StatusBadge = ({ label, ok }: { label: string; ok: boolean }) => (
  <View style={styles.badge}>
    <Text style={styles.badgeLabel}>{label}</Text>
    <View style={[styles.badgePill, { backgroundColor: ok ? '#10B981' : '#F59E0B' }]}>
      <Text style={styles.badgePillText}>{ok ? 'Verified' : 'Pending'}</Text>
    </View>
  </View>
);

const InfoRow = ({ label, value }: { label: string; value: string }) => (
  <View style={styles.accountInfoRow}>
    <Text style={styles.accountInfoLabel}>{label}:</Text>
    <Text style={styles.accountInfoValue} numberOfLines={1}>
      {value}
    </Text>
  </View>
);

/* ---------------- Styles ---------------- */

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: '#87CEEB',
    fontSize: 16,
    marginTop: 12,
  },
  errorText: {
    color: '#F9FAFB',
    fontSize: 16,
    marginBottom: 20,
  },

  // Decorative bubbles
  bubble: {
    position: 'absolute',
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  bubble1: { top: -20, right: -20 },
  bubble2: { top: 80, left: -40 },

  // Header
  headerWrap: {
    backgroundColor: 'transparent',
    paddingHorizontal: isSmallScreen ? 16 : 20,
    paddingBottom: 12,
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  backButtonCircle: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backIcon: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : 22,
    fontWeight: 'bold',
  },
  editButtonCircle: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135, 206, 235, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135, 206, 235, 0.3)',
  },
  editIcon: {
    fontSize: 16,
  },

  scrollView: {
    flex: 1,
  },

  // Hero Section
  heroSection: {
    padding: isSmallScreen ? 20 : 24,
    alignItems: 'center',
    marginBottom: 0,
  },
  profilePictureContainer: {
    alignItems: 'center',
    marginBottom: 20,
    position: 'relative',
  },
  logoCircle: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    borderWidth: 3,
    borderColor: 'rgba(135, 206, 235, 0.3)',
  },
  logoPlaceholder: {
    width: '100%',
    height: '100%',
    borderRadius: 60,
    backgroundColor: '#87CEEB',
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoInitials: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#0A1929',
  },
  logoImage: {
    width: '100%',
    height: '100%',
    borderRadius: 60,
  },
  uploadButton: {
    position: 'absolute',
    bottom: 12,
    right: 0,
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#87CEEB',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#0A1929',
  },
  uploadButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  verificationBadge: {
    position: 'absolute',
    top: -5,
    right: -5,
    backgroundColor: '#10B981',
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 3,
    borderColor: '#0A1929',
  },
  verificationIcon: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  profileInfo: {
    alignItems: 'center',
  },
  nameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  orgName: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 24 : 28,
    fontWeight: 'bold',
  },
  verificationBadgeSmall: {
    backgroundColor: '#10B981',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    marginLeft: 8,
  },
  verificationIconSmall: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  orgEmail: {
    color: '#87CEEB',
    fontSize: isSmallScreen ? 14 : 16,
    marginBottom: 4,
  },
  orgStatus: {
    color: '#87CEEB',
    fontSize: isSmallScreen ? 14 : 16,
    fontStyle: 'italic',
  },

  // Section
  section: {
    paddingHorizontal: isSmallScreen ? 16 : 20,
    paddingVertical: 20,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.05)',
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 16,
  },

  // Verification Progress
  verificationCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.03)',
    borderRadius: 14,
    padding: 20,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.05)',
  },
  progressHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  progressText: {
    color: '#E5E7EB',
    fontSize: 14,
  },
  progressPercentage: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: 'bold',
  },
  progressBar: {
    height: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 4,
    marginBottom: 8,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 4,
  },
  missingText: {
    color: '#F59E0B',
    fontSize: 12,
  },

  // Form
  formContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.03)',
    borderRadius: 14,
    padding: 20,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.05)',
  },
  inputGroup: {
    marginBottom: 16,
  },
  inputLabelRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  inputIcon: {
    fontSize: 16,
    marginRight: 8,
  },
  inputLabel: {
    fontSize: 14,
    color: '#87CEEB',
    fontWeight: '600',
  },
  input: {
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    borderRadius: 10,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 16,
    color: '#F9FAFB',
    borderWidth: 1,
    borderColor: 'rgba(135, 206, 235, 0.2)',
  },
  inputDisabled: {
    opacity: 0.7,
    backgroundColor: 'rgba(135, 206, 235, 0.05)',
  },
  saveButtons: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 16,
  },
  saveButton: {
    flex: 2,
    borderRadius: 10,
    overflow: 'hidden',
  },
  saveButtonGradient: {
    paddingVertical: 14,
    paddingHorizontal: 20,
    alignItems: 'center',
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 16,
  },
  cancelButton: {
    flex: 1,
    backgroundColor: 'rgba(239, 68, 68, 0.2)',
    paddingVertical: 14,
    paddingHorizontal: 20,
    borderRadius: 10,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(239, 68, 68, 0.3)',
  },
  cancelButtonText: {
    color: '#EF4444',
    fontWeight: 'bold',
    fontSize: 16,
  },

  // Documents
  documentsContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.03)',
    borderRadius: 14,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.05)',
  },
  documentItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.05)',
  },
  documentLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  documentIcon: {
    fontSize: 20,
    marginRight: 12,
    width: 24,
    textAlign: 'center',
  },
  documentInfo: {
    flex: 1,
  },
  documentName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 2,
  },
  documentDescription: {
    color: '#87CEEB',
    fontSize: 12,
  },
  documentStatus: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  documentStatusText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },

  // Badges
  badgeRow: {
    flexDirection: 'row',
    gap: 10,
    flexWrap: 'wrap',
  },
  badge: {
    backgroundColor: 'rgba(255, 255, 255, 0.03)',
    borderRadius: 12,
    padding: 12,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.05)',
  },
  badgeLabel: {
    color: '#F9FAFB',
    fontWeight: '600',
    marginRight: 10,
    fontSize: 14,
  },
  badgePill: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
  },
  badgePillText: {
    color: '#FFFFFF',
    fontWeight: '700',
    fontSize: 12,
  },

  // Account Info
  accountInfoCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.03)',
    borderRadius: 14,
    padding: 20,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.05)',
  },
  accountInfoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.05)',
  },
  accountInfoLabel: {
    fontSize: 14,
    color: '#B0E0E6',
    fontWeight: '500',
    marginRight: 8,
  },
  accountInfoValue: {
    fontSize: 14,
    color: '#87CEEB',
    fontWeight: '600',
    maxWidth: '60%',
    textAlign: 'right',
  },

  // Settings
  settingItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.03)',
    borderRadius: 14,
    padding: 20,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.05)',
  },
  settingInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  settingIcon: {
    fontSize: 20,
    marginRight: 15,
  },
  settingText: {
    flex: 1,
  },
  settingTitle: {
    fontSize: 16,
    color: '#F9FAFB',
    fontWeight: '600',
    marginBottom: 2,
  },
  settingDescription: {
    fontSize: 14,
    color: '#B0E0E6',
  },

  // Action Buttons
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.03)',
    borderRadius: 14,
    padding: 20,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.05)',
  },
  actionIcon: {
    fontSize: 20,
    marginRight: 15,
  },
  actionText: {
    fontSize: 16,
    color: '#F9FAFB',
    fontWeight: '600',
    flex: 1,
  },
  actionArrow: {
    fontSize: 18,
    color: '#87CEEB',
  },

  // Logout
  logoutSection: {
    padding: isSmallScreen ? 16 : 20,
  },
  logoutButton: {
    backgroundColor: 'rgba(239, 68, 68, 0.2)',
    paddingVertical: 16,
    paddingHorizontal: 20,
    borderRadius: 14,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(239, 68, 68, 0.3)',
  },
  logoutButtonText: {
    color: '#EF4444',
    fontSize: 18,
    fontWeight: 'bold',
  },

  // Modal
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#102B6A',
    borderRadius: 20,
    padding: 24,
    margin: 20,
    width: '90%',
    maxWidth: 400,
  },
  modalTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  modalDescription: {
    color: '#E5E7EB',
    fontSize: 14,
    marginBottom: 24,
  },
  modalActions: {
    gap: 12,
  },
  modalButton: {
    borderRadius: 10,
    overflow: 'hidden',
  },
  modalButtonGradient: {
    paddingVertical: 14,
    paddingHorizontal: 16,
    alignItems: 'center',
  },
  modalButtonCancel: {
    backgroundColor: 'rgba(107, 114, 128, 0.3)',
    borderWidth: 1,
    borderColor: 'rgba(107, 114, 128, 0.5)',
    paddingVertical: 14,
    alignItems: 'center',
  },
  modalButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },

  // App Info
  appInfoSection: {
    padding: 20,
    alignItems: 'center',
  },
  appInfoText: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
    marginBottom: 4,
    opacity: 0.7,
  },

  backButton: {
    backgroundColor: '#87CEEB',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
    marginTop: 20,
  },
  backButtonText: {
    color: '#0A1929',
    fontSize: 14,
    fontWeight: '600',
  },
});