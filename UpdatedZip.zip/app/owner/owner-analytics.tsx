// app/owner/OwnerAnalytics.tsx (or wherever you keep it)
import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  RefreshControl,
  ActivityIndicator,
} from 'react-native';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import BookingService from '../../src/services/BookingService';

type SavingsBreakdown = {
  loyaltyRewards: number;
  referralDiscounts: number;
  seasonalOffers: number;
  firstTimeDiscounts: number;
};

type AnalyticsData = {
  totalSpent: number;
  totalBookings: number;
  averageRating: number;
  completedServices: number;
  cancelledServices: number;
  favoriteService: string;
  monthlySpending: number[];      // last 6 months, newest last
  totalSavings: number;
  savingsBreakdown: SavingsBreakdown;
  savingsHistory: number[];       // last 6 months, newest last
  savingsPercentage: number;
  loyaltyPoints: number;
  nextReward: number;             // points needed for next reward
};

const MONTH_WINDOW = 6;

export default function OwnerAnalytics() {
  const { user } = useAuth();
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  // ----- Helpers -----
  const monthsBack = (n: number) => {
    const d = new Date();
    d.setMonth(d.getMonth() - n);
    return new Date(d.getFullYear(), d.getMonth(), 1);
  };

  const rangeStart = useMemo(() => monthsBack(MONTH_WINDOW - 1), []);
  const monthKey = (dt: Date) => `${dt.getFullYear()}-${(dt.getMonth() + 1).toString().padStart(2, '0')}`;

  const emptyAnalytics: AnalyticsData = {
    totalSpent: 0,
    totalBookings: 0,
    averageRating: 0,
    completedServices: 0,
    cancelledServices: 0,
    favoriteService: '—',
    monthlySpending: Array(MONTH_WINDOW).fill(0),
    totalSavings: 0,
    savingsBreakdown: {
      loyaltyRewards: 0,
      referralDiscounts: 0,
      seasonalOffers: 0,
      firstTimeDiscounts: 0,
    },
    savingsHistory: Array(MONTH_WINDOW).fill(0),
    savingsPercentage: 0,
    loyaltyPoints: 0,
    nextReward: 50, // sensible default goal
  };

  // Safe number
  const num = (v: any, fallback = 0) => (Number.isFinite(+v) ? +v : fallback);

  // ----- Load analytics from backend -----
  const loadAnalytics = async () => {
    if (!user?.id) return;

    setLoading(true);
    try {
      // 1) Bookings core aggregates (used by multiple widgets)
      // Expected columns in "bookings": user_id, status, price, rating, service_type, created_at
      const { data: bookingRows, error: bookingsErr } = await supabase
        .from('bookings')
        .select('status, price, rating, service_type, created_at')
        .eq('user_id', user.id)
        .order('created_at', { ascending: true });

      if (bookingsErr) console.warn('[analytics] bookings error:', bookingsErr);

      const rows = bookingRows ?? [];

      const totalSpent = rows
        .filter(r => r.status !== 'cancelled')
        .reduce((sum, r) => sum + num(r.price), 0);

      const totalBookings = rows.length;

      const completed = rows.filter(r => r.status === 'completed');
      const completedServices = completed.length;

      const cancelledServices = rows.filter(r => r.status === 'cancelled').length;

      const avgRating =
        completed.length > 0
          ? +(completed.reduce((s, r) => s + num(r.rating), 0) / completed.length).toFixed(1)
          : 0;

      // Favorite service (most completed count)
      const serviceCount: Record<string, number> = {};
      completed.forEach(r => {
        const key = r.service_type || 'unknown';
        serviceCount[key] = (serviceCount[key] || 0) + 1;
      });
      const favoriteService =
        Object.keys(serviceCount).sort((a, b) => serviceCount[b] - serviceCount[a])[0] || '—';

      // Monthly spending (last 6 months)
      const monthBuckets: Record<string, number> = {};
      const monthSavings: Record<string, number> = {};

      // Optional: discount/savings rows
      // Expected columns in "discounts": user_id, type ('loyalty'|'referral'|'seasonal'|'first_time'|...), amount, created_at
      const { data: discountRows, error: discountsErr } = await supabase
        .from('discounts')
        .select('type, amount, created_at')
        .eq('user_id', user.id)
        .gte('created_at', rangeStart.toISOString());

      if (discountsErr) console.warn('[analytics] discounts error:', discountsErr);

      // init last 6 months
      for (let i = MONTH_WINDOW - 1; i >= 0; i--) {
        const d = monthsBack(i);
        monthBuckets[monthKey(d)] = 0;
        monthSavings[monthKey(d)] = 0;
      }

      rows.forEach(r => {
        const created = new Date(r.created_at);
        if (created >= rangeStart) {
          const k = monthKey(new Date(created.getFullYear(), created.getMonth(), 1));
          if (r.status !== 'cancelled') monthBuckets[k] = num(monthBuckets[k]) + num(r.price);
        }
      });

      (discountRows ?? []).forEach(d => {
        const created = new Date(d.created_at);
        const k = monthKey(new Date(created.getFullYear(), created.getMonth(), 1));
        if (created >= rangeStart) monthSavings[k] = num(monthSavings[k]) + num(d.amount);
      });

      const monthlySpending: number[] = Object.keys(monthBuckets)
        .sort()
        .map(k => Math.round(num(monthBuckets[k])));

      const savingsHistory: number[] = Object.keys(monthSavings)
        .sort()
        .map(k => Math.round(num(monthSavings[k])));

      // Breakdown + totals
      const bd: SavingsBreakdown = { loyaltyRewards: 0, referralDiscounts: 0, seasonalOffers: 0, firstTimeDiscounts: 0 };
      (discountRows ?? []).forEach(d => {
        const amt = num(d.amount);
        const t = String(d.type || '').toLowerCase();
        if (t.includes('loyal')) bd.loyaltyRewards += amt;
        else if (t.includes('ref')) bd.referralDiscounts += amt;
        else if (t.includes('season')) bd.seasonalOffers += amt;
        else if (t.includes('first')) bd.firstTimeDiscounts += amt;
      });
      const totalSavings = Object.values(bd).reduce((s, n) => s + n, 0);

      const baseSpend = totalSpent + totalSavings || 0;
      const savingsPercentage = baseSpend ? +(100 * (totalSavings / baseSpend)).toFixed(1) : 0;

      // Loyalty points (either dedicated table or in profiles)
      // Try loyalty_points table first
      let loyaltyPoints = 0;
      let nextReward = 50;

      const { data: lpRows, error: lpErr } = await supabase
        .from('loyalty_points')
        .select('points,next_reward')
        .eq('user_id', user.id)
        .maybeSingle();

      if (!lpErr && lpRows) {
        loyaltyPoints = num(lpRows.points);
        nextReward = num(lpRows.next_reward, nextReward);
      } else {
        // fallback to profiles.loyalty_points
        const { data: prof, error: profErr } = await supabase
          .from('profiles')
          .select('loyalty_points')
          .eq('id', user.id)
          .maybeSingle();
        if (!profErr && prof?.loyalty_points != null) {
          loyaltyPoints = num(prof.loyalty_points);
        }
      }

      // Final shape
      const analytics: AnalyticsData = {
        totalSpent: Math.round(totalSpent),
        totalBookings,
        averageRating: avgRating,
        completedServices,
        cancelledServices,
        favoriteService,
        monthlySpending,
        totalSavings: Math.round(totalSavings),
        savingsBreakdown: {
          loyaltyRewards: Math.round(bd.loyaltyRewards),
          referralDiscounts: Math.round(bd.referralDiscounts),
          seasonalOffers: Math.round(bd.seasonalOffers),
          firstTimeDiscounts: Math.round(bd.firstTimeDiscounts),
        },
        savingsHistory,
        savingsPercentage,
        loyaltyPoints,
        nextReward,
      };

      setData(analytics);
    } catch (e) {
      console.error('[analytics] unexpected error:', e);
      setData(emptyAnalytics);
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadAnalytics();
    setRefreshing(false);
  };

  useEffect(() => {
    loadAnalytics();
  }, [user?.id]);

  const analyticsData = data ?? emptyAnalytics;

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView
        style={styles.scrollView}
        refreshControl={<RefreshControl tintColor="#CBE3FF" refreshing={refreshing} onRefresh={onRefresh} />}
      >
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Analytics</Text>
          <View style={styles.placeholder} />
        </View>

        {loading ? (
          <View style={{ padding: 24, alignItems: 'center' }}>
            <ActivityIndicator color="#CBE3FF" />
            <Text style={{ color: '#CBE3FF', marginTop: 8 }}>Loading analytics…</Text>
          </View>
        ) : (
          <>
            {/* Overview Stats */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Overview</Text>
              <View style={styles.statsGrid}>
                <View style={styles.statCard}>
                  <Text style={styles.statNumber}>£{analyticsData.totalSpent}</Text>
                  <Text style={styles.statLabel}>Total Spent</Text>
                </View>
                <View style={styles.statCard}>
                  <Text style={styles.statNumber}>{analyticsData.totalBookings}</Text>
                  <Text style={styles.statLabel}>Total Bookings</Text>
                </View>
                <View style={styles.statCard}>
                  <Text style={styles.statNumber}>{analyticsData.averageRating}⭐</Text>
                  <Text style={styles.statLabel}>Avg Rating</Text>
                </View>
                <View style={styles.statCard}>
                  <Text style={styles.statNumber}>{analyticsData.completedServices}</Text>
                  <Text style={styles.statLabel}>Completed</Text>
                </View>
              </View>
            </View>

            {/* Customer Savings Section */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>💰 Customer Savings</Text>

              {/* Total Savings Card */}
              <View style={styles.savingsCard}>
                <View style={styles.savingsHeader}>
                  <Text style={styles.savingsTitle}>Total Savings</Text>
                  <Text style={styles.savingsPercentage}>{analyticsData.savingsPercentage}%</Text>
                </View>
                <Text style={styles.savingsAmount}>£{analyticsData.totalSavings}</Text>
                <Text style={styles.savingsSubtitle}>Saved compared to regular prices</Text>
              </View>

              {/* Savings Breakdown */}
              <View style={styles.savingsBreakdown}>
                <Text style={styles.breakdownTitle}>Savings Breakdown</Text>
                <BreakdownRow label="🎯 Loyalty Rewards" desc="Points-based discounts" amount={analyticsData.savingsBreakdown.loyaltyRewards} />
                <BreakdownRow label="👥 Referral Discounts" desc="Friend referral bonuses" amount={analyticsData.savingsBreakdown.referralDiscounts} />
                <BreakdownRow label="🎄 Seasonal Offers" desc="Holiday and special promotions" amount={analyticsData.savingsBreakdown.seasonalOffers} />
                <BreakdownRow label="🎁 First-Time Discounts" desc="Welcome offers" amount={analyticsData.savingsBreakdown.firstTimeDiscounts} />
              </View>

              {/* Loyalty Points */}
              <View style={styles.loyaltyCard}>
                <View style={styles.loyaltyHeader}>
                  <Text style={styles.loyaltyTitle}>🎖️ Loyalty Points</Text>
                  <Text style={styles.loyaltyPoints}>{analyticsData.loyaltyPoints} pts</Text>
                </View>
                <View style={styles.loyaltyProgress}>
                  <View style={styles.progressBar}>
                    <View
                      style={[
                        styles.progressFill,
                        {
                          width: `${
                            (analyticsData.loyaltyPoints /
                              (analyticsData.loyaltyPoints + Math.max(analyticsData.nextReward, 1))) *
                            100
                          }%`,
                        },
                      ]}
                    />
                  </View>
                  <Text style={styles.progressText}>
                    {analyticsData.nextReward} more points for next reward
                  </Text>
                </View>
              </View>
            </View>

            {/* Service Breakdown */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Service Breakdown</Text>
              <View style={styles.serviceCard}>
                <Text style={styles.serviceTitle}>Favorite Service</Text>
                <Text style={styles.serviceValue}>{analyticsData.favoriteService}</Text>
              </View>
              <View style={styles.serviceCard}>
                <Text style={styles.serviceTitle}>Cancelled Services</Text>
                <Text style={styles.serviceValue}>{analyticsData.cancelledServices}</Text>
              </View>
            </View>

            {/* Monthly Spending */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Monthly Spending</Text>
              <Bars values={analyticsData.monthlySpending} barStyle={styles.bar} />
            </View>

            {/* Monthly Savings */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Monthly Savings</Text>
              <Bars values={analyticsData.savingsHistory} barStyle={styles.savingsBar} />
            </View>

            {/* Quick Actions */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Quick Actions</Text>
              <TouchableOpacity style={styles.actionButton} onPress={() => router.push('/unified-booking')}>
                <Text style={styles.actionButtonText}>📅 Book New Service</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.actionButton} onPress={() => router.push('/owner-profile')}>
                <Text style={styles.actionButtonText}>👤 View Profile</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.actionButton} onPress={() => router.push('/rewards-system')}>
                <Text style={styles.actionButtonText}>🎁 View Rewards</Text>
              </TouchableOpacity>
            </View>
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

/* ---------- Small presentational helpers ---------- */
function BreakdownRow({ label, desc, amount }: { label: string; desc: string; amount: number }) {
  return (
    <View style={styles.breakdownItem}>
      <View style={styles.breakdownInfo}>
        <Text style={styles.breakdownLabel}>{label}</Text>
        <Text style={styles.breakdownDescription}>{desc}</Text>
      </View>
      <Text style={styles.breakdownAmount}>£{amount}</Text>
    </View>
  );
}

function Bars({ values, barStyle }: { values: number[]; barStyle: any }) {
  const max = Math.max(1, ...values);
  return (
    <View style={styles.chartContainer}>
      {values.map((amount, i) => {
        const h = (amount / max) * 100;
        return (
          <View key={i} style={styles.barContainer}>
            <View style={[barStyle, { height: `${h}%` }]} />
            <Text style={styles.barLabel}>£{amount}</Text>
          </View>
        );
      })}
    </View>
  );
}

/* -------------------- Styles -------------------- */
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A1929' },
  scrollView: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1E3A8A',
  },
  backButton: { padding: 8 },
  backButtonText: { color: '#87CEEB', fontSize: 16 },
  headerTitle: { color: '#F9FAFB', fontSize: 20, fontWeight: 'bold' },
  placeholder: { width: 50 },

  section: { padding: 20 },
  sectionTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: '600', marginBottom: 15 },

  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' },
  statCard: {
    width: '48%',
    backgroundColor: '#1E3A8A',
    padding: 15,
    borderRadius: 12,
    marginBottom: 10,
    alignItems: 'center',
  },
  statNumber: { fontSize: 20, fontWeight: 'bold', color: '#F9FAFB', marginBottom: 4 },
  statLabel: { fontSize: 12, color: '#87CEEB', textAlign: 'center' },

  // Savings Styles
  savingsCard: { backgroundColor: '#10B981', padding: 20, borderRadius: 12, marginBottom: 15, alignItems: 'center' },
  savingsHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', width: '100%', marginBottom: 10 },
  savingsTitle: { color: '#FFFFFF', fontSize: 16, fontWeight: '600' },
  savingsPercentage: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: 'bold',
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  savingsAmount: { color: '#FFFFFF', fontSize: 32, fontWeight: 'bold', marginBottom: 5 },
  savingsSubtitle: { color: '#FFFFFF', fontSize: 14, opacity: 0.9 },

  savingsBreakdown: { backgroundColor: '#1E3A8A', padding: 15, borderRadius: 12, marginBottom: 15 },
  breakdownTitle: { color: '#F9FAFB', fontSize: 16, fontWeight: '600', marginBottom: 12 },
  breakdownItem: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  breakdownInfo: { flex: 1 },
  breakdownLabel: { color: '#F9FAFB', fontSize: 14, fontWeight: '500' },
  breakdownDescription: { color: '#87CEEB', fontSize: 12, marginTop: 2 },
  breakdownAmount: { color: '#10B981', fontSize: 16, fontWeight: 'bold' },

  loyaltyCard: { backgroundColor: '#1E3A8A', padding: 15, borderRadius: 12, marginBottom: 15 },
  loyaltyHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  loyaltyTitle: { color: '#F9FAFB', fontSize: 16, fontWeight: '600' },
  loyaltyPoints: { color: '#FFD700', fontSize: 18, fontWeight: 'bold' },
  loyaltyProgress: { alignItems: 'center' },
  progressBar: { width: '100%', height: 8, backgroundColor: 'rgba(255,255,255,0.2)', borderRadius: 4, marginBottom: 8 },
  progressFill: { height: '100%', backgroundColor: '#FFD700', borderRadius: 4 },
  progressText: { color: '#87CEEB', fontSize: 12, textAlign: 'center' },

  serviceCard: {
    backgroundColor: '#1E3A8A', padding: 15, borderRadius: 12, marginBottom: 10,
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
  },
  serviceTitle: { color: '#F9FAFB', fontSize: 16 },
  serviceValue: { color: '#87CEEB', fontSize: 16, fontWeight: '600' },

  chartContainer: {
    flexDirection: 'row', justifyContent: 'space-around', alignItems: 'flex-end',
    height: 120, backgroundColor: '#1E3A8A', padding: 20, borderRadius: 12,
  },
  barContainer: { alignItems: 'center' },
  bar: { width: 20, backgroundColor: '#87CEEB', borderRadius: 10, marginBottom: 8 },
  savingsBar: { width: 20, backgroundColor: '#10B981', borderRadius: 10, marginBottom: 8 },
  barLabel: { color: '#F9FAFB', fontSize: 12 },

  actionButton: { backgroundColor: '#1E3A8A', padding: 15, borderRadius: 12, marginBottom: 10, alignItems: 'center' },
  actionButtonText: { color: '#F9FAFB', fontSize: 16, fontWeight: '600' },
});