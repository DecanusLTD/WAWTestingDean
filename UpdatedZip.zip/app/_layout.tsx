// app/_layout.tsx (RootLayout)
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { AuthProvider } from '../src/providers/enhanced-auth-context';
import { useEffect, useRef, useState } from 'react';
import { LogBox, Platform } from 'react-native';
import * as SplashScreen from 'expo-splash-screen';
import { StripeProvider } from '@stripe/stripe-react-native';

// Make splash manual and guard errors
(async () => {
  try {
    console.log('[Splash] preventAutoHideAsync()');
    await SplashScreen.preventAutoHideAsync();
  } catch (e) {
    console.warn('[Splash] preventAutoHideAsync error:', e);
  }
})();

LogBox.ignoreLogs([
  'Non-serializable values were found in the navigation state',
  'AsyncStorage has been extracted from react-native',
]);

export default function RootLayout() {
  const [appReady, setAppReady] = useState(false);
  const hideOnceRef = useRef(false);

  useEffect(() => {
    (async () => {
      try {
        console.log('[RootLayout] boot starting');
        // If you load fonts/assets, await them here.
        // await Font.loadAsync(...)
        await new Promise(requestAnimationFrame);
        setAppReady(true);
      } catch (e) {
        console.error('[RootLayout] boot error:', e);
        setAppReady(true); // don’t deadlock the splash
      }
    })();
  }, []);

  useEffect(() => {
    const hide = async () => {
      if (appReady && !hideOnceRef.current) {
        hideOnceRef.current = true;
        try {
          console.log('[Splash] hideAsync()');
          await SplashScreen.hideAsync();
        } catch (e) {
          console.warn('[Splash] hideAsync error:', e);
        }
      }
    };
    hide();
  }, [appReady]);

  return (
    <StripeProvider
      publishableKey="pk_test_51S3OQLGYkpu3JDyWrHRRw6kvG9t4BNGpCiFVDAUeQCptnXAFJYnNEyWyv1HJG7XYsOd7Io4qYAn9T4deCcYUu2zC00O9yRUMdU"  // <-- put your PK here
      merchantIdentifier="merchant.com.wishawash"                                   // Apple Pay (iOS)
      urlScheme="wishawash"                                                         // Optional: 3DS redirect on Android
    >
      <AuthProvider>
        <StatusBar style="light" backgroundColor="#1E3A8A" />
        <Stack
          screenOptions={{
            headerShown: false,
            contentStyle: { backgroundColor: '#0A1929' },
            animation: Platform.OS === 'android' ? 'slide_from_right' : 'default',
            gestureEnabled: false,
          }}
        />
      </AuthProvider>
    </StripeProvider>
  );
}