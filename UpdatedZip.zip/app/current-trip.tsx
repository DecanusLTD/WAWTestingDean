// app/current-trip.tsx
import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  Animated,
  Dimensions,
  Alert,
  Platform,
  AppState,
} from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../src/providers/enhanced-auth-context';
import { LinearGradient } from 'expo-linear-gradient';
import { supabase } from '../src/lib/supabase';
import { hapticFeedback } from '../src/services/HapticFeedbackService';
import * as Location from 'expo-location';
import MapView, { Marker, Polyline, Region, LatLng } from 'react-native-maps';

const MAPBOX_TOKEN = 'pk.eyJ1IjoidHlzb24tMXN0IiwiYSI6ImNtZWtkaTk5dTAxYW0yaXF0bDVieTV6YTEifQ.-HXgTa_8yHcMRQzAeJBfFg';
const { height, width } = Dimensions.get('window');

const BG = '#0A1929';
const ACCENT = '#10B981';

// FIXED: Added missing payment workflow statuses
type BookingStatus =
  | 'pending'
  | 'pending_valeter_acceptance'
  | 'valeter_declined'
  | 'valeter_timeout'
  | 'pending_payment'
  | 'payment_timeout'
  | 'scheduled'
  | 'confirmed'
  | 'valeter_assigned'
  | 'en_route'
  | 'arrived'
  | 'in_progress'
  | 'completed'
  | 'cancelled';

type DbBooking = {
  id: string;
  user_id: string;
  service_type: string;
  service_name: string | null;
  price: number;
  status: BookingStatus;
  location_address: string | null;
  location_lat: number | null;
  location_lng: number | null;
  created_at: string;
  updated_at: string;
  valeter_id: string | null;
  eta_minutes: number | null;
  driver_lat: number | null;
  driver_lng: number | null;
  driver_location: string | null;
  payment_completed_at: string | null; // ADDED: Track when payment is completed
};

type UserRole = 'customer' | 'valeter' | 'organization' | null;

function decodePolyline6(polyline: string): LatLng[] {
  let index = 0;
  const len = polyline.length;
  let lat = 0;
  let lng = 0;
  const coords: LatLng[] = [];

  const shiftAndMask = () => {
    let result = 0;
    let shift = 0;
    let b: number;
    do {
      b = polyline.charCodeAt(index++) - 63;
      result |= (b & 0x1f) << shift;
      shift += 5;
    } while (b >= 0x20);
    return (result & 1) ? ~(result >> 1) : (result >> 1);
  };

  while (index < len) {
    lat += shiftAndMask();
    lng += shiftAndMask();
    coords.push({ latitude: lat / 1e6, longitude: lng / 1e6 });
  }
  return coords;
}

async function fetchMapboxRoute(
  origin: { lat: number; lng: number },
  dest: { lat: number; lng: number }
) {
  if (!MAPBOX_TOKEN) throw new Error('Missing MAPBOX_TOKEN');

  const url =
    `https://api.mapbox.com/directions/v5/mapbox/driving/` +
    `${origin.lng},${origin.lat};${dest.lng},${dest.lat}` +
    `?alternatives=false&geometries=polyline6&overview=full&steps=false&access_token=${MAPBOX_TOKEN}`;

  const res = await fetch(url);
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Mapbox Directions error ${res.status}: ${body}`);
  }
  const json = await res.json();
  const route = json?.routes?.[0];
  if (!route) throw new Error('No route returned from Mapbox');

  const coords = decodePolyline6(route.geometry);
  const durationSec = route.duration as number;
  const distanceMeters = route.distance as number;

  return {
    coords,
    durationMin: Math.max(1, Math.round(durationSec / 60)),
    distanceKm: Math.round((distanceMeters / 1000) * 10) / 10,
  };
}

export default function CurrentTrip() {
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const bookingIdParam = params.bookingId as string | undefined;

  const [booking, setBooking] = useState<DbBooking | null>(null);
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);
  const [loading, setLoading] = useState(true);

  const [viewerRole, setViewerRole] = useState<UserRole>(null);
  const [routeCoords, setRouteCoords] = useState<LatLng[] | null>(null);
  const [distanceKm, setDistanceKm] = useState<number | null>(null);
  const [region, setRegion] = useState<Region | undefined>(undefined);

  const pulseAnim = useRef(new Animated.Value(1)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 800, useNativeDriver: true }).start();

    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1.15, duration: 1000, useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 1, duration: 1000, useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, []);

  // Load viewer role
  useEffect(() => {
    let mounted = true;
    (async () => {
      if (user?.userType && mounted) {
        setViewerRole(user.userType as UserRole);
        return;
      }
      if (!user?.id) return;

      const { data, error } = await supabase
        .from('profiles')
        .select('user_type, role')
        .eq('id', user.id)
        .single();

      if (!mounted) return;
      if (!error) {
        const dbType = (data?.user_type || data?.role || null) as UserRole;
        setViewerRole(dbType);
      }
    })();
    return () => { mounted = false; };
  }, [user?.id, user?.userType]);

  const fetchCurrentJob = async () => {
    if (!user) return;
    setLoading(true);
    try {
      let row: DbBooking | null = null;

      if (bookingIdParam) {
        const { data, error } = await supabase
          .from('bookings')
          .select('*')
          .eq('id', bookingIdParam)
          .maybeSingle<DbBooking>();
        if (error) throw error;
        row = data ?? null;
      } else {
        const { data, error } = await supabase
          .from('bookings')
          .select('*')
          .or(`valeter_id.eq.${user.id},user_id.eq.${user.id}`)
          .in('status', [
            'pending_valeter_acceptance',
            'pending_payment',
            'confirmed',
            'scheduled',
            'valeter_assigned',
            'en_route',
            'arrived',
            'in_progress'
          ])
          .order('created_at', { ascending: false })
          .limit(1)
          .returns<DbBooking[]>();
        if (error) throw error;
        row = data?.[0] ?? null;
      }

      setBooking(row);

      if (row?.location_lat && row?.location_lng) {
        setRegion({
          latitude: row.location_lat,
          longitude: row.location_lng,
          latitudeDelta: 0.05,
          longitudeDelta: 0.05,
        });
      }
    } catch (e) {
      console.error('[CurrentTrip] load error:', e);
      setBooking(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCurrentJob();
  }, []);

  // Add listener for when app comes to foreground (after payment completion)
  useEffect(() => {
    const handleAppStateChange = (nextAppState: string) => {
      if (nextAppState === 'active' && booking?.id) {
        console.log('[CurrentTrip] App became active, refreshing booking data...');
        fetchCurrentJob();
      }
    };

    const subscription = AppState.addEventListener('change', handleAppStateChange);
    return () => subscription?.remove();
  }, [booking?.id]);

  useEffect(() => {
    if (!booking?.id) return;
    const channel = supabase
      .channel(`booking:${booking.id}`)
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'bookings', filter: `id=eq.${booking.id}` },
        (payload) => {
          console.log('[CurrentTrip] Real-time update received:', payload.new);
          setBooking(payload.new as DbBooking);
        }
      )
      .subscribe();

    // Add polling as fallback for payment status updates
    const pollInterval = setInterval(async () => {
      if (booking.status === 'confirmed' && !booking.payment_completed_at) {
        console.log('[CurrentTrip] Polling for payment completion...');
        try {
          const { data, error } = await supabase
            .from('bookings')
            .select('*')
            .eq('id', booking.id)
            .single();

          if (!error && data && data.payment_completed_at !== booking.payment_completed_at) {
            console.log('[CurrentTrip] Payment status changed via polling:', data.payment_completed_at);
            setBooking(data as DbBooking);
          }
        } catch (e) {
          console.warn('[CurrentTrip] Polling error:', e);
        }
      }
    }, 2000); // Poll every 2 seconds when waiting for payment

    return () => {
      supabase.removeChannel(channel);
      clearInterval(pollInterval);
    };
  }, [booking?.id, booking?.status, booking?.payment_completed_at]);

  const isValeter = Boolean(user && booking && user.id === booking.valeter_id);
  const isCustomer = Boolean(user && booking && user.id === booking.user_id);
  const isCustomerView = viewerRole === 'customer';
  const isCustomerEffective = isCustomer || isCustomerView;

  // FIXED: Check payment completion before allowing journey to start
  const canStartJourney = (booking: DbBooking): boolean => {
    return booking.status === 'confirmed' && booking.payment_completed_at !== null;
  };

  const getNextBookingStatus = (s: BookingStatus | undefined): BookingStatus | null => {
    switch (s) {
      case 'confirmed': return 'en_route'; // Only after payment is completed
      case 'en_route': return 'arrived';
      case 'arrived': return 'in_progress';
      case 'in_progress': return 'completed';
      case 'completed':
      case 'cancelled': return null;
      case 'scheduled':
      case 'valeter_assigned':
      default: return 'en_route';
    }
  };

  // FIXED: Handle payment workflow statuses properly
  const getStatusInfo = (status: BookingStatus | undefined, booking?: DbBooking): { text: string; icon: string; color: string; progress: number } => {
    switch (status) {
      case 'pending_valeter_acceptance':
        return { text: 'Waiting for response', icon: '⏳', color: '#F59E0B', progress: 5 };
      case 'pending_payment':
        return isValeter
          ? { text: 'Waiting for payment', icon: '💳', color: '#F59E0B', progress: 15 }
          : { text: 'Payment required', icon: '💳', color: '#F59E0B', progress: 15 };
      case 'confirmed':
        // FIXED: Check if payment is actually completed
        if (booking?.payment_completed_at) {
          return isValeter
            ? { text: 'Ready to start', icon: '🚀', color: '#10B981', progress: 25 }
            : { text: 'Valeter preparing', icon: '🚀', color: '#10B981', progress: 25 };
        } else {
          return isValeter
            ? { text: 'Awaiting payment', icon: '💳', color: '#F59E0B', progress: 15 }
            : { text: 'Payment processing', icon: '💳', color: '#F59E0B', progress: 15 };
        }
      case 'en_route':
        return { text: 'On the way', icon: '🚗', color: '#10B981', progress: 33 };
      case 'arrived':
        return { text: 'Arrived', icon: '📍', color: '#3B82F6', progress: 66 };
      case 'in_progress':
        return { text: 'In Progress', icon: '🧽', color: '#8B5CF6', progress: 90 };
      case 'completed':
        return { text: 'Completed', icon: '✨', color: '#059669', progress: 100 };
      case 'cancelled':
        return { text: 'Cancelled', icon: '❌', color: '#EF4444', progress: 0 };
      case 'valeter_declined':
        return { text: 'Declined', icon: '❌', color: '#EF4444', progress: 0 };
      case 'valeter_timeout':
        return { text: 'Timed out', icon: '⏰', color: '#EF4444', progress: 0 };
      default:
        return { text: 'Finding valeter', icon: '🔍', color: '#6B7280', progress: 10 };
    }
  };

  const getNextActionText = (current: BookingStatus | undefined): string => {
    const next = getNextBookingStatus(current);
    if (!next) return 'Complete';
    switch (next) {
      case 'en_route': return 'Start Journey';
      case 'arrived': return 'Mark Arrived';
      case 'in_progress': return 'Start Wash';
      case 'completed': return 'Complete Job';
      default: return 'Update';
    }
  };

  async function getDriverPosition() {
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') throw new Error('Location permission not granted');
    const pos = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
    const lat = pos.coords.latitude;
    const lng = pos.coords.longitude;
    let driverLocation: string | null = null;
    try {
      const rg = await Location.reverseGeocodeAsync({ latitude: lat, longitude: lng });
      if (rg && rg[0]) {
        const r = rg[0];
        driverLocation = [r.name, r.city ?? r.subregion, r.region].filter(Boolean).join(', ') || null;
      }
    } catch {}
    return { lat, lng, driverLocation };
  }

  const updateToNextStatus = async () => {
    if (!booking) return;
    if (!isValeter) {
      Alert.alert('Read-only', 'Only the assigned valeter can update the job status.');
      return;
    }

    const current = booking.status;

    // FIXED: Prevent starting journey if payment not completed
    if (current === 'confirmed' && !canStartJourney(booking)) {
      Alert.alert(
        'Payment Required',
        'Cannot start journey until customer completes payment. Please wait for payment confirmation.',
        [{ text: 'OK' }]
      );
      return;
    }

    const next = getNextBookingStatus(current);
    if (!next) return;

    try {
      await hapticFeedback('medium');
    } catch {}

    const go = async () => {
      setIsUpdatingStatus(true);
      try {
        const payload: Record<string, any> = {
          status: next,
          updated_at: new Date().toISOString(),
        };

        if (next === 'en_route') {
          if (!(booking.location_lat && booking.location_lng)) {
            throw new Error('This booking has no destination lat/lng set.');
          }

          const { lat, lng, driverLocation } = await getDriverPosition();

          let mapboxEtaMin: number | null = null;
          try {
            const route = await fetchMapboxRoute(
              { lat, lng },
              { lat: booking.location_lat, lng: booking.location_lng }
            );
            setRouteCoords(route.coords);
            setDistanceKm(route.distanceKm);

            if (!region) {
              const midLat = (lat + booking.location_lat) / 2;
              const midLng = (lng + booking.location_lng) / 2;
              setRegion({
                latitude: midLat,
                longitude: midLng,
                latitudeDelta: Math.abs(lat - booking.location_lat) * 1.8 || 0.05,
                longitudeDelta: Math.abs(lng - booking.location_lng) * 1.8 || 0.05,
              });
            }

            mapboxEtaMin = route.durationMin;
          } catch (mbxErr) {
            console.warn('[CurrentTrip] Mapbox route failed:', mbxErr);
          }

          payload.driver_lat = lat;
          payload.driver_lng = lng;
          payload.driver_location = driverLocation;
          if (mapboxEtaMin != null) payload.eta_minutes = mapboxEtaMin;
        } else if (next === 'arrived') {
          payload.eta_minutes = 0;
        }

        const { data, error } = await supabase
          .from('bookings')
          .update(payload)
          .eq('id', booking.id)
          .select()
          .single();

        if (error) throw error;
        setBooking(data as DbBooking);
        Alert.alert('Updated', `Status updated to ${next}`);
      } catch (e) {
        console.error('[CurrentTrip] status update error:', e);
        await fetchCurrentJob();
        Alert.alert('Update Failed', (e as Error)?.message || 'Failed to update status. Please try again.');
      } finally {
        setIsUpdatingStatus(false);
      }
    };

    Alert.alert('Update Status', `Move to: ${next}?`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Confirm', onPress: go },
    ]);
  };

  const cancelRequest = async () => {
    if (!booking || !isCustomerEffective) return;
    const allowable = booking.status === 'scheduled' || booking.status === 'valeter_assigned' || booking.status === 'pending_valeter_acceptance' || booking.status === 'pending_payment';
    if (!allowable) {
      Alert.alert('Cannot cancel', 'You can only cancel before a valeter is on the way.');
      return;
    }

    try {
      await hapticFeedback('medium');
    } catch {}

    Alert.alert(
      'Cancel Request?',
      'This will cancel your wash request.',
      [
        { text: 'Keep waiting', style: 'cancel' },
        {
          text: 'Cancel request',
          style: 'destructive',
          onPress: async () => {
            try {
              const { data, error } = await supabase
                .from('bookings')
                .update({
                  status: 'cancelled',
                  updated_at: new Date().toISOString(),
                  valeter_id: null,
                })
                .eq('id', booking.id)
                .eq('user_id', booking.user_id)
                .select()
                .single();

              if (error) throw error;
              setBooking(data as DbBooking);
              Alert.alert('Cancelled', 'Your request has been cancelled.');
              router.replace('/owner/owner-dashboard');
            } catch (e) {
              console.error('[CurrentTrip] cancel error:', e);
              Alert.alert('Cancel failed', 'Please try again in a moment.');
            }
          },
        },
      ]
    );
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <Animated.View style={{ transform: [{ scale: pulseAnim }] }}>
            <Text style={styles.loadingIcon}>🧽</Text>
          </Animated.View>
          <Text style={styles.loadingText}>Loading trip...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!booking) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyIcon}>🚗</Text>
          <Text style={styles.emptyTitle}>No Active Trip</Text>
          <Text style={styles.emptyText}>
            You don't have an active trip right now.
          </Text>
          <TouchableOpacity
            style={styles.emptyButton}
            onPress={() => router.back()}
            activeOpacity={0.8}
          >
            <LinearGradient colors={[ACCENT, '#059669']} style={styles.emptyButtonGrad}>
              <Text style={styles.emptyButtonText}>Go Back</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const statusInfo = getStatusInfo(booking.status, booking);
  const showDriver = booking.driver_lat != null && booking.driver_lng != null;
  const showDest = booking.location_lat != null && booking.location_lng != null;
  const canCustomerCancel = isCustomerEffective && (
    booking.status === 'scheduled' ||
    booking.status === 'valeter_assigned' ||
    booking.status === 'pending_valeter_acceptance' ||
    booking.status === 'pending_payment'
  );

  // FIXED: Only show action button if valeter can actually take the next action
  const canTakeAction = isValeter && booking.status !== 'completed' && booking.status !== 'cancelled' && getNextBookingStatus(booking.status);
  const canActuallyStart = booking.status !== 'confirmed' || canStartJourney(booking);

  return (
    <SafeAreaView style={styles.container}>
      {/* Close Button */}
      <TouchableOpacity
        style={styles.closeBtn}
        onPress={() => router.back()}
        activeOpacity={0.85}
      >
        <Text style={styles.closeBtnText}>✕</Text>
      </TouchableOpacity>

      {/* Map */}
      <View style={styles.mapContainer}>
        {showDest ? (
          <MapView
            style={StyleSheet.absoluteFill}
            initialRegion={
              region || {
                latitude: booking.location_lat!,
                longitude: booking.location_lng!,
                latitudeDelta: 0.05,
                longitudeDelta: 0.05,
              }
            }
            onRegionChangeComplete={setRegion}
            mapType={Platform.OS === 'ios' ? 'standard' : 'standard'}
          >
            {showDest && (
              <Marker
                coordinate={{ latitude: booking.location_lat!, longitude: booking.location_lng! }}
                title="Destination"
              >
                <Text style={{ fontSize: 28 }}>📍</Text>
              </Marker>
            )}
            {showDriver && (
              <Marker
                coordinate={{ latitude: booking.driver_lat!, longitude: booking.driver_lng! }}
                title="Valeter"
              >
                <Text style={{ fontSize: 28 }}>🚗</Text>
              </Marker>
            )}
            {routeCoords && routeCoords.length > 1 && (
              <Polyline
                coordinates={routeCoords}
                strokeWidth={4}
                strokeColor={ACCENT}
              />
            )}
          </MapView>
        ) : (
          <View style={styles.mapPlaceholder}>
            <Text style={styles.mapPlaceholderIcon}>🗺️</Text>
            <Text style={styles.mapPlaceholderText}>No location set</Text>
          </View>
        )}

        {/* Map Overlay Hint */}
        <View style={styles.mapOverlay}>
          <View style={styles.mapHintBox}>
            <Text style={styles.mapHint}>{isValeter ? 'Your active trip' : 'Tracking your wash'}</Text>
          </View>
        </View>
      </View>

      {/* Bottom Drawer */}
      <Animated.View style={[styles.drawer, { opacity: fadeAnim }]}>
        {/* Status Header */}
        <View style={styles.drawerHeader}>
          <Animated.View
            style={[
              styles.statusDot,
              { backgroundColor: statusInfo.color, transform: [{ scale: pulseAnim }] }
            ]}
          />
          <Text style={styles.statusText}>
            {statusInfo.icon} {statusInfo.text}
          </Text>
        </View>

        {/* ADDED: Payment status indicator for valeters */}
        {isValeter && booking.status === 'confirmed' && !booking.payment_completed_at && (
          <View style={styles.paymentWarning}>
            <Text style={styles.paymentWarningText}>⏳ Waiting for customer payment to complete...</Text>
          </View>
        )}

        {/* Progress Bar */}
        <View style={styles.progressContainer}>
          <View style={styles.progressBar}>
            <LinearGradient
              colors={[statusInfo.color, statusInfo.color]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={[styles.progressFill, { width: `${statusInfo.progress}%` }]}
            />
          </View>
          <View style={styles.progressLabels}>
            <Text style={styles.progressLabel}>En route</Text>
            <Text style={styles.progressLabel}>Arrived</Text>
            <Text style={styles.progressLabel}>Washing</Text>
            <Text style={styles.progressLabel}>Done</Text>
          </View>
        </View>

        {/* Info Cards */}
        <View style={styles.infoGrid}>
          <View style={styles.infoCard}>
            <Text style={styles.infoLabel}>Service</Text>
            <Text style={styles.infoValue}>{booking.service_name || booking.service_type || '—'}</Text>
          </View>
          <View style={styles.infoCard}>
            <Text style={styles.infoLabel}>Price</Text>
            <Text style={styles.infoValue}>£{Number(booking.price || 0).toFixed(2)}</Text>
          </View>
          <View style={styles.infoCard}>
            <Text style={styles.infoLabel}>ETA</Text>
            <Text style={styles.infoValue}>
              {booking.eta_minutes != null ? `${booking.eta_minutes} min` : '—'}
            </Text>
          </View>
          {distanceKm != null && (
            <View style={styles.infoCard}>
              <Text style={styles.infoLabel}>Distance</Text>
              <Text style={styles.infoValue}>{distanceKm} km</Text>
            </View>
          )}
        </View>

        {/* Location */}
        <View style={styles.locationBox}>
          <Text style={styles.locationLabel}>📍 Location</Text>
          <Text style={styles.locationText}>{booking.location_address || 'No address provided'}</Text>
        </View>

        {/* Actions */}
        {canTakeAction && canActuallyStart && (
          <TouchableOpacity
            style={[
              styles.actionBtn,
              { opacity: isUpdatingStatus ? 0.6 : 1 }
            ]}
            onPress={updateToNextStatus}
            disabled={isUpdatingStatus}
            activeOpacity={0.8}
          >
            <LinearGradient
              colors={[statusInfo.color, statusInfo.color]}
              style={styles.actionBtnGrad}
            >
              <Text style={styles.actionBtnText}>
                {isUpdatingStatus ? '⏳ Updating...' : `${getStatusInfo(getNextBookingStatus(booking.status) || 'completed').icon} ${getNextActionText(booking.status)}`}
              </Text>
            </LinearGradient>
          </TouchableOpacity>
        )}

        {canCustomerCancel && (
          <TouchableOpacity
            style={styles.cancelButton}
            onPress={cancelRequest}
            activeOpacity={0.8}
          >
            <Text style={styles.cancelButtonText}>Cancel Request</Text>
          </TouchableOpacity>
        )}

        {!isValeter && !canCustomerCancel && (
          <View style={styles.readOnlyBadge}>
            <Text style={styles.readOnlyText}>Live updates • Read only</Text>
          </View>
        )}
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },

  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingIcon: {
    fontSize: 64,
    marginBottom: 16,
  },
  loadingText: {
    color: '#E5E7EB',
    fontSize: 16,
  },

  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 40,
  },
  emptyIcon: {
    fontSize: 64,
    marginBottom: 16,
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: '800',
    marginBottom: 8,
  },
  emptyText: {
    color: '#E5E7EB',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 24,
  },
  emptyButton: {
    borderRadius: 12,
    overflow: 'hidden',
  },
  emptyButtonGrad: {
    paddingVertical: 14,
    paddingHorizontal: 32,
  },
  emptyButtonText: {
    color: '#fff',
    fontWeight: '900',
    fontSize: 16,
  },

  closeBtn: {
    position: 'absolute',
    top: 12,
    right: 12,
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 10,
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 3,
  },
  closeBtnText: {
    color: BG,
    fontSize: 16,
    fontWeight: '900',
  },

  mapContainer: {
    flex: 1,
    position: 'relative',
  },
  mapPlaceholder: {
    flex: 1,
    backgroundColor: '#1E3A8A',
    justifyContent: 'center',
    alignItems: 'center',
  },
  mapPlaceholderIcon: {
    fontSize: 64,
    marginBottom: 16,
  },
  mapPlaceholderText: {
    color: '#E5E7EB',
    fontSize: 16,
  },
  mapOverlay: {
    position: 'absolute',
    top: 60,
    alignSelf: 'center',
  },
  mapHintBox: {
    backgroundColor: 'rgba(10,25,41,0.8)',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 999,
  },
  mapHint: {
    color: '#E5E7EB',
    fontWeight: '600',
    fontSize: 12,
  },

  drawer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'rgba(10,25,41,0.98)',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    borderTopWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 32,
    maxHeight: height * 0.65,
  },

  drawerHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  statusDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 10,
  },
  statusText: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
  },

  // ADDED: Payment warning styles
  paymentWarning: {
    backgroundColor: 'rgba(245, 158, 11, 0.15)',
    borderRadius: 12,
    padding: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: 'rgba(245, 158, 11, 0.3)',
  },
  paymentWarningText: {
    color: '#F59E0B',
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
  },

  progressContainer: {
    marginBottom: 20,
  },
  progressBar: {
    height: 6,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 3,
    overflow: 'hidden',
    marginBottom: 8,
  },
  progressFill: {
    height: '100%',
    borderRadius: 3,
  },
  progressLabels: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  progressLabel: {
    color: '#E5E7EB',
    fontSize: 10,
    opacity: 0.7,
  },

  infoGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 16,
  },
  infoCard: {
    flex: 1,
    minWidth: (width - 52) / 2,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 12,
    padding: 14,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  infoLabel: {
    color: '#E5E7EB',
    fontSize: 11,
    marginBottom: 4,
    opacity: 0.8,
  },
  infoValue: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
  },

  locationBox: {
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 12,
    padding: 14,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  locationLabel: {
    color: '#F9FAFB',
    fontSize: 12,
    fontWeight: '700',
    marginBottom: 6,
  },
  locationText: {
    color: '#E5E7EB',
    fontSize: 14,
    lineHeight: 20,
  },

  actionBtn: {
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 12,
  },
  actionBtnGrad: {
    paddingVertical: 16,
    alignItems: 'center',
  },
  actionBtnText: {
    color: '#fff',
    fontWeight: '900',
    fontSize: 16,
  },

  cancelButton: {
    backgroundColor: 'rgba(239, 68, 68, 0.15)',
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(239, 68, 68, 0.3)',
    marginBottom: 12,
  },
  cancelButtonText: {
    color: '#EF4444',
    fontWeight: '700',
    fontSize: 14,
  },

  readOnlyBadge: {
    backgroundColor: 'rgba(59, 130, 246, 0.15)',
    borderRadius: 12,
    paddingVertical: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(59, 130, 246, 0.3)',
  },
  readOnlyText: {
    color: '#3B82F6',
    fontSize: 12,
    fontWeight: '600',
  },
});