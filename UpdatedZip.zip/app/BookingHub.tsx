// app/booking/BookingHub.tsx
import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Animated,
  PanResponder,
  ScrollView as RNScrollView,
  Alert,
  ActivityIndicator,
  Platform,
} from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router, useLocalSearchParams } from 'expo-router';
import * as Location from 'expo-location';
import { useAuth } from '../src/providers/enhanced-auth-context';
import { supabase } from '../src/lib/supabase';
import BookingService from '../src/services/BookingService';
import { pricingEngine } from '../src/utils/pricing-engine';
import { useStripe } from '@stripe/stripe-react-native';

const { width, height } = Dimensions.get('window');
const SNAP_MIN = 88;
const SNAP_MID = Math.min(520, height * 0.52);
const SNAP_MAX = Math.min(760, height * 0.9);

const BG = '#0A1929';
const ACCENT = '#10B981';
const SKY = '#87CEEB';

type Mode = 'valeter' | 'location';

// NEW: Updated phases for valeter mode
type ValeterPhase =
  | 'form'
  | 'valeter_list'
  | 'waiting_acceptance'
  | 'waiting_payment'
  | 'searching'
  | 'en_route'
  | 'arrived'
  | 'in_progress'
  | 'completed'
  | 'cancelled';

type Vehicle = {
  id: string;
  type: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  isDefault: boolean;
  photo?: string | null;
};

// NEW: Valeter type
type Valeter = {
  id: string;
  name: string;
  rating: number;
  totalJobs: number;
  distance: number;
  price: number;
  isOnline: boolean;
  lastLat: number;
  lastLng: number;
  profilePicture?: string;
};

type LegacyServiceId = 'wash' | 'valet' | 'priority_wash';

const serviceOptions = [
  { id: 'basic-wash', name: 'Basic Wash', desc: 'Exterior wash & dry', dur: '15-20 min', colors: ['#10B981','#059669'] },
  { id: 'premium-wash', name: 'Premium Wash', desc: 'Exterior + Interior', dur: '25-30 min', colors: ['#3B82F6','#1D4ED8'] },
  { id: 'full-valet', name: 'Full Valet', desc: 'Complete in/out', dur: '45-60 min', colors: ['#8B5CF6','#7C3AED'] },
  { id: 'exterior-detail', name: 'Exterior Detail', desc: 'Pro exterior detail', dur: '2-3 hours', colors: ['#F59E0B','#D97706'] },
  { id: 'interior-detail', name: 'Interior Detail', desc: 'Deep interior', dur: '1-2 hours', colors: ['#EF4444','#DC2626'] },
  { id: 'premium-valet', name: 'Premium Valet', desc: 'Luxury specialist', dur: '3-4 hours', colors: ['#FFD700','#FFA500'] },
] as const;

const timeSlots = [
  { id: 'on-demand', name: 'On-Demand', icon: '⚡', colors: ['#10B981','#059669'] },
  { id: 'morning', name: 'Morning (8–12)', icon: '🌅', colors: ['#F59E0B','#D97706'] },
  { id: 'afternoon', name: 'Afternoon (12–5)', icon: '☀️', colors: ['#FCD34D','#F59E0B'] },
  { id: 'evening', name: 'Evening (5–9)', icon: '🌆', colors: ['#8B5CF6','#7C3AED'] },
  { id: 'weekend', name: 'Weekend', icon: '🎉', colors: ['#EC4899','#DB2777'] },
] as const;

const presetLocations = [
  { id: 'current', name: 'Use Current Location', icon: '📍', colors: ['#10B981','#059669'] },
  { id: 'home', name: 'Home Address', icon: '🏠', colors: ['#3B82F6','#1D4ED8'] },
  { id: 'work', name: 'Work', icon: '🏢', colors: ['#8B5CF6','#7C3AED'] },
  { id: 'shopping', name: 'Shopping Centre', icon: '🛍️', colors: ['#EC4899','#DB2777'] },
  { id: 'airport', name: 'Airport', icon: '✈️', colors: ['#FCD34D','#F59E0B'] },
  { id: 'hotel', name: 'Hotel', icon: '🏨', colors: ['#06B6D4','#0891B2'] },
] as const;

type CarWashLocation = {
  id: string;
  name: string;
  address: string;
  latitude: number;
  longitude: number;
  rating: number;
  totalReviews: number;
  basePrice: number;
  priorityPrice: number;
  status: 'green'|'yellow'|'orange'|'red';
};

const vehicleTypes = [
  { id: 'bike', name: 'Motorcycle', icon: '🏍️', mult: 0.6 },
  { id: 'small_car', name: 'Small Car', icon: '🚗', mult: 1.0 },
  { id: 'large_car', name: 'Large Car', icon: '🚙', mult: 1.3 },
  { id: 'suv', name: 'SUV', icon: '🚙', mult: 1.5 },
  { id: 'van', name: 'Van', icon: '🚐', mult: 1.8 },
  { id: 'coach', name: 'Coach', icon: '🚌', mult: 3.0 },
  { id: 'luxury', name: 'Luxury', icon: '🏎️', mult: 2.0 },
] as const;

const serviceTypes = [
  { id: 'exterior_only', name: 'Exterior Only', dur: '15 min', mult: 0.7 },
  { id: 'standard', name: 'Standard Wash', dur: '30 min', mult: 1.0 },
  { id: 'premium', name: 'Premium Wash', dur: '45 min', mult: 1.4 },
  { id: 'luxury', name: 'Luxury Detail', dur: '90 min', mult: 2.0 },
] as const;

// Booking status (subset) - NEW statuses added
type BookingStatus =
  | 'pending'
  | 'pending_valeter_acceptance'
  | 'valeter_declined'
  | 'valeter_timeout'
  | 'pending_payment'
  | 'payment_timeout'
  | 'scheduled'
  | 'confirmed'
  | 'valeter_assigned'
  | 'en_route'
  | 'arrived'
  | 'in_progress'
  | 'completed'
  | 'cancelled';

const SEARCHING: BookingStatus[] = ['pending','scheduled','confirmed'];
const LIVE_TRACK: BookingStatus[] = ['valeter_assigned','en_route','arrived','in_progress'];

type MarkerDef = { key: string; title: string; coord: { latitude: number; longitude: number }; emoji?: string };

const MapLayer = React.memo(function MapLayer({
  region,
  markers,
  onRegionChangeComplete,
  showAgents,
}: {
  region: { latitude: number; longitude: number; latitudeDelta: number; longitudeDelta: number };
  markers: MarkerDef[];
  onRegionChangeComplete?: (r: any) => void;
  showAgents: boolean;
}) {
  type Agent = { id: string; lat: number; lng: number; vx: number; vy: number };
  const [agents, setAgents] = React.useState<Agent[]>([]);

  React.useEffect(() => {
    if (!showAgents) { setAgents([]); return; }
    const count = 8;
    const list: Agent[] = [];
    for (let i = 0; i < count; i++) {
      const lat = region.latitude + (Math.random() - 0.5) * region.latitudeDelta * 0.6;
      const lng = region.longitude + (Math.random() - 0.5) * region.longitudeDelta * 0.6;
      const vx = Math.random() * 0.0006 - 0.0003;
      const vy = Math.random() * 0.0004 - 0.0002;
      list.push({ id: `a-${i}`, lat, lng, vx, vy });
    }
    setAgents(list);

    const tick = setInterval(() => {
      setAgents(prev => prev.map(a => {
        let lat = a.lat + a.vy;
        let lng = a.lng + a.vx;

        const latMin = region.latitude - region.latitudeDelta * 0.5;
        const latMax = region.latitude + region.latitudeDelta * 0.5;
        const lngMin = region.longitude - region.longitudeDelta * 0.5;
        const lngMax = region.longitude + region.longitudeDelta * 0.5;

        let vx = a.vx;
        let vy = a.vy;

        if (lat < latMin || lat > latMax) vy = -vy;
        if (lng < lngMin || lng > lngMax) vx = -vx;

        vx += (Math.random() - 0.5) * 0.00005;
        vy += (Math.random() - 0.5) * 0.00004;

        return {
          ...a,
          lat: Math.max(latMin, Math.min(latMax, lat)),
          lng: Math.max(lngMin, Math.min(lngMax, lng)),
          vx,
          vy,
        };
      }));
    }, 900);

    return () => clearInterval(tick);
  }, [showAgents, region.latitude, region.longitude, region.latitudeDelta, region.longitudeDelta]);

  return (
    <MapView
      style={StyleSheet.absoluteFill}
      initialRegion={region}
      region={region}
      onRegionChangeComplete={onRegionChangeComplete}
      showsMyLocationButton={false}
      mapType={Platform.OS === 'ios' ? 'standard' : 'standard'}
    >
      {markers.map(m => (
        <Marker key={m.key} coordinate={m.coord} title={m.title}>
          <Text style={{ fontSize: 22 }}>{m.emoji || '📍'}</Text>
        </Marker>
      ))}

      {showAgents && agents.map(a => (
        <Marker
          key={a.id}
          coordinate={{ latitude: a.lat, longitude: a.lng }}
          title="Valeter nearby"
          description="On the move"
        >
          <Text style={{ fontSize: 22 }}>🧽</Text>
        </Marker>
      ))}
    </MapView>
  );
});

export default function BookingHub() {
  const isInnerScrolling = useRef(false);
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { initPaymentSheet, presentPaymentSheet } = useStripe();

  const { bookingId: bookingIdParam } = useLocalSearchParams<{ bookingId?: string }>();

  const stableScrollProps = {
    nestedScrollEnabled: true as const,
    contentInsetAdjustmentBehavior: 'never' as const,
    bounces: true,
    overScrollMode: 'never' as const,
    keyboardShouldPersistTaps: 'handled' as const,
    keyboardDismissMode: 'on-drag' as const,
    scrollEventThrottle: 16,
    onScrollBeginDrag: () => { isInnerScrolling.current = true; },
    onScrollEndDrag: () => { isInnerScrolling.current = false; },
    onMomentumScrollEnd: () => { isInnerScrolling.current = false; },
  };

  const [region, setRegion] = useState({
    latitude: 53.483959,
    longitude: -2.244644,
    latitudeDelta: 0.08,
    longitudeDelta: 0.08,
  });

  const [mode, setMode] = useState<Mode>('valeter');
  const sheetY = useRef(new Animated.Value(height - SNAP_MID)).current;
  const [snap, setSnap] = useState<number>(SNAP_MID);

  const pan = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => false,
      onMoveShouldSetPanResponder: (_e, g) => {
        if (isInnerScrolling.current) return false;
        const absDx = Math.abs(g.dx);
        const absDy = Math.abs(g.dy);
        return absDy > 6 && absDy > absDx;
      },
      onPanResponderTerminationRequest: () => false,
      onPanResponderMove: (_e, g) => {
        const newY = Math.min(height - SNAP_MIN, Math.max(height - SNAP_MAX, (height - snap) + g.dy));
        sheetY.setValue(newY);
      },
      onPanResponderRelease: () => {
        const current = (sheetY as any)._value as number;
        const thresholds = [height - SNAP_MAX, height - SNAP_MID, height - SNAP_MIN];
        const distances = thresholds.map(t => Math.abs(current - t));
        const idx = distances.indexOf(Math.min(...distances));
        const target = thresholds[idx];
        Animated.spring(sheetY, { toValue: target, useNativeDriver: false, bounciness: 4, speed: 14 }).start(() => {
          setSnap(height - target);
        });
      },
    })
  ).current;

  useEffect(() => {
    Animated.spring(sheetY, { toValue: height - SNAP_MID, useNativeDriver: false, bounciness: 4, speed: 14 }).start();
    setSnap(SNAP_MID);
  }, [mode]);

  // ------------ VALETER flow ------------
  const [valeterPhase, setValeterPhase] = useState<ValeterPhase>('form');
  const [currentBookingId, setCurrentBookingId] = useState<string | null>(null);
  const [status, setStatus] = useState<BookingStatus>('pending');
  const [searchInfo, setSearchInfo] = useState<{ address?: string; price?: number; service?: string }>({});

  // NEW: Valeter selection state
  const [availableValeters, setAvailableValeters] = useState<Valeter[]>([]);
  const [selectedValeter, setSelectedValeter] = useState<Valeter | null>(null);
  const [valetersLoading, setValetersLoading] = useState(false);
  const [priceFilter, setPriceFilter] = useState<{ min: number; max: number }>({ min: 0, max: 100 });
  const [minRatingFilter, setMinRatingFilter] = useState<number>(0);
  const [sortBy, setSortBy] = useState<'distance' | 'price' | 'rating'>('distance');

  // NEW: Countdown timers
  const [acceptanceCountdown, setAcceptanceCountdown] = useState<number | null>(null);
  const [paymentCountdown, setPaymentCountdown] = useState<number | null>(null);

  const [driverCoord, setDriverCoord] = useState<{ lat: number; lng: number } | null>(null);
  const [destCoord, setDestCoord] = useState<{ lat: number; lng: number } | null>(null);

  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [vehLoading, setVehLoading] = useState(false);
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(null);
  const [selectedServiceId, setSelectedServiceId] = useState<typeof serviceOptions[number]['id'] | null>(null);
  const [selectedPresetLoc, setSelectedPresetLoc] = useState<typeof presetLocations[number]['id'] | null>('current');
  const [selectedTimeId, setSelectedTimeId] = useState<typeof timeSlots[number]['id']>('on-demand');

  const [gps, setGps] = useState<{ lat: number; lng: number } | null>(null);
  const [gpsAddr, setGpsAddr] = useState<string | null>(null);
  const [gpsLoading, setGpsLoading] = useState(false);
  const [processing, setProcessing] = useState(false);

  const isTracking = Boolean(bookingIdParam || (currentBookingId && ['searching', 'en_route', 'arrived', 'in_progress', 'completed', 'cancelled'].includes(valeterPhase)));

  // NEW: Check for existing active booking when component loads
  useEffect(() => {
    const checkForActiveBooking = async () => {
      if (!user?.id || bookingIdParam) return; // Skip if already tracking a specific booking

      try {
        const { data, error } = await supabase
          .from('bookings')
          .select('id, status, valeter_id')
          .eq('user_id', user.id)
          .in('status', [
            'pending_valeter_acceptance',
            'pending_payment',
            'confirmed',
            'en_route',
            'arrived',
            'in_progress'
          ])
          .order('created_at', { ascending: false })
          .limit(1);

        if (error) throw error;

        const activeBooking = data?.[0];
        if (activeBooking) {
          // User has an active booking - redirect to it
          setCurrentBookingId(activeBooking.id);

          // Set appropriate phase based on status
          if (activeBooking.status === 'pending_valeter_acceptance') {
            setValeterPhase('waiting_acceptance');
          } else if (activeBooking.status === 'pending_payment') {
            setValeterPhase('waiting_payment');
          } else {
            setValeterPhase('searching'); // Will be updated by real-time
          }

          // Start real-time tracking
          beginRealtime(activeBooking.id);

          Alert.alert(
            'Active Booking Found',
            'You already have a booking in progress. Redirecting you to track it.',
            [{ text: 'OK' }]
          );
        }
      } catch (e) {
        console.error('Error checking for active booking:', e);
      }
    };

    checkForActiveBooking();
  }, [user?.id, bookingIdParam]);

  // Initial location
  useEffect(() => {
    (async () => {
      try {
        const { status } = await Location.requestForegroundPermissionsAsync();
        if (status !== 'granted') return;
        const pos = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
        setRegion(r => ({
          ...r,
          latitude: pos.coords.latitude,
          longitude: pos.coords.longitude,
          latitudeDelta: 0.04,
          longitudeDelta: 0.04,
        }));
        setGps({ lat: pos.coords.latitude, lng: pos.coords.longitude });
      } catch {}
    })();
  }, []);

  // Load vehicles
  useEffect(() => {
    const run = async () => {
      if (!user?.id) return;
      setVehLoading(true);
      const { data, error } = await supabase
        .from('customer_vehicles')
        .select('id, user_id, type, make, model, color, registration, is_default, photo')
        .eq('user_id', user.id)
        .order('is_default', { ascending: false })
        .order('created_at', { ascending: true });
      setVehLoading(false);
      if (error) return;
      const list = (data ?? []).map((r: any) => ({
        id: String(r.id),
        type: String(r.type ?? 'Car'),
        make: String(r.make ?? ''),
        model: String(r.model ?? ''),
        color: String(r.color ?? ''),
        registration: String(r.registration ?? ''),
        isDefault: !!r.is_default,
        photo: r.photo ?? null,
      })) as Vehicle[];
      setVehicles(list);
      const def = list.find(v => v.isDefault);
      if (def) setSelectedVehicle(def);
    };
    run();
  }, [user?.id]);

  const safeNumber = (v: any, fallback = 0) =>
    Number.isFinite(Number(v)) ? Number(v) : fallback;

  const getVehicleSize = (vehicle?: { type?: string }): 'small'|'medium'|'large'|'suv'|'luxury' => {
    const raw = (vehicle?.type || '').toLowerCase();
    if (['small','city','mini','compact','hatch'].some(k => raw.includes(k))) return 'small';
    if (['suv','crossover','4x4'].some(k => raw.includes(k))) return 'suv';
    if (['lux','executive','premium'].some(k => raw.includes(k))) return 'luxury';
    if (['van','mpv','people carrier'].some(k => raw.includes(k))) return 'large';
    if (['estate','saloon','sedan','coupe'].some(k => raw.includes(k))) return 'medium';
    return 'medium';
  };

  const mapUiServiceToLegacy = (
    uiId?: string | null,
    timeId?: string | null
  ): LegacyServiceId | null => {
    if (!uiId) return null;
    if ((uiId === 'basic-wash' || uiId === 'premium-wash') && timeId === 'on-demand') return 'priority_wash';
    if (uiId === 'basic-wash' || uiId === 'premium-wash') return 'wash';
    return 'valet';
  };

  const computeValeterPrice = ({
    selectedVehicle,
    selectedServiceId,
    selectedTimeId,
    valeterMultiplier = 1.0,
  }: {
    selectedVehicle: { type?: string } | null;
    selectedServiceId: string | null;
    selectedTimeId: string | null;
    valeterMultiplier?: number;
  }) => {
    const legacy = mapUiServiceToLegacy(selectedServiceId ?? null, selectedTimeId ?? null);
    if (!legacy) return null;

    try {
      const timeOfDay = pricingEngine.getTimeOfDay();
      const dayOfWeek = pricingEngine.getDayOfWeek();
      const demand = pricingEngine.getDemandLevel('Manchester', timeOfDay, dayOfWeek);

      const priceObj = pricingEngine.calculatePrice({
        location: 'Manchester',
        timeOfDay,
        dayOfWeek,
        demand,
        weather: 'sunny',
        vehicleSize: getVehicleSize(selectedVehicle || undefined),
        serviceType: legacy,
      });

      const total = safeNumber(priceObj?.totalPrice, NaN);
      if (!Number.isFinite(total)) return null;
      return Math.round(total * valeterMultiplier);
    } catch {
      return null;
    }
  };

  // NEW: Calculate distance between two points (Haversine formula)
  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 3959; // Earth radius in miles
    const dLat = (lat2 - lat1) * (Math.PI / 180);
    const dLon = (lon2 - lon1) * (Math.PI / 180);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * (Math.PI / 180)) *
      Math.cos(lat2 * (Math.PI / 180)) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  // NEW: Fetch available valeters
  const fetchAvailableValeters = async (location: { lat: number; lng: number }) => {
    if (!selectedServiceId || !selectedVehicle) return;

    try {
      setValetersLoading(true);

      // Query valeters with presence data
      const { data: valetersData, error } = await supabase
        .from('profiles')
        .select(`
          id,
          name,
          valeter_presence!inner (
            is_online,
            last_lat,
            last_lng
          )
        `)
        .eq('role', 'valeter')
        .eq('valeter_presence.is_online', true);

      if (error) throw error;

      // Check for active jobs
      const valeterIds = valetersData?.map(v => v.id) || [];
      const { data: activeJobs } = await supabase
        .from('bookings')
        .select('valeter_id')
        .in('valeter_id', valeterIds)
        .in('status', ['scheduled', 'in_progress', 'en_route', 'arrived']);

      const busyValeterIds = new Set(activeJobs?.map(j => j.valeter_id) || []);

      // Filter and map valeters
      const valeters: Valeter[] = (valetersData || [])
        .filter(v => !busyValeterIds.has(v.id))
        .map(v => {
          const presence = Array.isArray(v.valeter_presence) ? v.valeter_presence[0] : v.valeter_presence;
          const valeterLat = Number(presence?.last_lat || 0);
          const valeterLng = Number(presence?.last_lng || 0);
          const distance = calculateDistance(location.lat, location.lng, valeterLat, valeterLng);

          // TODO: Get actual pricing multiplier from valeter_pricing table
          const multiplier = 1.0; // Placeholder - will be replaced with DB value
          const price = computeValeterPrice({
            selectedVehicle,
            selectedServiceId,
            selectedTimeId,
            valeterMultiplier: multiplier,
          }) || 0;

          return {
            id: v.id,
            name: v.name || 'Unknown',
            rating: 4.8, // TODO: Calculate from reviews
            totalJobs: 0, // TODO: Count from bookings
            distance: Math.round(distance * 10) / 10,
            price,
            isOnline: true,
            lastLat: valeterLat,
            lastLng: valeterLng,
          };
        })
        .filter(v => v.distance <= 10); // Within 10 miles

      setAvailableValeters(valeters);
    } catch (e: any) {
      console.error('Error fetching valeters:', e);
      Alert.alert('Error', 'Failed to load available valeters');
    } finally {
      setValetersLoading(false);
    }
  };

  const requestGps = async () => {
    try {
      setGpsLoading(true);
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Location', 'Permission denied. Choose a preset location instead.');
        setGpsLoading(false);
        return;
      }
      const pos = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const coords = { lat: pos.coords.latitude, lng: pos.coords.longitude };
      setGps(coords);
      setRegion(prev => ({ ...prev, latitude: coords.lat, longitude: coords.lng }));
      try {
        const r = await Location.reverseGeocodeAsync({ latitude: coords.lat, longitude: coords.lng });
        const g = r?.[0];
        const parts = [g?.name||g?.street||'', g?.postalCode||'', g?.city||g?.subregion||'', g?.region||'', g?.country||'']
          .filter(Boolean).join(', ').replace(/\s+,/g, ',').replace(/,+\s*$/,'');
        setGpsAddr(parts || null);
      } catch { setGpsAddr(null); }
    } finally { setGpsLoading(false); }
  };

  const { user: authUser } = useAuth();

  const startPaymentSheet = async ({ amountPence, serviceName }: { amountPence: number; serviceName: string; }) => {
    const { data, error } = await supabase.functions.invoke('hyper-endpoint', {
      body: {
        amount: amountPence,
        currency: 'gbp',
        userId: authUser!.id,
        email: authUser?.email,
        metadata: { serviceName },
      },
    });
    if (error) throw new Error(error.message || 'Failed to initialise payment');
    const { paymentIntentClientSecret, customerId, ephemeralKeySecret } = data || {};
    if (!paymentIntentClientSecret || !customerId || !ephemeralKeySecret) throw new Error('Payment initialisation response incomplete');

    const { error: initErr } = await initPaymentSheet({
      merchantDisplayName: 'Wish-a-Wash',
      customerId,
      customerEphemeralKeySecret: ephemeralKeySecret,
      paymentIntentClientSecret,
      defaultBillingDetails: { email: authUser?.email || '' },
      allowsDelayedPaymentMethods: false,
    });
    if (initErr) throw new Error(initErr.message);

    const { error: presentErr } = await presentPaymentSheet();
    if (presentErr) throw new Error(presentErr.message);
  };

  // NEW: Proceed to valeter list after form completion
  const proceedToValeterList = async () => {
    if (!user?.id) return Alert.alert('Sign in', 'Please sign in first.');
    if (!selectedVehicle || !selectedServiceId || !selectedPresetLoc)
      return Alert.alert('Selections', 'Pick vehicle, service, and a location.');

    // NEW: Check for active booking before proceeding
    try {
      const { data: activeBookings } = await supabase
        .from('bookings')
        .select('id, status')
        .eq('user_id', user.id)
        .in('status', [
          'pending_valeter_acceptance',
          'pending_payment',
          'confirmed',
          'en_route',
          'arrived',
          'in_progress'
        ])
        .limit(1);

      if (activeBookings && activeBookings.length > 0) {
        Alert.alert(
          'Active Booking Exists',
          'You already have a booking in progress. Please complete or cancel it before creating a new one.',
          [
            { text: 'Cancel', style: 'cancel' },
            {
              text: 'View Active Booking',
              onPress: () => {
                const booking = activeBookings[0];
                setCurrentBookingId(booking.id);
                setValeterPhase('searching'); // Will be updated by real-time
                beginRealtime(booking.id);
              }
            }
          ]
        );
        return;
      }
    } catch (e) {
      console.error('Error checking for active bookings:', e);
    }

    if (selectedPresetLoc === 'current' && !gps && !gpsLoading) {
      await requestGps();
    }

    const presetCoords: Record<string,{lat:number;lng:number}> = {
      home: { lat: 53.483959, lng: -2.244644 },
      work: { lat: 53.4808,  lng: -2.2426 },
      shopping: { lat: 53.474, lng: -2.248 },
      airport: { lat: 53.365, lng: -2.273 },
      hotel: { lat: 53.479, lng: -2.245 },
    };

    const loc =
      selectedPresetLoc === 'current' && gps
        ? gps
        : presetCoords[selectedPresetLoc] || { lat: region.latitude, lng: region.longitude };

    await fetchAvailableValeters(loc);

    setValeterPhase('valeter_list');
    Animated.spring(sheetY, { toValue: height - SNAP_MAX, useNativeDriver: false, bounciness: 4, speed: 14 }).start();
    setSnap(SNAP_MAX);
  };

  // NEW: Customer selects a valeter
  const selectValeterHandler = async (valeter: Valeter) => {
    if (!user?.id || !selectedVehicle || !selectedServiceId) return;

    setSelectedValeter(valeter);
    setProcessing(true);

    try {
      const presetCoords: Record<string,{lat:number;lng:number}> = {
        home: { lat: 53.483959, lng: -2.244644 },
        work: { lat: 53.4808,  lng: -2.2426 },
        shopping: { lat: 53.474, lng: -2.248 },
        airport: { lat: 53.365, lng: -2.273 },
        hotel: { lat: 53.479, lng: -2.245 },
      };

      const loc =
        selectedPresetLoc === 'current' && gps
          ? gps
          : presetCoords[selectedPresetLoc!] || { lat: region.latitude, lng: region.longitude };

      const legacy = mapUiServiceToLegacy(selectedServiceId, selectedTimeId);

      // Create booking with status 'pending_valeter_acceptance'
      const { data: booking, error } = await supabase
        .from('bookings')
        .insert({
          user_id: user.id,
          valeter_id: valeter.id,
          service_type: legacy,
          service_name: serviceOptions.find(s => s.id === selectedServiceId)?.name,
          scheduled_at: new Date().toISOString(),
          price: valeter.price,
          status: 'pending_valeter_acceptance',
          request_sent_at: new Date().toISOString(),
          location_address: selectedPresetLoc === 'current' ? (gpsAddr || 'Current Location') : selectedPresetLoc,
          location_lat: loc.lat,
          location_lng: loc.lng,
          vehicle_type: getVehicleSize(selectedVehicle),
          vehicle_info: `${selectedVehicle.make} ${selectedVehicle.model} (${selectedVehicle.registration})`,
          time_slot: selectedTimeId,
        })
        .select()
        .single();

      if (error) throw error;

      setCurrentBookingId(booking.id);
      setSearchInfo({
        address: selectedPresetLoc === 'current' ? (gpsAddr || 'Current Location') : selectedPresetLoc!,
        price: valeter.price,
        service: serviceOptions.find(s => s.id === selectedServiceId)?.name,
      });

      // Start 5-minute countdown
      setAcceptanceCountdown(300);
      setValeterPhase('waiting_acceptance');

      // Subscribe to booking updates
      beginRealtime(booking.id);

    } catch (e: any) {
      Alert.alert('Error', e.message || 'Failed to send request to valeter');
      setSelectedValeter(null);
    } finally {
      setProcessing(false);
    }
  };

  // NEW: Countdown timer for acceptance
  useEffect(() => {
    if (acceptanceCountdown === null || acceptanceCountdown <= 0) return;

    const timer = setTimeout(() => {
      setAcceptanceCountdown(acceptanceCountdown - 1);
    }, 1000);

    if (acceptanceCountdown === 1) {
      handleValeterTimeout();
    }

    return () => clearTimeout(timer);
  }, [acceptanceCountdown]);

  // NEW: Countdown timer for payment
  useEffect(() => {
    if (paymentCountdown === null || paymentCountdown <= 0) return;

    const timer = setTimeout(() => {
      setPaymentCountdown(paymentCountdown - 1);
    }, 1000);

    if (paymentCountdown === 1) {
      handlePaymentTimeout();
    }

    return () => clearTimeout(timer);
  }, [paymentCountdown]);

  // NEW: Format countdown time
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // NEW: Handle valeter acceptance - simplified to just show payment screen
  const handleValeterAcceptance = async () => {
    if (!selectedValeter) return;

    try {
      const amountPence = Math.max(50, Math.round(selectedValeter.price * 100));
      await startPaymentSheet({
        amountPence,
        serviceName: serviceOptions.find(s => s.id === selectedServiceId)!.name
      });

      // Payment successful - update booking to indicate payment completed
      if (currentBookingId) {
        await supabase
          .from('bookings')
          .update({
            status: 'confirmed', // Keep confirmed but payment is now done
            payment_completed_at: new Date().toISOString(),
          })
          .eq('id', currentBookingId);

        setPaymentCountdown(null);
        setValeterPhase('en_route');
        Alert.alert('Success', 'Payment complete! Your valeter is on the way.');
      }
    } catch (e: any) {
      Alert.alert('Payment Failed', e.message || 'Please try again');
    }
  };

  // NEW: Handle valeter decline
  const handleValeterDecline = () => {
    setAcceptanceCountdown(null);
    Alert.alert(
      'Valeter Declined',
      `${selectedValeter?.name} declined your request. Please select another valeter.`,
      [{
        text: 'OK',
        onPress: () => {
          setAvailableValeters(prev => prev.filter(v => v.id !== selectedValeter?.id));
          setSelectedValeter(null);
          setValeterPhase('valeter_list');
        }
      }]
    );
  };

  // NEW: Handle valeter timeout
  const handleValeterTimeout = () => {
    Alert.alert(
      'Request Timeout',
      `${selectedValeter?.name} didn't respond in time. Please select another valeter.`,
      [{
        text: 'OK',
        onPress: async () => {
          // Update booking status
          if (currentBookingId) {
            await supabase
              .from('bookings')
              .update({ status: 'valeter_timeout' })
              .eq('id', currentBookingId);
          }

          setAvailableValeters(prev => prev.filter(v => v.id !== selectedValeter?.id));
          setSelectedValeter(null);
          setValeterPhase('valeter_list');
        }
      }]
    );
  };

  // NEW: Handle payment timeout
  const handlePaymentTimeout = () => {
    Alert.alert(
      'Payment Timeout',
      'Payment window expired. Booking cancelled.',
      [{
        text: 'OK',
        onPress: async () => {
          if (currentBookingId) {
            await supabase
              .from('bookings')
              .update({
                status: 'cancelled',
                cancelled_by: 'system',
                cancellation_reason: 'Payment timeout',
              })
              .eq('id', currentBookingId);
          }

          setSelectedValeter(null);
          setCurrentBookingId(null);
          setValeterPhase('form');
        }
      }]
    );
  };

  // Filter and sort valeters
  const filteredValeters = useMemo(() => {
    let filtered = availableValeters.filter(v =>
      v.price >= priceFilter.min &&
      v.price <= priceFilter.max &&
      v.rating >= minRatingFilter
    );

    filtered.sort((a, b) => {
      if (sortBy === 'distance') return a.distance - b.distance;
      if (sortBy === 'price') return a.price - b.price;
      if (sortBy === 'rating') return b.rating - a.rating;
      return 0;
    });

    return filtered;
  }, [availableValeters, priceFilter, minRatingFilter, sortBy]);

  // ---------- Realtime tracking (status + live driver lat/lng) ----------
  const supaChannelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);

  const handleRowUpdate = (row: any) => {
    if (!row) return;

    const s: BookingStatus = row.status || row.booking_status || 'pending';
    setStatus(s);
    setSearchInfo(prev => ({
      address: row.location_address ?? row.location?.address ?? prev.address,
      price: Number(row.price ?? prev.price ?? 0),
      service: row.service_name || row.serviceName || row.service_type || prev.service,
    }));

    if (typeof row.location_lat === 'number' && typeof row.location_lng === 'number') {
      const dest = { lat: Number(row.location_lat), lng: Number(row.location_lng) };
      setDestCoord(dest);
    }

    if (typeof row.driver_lat === 'number' && typeof row.driver_lng === 'number') {
      setDriverCoord({ lat: Number(row.driver_lat), lng: Number(row.driver_lng) });
    }

    if (row.location_lat && row.location_lng) {
      setRegion(r => ({
        ...r,
        latitude: Number(row.location_lat),
        longitude: Number(row.location_lng),
      }));
    }

    // SIMPLIFIED: Direct handling of status changes
    if (s === 'confirmed') {
      // If we have a booking and status is confirmed, show payment screen
      // This covers all cases where valeter has accepted
      setAcceptanceCountdown(null);
      setPaymentCountdown(300);
      setValeterPhase('waiting_payment');
    } else if (s === 'valeter_declined') {
      handleValeterDecline();
    } else {
      // Handle other status changes normally
      shiftPhaseByStatus(s);
    }
  };

  const beginRealtime = (bookingId: string) => {
    if (supaChannelRef.current) {
      try {
        supabase.removeChannel(supaChannelRef.current);
      } catch {}
      supaChannelRef.current = null;
    }

    const channel = supabase
      .channel(`booking:${bookingId}`)
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'bookings', filter: `id=eq.${bookingId}` },
        (payload) => handleRowUpdate(payload.new)
      )
      .subscribe();

    supaChannelRef.current = channel;

    // Fetch current state immediately to ensure sync
    (async () => {
      try {
        const { data, error } = await supabase
          .from('bookings')
          .select('*')
          .eq('id', bookingId)
          .single();

        if (error) throw error;
        if (data) handleRowUpdate(data);
      } catch (e) {
        console.error('Error fetching current booking state:', e);
      }
    })();
  };

  useEffect(() => {
    if (!bookingIdParam) return;
    setMode('valeter');
    setValeterPhase('searching');
    setCurrentBookingId(String(bookingIdParam));
    Animated.spring(sheetY, { toValue: height - SNAP_MID, useNativeDriver: false, bounciness: 4, speed: 14 }).start(() => setSnap(SNAP_MID));
    beginRealtime(String(bookingIdParam));
    return () => {
      if (supaChannelRef.current) supabase.removeChannel(supaChannelRef.current);
    };
  }, [bookingIdParam, user?.id]);

  const shiftPhaseByStatus = (s: BookingStatus) => {
    if (s === 'valeter_assigned' || s === 'en_route') setValeterPhase('en_route');
    else if (s === 'arrived') setValeterPhase('arrived');
    else if (s === 'in_progress') setValeterPhase('in_progress');
    else if (s === 'completed') setValeterPhase('completed');
    else if (s === 'cancelled') setValeterPhase('cancelled');
    else if (s === 'pending_valeter_acceptance') setValeterPhase('waiting_acceptance');
    else if (s === 'pending' && !currentBookingId) setValeterPhase('searching');
  };

  const cancelValeter = async () => {
    const id = currentBookingId || String(bookingIdParam || '');
    if (!id || !user?.id) return;
    try {
      if ((BookingService as any).cancelBooking) {
        await (BookingService as any).cancelBooking(id, user.id, {
          by: 'customer',
          reason: 'User cancelled during search',
        });
      } else if ((BookingService as any).updateBookingStatus) {
        await (BookingService as any).updateBookingStatus(id, user.id, 'cancelled');
      }
      setValeterPhase('cancelled');
      Alert.alert('Cancelled', 'Your booking has been cancelled.');
    } catch (e: any) {
      Alert.alert('Cancel failed', e?.message || 'Please try again.');
    }
  };

  // ------------ PHYSICAL LOCATION flow (unchanged) ------------
  const [cwLocations, setCwLocations] = useState<CarWashLocation[]>([]);
  const [cwLoading, setCwLoading] = useState(false);
  const [cwSelected, setCwSelected] = useState<string | null>(null);
  const [cwVehType, setCwVehType] = useState<typeof vehicleTypes[number]['id'] | null>(null);
  const [cwService, setCwService] = useState<typeof serviceTypes[number]['id'] | null>(null);
  const [cwPricing, setCwPricing] = useState<{ base: number; priority: number; total: number } | null>(null);

  const selectedCw = cwLocations.find(l => l.id === cwSelected) || null;

  useEffect(() => {
    const run = async () => {
      setCwLoading(true);
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id,name,address,latitude,longitude,rating,total_reviews,base_price,priority_price,status')
        .order('name', { ascending: true });
      setCwLoading(false);
      if (error) return;
      const mapped = (data ?? []).map((row: any) => ({
        id: row.id,
        name: row.name,
        address: row.address,
        latitude: Number(row.latitude),
        longitude: Number(row.longitude),
        rating: Number(row.rating ?? 0),
        totalReviews: Number(row.total_reviews ?? 0),
        basePrice: Number(row.base_price ?? 0),
        priorityPrice: Number(row.priority_price ?? 0),
        status: (row.status ?? 'green') as CarWashLocation['status'],
      })) as CarWashLocation[];
      setCwLocations(mapped);
    };
    run();
  }, []);

  useEffect(() => {
    if (!selectedCw || !cwVehType || !cwService) { setCwPricing(null); return; }
    const vt = vehicleTypes.find(v => v.id === cwVehType)!;
    const sv = serviceTypes.find(s => s.id === cwService)!;
    const base = selectedCw.basePrice * vt.mult * sv.mult;
    const priority = selectedCw.priorityPrice;
    const total = base + priority;
    setCwPricing({ base, priority, total });
  }, [selectedCw, cwVehType, cwService]);

  const confirmPhysicalBooking = async () => {
    if (!user?.id) return Alert.alert('Sign in', 'Please sign in first.');
    if (!selectedCw || !cwVehType || !cwService || !cwPricing) return Alert.alert('Selections', 'Complete all steps.');
    try {
      setProcessing(true);
      const scheduledAtIso = new Date().toISOString();
      const { error } = await supabase
        .from('bookings')
        .insert({
          user_id: user.id,
          service_type: cwService,
          service_name: serviceTypes.find(s => s.id === cwService)?.name ?? null,
          scheduled_at: scheduledAtIso,
          price: Number(cwPricing.total.toFixed(2)),
          location_address: selectedCw.address,
          location_lat: selectedCw.latitude,
          location_lng: selectedCw.longitude,
          vehicle_type: cwVehType,
          vehicle_info: null,
          time_slot: null,
          special_instructions: null,
        })
        .select('id')
        .single();
      if (error) throw error;

      Alert.alert('Booked', 'Your location booking has been created.');
    } catch (e: any) {
      Alert.alert('Booking failed', e?.message || 'Please try again.');
    } finally { setProcessing(false); }
  };

  // ------------ Map markers (dynamic) ------------
  const markers: MarkerDef[] = useMemo(() => {
    if (isTracking) {
      const arr: MarkerDef[] = [];
      if (destCoord) {
        arr.push({
          key: 'dest',
          title: 'Your location',
          coord: { latitude: destCoord.lat, longitude: destCoord.lng },
          emoji: '📍',
        });
      }
      if (driverCoord && LIVE_TRACK.includes(status)) {
        arr.push({
          key: 'valeter',
          title: 'Valeter',
          coord: { latitude: driverCoord.lat, longitude: driverCoord.lng },
          emoji: '🚗',
        });
      }
      return arr;
    }

    if (mode === 'location') {
      return cwLocations.map(l => ({
        key: l.id,
        title: l.name,
        coord: { latitude: l.latitude, longitude: l.longitude },
        emoji: '🧼',
      }));
    }

    return [];
  }, [isTracking, destCoord, driverCoord, status, mode, cwLocations]);

  const showAgents = !isTracking && mode === 'valeter' && valeterPhase === 'form';

  // ------------ UI Components ------------
  const goHome = () => router.replace('/owner/owner-dashboard');

  const Tabs = () => (
    <View style={styles.tabs}>
      <TouchableOpacity
        onPress={() => setMode('valeter')}
        activeOpacity={0.9}
        style={[styles.tabBtn, mode === 'valeter' && styles.tabActive]}
      >
        <Text style={[styles.tabText, mode === 'valeter' && styles.tabTextActive]}>Valeter</Text>
      </TouchableOpacity>
      <TouchableOpacity
        onPress={() => setMode('location')}
        activeOpacity={0.9}
        style={[styles.tabBtn, mode === 'location' && styles.tabActive]}
      >
        <Text style={[styles.tabText, mode === 'location' && styles.tabTextActive]}>Physical location</Text>
      </TouchableOpacity>
    </View>
  );

  const VehicleStrip = () => (
    <View style={{ marginTop: 10 }}>
      <Text style={styles.sectionTitle}>Your vehicles</Text>
      {vehLoading ? (
        <ActivityIndicator />
      ) : vehicles.length ? (
        <RNScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingRight: 10 }}
          nestedScrollEnabled
          directionalLockEnabled
          scrollEventThrottle={16}
          onTouchStart={() => { isInnerScrolling.current = true; }}
          onTouchEnd={() => { isInnerScrolling.current = false; }}
          onTouchCancel={() => { isInnerScrolling.current = false; }}
        >
          {vehicles.map(v => {
            const sel = selectedVehicle?.id === v.id;
            return (
              <TouchableOpacity key={v.id} onPress={() => setSelectedVehicle(v)} style={[styles.pillCard, sel && styles.cardSel]}>
                <LinearGradient colors={sel ? ['#10B981','#059669'] : ['#1E3A8A','#87CEEB']} style={styles.pillGrad}>
                  <Text style={styles.emoji}>🚗</Text>
                  <Text style={styles.pillTitle}>{v.make} {v.model}</Text>
                  <Text style={styles.pillSub}>{v.registration}</Text>
                </LinearGradient>
              </TouchableOpacity>
            );
          })}
        </RNScrollView>
      ) : (
        <TouchableOpacity onPress={() => router.push('/vehicles/add')} style={styles.addBtn}>
          <Text style={{ color: '#fff', fontWeight: '700' }}>+ Add a vehicle</Text>
        </TouchableOpacity>
      )}
    </View>
  );

  const ValeterForm = () => {
    const serviceSel = serviceOptions.find(s=>s.id===selectedServiceId) || null;
    const price = useMemo(
      () => computeValeterPrice({ selectedVehicle, selectedServiceId, selectedTimeId }),
      [selectedVehicle, selectedServiceId, selectedTimeId]
    );

    return (
      <>
        <RNScrollView
          {...stableScrollProps}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: 240 + insets.bottom, flexGrow: 1 }}
        >
          <VehicleStrip />

          <Text style={styles.sectionTitle}>Service</Text>
          <View style={{ gap: 12 }}>
            {serviceOptions.map(s => {
              const sel = s.id === selectedServiceId;
              return (
                <TouchableOpacity key={s.id} onPress={() => setSelectedServiceId(s.id)} activeOpacity={0.9} style={[styles.card, sel && styles.cardSel]}>
                  <LinearGradient colors={sel ? s.colors : ['#1E3A8A','#87CEEB']} style={styles.cardGrad}>
                    <Text style={styles.cardTitle}>{s.name}</Text>
                    <Text style={styles.cardSub}>{s.desc} • ⏱️ {s.dur}</Text>
                  </LinearGradient>
                </TouchableOpacity>
              );
            })}
          </View>

          <Text style={[styles.sectionTitle, { marginTop: 14 }]}>Location</Text>
          <View style={{ gap: 12 }}>
            {presetLocations.map(p => {
              const sel = selectedPresetLoc === p.id;
              return (
                <TouchableOpacity key={p.id} onPress={async () => {
                  setSelectedPresetLoc(p.id);
                  if (p.id === 'current') await requestGps();
                }} activeOpacity={0.9} style={[styles.card, sel && styles.cardSel]}>
                  <LinearGradient colors={sel ? p.colors : ['#1E3A8A','#87CEEB']} style={[styles.cardGrad, { alignItems: 'center' }]}>
                    <Text style={{ fontSize: 24, marginBottom: 4 }}>{p.icon}</Text>
                    <Text style={styles.cardTitle}>{p.name}</Text>
                    {p.id === 'current' ? (
                      <>
                        {gpsLoading ? <ActivityIndicator style={{ marginTop: 6 }} /> : null}
                        {gpsAddr ? <Text style={[styles.cardSub, { marginTop: 6 }]}>📍 {gpsAddr}</Text> : null}
                      </>
                    ) : null}
                  </LinearGradient>
                </TouchableOpacity>
              );
            })}
          </View>

          <Text style={[styles.sectionTitle, { marginTop: 14 }]}>Preferred time</Text>
          <RNScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ paddingRight: 10 }}
            nestedScrollEnabled
            directionalLockEnabled
            scrollEventThrottle={16}
            onTouchStart={() => { isInnerScrolling.current = true; }}
            onTouchEnd={() => { isInnerScrolling.current = false; }}
            onTouchCancel={() => { isInnerScrolling.current = false; }}
          >
            {timeSlots.map(t => {
              const sel = t.id === selectedTimeId;
              return (
                <TouchableOpacity key={t.id} onPress={() => setSelectedTimeId(t.id)} activeOpacity={0.9} style={[styles.pillCardWide, sel && styles.cardSel]}>
                  <LinearGradient colors={sel ? t.colors : ['#1E3A8A','#87CEEB']} style={[styles.pillGrad, { paddingHorizontal: 16 }]}>
                    <Text style={{ fontSize: 18, marginRight: 6 }}>{t.icon}</Text>
                    <Text style={styles.pillTitle}>{t.name}</Text>
                  </LinearGradient>
                </TouchableOpacity>
              );
            })}
          </RNScrollView>

          <View style={styles.summaryBox}>
            <Text style={styles.summaryTitle}>Summary</Text>
            <Row label="Service" value={serviceSel?.name} />
            <Row label="Vehicle" value={selectedVehicle ? `${selectedVehicle.make} ${selectedVehicle.model}` : undefined} />
            <Row label="Time" value={timeSlots.find(t => t.id === selectedTimeId)?.name} />
            <Row label="Est. price" value={Number.isFinite(price as number) ? `£${price}` : '—'} />
          </View>

          <TouchableOpacity
            onPress={proceedToValeterList}
            activeOpacity={0.9}
            disabled={processing || !selectedVehicle || !selectedServiceId || !selectedPresetLoc}
            style={[styles.ctaBtn, (processing || !selectedVehicle || !selectedServiceId || !selectedPresetLoc) && { opacity: 0.6 }]}
          >
            <LinearGradient colors={[ACCENT, '#059669']} style={styles.ctaGrad}>
              <Text style={styles.ctaText}>{processing ? 'Processing…' : 'Find Available Valeters'}</Text>
            </LinearGradient>
          </TouchableOpacity>
        </RNScrollView>
      </>
    );
  };

  // NEW: Valeter List View
  const ValeterList = () => (
    <RNScrollView
      {...stableScrollProps}
      showsVerticalScrollIndicator={false}
      contentContainerStyle={{ paddingBottom: 240 + insets.bottom, flexGrow: 1 }}
    >
      <View style={styles.filterSection}>
        <Text style={styles.sectionTitle}>Available Valeters ({filteredValeters.length})</Text>

        <View style={styles.filterRow}>
          <Text style={styles.filterLabel}>Sort by:</Text>
          <View style={styles.sortButtons}>
            {(['distance', 'price', 'rating'] as const).map(sort => (
              <TouchableOpacity
                key={sort}
                onPress={() => setSortBy(sort)}
                style={[styles.sortBtn, sortBy === sort && styles.sortBtnActive]}
              >
                <Text style={[styles.sortBtnText, sortBy === sort && styles.sortBtnTextActive]}>
                  {sort === 'distance' ? '📍 Distance' : sort === 'price' ? '💷 Price' : '⭐ Rating'}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        <View style={styles.filterRow}>
          <Text style={styles.filterLabel}>Min Rating: {minRatingFilter.toFixed(1)}</Text>
          <View style={styles.ratingButtons}>
            {[0, 4.5, 4.7, 4.8].map(rating => (
              <TouchableOpacity
                key={rating}
                onPress={() => setMinRatingFilter(rating)}
                style={[styles.ratingBtn, minRatingFilter === rating && styles.ratingBtnActive]}
              >
                <Text style={[styles.ratingBtnText, minRatingFilter === rating && styles.ratingBtnTextActive]}>
                  {rating === 0 ? 'All' : `${rating}+`}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </View>

      {valetersLoading ? (
        <ActivityIndicator size="large" color={ACCENT} style={{ marginTop: 20 }} />
      ) : filteredValeters.length === 0 ? (
        <View style={styles.emptyState}>
          <Text style={styles.emptyText}>No valeters available</Text>
          <TouchableOpacity onPress={() => { setPriceFilter({ min: 0, max: 100 }); setMinRatingFilter(0); }}>
            <Text style={styles.resetText}>Reset Filters</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <View style={{ gap: 12 }}>
          {filteredValeters.map(valeter => (
            <TouchableOpacity
              key={valeter.id}
              onPress={() => selectValeterHandler(valeter)}
              disabled={processing}
              style={styles.valeterCard}
            >
              <View style={styles.valeterCardContent}>
                <View style={styles.valeterAvatar}>
                  <Text style={styles.valeterAvatarText}>{valeter.name.charAt(0)}</Text>
                </View>

                <View style={styles.valeterInfo}>
                  <Text style={styles.valeterName}>{valeter.name}</Text>
                  <View style={styles.valeterStats}>
                    <Text style={styles.valeterStat}>⭐ {valeter.rating.toFixed(1)}</Text>
                    <Text style={styles.valeterStat}>📍 {valeter.distance} mi</Text>
                    <Text style={styles.valeterStat}>🧽 {valeter.totalJobs} jobs</Text>
                  </View>
                </View>

                <View style={styles.valeterPrice}>
                  <Text style={styles.valeterPriceAmount}>£{valeter.price}</Text>
                  <Text style={styles.valeterPriceLabel}>Total</Text>
                </View>
              </View>
            </TouchableOpacity>
          ))}
        </View>
      )}

      <TouchableOpacity
        onPress={() => setValeterPhase('form')}
        style={[styles.ctaBtn, { backgroundColor: 'rgba(255,255,255,0.1)', marginTop: 20 }]}
      >
        <View style={styles.ctaGrad}>
          <Text style={styles.ctaText}>← Back to Form</Text>
        </View>
      </TouchableOpacity>
    </RNScrollView>
  );

  // NEW: Waiting for Acceptance View
  const WaitingForAcceptance = () => (
    <RNScrollView
      {...stableScrollProps}
      showsVerticalScrollIndicator={false}
      contentContainerStyle={{ paddingBottom: 240 + insets.bottom, flexGrow: 1 }}
    >
      <View style={{ alignItems: 'center', paddingTop: 20 }}>
        <View style={styles.pulseOuter}>
          <View style={styles.pulseInner}>
            <Text style={{ fontSize: 28 }}>⏳</Text>
          </View>
        </View>

        <Text style={styles.searchHeadline}>Waiting for {selectedValeter?.name}</Text>
        <Text style={styles.searchSub}>
          Your request has been sent. The valeter has 5 minutes to respond.
        </Text>

        <View style={styles.countdownBox}>
          <Text style={styles.countdownTime}>
            {acceptanceCountdown !== null ? formatTime(acceptanceCountdown) : '5:00'}
          </Text>
          <Text style={styles.countdownLabel}>Time remaining</Text>
        </View>

        <View style={styles.metaRow}>
          <Text style={styles.metaChip}>🧴 {serviceOptions.find(s => s.id === selectedServiceId)?.name}</Text>
          <Text style={styles.metaChip}>💷 £{selectedValeter?.price}</Text>
          <Text style={styles.metaChip}>📍 {selectedValeter?.distance} mi away</Text>
        </View>
      </View>
    </RNScrollView>
  );

  // NEW: Waiting for Payment View
  const WaitingForPayment = () => (
    <RNScrollView
      {...stableScrollProps}
      showsVerticalScrollIndicator={false}
      contentContainerStyle={{ paddingBottom: 240 + insets.bottom, flexGrow: 1 }}
    >
      <View style={{ alignItems: 'center', paddingTop: 20 }}>
        <View style={styles.pulseOuter}>
          <View style={[styles.pulseInner, { backgroundColor: '#F59E0B' }]}>
            <Text style={{ fontSize: 28 }}>💳</Text>
          </View>
        </View>

        <Text style={styles.searchHeadline}>{selectedValeter?.name} Accepted!</Text>
        <Text style={styles.searchSub}>
          Please complete payment to confirm your booking.
        </Text>

        <View style={styles.countdownBox}>
          <Text style={styles.countdownTime}>
            {paymentCountdown !== null ? formatTime(paymentCountdown) : '5:00'}
          </Text>
          <Text style={styles.countdownLabel}>Time to complete payment</Text>
        </View>

        <View style={styles.summaryBox}>
          <Text style={styles.summaryTitle}>Booking Summary</Text>
          <Row label="Valeter" value={selectedValeter?.name} />
          <Row label="Service" value={serviceOptions.find(s => s.id === selectedServiceId)?.name} />
          <Row label="Total" value={selectedValeter ? `£${selectedValeter.price}` : undefined} />
        </View>

        <TouchableOpacity
          onPress={handleValeterAcceptance}
          style={[styles.ctaBtn, { backgroundColor: ACCENT, marginTop: 20 }]}
        >
          <View style={styles.ctaGrad}>
            <Text style={styles.ctaText}>Pay Now</Text>
          </View>
        </TouchableOpacity>
      </View>
    </RNScrollView>
  );

  // Existing searching / tracking UI
  const ValeterSearching = () => {
    const headline =
      status === 'confirmed' ? 'Payment complete!'
      : status === 'valeter_assigned' ? 'Valeter found'
      : status === 'en_route' ? 'Valeter on the way'
      : status === 'arrived' ? 'Your valeter has arrived'
      : status === 'in_progress' ? 'Service in progress'
      : status === 'completed' ? 'All done!'
      : status === 'cancelled' ? 'Booking cancelled'
      : 'Finding your valeter';

    const statusLines =
      status === 'confirmed' ? ['💳 Payment successful', '🚀 Valeter preparing to start', '🚗 Waiting for valeter to begin journey']
      : status === 'valeter_assigned' ? ['✅ Valeter assigned', '📲 Setting up details', '🚗 Preparing to head your way']
      : status === 'en_route' ? ['🚗 En route', '📍 Live location is updating', '🕒 ETA updating']
      : status === 'arrived' ? ['📍 Valeter at your location', '🔔 They know you are ready', '🧽 Starting shortly']
      : status === 'in_progress' ? ['🧼 Service in progress', '✨ Sit tight — we will ping you on finish']
      : status === 'completed' ? ['✅ Completed', '🧾 Receipt in your bookings']
      : status === 'cancelled' ? ['⚠️ Booking cancelled']
      : ['📍 Scanning your area', '🚗 Checking compatibility', '⭐ Finding top-rated valeters'];

    return (
      <>
        <RNScrollView
          {...stableScrollProps}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: 240 + insets.bottom, flexGrow: 1 }}
        >
          <View style={{ alignItems: 'center', paddingTop: 8 }}>
            <View style={styles.pulseOuter}>
              <View style={styles.pulseInner}>
                <Text style={{ fontSize: 28 }}>
                  {status === 'confirmed' ? '💳'
                  : ['valeter_assigned','en_route','arrived','in_progress','completed'].includes(status) ? '✅'
                  : '🔍'}
                </Text>
              </View>
            </View>

            <Text style={styles.searchHeadline}>{headline}</Text>
            <Text style={styles.searchSub}>
              {status === 'pending' || status === 'scheduled'
                ? 'Searching for available valeters in your area…'
                : status === 'confirmed'
                ? 'Your valeter will start the journey soon.'
                : status === 'valeter_assigned'
                ? 'We are setting up live details for you.'
                : status === 'en_route'
                ? 'We will keep this updated.'
                : status === 'arrived'
                ? 'Head outside when ready.'
                : status === 'in_progress'
                ? 'Relax — we will ping you when done.'
                : status === 'completed'
                ? 'Thanks for booking with us.'
                : 'If this was a mistake, you can make a new booking.'}
            </Text>

            <View style={styles.metaRow}>
              {searchInfo.service ? <Text style={styles.metaChip}>🧴 {searchInfo.service}</Text> : null}
              {Number.isFinite(searchInfo.price) ? <Text style={styles.metaChip}>💷 £{Number(searchInfo.price).toFixed(0)}</Text> : null}
              {searchInfo.address ? <Text numberOfLines={1} style={[styles.metaChip, styles.metaAddress]}>📍 {searchInfo.address}</Text> : null}
            </View>

            <View style={{ marginTop: 16, gap: 6, width: '92%' }}>
              {statusLines.map((t, i) => (<Text key={i} style={{ color: '#E5E7EB', textAlign: 'center' }}>{t}</Text>))}
            </View>
          </View>
        </RNScrollView>

        <View style={[styles.stickyFooter, { paddingBottom: Math.max(insets.bottom, 12) }]}>
          {valeterPhase !== 'completed' && valeterPhase !== 'cancelled' ? (
            <TouchableOpacity onPress={cancelValeter} activeOpacity={0.9} style={[styles.ctaBtn]}>
              <LinearGradient colors={['#EF4444', '#B91C1C']} style={styles.ctaGrad}>
                <Text style={styles.ctaText}>Cancel request</Text>
              </LinearGradient>
            </TouchableOpacity>
          ) : (
            <TouchableOpacity onPress={() => { setValeterPhase('form'); setCurrentBookingId(null); }} activeOpacity={0.9} style={[styles.ctaBtn]}>
              <LinearGradient colors={[ACCENT, '#059669']} style={styles.ctaGrad}>
                <Text style={styles.ctaText}>Book again</Text>
              </LinearGradient>
            </TouchableOpacity>
          )}
        </View>
      </>
    );
  };

  const LocationForm = () => (
    <>
      <RNScrollView
        {...stableScrollProps}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 240 + insets.bottom, flexGrow: 1 }}
      >
        <Text style={[styles.sectionTitle, { marginTop: 6 }]}>Choose a location</Text>
        {cwLoading ? <ActivityIndicator /> : (
          cwLocations.map(l => {
            const sel = cwSelected === l.id;
            return (
              <TouchableOpacity key={l.id} onPress={() => { setCwSelected(l.id); setRegion(r=>({ ...r, latitude: l.latitude, longitude: l.longitude })); }} activeOpacity={0.9} style={[styles.card, sel && styles.cardSel]}>
                <LinearGradient colors={sel ? ['#3B82F6','#1D4ED8'] : ['#1E3A8A','#87CEEB']} style={styles.cardGrad}>
                  <Text style={styles.cardTitle}>{l.name}</Text>
                  <Text style={styles.cardSub}>{l.address}</Text>
                  <Text style={styles.cardSub}>⭐ {l.rating} ({l.totalReviews}) • Priority £{l.priorityPrice} • Base £{l.basePrice}</Text>
                </LinearGradient>
              </TouchableOpacity>
            );
          })
        )}

        <Text style={[styles.sectionTitle, { marginTop: 14 }]}>Vehicle type</Text>
        <RNScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingRight: 10 }}
          nestedScrollEnabled
          directionalLockEnabled
          scrollEventThrottle={16}
          onTouchStart={() => { isInnerScrolling.current = true; }}
          onTouchEnd={() => { isInnerScrolling.current = false; }}
          onTouchCancel={() => { isInnerScrolling.current = false; }}
        >
          {vehicleTypes.map(v => {
            const sel = cwVehType === v.id;
            return (
              <TouchableOpacity key={v.id} onPress={() => setCwVehType(v.id)} activeOpacity={0.9} style={[styles.pillCard, sel && styles.cardSel]}>
                <LinearGradient colors={sel ? ['#3B82F6','#1D4ED8'] : ['#1E3A8A','#87CEEB']} style={styles.pillGrad}>
                  <Text style={styles.emoji}>{v.icon}</Text>
                  <Text style={styles.pillTitle}>{v.name}</Text>
                  <Text style={styles.pillSub}>{v.mult}x</Text>
                </LinearGradient>
              </TouchableOpacity>
            );
          })}
        </RNScrollView>

        <Text style={[styles.sectionTitle, { marginTop: 14 }]}>Service</Text>
        <RNScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingRight: 10 }}>
          {serviceTypes.map(s => {
            const sel = cwService === s.id;
            return (
              <TouchableOpacity key={s.id} onPress={() => setCwService(s.id)} activeOpacity={0.9} style={[styles.pillCardWide, sel && styles.cardSel]}>
                <LinearGradient colors={sel ? ['#8B5CF6','#7C3AED'] : ['#1E3A8A','#87CEEB']} style={[styles.pillGrad, { paddingHorizontal: 16 }]}>
                  <Text style={styles.pillTitle}>{s.name}</Text>
                  <Text style={[styles.pillSub, { marginLeft: 8 }]}>⏱️ {s.dur}</Text>
                </LinearGradient>
              </TouchableOpacity>
            );
          })}
        </RNScrollView>

        <View style={styles.summaryBox}>
          <Text style={styles.summaryTitle}>Summary</Text>
          <Row label="Location" value={selectedCw?.name} />
          <Row label="Vehicle" value={cwVehType ? vehicleTypes.find(v=>v.id===cwVehType)?.name : undefined} />
          <Row label="Service" value={cwService ? serviceTypes.find(s=>s.id===cwService)?.name : undefined} />
          <Row label="Base" value={cwPricing ? `£${cwPricing.base.toFixed(2)}` : '—'} />
          <Row label="Priority fee" value={cwPricing ? `£${cwPricing.priority.toFixed(2)}` : '—'} />
          <Row label="Total" value={cwPricing ? `£${cwPricing.total.toFixed(2)}` : '—'} />
        </View>
        <TouchableOpacity
          onPress={confirmPhysicalBooking}
          activeOpacity={0.9}
          disabled={processing || !selectedCw || !cwVehType || !cwService || !cwPricing}
          style={[styles.ctaBtn, (processing || !selectedCw || !cwVehType || !cwService || !cwPricing) && { opacity: 0.6 }]}
        >
          <LinearGradient colors={[SKY, '#1D4ED8']} style={styles.ctaGrad}>
            <Text style={styles.ctaText}>{processing ? 'Processing…' : 'Confirm & Track'}</Text>
          </LinearGradient>
        </TouchableOpacity>
      </RNScrollView>
    </>
  );

  const showTabs = !isTracking;

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <MapLayer
        region={region}
        markers={markers}
        onRegionChangeComplete={setRegion}
        showAgents={showAgents}
      />

      <TouchableOpacity onPress={goHome} activeOpacity={0.85} style={[styles.closeBtn, { top: insets.top + 8 }]}>
        <Text style={{ color: '#0A1929', fontSize: 16, fontWeight: '900' }}>✕</Text>
      </TouchableOpacity>

      <View pointerEvents="none" style={[styles.mapOverlay, { top: insets.top + 8 }]}>
        <Text style={styles.mapHint}>
          {isTracking ? 'Tracking your booking…' : (valeterPhase === 'form' ? 'Pick a mode below to start' : 'Tracking your booking…')}
        </Text>
      </View>

      <Animated.View
        style={[styles.sheet, { paddingBottom: Math.max(insets.bottom, 12), transform: [{ translateY: sheetY }] }]}
      >
        <View {...pan.panHandlers} style={styles.bigGrab}>
          <View style={styles.bigGrabHandle} />
        </View>

        {showTabs ? <Tabs /> : null}

        <View style={styles.sheetBody}>
          {isTracking
            ? <ValeterSearching />
            : (mode === 'valeter'
              ? (valeterPhase === 'form' ? <ValeterForm />
                : valeterPhase === 'valeter_list' ? <ValeterList />
                : valeterPhase === 'waiting_acceptance' ? <WaitingForAcceptance />
                : valeterPhase === 'waiting_payment' ? <WaitingForPayment />
                : <ValeterSearching />)
              : <LocationForm />)}
        </View>
      </Animated.View>
    </SafeAreaView>
  );
}

const Row = ({ label, value }: { label: string; value?: string }) => (
  <View style={styles.row}>
    <Text style={styles.rowLabel}>{label}:</Text>
    <Text style={styles.rowValue}>{value ?? '—'}</Text>
  </View>
);

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },

  closeBtn: {
    position: 'absolute', right: 12,
    backgroundColor: '#FFFFFF', width: 36, height: 36, borderRadius: 18,
    alignItems: 'center', justifyContent: 'center',
    shadowColor: '#000', shadowOpacity: 0.2, shadowRadius: 8, elevation: 3, zIndex: 4,
  },

  mapOverlay: { position: 'absolute', alignSelf: 'center', backgroundColor: 'rgba(10,25,41,0.6)', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 999 },
  mapHint: { color: '#E5E7EB', fontWeight: '600' },

  sheet: {
    position: 'absolute', left: 0, right: 0, height,
    backgroundColor: 'rgba(10,25,41,0.98)',
    borderTopLeftRadius: 20, borderTopRightRadius: 20,
    borderTopWidth: 1, borderColor: 'rgba(255,255,255,0.08)',
  },

  bigGrab: { paddingTop: 10, paddingBottom: 6, alignItems: 'center' },
  bigGrabHandle: {
    width: 110, height: 10, borderRadius: 999, backgroundColor: 'rgba(255,255,255,0.55)',
  },

  tabs: { flexDirection: 'row', gap: 10, paddingHorizontal: 14, paddingTop: 10 },
  tabBtn: { flex: 1, borderRadius: 999, paddingVertical: 12, alignItems: 'center', borderWidth: 1, borderColor: 'rgba(255,255,255,0.22)' },
  tabActive: { backgroundColor: 'rgba(16,185,129,0.14)', borderColor: ACCENT },
  tabText: { color: '#E5E7EB', fontWeight: '700' },
  tabTextActive: { color: '#fff' },

  sheetBody: { flex: 1, paddingHorizontal: 14, paddingTop: 8 },

  sectionTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: '800', marginBottom: 10 },

  pillCard: {
    width: 180, borderRadius: 14, overflow: 'hidden', marginRight: 10,
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.14)',
  },
  pillCardWide: {
    minWidth: 180, borderRadius: 14, overflow: 'hidden', marginRight: 10,
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.14)',
  },
  pillGrad: { padding: 12, alignItems: 'center', justifyContent: 'center' },
  emoji: { fontSize: 26, marginBottom: 4 },
  pillTitle: { color: '#fff', fontWeight: '800' },
  pillSub: { color: '#E5E7EB', fontSize: 12, marginTop: 2 },

  addBtn: { marginTop: 8, alignSelf: 'flex-start', paddingVertical: 10, paddingHorizontal: 12, borderRadius: 10, backgroundColor: 'rgba(255,255,255,0.12)' },

  card: {
    borderRadius: 14, overflow: 'hidden',
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.16)',
  },
  cardSel: { borderColor: ACCENT, borderWidth: 2 },
  cardGrad: { padding: 14 },
  cardTitle: { color: '#fff', fontWeight: '800', fontSize: 16 },
  cardSub: { color: '#E5E7EB', marginTop: 6 },

  summaryBox: { marginTop: 16, backgroundColor: 'rgba(255,255,255,0.06)', borderRadius: 14, padding: 14, borderWidth: 1, borderColor: 'rgba(255,255,255,0.12)' },
  summaryTitle: { color: '#fff', fontWeight: '900', fontSize: 16, marginBottom: 8 },
  row: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 8 },
  rowLabel: { color: '#E5E7EB' },
  rowValue: { color: '#fff', fontWeight: '800' },

  stickyFooter: {
    position: 'absolute', left: 0, right: 0, bottom: 0,
    paddingHorizontal: 14, backgroundColor: 'rgba(10,25,41,0.98)',
    borderTopWidth: 1, borderTopColor: 'rgba(255,255,255,0.1)', zIndex: 10,
  },
  ctaBtn: { marginTop: 10, borderRadius: 12, overflow: 'hidden' },
  ctaGrad: { paddingVertical: 14, alignItems: 'center' },
  ctaText: { color: '#fff', fontWeight: '900', fontSize: 16 },

  pulseOuter: { width: 120, height: 120, borderRadius: 60, backgroundColor: 'rgba(16,185,129,0.2)', justifyContent: 'center', alignItems: 'center', marginTop: 6 },
  pulseInner: { width: 80, height: 80, borderRadius: 40, backgroundColor: '#10B981', alignItems: 'center', justifyContent: 'center' },
  searchHeadline: { color: '#F9FAFB', fontSize: 22, fontWeight: '800', marginTop: 12, textAlign: 'center' },
  searchSub: { color: '#E5E7EB', fontSize: 14, marginTop: 6, textAlign: 'center', paddingHorizontal: 20 },
  metaRow: { flexDirection: 'row', flexWrap: 'nowrap', gap: 8, marginTop: 12, maxWidth: '92%', alignSelf: 'center' },
  metaChip: {
    color: '#0A1929',
    backgroundColor: '#93C5FD',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    fontSize: 12,
    overflow: 'hidden',
  },
  metaAddress: { backgroundColor: '#87CEEB', maxWidth: '60%' },

  // NEW: Valeter list styles
  filterSection: { marginBottom: 16 },
  filterRow: { marginTop: 12 },
  filterLabel: { color: '#E5E7EB', fontSize: 14, marginBottom: 6 },
  sortButtons: { flexDirection: 'row', gap: 8, flexWrap: 'wrap' },
  sortBtn: {
    paddingVertical: 8, paddingHorizontal: 12, borderRadius: 8,
    backgroundColor: 'rgba(255,255,255,0.1)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.2)',
  },
  sortBtnActive: { backgroundColor: ACCENT, borderColor: ACCENT },
  sortBtnText: { color: '#E5E7EB', fontSize: 12, fontWeight: '600' },
  sortBtnTextActive: { color: '#fff' },
  ratingButtons: { flexDirection: 'row', gap: 8, flexWrap: 'wrap' },
  ratingBtn: {
    paddingVertical: 8, paddingHorizontal: 16, borderRadius: 8,
    backgroundColor: 'rgba(255,255,255,0.1)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.2)',
  },
  ratingBtnActive: { backgroundColor: '#F59E0B', borderColor: '#F59E0B' },
  ratingBtnText: { color: '#E5E7EB', fontSize: 14, fontWeight: '600' },
  ratingBtnTextActive: { color: '#fff' },

  emptyState: { alignItems: 'center', paddingVertical: 40 },
  emptyText: { color: '#E5E7EB', fontSize: 16, marginBottom: 12 },
  resetText: { color: ACCENT, fontSize: 14, fontWeight: '700' },

  valeterCard: {
    backgroundColor: 'rgba(255,255,255,0.08)', borderRadius: 14,
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.12)', overflow: 'hidden',
  },
  valeterCardContent: { flexDirection: 'row', padding: 14, alignItems: 'center' },
  valeterAvatar: {
    width: 50, height: 50, borderRadius: 25, backgroundColor: ACCENT,
    justifyContent: 'center', alignItems: 'center', marginRight: 12,
  },
  valeterAvatarText: { color: '#fff', fontSize: 20, fontWeight: '800' },
  valeterInfo: { flex: 1 },
  valeterName: { color: '#fff', fontSize: 16, fontWeight: '800', marginBottom: 4 },
  valeterStats: { flexDirection: 'row', gap: 12 },
  valeterStat: { color: '#E5E7EB', fontSize: 12 },
  valeterPrice: { alignItems: 'flex-end' },
  valeterPriceAmount: { color: '#10B981', fontSize: 24, fontWeight: '900' },
  valeterPriceLabel: { color: '#E5E7EB', fontSize: 11 },

  // NEW: Countdown styles
  countdownBox: {
    marginTop: 20, backgroundColor: 'rgba(255,255,255,0.06)', borderRadius: 14,
    padding: 20, borderWidth: 1, borderColor: 'rgba(255,255,255,0.12)',
    alignItems: 'center', minWidth: 200,
  },
  countdownTime: { color: '#10B981', fontSize: 48, fontWeight: '900' },
  countdownLabel: { color: '#E5E7EB', fontSize: 12, marginTop: 4 },
});