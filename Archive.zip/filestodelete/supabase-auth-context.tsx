import React, { createContext, useContext, useEffect, useState } from 'react';
import { supabase, User, Database } from '../src/lib/supabase';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Session } from '@supabase/supabase-js';

interface AuthContextType {
  user: User | null;
  session: Session | null;
  isLoading: boolean;
  signUp: (email: string, password: string, userData: Partial<User>) => Promise<{ error: any }>;
  signIn: (email: string, password: string) => Promise<{ error: any }>;
  signOut: () => Promise<void>;
  resetPassword: (email: string) => Promise<{ error: any }>;
  updateProfile: (updates: Partial<User>) => Promise<{ error: any }>;
  // Auto-login methods for development
  autoLoginCustomer: () => Promise<void>;
  autoLoginValeter: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const SupabaseAuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      if (session?.user) {
        fetchUser(session.user.id);
      }
      setIsLoading(false);
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setSession(session);
        if (session?.user) {
          await fetchUser(session.user.id);
        } else {
          setUser(null);
        }
        setIsLoading(false);
      }
    );

    return () => subscription.unsubscribe();
  }, []);

  const fetchUser = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .eq('id', userId)
        .single();

      if (error) {
        console.error('Error fetching user:', error);
        return;
      }

      setUser(data);
    } catch (error) {
      console.error('Error fetching user:', error);
    }
  };

  const signUp = async (email: string, password: string, userData: Partial<User>) => {
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
      });

      if (error) {
        return { error };
      }

      if (data.user) {
        // Create user profile in database
        const { error: profileError } = await supabase
          .from('users')
          .insert([
            {
              id: data.user.id,
              email: data.user.email!,
              name: userData.name || '',
              phone: userData.phone,
              user_type: userData.user_type || 'customer',
              is_verified: false,
              verification_type: 'email',
              total_washes: 0,
              tier: 'bronze',
              tier_points: 0,
              join_date: new Date().toISOString(),
              created_at: new Date().toISOString(),
              updated_at: new Date().toISOString(),
              ...userData,
            },
          ]);

        if (profileError) {
          console.error('Error creating user profile:', profileError);
          return { error: profileError };
        }

        // If valeter, create valeter profile
        if (userData.user_type === 'valeter') {
          const { error: valeterError } = await supabase
            .from('valeter_profiles')
            .insert([
              {
                user_id: data.user.id,
                working_radius: 10,
                is_online: false,
                specializations: [],
                documents: {},
                created_at: new Date().toISOString(),
                updated_at: new Date().toISOString(),
              },
            ]);

          if (valeterError) {
            console.error('Error creating valeter profile:', valeterError);
          }
        }
      }

      return { error: null };
    } catch (error) {
      return { error };
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        return { error };
      }

      if (data.user) {
        await fetchUser(data.user.id);
      }

      return { error: null };
    } catch (error) {
      return { error };
    }
  };

  const signOut = async () => {
    try {
      await supabase.auth.signOut();
      setUser(null);
      setSession(null);
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  const resetPassword = async (email: string) => {
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email);
      return { error };
    } catch (error) {
      return { error };
    }
  };

  const updateProfile = async (updates: Partial<User>) => {
    if (!user) {
      return { error: new Error('No user logged in') };
    }

    try {
      const { error } = await supabase
        .from('users')
        .update({
          ...updates,
          updated_at: new Date().toISOString(),
        })
        .eq('id', user.id);

      if (error) {
        return { error };
      }

      // Update local user state
      setUser({ ...user, ...updates });
      return { error: null };
    } catch (error) {
      return { error };
    }
  };

  // Super Admin authentication
  const authenticateSuperAdmin = async (accessCode: string, deviceId: string) => {
    try {
      // Check if user is already authenticated
      if (!session?.user) {
        return { error: new Error('No user session'), success: false };
      }

      // Validate access code (in production, this would be more secure)
      const validAccessCodes = [
        'REECEYRACKZ2026',
        'WISHWASH2026',
        'SUPERADMIN2026',
        'FOUNDER2026',
        'ADMIN2026'
      ];

      const isValid = validAccessCodes.includes(accessCode.toUpperCase());

      // Log the access attempt
      await logAdminAccess(accessCode, isValid, deviceId);

      if (isValid) {
        // Update user to super_admin if not already
        if (user?.user_type !== 'super_admin') {
          await updateProfile({ user_type: 'super_admin' });
        }
        return { error: null, success: true };
      }

      return { error: new Error('Invalid access code'), success: false };
    } catch (error) {
      return { error, success: false };
    }
  };

  const logAdminAccess = async (accessCode: string, success: boolean, deviceId: string) => {
    if (!session?.user) return;

    try {
      await supabase
        .from('admin_access_logs')
        .insert([
          {
            user_id: session.user.id,
            access_code: success ? '***' : accessCode, // Don't log successful codes
            success,
            device_id: deviceId,
            created_at: new Date().toISOString(),
          },
        ]);
    } catch (error) {
      console.error('Error logging admin access:', error);
    }
  };

  // Auto-login methods for development (will be removed in production)
  const autoLoginCustomer = async () => {
    // This would be removed in production
    console.log('Auto-login customer - development only');
  };

  const autoLoginValeter = async () => {
    // This would be removed in production
    console.log('Auto-login valeter - development only');
  };

  const autoLoginSuperAdmin = async () => {
    // This would be removed in production
    console.log('Auto-login super admin - development only');
  };

  const value = {
    user,
    session,
    isLoading,
    signUp,
    signIn,
    signOut,
    resetPassword,
    updateProfile,
    authenticateSuperAdmin,
    logAdminAccess,
    autoLoginCustomer,
    autoLoginValeter,
    autoLoginSuperAdmin,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export const useSupabaseAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useSupabaseAuth must be used within a SupabaseAuthProvider');
  }
  return context;
};
