// app/valeter/PowerfulDriverDashboard.tsx
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  View, Text, StyleSheet, TouchableOpacity, Animated, Dimensions,
  SafeAreaView, StatusBar, ScrollView, Modal, Image, Alert, ActivityIndicator
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useAuth } from '../../providers/enhanced-auth-context';
import AIChatComponent from '../chat/AIChatComponent';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import * as Location from 'expo-location';
import { supabase } from '../../lib/supabase';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const isMediumScreen = width >= 375 && width < 414;

interface QuickAction {
  id: string;
  icon: string;
  title: string;
  subtitle: string;
  onPress: () => void;
  color: string;
}

interface Stat {
  title: string;
  value: string;
  icon: string;
  change: string;
  isPositive: boolean;
}

export default function PowerfulDriverDashboard() {
  const { user } = useAuth();
  const [showChat, setShowChat] = useState(false);
  const [isOnline, setIsOnline] = useState(false);
  const [loadingPresence, setLoadingPresence] = useState(true);
  const [toggling, setToggling] = useState(false);

  const scrollY = useRef(new Animated.Value(0)).current;
  const headerHeight = scrollY.interpolate({ inputRange: [0, 100], outputRange: [180, 100], extrapolate: 'clamp' });
  const headerOpacity = scrollY.interpolate({ inputRange: [0, 50, 100], outputRange: [1, 0.9, 0.8], extrapolate: 'clamp' });
  const fadeValue = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(fadeValue, { toValue: 1, duration: 1000, useNativeDriver: true }).start();
  }, []);

  // Load initial online status + subscribe to realtime for this user
  useEffect(() => {
    if (!user?.id) return;
    let mounted = true;

    (async () => {
      setLoadingPresence(true);
      const { data, error } = await supabase
        .from('valeter_presence')
        .select('is_online')
        .eq('user_id', user.id)
        .maybeSingle();
      if (!mounted) return;
      if (error) console.warn('[presence] read error', error);
      setIsOnline(!!data?.is_online);
      setLoadingPresence(false);
    })();

    const channel = supabase
      .channel('presence-self')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'valeter_presence', filter: `user_id=eq.${user.id}` },
        (payload) => {
          const row: any = payload.new ?? payload.old;
          if (row && typeof row.is_online === 'boolean') setIsOnline(row.is_online);
        }
      )
      .subscribe();

    return () => {
      mounted = false;
      supabase.removeChannel(channel);
    };
  }, [user?.id]);

  // Go online: request location and call update_my_presence(true, lat, lng)
  const goOnlineWithLocation = async () => {
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission needed', 'Location permission is required to go online so customers can find you.');
      throw new Error('location-permission-denied');
    }
    const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
    const lat = Number(loc.coords.latitude.toFixed(6));
    const lng = Number(loc.coords.longitude.toFixed(6));

    const { error } = await supabase.rpc('update_my_presence', {
      p_is_online: true,
      p_last_lat: lat,
      p_last_lng: lng,
    });
    if (error) throw error;
  };

  // Go offline: set_online(false)
  const goOffline = async () => {
    const { error } = await supabase.rpc('set_online', { p_is_online: false });
    if (error) throw error;
  };

  const toggleOnline = async () => {
    try {
      if (!user?.id) return;
      setToggling(true);
      if (!isOnline) {
        await goOnlineWithLocation();
        hapticFeedback?.success?.();
      } else {
        await goOffline();
        hapticFeedback?.impact?.('light');
      }
      // DB realtime will flip isOnline; we also pessimize local state for snappy UI
      setIsOnline(!isOnline);
    } catch (e) {
      console.error('[presence] toggle error', e);
      hapticFeedback?.error?.();
      Alert.alert('Error', 'Could not update your online status. Try again.');
    } finally {
      setToggling(false);
    }
  };

  // Quick actions list
  const quickActions: QuickAction[] = useMemo(() => [
    {
      id: 'go-online',
      icon: isOnline ? '🔴' : '🟢',
      title: isOnline ? 'Go Offline' : 'Go Online',
      subtitle: isOnline ? 'Stop accepting jobs' : 'Start accepting jobs',
      onPress: toggleOnline,
      color: isOnline ? '#EF4444' : '#10B981',
    },
    {
      id: 'current-trip',
      icon: '📍',
      title: 'Current Trip',
      subtitle: 'View active job',
      onPress: () => router.push('/current-trip'),
      color: '#3B82F6',
    },
    {
      id: 'jobs',
      icon: '🚗',
      title: 'Jobs',
      subtitle: 'Accept washes',
      onPress: () => router.push('/wash-requests'),
      color: '#10B981',
    },
    {
      id: 'radius',
      icon: '✈️',
      title: 'Radius',
      subtitle: 'Set working area',
      onPress: () => router.push('/distance-covering'),
      color: '#87CEEB',
    },
    {
      id: 'profile',
      icon: '👤',
      title: 'My Profile',
      subtitle: 'View & edit profile',
      onPress: () => router.push('valeter/valeter-profile'),
      color: '#F59E0B',
    },
    {
      id: 'wash-completion',
      icon: '📸',
      title: 'Complete Wash',
      subtitle: 'Upload photos & notes',
      onPress: () => router.push('/wash-completion-upload'),
      color: '#10B981',
    },
    {
      id: 'wash-history',
      icon: '📋',
      title: 'Wash History',
      subtitle: 'View completed washes',
      onPress: () => router.push('valeter/valeter-wash-history'),
      color: '#8B5CF6',
    },
    {
      id: 'rewards',
      icon: '🎁',
      title: 'Rewards',
      subtitle: 'Earn points & rewards',
      onPress: () => router.push('valeter/valeter-rewards-system'),
      color: '#F59E0B',
    },
  ], [isOnline]);

  // Stats (placeholder/demo)
  const stats: Stat[] = [
    { title: "Today's Earnings", value: '£45', icon: '💰', change: '+£12', isPositive: true },
    { title: 'Jobs Completed', value: '3', icon: '✅', change: '+1', isPositive: true },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0A1929" />

      {/* Fixed Header */}
      <Animated.View style={[styles.header, { height: headerHeight, opacity: headerOpacity }]}>
        <LinearGradient colors={['#0A1929', '#1E3A8A']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={StyleSheet.absoluteFill} />
        <View style={styles.headerContent}>
          <View style={styles.headerTop}>
            <View style={styles.headerLeft}>
              <Text style={styles.greeting}>
                {new Date().getHours() < 12 ? 'Good morning! 👋' : new Date().getHours() < 17 ? 'Good afternoon! 🌟' : 'Good evening! 🌙'}
              </Text>
              <Text style={styles.userName}>{user?.name || 'Valeter'}</Text>
              <Text style={styles.subtitle}>Professional Valeting Dashboard</Text>
            </View>
            <View style={styles.headerActions}>
              <TouchableOpacity style={styles.profileButton} onPress={() => router.push('valeter/valeter-profile')}>
                {user?.profilePicture ? <Image source={{ uri: user.profilePicture }} style={styles.profileImage} /> : <Text style={styles.profileIcon}>👤</Text>}
              </TouchableOpacity>
            </View>
          </View>

          <View style={styles.poweredByContainer}>
            <Text style={styles.poweredByText}>Powered by Wish a Wash ⚡</Text>
            <View style={styles.onlineStatus}>
              <View style={[styles.onlineIndicator, { backgroundColor: isOnline ? '#4CAF50' : '#EF4444' }]} />
              <Text style={[styles.onlineText, { color: isOnline ? '#4CAF50' : '#EF4444' }]}>
                {loadingPresence || toggling ? 'Updating…' : isOnline ? 'Online' : 'Offline'}
              </Text>
            </View>
          </View>
        </View>
      </Animated.View>

      {/* Scrollable Content */}
      <Animated.ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], { useNativeDriver: false })}
        scrollEventThrottle={16}
      >
        {/* Quick Actions */}
        <Animated.View style={[styles.section, { opacity: fadeValue }]}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <View style={styles.quickActionsGrid}>
            {quickActions.map((action) => (
              <TouchableOpacity
                key={action.id}
                style={[styles.quickAction, { backgroundColor: action.color, opacity: action.id === 'go-online' && (loadingPresence || toggling) ? 0.6 : 1 }]}
                onPress={action.onPress}
                disabled={action.id === 'go-online' && (loadingPresence || toggling)}
              >
                <Text style={styles.quickActionIcon}>{action.icon}</Text>
                <Text style={styles.quickActionTitle}>{action.title}</Text>
                <Text style={styles.quickActionSubtitle}>{action.subtitle}</Text>
                {action.id === 'go-online' && (loadingPresence || toggling) ? <ActivityIndicator style={{ marginTop: 8 }} /> : null}
              </TouchableOpacity>
            ))}
          </View>
        </Animated.View>

        {/* Statistics */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Today's Statistics</Text>
          <View style={styles.statsGrid}>
            {stats.map((stat) => (
              <View key={stat.title} style={styles.statCard}>
                <View style={styles.statHeader}>
                  <Text style={styles.statIcon}>{stat.icon}</Text>
                  <View style={[styles.changeIndicator, { backgroundColor: stat.isPositive ? '#10B981' : '#EF4444' }]}>
                    <Text style={styles.changeText}>{stat.isPositive ? '↗' : '↘'} {stat.change}</Text>
                  </View>
                </View>
                <Text style={styles.statValue}>{stat.value}</Text>
                <Text style={styles.statTitle}>{stat.title}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Quick Navigation */}
        <View style={styles.quickNav}>
          <TouchableOpacity style={styles.navButton} onPress={() => router.push('/valeter-profile')}>
            <Text style={styles.navButtonIcon}>👤</Text>
            <Text style={styles.navButtonText}>Profile</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.navButton} onPress={() => router.push('/detailed-stats')}>
            <Text style={styles.navButtonIcon}>💰</Text>
            <Text style={styles.navButtonText}>Earnings</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.navButton} onPress={() => router.push('/organization-dashboard')}>
            <Text style={styles.navButtonIcon}>🏢</Text>
            <Text style={styles.navButtonText}>Organizations</Text>
          </TouchableOpacity>
        </View>
      </Animated.ScrollView>

      {/* AI Chat Modal */}
      <Modal visible={showChat} animationType="slide" presentationStyle="fullScreen">
        <AIChatComponent userType="valeter" onClose={() => setShowChat(false)} />
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A1929' },
  header: { backgroundColor: '#0A1929', height: 200 },
  headerContent: { flex: 1, justifyContent: 'flex-end', padding: isSmallScreen ? 16 : isMediumScreen ? 20 : 24 },
  headerTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end' },
  headerLeft: { flex: 1 },
  headerActions: { flexDirection: 'row', gap: 12 },
  greeting: { fontSize: 16, color: '#F9FAFB', opacity: 0.9 },
  userName: { fontSize: 22, fontWeight: 'bold', color: '#F9FAFB', marginTop: 4 },
  subtitle: { fontSize: 14, color: '#87CEEB', marginTop: 4 },
  poweredByContainer: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 8 },
  poweredByText: { color: 'rgba(255, 255, 255, 0.6)', fontSize: 10, fontWeight: '400' },
  onlineStatus: { flexDirection: 'row', alignItems: 'center', marginTop: 8 },
  onlineIndicator: { width: 8, height: 8, borderRadius: 4, marginRight: 6 },
  onlineText: { fontSize: 12, fontWeight: '600' },
  profileButton: { width: 44, height: 44, borderRadius: 22, backgroundColor: 'rgba(255, 255, 255, 0.2)', justifyContent: 'center', alignItems: 'center' },
  profileIcon: { fontSize: 20 },
  profileImage: { width: 44, height: 44, borderRadius: 22 },

  scrollView: { flex: 1 },
  scrollContent: { paddingTop: 20, paddingHorizontal: 20 },
  section: { marginBottom: 32 },
  sectionTitle: { fontSize: 20, fontWeight: 'bold', color: '#F9FAFB', marginBottom: 16 },

  quickActionsGrid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' },
  quickAction: {
    width: '48%', borderRadius: 16, padding: 20, marginBottom: 16, alignItems: 'center',
    elevation: 4, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4,
  },
  quickActionIcon: { fontSize: 32, marginBottom: 8 },
  quickActionTitle: { fontSize: 16, fontWeight: 'bold', color: '#FFFFFF', marginBottom: 4, textAlign: 'center' },
  quickActionSubtitle: { fontSize: 10, color: 'rgba(255, 255, 255, 0.8)', textAlign: 'center' },

  statsGrid: { flexDirection: 'row', justifyContent: 'space-between', gap: 16 },
  statCard: {
    flex: 1, backgroundColor: '#1E3A8A', borderRadius: 16, padding: 20, alignItems: 'center',
    elevation: 4, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4,
  },
  statHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', width: '100%', marginBottom: 12 },
  statIcon: { fontSize: 24 },
  changeIndicator: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12 },
  changeText: { fontSize: 12, fontWeight: 'bold', color: '#FFFFFF' },
  statValue: { fontSize: 28, fontWeight: 'bold', color: '#FFFFFF', marginBottom: 4 },
  statTitle: { fontSize: 14, color: 'rgba(255, 255, 255, 0.8)', textAlign: 'center' },

  quickNav: {
    flexDirection: 'row', justifyContent: 'space-around', paddingHorizontal: 20, paddingVertical: 20,
    backgroundColor: '#1E3A8A', borderRadius: 16, marginHorizontal: 16, marginBottom: 20,
  },
  navButton: { alignItems: 'center', padding: 12 },
  navButtonIcon: { fontSize: 24, marginBottom: 4 },
  navButtonText: { fontSize: 12, color: '#FFFFFF', fontWeight: '600' },
});