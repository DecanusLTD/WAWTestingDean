// app/customer/EnhancedCustomerDashboard.tsx
import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Animated,
  Dimensions,
  SafeAreaView,
  StatusBar,
  Modal,
  Image,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useAuth } from '../../providers/enhanced-auth-context';
import BookingService, { Booking } from '../../services/BookingService';
import AIChatComponent from '../chat/AIChatComponent';
import { supabase } from '../../lib/supabase';

const { width } = Dimensions.get('window');

// Responsive breakpoints
const isSmallScreen = width < 375;
const isMediumScreen = width >= 375 && width < 414;

interface Stats {
  totalBookings: number;
  totalSpent: number;
  averageRating: number;
  completedServices: number;
  savings: number;
}

interface QuickAction {
  id: string;
  icon: string;
  title: string;
  subtitle: string;
  route: string;
  color: string;
  gradient: string[];
}

interface NearbyValeter {
  id: string;
  name: string;
  rating: number;
  distance: number | null;
  isOnline: boolean;
  organization: string;
}

const CARD_W = isSmallScreen ? 170 : isMediumScreen ? 180 : 190;

// Keep statuses in case the service is a bit loose
const ACTIVE_STATUSES: Booking['status'][] = [
  'scheduled',
  'confirmed',
  'valeter_assigned',
  'en_route',
  'arrived',
  'in_progress',
];

/* ------------ helpers for presence + identity ------------- */
const truthyOnline = (v: any) => {
  if (v === true) return true;
  if (typeof v === 'number') return v === 1;
  if (typeof v === 'string') {
    const s = v.trim().toLowerCase();
    return s === 'true' || s === '1' || s === 'online' || s === 'yes' || s === 'y';
  }
  return false;
};

type NameOrg = { name: string; organization: string };
const pickNameOrg = (profile: any, valeterProfile: any): NameOrg => {
  const name =
    profile?.full_name ??
    profile?.display_name ??
    valeterProfile?.display_name ??
    'Valeter';
  const organization =
    profile?.company_name ??
    valeterProfile?.company_name ??
    'Independent';
  return { name, organization };
};
/* ---------------------------------------------------------- */

export default function EnhancedCustomerDashboard() {
  const { user } = useAuth();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [activeBooking, setActiveBooking] = useState<Booking | null>(null);
  const [showChat, setShowChat] = useState(false);
  const [nearbyValeters, setNearbyValeters] = useState<NearbyValeter[]>([]);
  const [stats, setStats] = useState<Stats>({
    totalBookings: 0,
    totalSpent: 0,
    averageRating: 0,
    completedServices: 0,
    savings: 0,
  });
  const [loading, setLoading] = useState(true);

  const scrollY = useRef(new Animated.Value(0)).current;
  const headerHeight = scrollY.interpolate({ inputRange: [0, 100], outputRange: [180, 100], extrapolate: 'clamp' });
  const headerOpacity = scrollY.interpolate({ inputRange: [0, 50, 100], outputRange: [1, 0.9, 0.8], extrapolate: 'clamp' });

  // Animation for valeter dots
  const valeterDotAnim1 = useRef(new Animated.Value(0)).current;
  const valeterDotAnim2 = useRef(new Animated.Value(0)).current;
  const valeterDotAnim3 = useRef(new Animated.Value(0)).current;
  const valeterDotAnim4 = useRef(new Animated.Value(0)).current;
  const valeterDotAnim5 = useRef(new Animated.Value(0)).current;

  const quickActions: QuickAction[] = [
    { id: 'instant-wash', icon: '⚡', title: 'Instant Wash', subtitle: 'Quick booking', route: '/auto-service-booking', color: '#10B981', gradient: ['#10B981', '#059669'] },
    { id: 'priority-wash', icon: '⭐', title: 'Local Priority', subtitle: 'Premium service', route: '/priority-wash', color: '#8B5CF6', gradient: ['#8B5CF6', '#7C3AED'] },
    { id: 'rewards', icon: '🎁', title: 'Rewards', subtitle: 'Earn points & rewards', route: '/rewards-system', color: '#F59E0B', gradient: ['#F59E0B', '#D97706'] },
    { id: 'wash-history', icon: '📸', title: 'Wash History', subtitle: 'View completed washes', route: '/wash-history', color: '#10B981', gradient: ['#10B981', '#059669'] },
  ];

  // Use the SAME logic as Instant Wash page
  const fetchExistingActiveBooking = async (userId: string) => {
    try {
      if ((BookingService as any).getActiveBookingForUser) {
        const viaService2 = await (BookingService as any).getActiveBookingForUser(userId);
        if (viaService2 && (!viaService2.status || ACTIVE_STATUSES.includes(viaService2.status))) {
          return viaService2 as Booking;
        }
      }
      const viaService = await BookingService.getActiveBooking(userId);
      if (viaService && (!viaService.status || ACTIVE_STATUSES.includes(viaService.status))) {
        return viaService;
      }
      return null;
    } catch (e) {
      console.error('[getActiveBooking(sync with Instant)] error:', e);
      return null;
    }
  };

  useEffect(() => {
    const loadDashboardData = async () => {
      if (!user?.id) return;

      try {
        const userBookings = await BookingService.getUserBookings(user.id);
        setBookings(userBookings);

        const active = await fetchExistingActiveBooking(user.id);
        setActiveBooking(active);

        const bookingStats = await BookingService.getBookingStats(user.id);
        setStats(bookingStats);

        await loadNearbyValeters();

        const unsubscribe = BookingService.subscribeToBookings(user.id, async (updatedBookings) => {
          setBookings(updatedBookings);
          const updatedActive = await fetchExistingActiveBooking(user.id);
          setActiveBooking(updatedActive);
          BookingService.getBookingStats(user.id).then(setStats).catch((e: any) => console.warn('stats refresh err', e));
        });

        setLoading(false);
        return unsubscribe;
      } catch (error) {
        console.error('Error loading dashboard data:', error);
        setLoading(false);
      }
    };

    loadDashboardData();
  }, [user]);

  // Realtime presence → refresh nearby list
  useEffect(() => {
    const channel = supabase
      .channel('presence-feed')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'valeter_presence' }, () => {
        clearTimeout((loadNearbyValeters as any)._t);
        (loadNearbyValeters as any)._t = setTimeout(() => loadNearbyValeters(), 350);
      })
      .subscribe();

    return () => {
      clearTimeout((loadNearbyValeters as any)._t);
      supabase.removeChannel(channel);
    };
  }, []);

  // tolerant user location extraction
  const getUserLatLng = () => {
    const lat =
      user?.lastKnownLocation?.latitude ??
      user?.location?.latitude ??
      user?.profile?.lastKnownLocation?.latitude ??
      null;
    const lng =
      user?.lastKnownLocation?.longitude ??
      user?.location?.longitude ??
      user?.profile?.lastKnownLocation?.longitude ??
      null;
    return { lat, lng };
  };

  // Haversine distance (km)
  const haversineKm = (aLat: number, aLng: number, bLat: number, bLng: number) => {
    const toRad = (d: number) => (d * Math.PI) / 180;
    const R = 6371;
    const dLat = toRad(bLat - aLat);
    const dLng = toRad(bLng - aLng);
    const s1 = Math.sin(dLat / 2);
    const s2 = Math.sin(dLng / 2);
    const a = s1 * s1 + Math.cos(toRad(aLat)) * Math.cos(toRad(bLat)) * s2 * s2;
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return +(R * c).toFixed(1);
  };

  /* -------- Presence-only Nearby Valeters ---------- */
  const loadNearbyValeters = async () => {
    try {
      const { lat: uLat, lng: uLng } = getUserLatLng();

      // 1) Read presence table
      const { data: presenceRows, error: presErr } = await supabase
        .from('valeter_presence')
        .select('user_id, is_online, last_lat, last_lng, last_seen_at')
        .limit(200);

      if (presErr) {
        console.warn('[NearbyValeters] presence error:', presErr);
      }

      // Filter to online only
      const onlinePresence = (presenceRows ?? []).filter((p: any) => truthyOnline(p?.is_online));

      if (!onlinePresence.length) {
        setNearbyValeters([]);
        return;
      }

      // 2) Hydrate identity from profiles & valeter_profiles
      const ids = Array.from(new Set(onlinePresence.map((p: any) => p.user_id).filter(Boolean)));

      const [{ data: profs }, { data: vProfs }] = await Promise.all([
        supabase
          .from('profiles')
          .select('id, full_name, display_name, company_name')
          .in('id', ids),
        supabase
          .from('valeter_profiles')
          .select('user_id, display_name, company_name')
          .in('user_id', ids),
      ]);

      const profileMap = new Map<string, any>();
      (profs ?? []).forEach((p: any) => profileMap.set(p.id, p));

      const vprofileMap = new Map<string, any>();
      (vProfs ?? []).forEach((vp: any) => vprofileMap.set(vp.user_id, vp));

      // 3) Build list with distances
      const MAX_KM = 50; // client-side cutoff
      const list: NearbyValeter[] = onlinePresence
        .map((p: any) => {
          const lat = p?.last_lat != null ? Number(p.last_lat) : NaN;
          const lng = p?.last_lng != null ? Number(p.last_lng) : NaN;

          const profile = profileMap.get(p.user_id);
          const vprof = vprofileMap.get(p.user_id);
          const { name, organization } = pickNameOrg(profile, vprof);

          const distance =
            uLat != null &&
            uLng != null &&
            !Number.isNaN(lat) &&
            !Number.isNaN(lng)
              ? haversineKm(uLat, uLng, lat, lng)
              : null;

          return {
            id: p.user_id,
            name,
            organization,
            rating: 0, // presence-only; hydrate from a ratings table later if needed
            distance,
            isOnline: true,
          };
        })
        .filter((v) => v.distance == null || v.distance <= MAX_KM);

      // 4) Sort: distance asc, then most recently seen
      list.sort((a, b) => {
        if (a.distance == null && b.distance != null) return 1;
        if (a.distance != null && b.distance == null) return -1;
        if (a.distance != null && b.distance != null && a.distance !== b.distance) return a.distance - b.distance;

        const aSeen = (presenceRows ?? []).find((r: any) => r.user_id === a.id)?.last_seen_at;
        const bSeen = (presenceRows ?? []).find((r: any) => r.user_id === b.id)?.last_seen_at;
        return (bSeen ? new Date(bSeen).getTime() : 0) - (aSeen ? new Date(aSeen).getTime() : 0);
      });

      setNearbyValeters(list.slice(0, 8));

      // Debug crumb
      console.log('[NearbyValeters] presence online:', onlinePresence.length, 'rendered:', list.length);
    } catch (e) {
      console.error('[NearbyValeters] load error:', e);
      setNearbyValeters([]);
    }
  };
  /* -------------------------------------------------- */

  const handleQuickAction = (action: QuickAction) => {
    try {
      router.push(action.route as any);
    } catch {
      router.push(action.route as any);
    }
  };

  const getServiceIcon = (serviceType: string) => {
    switch (serviceType) {
      case 'priority_wash': return '⭐';
      case 'instant_wash': return '⚡';
      case 'full_valet': return '✨';
      default: return '🚗';
    }
  };

  const getServiceColor = (serviceType: string): [string, string] => {
    switch (serviceType) {
      case 'priority_wash': return ['#8B5CF6', '#7C3AED'];
      case 'instant_wash': return ['#10B981', '#059669'];
      case 'full_valet': return ['#F59E0B', '#D97706'];
      default: return ['#1E3A8A', '#87CEEB'];
    }
  };

  const getOnlineValetersCount = () => nearbyValeters.filter((v) => v.isOnline).length;

  const getAverageRating = () => {
    const online = nearbyValeters.filter((v) => v.isOnline);
    if (online.length === 0) return 0;
    return online.reduce((sum, v) => sum + v.rating, 0) / online.length;
  };

  useEffect(() => {
    const startAnimations = () => {
      Animated.loop(Animated.sequence([
        Animated.timing(valeterDotAnim1, { toValue: 1, duration: 2000, useNativeDriver: true }),
        Animated.timing(valeterDotAnim1, { toValue: 0, duration: 2000, useNativeDriver: true }),
      ])).start();

      Animated.loop(Animated.sequence([
        Animated.timing(valeterDotAnim2, { toValue: 1, duration: 2500, useNativeDriver: true }),
        Animated.timing(valeterDotAnim2, { toValue: 0, duration: 2500, useNativeDriver: true }),
      ])).start();

      Animated.loop(Animated.sequence([
        Animated.timing(valeterDotAnim3, { toValue: 1, duration: 3000, useNativeDriver: true }),
        Animated.timing(valeterDotAnim3, { toValue: 0, duration: 3000, useNativeDriver: true }),
      ])).start();

      Animated.loop(Animated.sequence([
        Animated.timing(valeterDotAnim4, { toValue: 1, duration: 2200, useNativeDriver: true }),
        Animated.timing(valeterDotAnim4, { toValue: 0, duration: 2200, useNativeDriver: true }),
      ])).start();

      Animated.loop(Animated.sequence([
        Animated.timing(valeterDotAnim5, { toValue: 1, duration: 2800, useNativeDriver: true }),
        Animated.timing(valeterDotAnim5, { toValue: 0, duration: 2800, useNativeDriver: true }),
      ])).start();
    };

    startAnimations();
  }, []);

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />
        <Text style={styles.loadingText}>Loading dashboard...</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0A1929" />
      <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />

      {/* Header */}
      <Animated.View style={[styles.header, { height: headerHeight, opacity: headerOpacity }]}>
        <View style={styles.headerContent}>
          <View style={styles.headerTop}>
            <TouchableOpacity
              style={styles.profileTapArea}
              onPress={() => router.push('owner/owner-profile')}
              activeOpacity={0.7}
              hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
              accessibilityRole="button"
              accessibilityLabel="Open account settings"
            >
              {user?.profilePicture ? (
                <Image source={{ uri: user.profilePicture }} style={styles.profileImage} />
              ) : (
                <View style={styles.profileButton}>
                  <Text style={styles.profileIcon}>👤</Text>
                </View>
              )}
              <View style={styles.greetingContainer}>
                <Text style={styles.greeting}>
                  {new Date().getHours() < 12 ? 'Good morning' : new Date().getHours() < 17 ? 'Good afternoon' : 'Good evening'}
                </Text>
                <Text style={styles.userName} numberOfLines={1}>
                  {user?.name || 'Customer'}
                </Text>
                <Text style={styles.subtitle}>Customer Dashboard</Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity style={styles.analyticsButton} onPress={() => router.push('/detailed-stats')}>
              <Text style={styles.analyticsIcon}>📊</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Animated.View>

      <Animated.ScrollView
        style={styles.scrollView}
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], { useNativeDriver: false })}
        scrollEventThrottle={16}
        showsVerticalScrollIndicator={false}
      >
        {/* Active Service (top) — only renders if you actually have one */}
        {activeBooking && (
          <View style={styles.activeBookingBanner}>
            <LinearGradient colors={getServiceColor(activeBooking.serviceType)} style={styles.activeBookingGradient}>
              <View style={styles.activeBookingContent}>
                <View style={styles.activeBookingLeft}>
                  <View style={styles.serviceHeader}>
                    <Text style={styles.serviceIcon}>{getServiceIcon(activeBooking.serviceType)}</Text>
                    <Text style={styles.activeBookingTitle}>Active Service</Text>
                  </View>
                  <Text style={styles.activeBookingService}>{activeBooking.serviceName}</Text>
                  <Text style={styles.activeBookingValeter}>
                    {activeBooking.valeterName} • {activeBooking.valeterOrganization}
                  </Text>
                  <Text style={styles.activeBookingStatus}>
                    Status: {activeBooking.status.replace('_', ' ').toUpperCase()}
                  </Text>
                </View>
                <View style={styles.activeBookingActions}>
                  <TouchableOpacity style={styles.messageButton} onPress={() => setShowChat(true)}>
                    <Text style={styles.messageButtonText}>💬</Text>
                  </TouchableOpacity>
                  {/* Single "Track" button that opens the current booking screen */}
                  <TouchableOpacity
                    style={styles.trackButton}
                    onPress={() => router.push({ pathname: '/current-trip', params: { bookingId: activeBooking.id } })}
                  >
                    <Text style={styles.trackButtonText}>Track</Text>
                  </TouchableOpacity>
                </View>
              </View>
            </LinearGradient>
          </View>
        )}

        {/* Quick Actions */}
        <View style={styles.quickActionsSection}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.quickActionsContainer}>
            {quickActions.map((action) => (
              <TouchableOpacity key={action.id} style={styles.quickActionCard} onPress={() => handleQuickAction(action)} activeOpacity={0.8}>
                <LinearGradient colors={action.gradient} style={styles.quickActionGradient}>
                  <Text style={styles.quickActionIcon}>{action.icon}</Text>
                  <Text style={styles.quickActionTitle}>{action.title}</Text>
                  <Text style={styles.quickActionSubtitle}>{action.subtitle}</Text>
                </LinearGradient>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Stats Overview */}
        <View style={styles.statsSection}>
          <Text style={styles.sectionTitle}>Overview</Text>
          <View style={styles.statsGrid}>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{stats.totalBookings}</Text>
              <Text style={styles.statLabel}>Total Bookings</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>£{stats.totalSpent}</Text>
              <Text style={styles.statLabel}>Total Spent</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{stats.averageRating}⭐</Text>
              <Text style={styles.statLabel}>Avg Rating</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{stats.completedServices}</Text>
              <Text style={styles.statLabel}>Completed</Text>
            </View>
          </View>
        </View>

        {/* Nearby Valeters (bottom) */}
        <View style={styles.nearbyValetersSection}>
          <Text style={styles.sectionTitle}>Nearby Valeters</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.nearbyValetersContainer}>
            {nearbyValeters
              .filter((v) => v.isOnline)
              .slice(0, 8)
              .map((valeter) => (
                <View key={valeter.id} style={styles.nearbyValeterCard}>
                  <View style={styles.valeterInfo}>
                    <Text style={styles.valeterName} numberOfLines={1}>{valeter.name}</Text>
                    <Text style={styles.valeterOrganization} numberOfLines={2}>{valeter.organization}</Text>
                    <Text style={styles.valeterRating}>⭐ {valeter.rating.toFixed(1)}</Text>
                    <Text style={styles.valeterDistance}>
                      {valeter.distance != null ? `${valeter.distance}km away` : 'Distance n/a'}
                    </Text>
                  </View>
                  <View style={[styles.onlineIndicator, { backgroundColor: valeter.isOnline ? '#10B981' : '#6B7280' }]} />
                </View>
              ))}
          </ScrollView>
        </View>
      </Animated.ScrollView>

      {/* Chat Modal */}
      <Modal visible={showChat} animationType="slide" presentationStyle="fullScreen">
        <AIChatComponent userType="customer" onClose={() => setShowChat(false)} />
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A1929' },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#0A1929' },
  loadingText: { color: '#F9FAFB', fontSize: 16 },
  header: { backgroundColor: '#0A1929' },
  headerContent: { flex: 1, justifyContent: 'flex-end', padding: isSmallScreen ? 16 : 20 },
  headerTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end' },

  profileTapArea: { flexDirection: 'row', alignItems: 'center', gap: 12, flex: 1 },
  profileButton: { width: 44, height: 44, borderRadius: 22, backgroundColor: 'rgba(255,255,255,0.2)', justifyContent: 'center', alignItems: 'center' },
  profileIcon: { fontSize: 20 },
  profileImage: { width: 44, height: 44, borderRadius: 22 },
  greetingContainer: { flex: 1 },
  greeting: { color: '#F9FAFB', fontSize: isSmallScreen ? 16 : 18, marginBottom: 4 },
  userName: { color: '#F9FAFB', fontSize: isSmallScreen ? 20 : 24, fontWeight: 'bold', marginBottom: 4 },
  subtitle: { color: '#87CEEB', fontSize: isSmallScreen ? 14 : 16 },

  analyticsButton: { width: 44, height: 44, borderRadius: 22, backgroundColor: 'rgba(255,255,255,0.2)', justifyContent: 'center', alignItems: 'center' },
  analyticsIcon: { fontSize: 20 },

  scrollView: { flex: 1 },

  activeBookingBanner: {
    marginHorizontal: isSmallScreen ? 12 : 20,
    marginBottom: 20,
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  activeBookingGradient: { padding: 20 },
  activeBookingContent: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  activeBookingLeft: { flex: 1 },
  serviceHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 4 },
  serviceIcon: { fontSize: 24, marginRight: 8 },
  activeBookingTitle: { color: '#FFFFFF', fontSize: 12, fontWeight: '600', marginBottom: 4 },
  activeBookingService: { color: '#FFFFFF', fontSize: 18, fontWeight: 'bold', marginBottom: 4 },
  activeBookingValeter: { color: '#FFFFFF', fontSize: 14, opacity: 0.9 },
  activeBookingStatus: { color: '#87CEEB', fontSize: 12, marginTop: 4 },
  activeBookingActions: { flexDirection: 'row', gap: 8, alignItems: 'center' },
  messageButton: { width: 44, height: 44, borderRadius: 22, backgroundColor: 'rgba(255,255,255,0.2)', justifyContent: 'center', alignItems: 'center' },
  messageButtonText: { fontSize: 20 },
  trackButton: { backgroundColor: 'rgba(255,255,255,0.2)', paddingHorizontal: 16, paddingVertical: 10, borderRadius: 20 },
  trackButtonText: { color: '#FFFFFF', fontSize: 14, fontWeight: '600' },

  quickActionsSection: { marginBottom: 24 },
  sectionTitle: { color: '#F9FAFB', fontSize: isSmallScreen ? 18 : 20, fontWeight: 'bold', marginBottom: 16, marginHorizontal: isSmallScreen ? 12 : 20 },
  quickActionsContainer: { paddingHorizontal: isSmallScreen ? 12 : 20 },
  quickActionCard: {
    width: CARD_W, height: CARD_W, borderRadius: 16, marginRight: 14, overflow: 'hidden',
    elevation: 6, shadowColor: '#000', shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.2, shadowRadius: 6,
  },
  quickActionGradient: { flex: 1, padding: 18, alignItems: 'center', justifyContent: 'center' },
  quickActionIcon: { fontSize: isSmallScreen ? 34 : 38, marginBottom: 10 },
  quickActionTitle: { color: '#FFFFFF', fontSize: isSmallScreen ? 16 : 18, fontWeight: '700', marginBottom: 6, textAlign: 'center' },
  quickActionSubtitle: { color: '#FFFFFF', fontSize: isSmallScreen ? 11 : 12, opacity: 0.9, textAlign: 'center' },

  statsSection: { marginBottom: 24 },
  statsGrid: {
    flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', gap: 12,
    paddingHorizontal: isSmallScreen ? 12 : 20,
  },
  statCard: {
    width: (width - (isSmallScreen ? 36 : 40)) / 2 - 6,
    backgroundColor: '#102B6A', padding: 18, borderRadius: 14, alignItems: 'center',
    elevation: 4, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.2, shadowRadius: 4,
  },
  statNumber: { fontSize: isSmallScreen ? 20 : 24, fontWeight: 'bold', color: '#F9FAFB', marginBottom: 4 },
  statLabel: { fontSize: 12, color: '#87CEEB', textAlign: 'center' },

  nearbyValetersSection: { marginBottom: 32 },
  nearbyValetersContainer: { paddingHorizontal: isSmallScreen ? 12 : 20 },
  nearbyValeterCard: {
    backgroundColor: '#102B6A', padding: 16, borderRadius: 14, marginRight: 14, width: CARD_W, minHeight: 132,
    elevation: 4, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.2, shadowRadius: 4,
    position: 'relative', justifyContent: 'space-between',
  },
  valeterInfo: { paddingRight: 12 },
  valeterName: { fontSize: isSmallScreen ? 16 : 17, fontWeight: '700', color: '#F9FAFB', marginBottom: 2 },
  valeterOrganization: { fontSize: isSmallScreen ? 12 : 13, color: '#B8D2F3', marginBottom: 6 },
  valeterRating: { fontSize: isSmallScreen ? 14 : 15, color: '#F59E0B', fontWeight: '700', marginBottom: 2 },
  valeterDistance: { fontSize: 12, color: '#87CEEB' },
  onlineIndicator: { width: 12, height: 12, borderRadius: 6, position: 'absolute', top: 10, right: 10 },
});