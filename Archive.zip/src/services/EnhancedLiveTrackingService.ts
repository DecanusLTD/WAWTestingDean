export interface LiveTrackingData {
  id: string;
  valeterId: string;
  customerId: string;
  jobId: string;
  currentLocation: {
    latitude: number;
    longitude: number;
    accuracy: number;
    timestamp: Date;
  };
  destination: {
    latitude: number;
    longitude: number;
    address: string;
  };
  route: {
    distance: number; // in meters
    duration: number; // in seconds
    polyline: string; // encoded polyline
    trafficLevel: 'low' | 'medium' | 'high';
  };
  status: 'en_route' | 'arrived' | 'in_progress' | 'completing' | 'completed';
  eta: Date;
  estimatedCompletion: Date;
  progress: number; // 0-100
  notifications: TrackingNotification[];
}

export interface TrackingNotification {
  id: string;
  type: 'location_update' | 'eta_update' | 'status_change' | 'traffic_alert' | 'completion_update';
  title: string;
  message: string;
  timestamp: Date;
  read: boolean;
  priority: 'low' | 'medium' | 'high';
}

export interface RouteAnimation {
  id: string;
  startLocation: { latitude: number; longitude: number };
  endLocation: { latitude: number; longitude: number };
  duration: number; // milliseconds
  easing: 'linear' | 'ease-in' | 'ease-out' | 'ease-in-out';
  onUpdate?: (progress: number, location: { latitude: number; longitude: number }) => void;
  onComplete?: () => void;
}

export class EnhancedLiveTrackingService {
  private static instance: EnhancedLiveTrackingService;
  private trackingData: Map<string, LiveTrackingData> = new Map();
  private animations: Map<string, RouteAnimation> = new Map();
  private listeners: ((data: LiveTrackingData) => void)[] = [];
  private notificationListeners: ((notification: TrackingNotification) => void)[] = [];
  private updateIntervals: Map<string, NodeJS.Timeout> = new Map();

  static getInstance(): EnhancedLiveTrackingService {
    if (!EnhancedLiveTrackingService.instance) {
      EnhancedLiveTrackingService.instance = new EnhancedLiveTrackingService();
    }
    return EnhancedLiveTrackingService.instance;
  }

  // Start tracking a job
  startTracking(
    jobId: string,
    valeterId: string,
    customerId: string,
    startLocation: { latitude: number; longitude: number },
    destination: { latitude: number; longitude: number; address: string }
  ): LiveTrackingData {
    const trackingData: LiveTrackingData = {
      id: `tracking_${jobId}`,
      valeterId,
      customerId,
      jobId,
      currentLocation: {
        latitude: startLocation.latitude,
        longitude: startLocation.longitude,
        accuracy: 5,
        timestamp: new Date()
      },
      destination,
      route: {
        distance: this.calculateDistance(startLocation, destination),
        duration: this.calculateDuration(startLocation, destination),
        polyline: this.generatePolyline(startLocation, destination),
        trafficLevel: this.getTrafficLevel()
      },
      status: 'en_route',
      eta: this.calculateETA(startLocation, destination),
      estimatedCompletion: this.calculateCompletionTime(startLocation, destination),
      progress: 0,
      notifications: []
    };

    this.trackingData.set(trackingData.id, trackingData);
    this.startLocationUpdates(trackingData.id);
    this.notifyListeners(trackingData);

    // Send initial notification
    this.sendNotification(trackingData.id, {
      type: 'status_change',
      title: 'Tracking Started',
      message: `Live tracking started for job ${jobId}`,
      priority: 'medium'
    });

    return trackingData;
  }

  // Update valeter location
  updateLocation(
    trackingId: string,
    latitude: number,
    longitude: number,
    accuracy: number = 5
  ): boolean {
    const tracking = this.trackingData.get(trackingId);
    if (!tracking) return false;

    const oldLocation = { ...tracking.currentLocation };
    tracking.currentLocation = {
      latitude,
      longitude,
      accuracy,
      timestamp: new Date()
    };

    // Update route and ETA
    tracking.route = {
      distance: this.calculateDistance(tracking.currentLocation, tracking.destination),
      duration: this.calculateDuration(tracking.currentLocation, tracking.destination),
      polyline: this.generatePolyline(tracking.currentLocation, tracking.destination),
      trafficLevel: this.getTrafficLevel()
    };

    tracking.eta = this.calculateETA(tracking.currentLocation, tracking.destination);
    tracking.progress = this.calculateProgress(tracking.currentLocation, tracking.destination);

    // Check if arrived
    if (tracking.route.distance < 50 && tracking.status === 'en_route') { // 50 meters threshold
      this.updateStatus(trackingId, 'arrived');
    }

    this.trackingData.set(trackingId, tracking);
    this.notifyListeners(tracking);

    // Send location update notification
    this.sendNotification(trackingId, {
      type: 'location_update',
      title: 'Location Updated',
      message: `New ETA: ${this.formatETA(tracking.eta)}`,
      priority: 'low'
    });

    return true;
  }

  // Update job status
  updateStatus(trackingId: string, status: LiveTrackingData['status']): boolean {
    const tracking = this.trackingData.get(trackingId);
    if (!tracking) return false;

    const oldStatus = tracking.status;
    tracking.status = status;

    // Update completion time if status changed
    if (status === 'in_progress') {
      tracking.estimatedCompletion = this.calculateCompletionTime(
        tracking.currentLocation,
        tracking.destination
      );
    }

    this.trackingData.set(trackingId, tracking);
    this.notifyListeners(tracking);

    // Send status change notification
    const statusMessages = {
      'arrived': 'Valeter has arrived at your location',
      'in_progress': 'Valeter has started the service',
      'completing': 'Service is being completed',
      'completed': 'Service has been completed'
    };

    if (statusMessages[status]) {
      this.sendNotification(trackingId, {
        type: 'status_change',
        title: 'Status Update',
        message: statusMessages[status],
        priority: 'high'
      });
    }

    return true;
  }

  // Get tracking data
  getTrackingData(trackingId: string): LiveTrackingData | undefined {
    return this.trackingData.get(trackingId);
  }

  // Get all tracking data for a user
  getUserTrackingData(userId: string, userType: 'valeter' | 'customer'): LiveTrackingData[] {
    return Array.from(this.trackingData.values()).filter(tracking => 
      userType === 'valeter' ? tracking.valeterId === userId : tracking.customerId === userId
    );
  }

  // Stop tracking
  stopTracking(trackingId: string): boolean {
    const tracking = this.trackingData.get(trackingId);
    if (!tracking) return false;

    // Clear update interval
    const interval = this.updateIntervals.get(trackingId);
    if (interval) {
      clearInterval(interval);
      this.updateIntervals.delete(trackingId);
    }

    // Send completion notification
    this.sendNotification(trackingId, {
      type: 'completion_update',
      title: 'Tracking Complete',
      message: 'Live tracking has ended',
      priority: 'medium'
    });

    this.trackingData.delete(trackingId);
    return true;
  }

  // Start route animation
  startRouteAnimation(animation: RouteAnimation): string {
    const animationId = `animation_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    this.animations.set(animationId, animation);

    const startTime = Date.now();
    const duration = animation.duration;

    const animate = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);

      // Calculate current position using linear interpolation
      const currentLat = animation.startLocation.latitude + 
        (animation.endLocation.latitude - animation.startLocation.latitude) * progress;
      const currentLng = animation.startLocation.longitude + 
        (animation.endLocation.longitude - animation.startLocation.longitude) * progress;

      if (animation.onUpdate) {
        animation.onUpdate(progress, { latitude: currentLat, longitude: currentLng });
      }

      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        if (animation.onComplete) {
          animation.onComplete();
        }
        this.animations.delete(animationId);
      }
    };

    requestAnimationFrame(animate);
    return animationId;
  }

  // Stop route animation
  stopRouteAnimation(animationId: string): boolean {
    return this.animations.delete(animationId);
  }

  // Add tracking listener
  addTrackingListener(listener: (data: LiveTrackingData) => void): void {
    this.listeners.push(listener);
  }

  // Remove tracking listener
  removeTrackingListener(listener: (data: LiveTrackingData) => void): void {
    const index = this.listeners.indexOf(listener);
    if (index > -1) {
      this.listeners.splice(index, 1);
    }
  }

  // Add notification listener
  addNotificationListener(listener: (notification: TrackingNotification) => void): void {
    this.notificationListeners.push(listener);
  }

  // Remove notification listener
  removeNotificationListener(listener: (notification: TrackingNotification) => void): void {
    const index = this.notificationListeners.indexOf(listener);
    if (index > -1) {
      this.notificationListeners.splice(index, 1);
    }
  }

  // Get notifications for tracking
  getNotifications(trackingId: string): TrackingNotification[] {
    const tracking = this.trackingData.get(trackingId);
    return tracking?.notifications || [];
  }

  // Mark notification as read
  markNotificationAsRead(trackingId: string, notificationId: string): boolean {
    const tracking = this.trackingData.get(trackingId);
    if (!tracking) return false;

    const notification = tracking.notifications.find(n => n.id === notificationId);
    if (notification) {
      notification.read = true;
      this.trackingData.set(trackingId, tracking);
      return true;
    }

    return false;
  }

  // Private methods
  private startLocationUpdates(trackingId: string): void {
    const interval = setInterval(() => {
      const tracking = this.trackingData.get(trackingId);
      if (!tracking || tracking.status === 'completed') {
        clearInterval(interval);
        this.updateIntervals.delete(trackingId);
        return;
      }

      // Simulate movement towards destination
      const progress = tracking.progress / 100;
      const newLat = tracking.currentLocation.latitude + 
        (tracking.destination.latitude - tracking.currentLocation.latitude) * 0.01;
      const newLng = tracking.currentLocation.longitude + 
        (tracking.destination.longitude - tracking.currentLocation.longitude) * 0.01;

      this.updateLocation(trackingId, newLat, newLng);
    }, 5000); // Update every 5 seconds

    this.updateIntervals.set(trackingId, interval);
  }

  private calculateDistance(
    start: { latitude: number; longitude: number },
    end: { latitude: number; longitude: number }
  ): number {
    const R = 6371e3; // Earth's radius in meters
    const φ1 = this.toRadians(start.latitude);
    const φ2 = this.toRadians(end.latitude);
    const Δφ = this.toRadians(end.latitude - start.latitude);
    const Δλ = this.toRadians(end.longitude - start.longitude);

    const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ/2) * Math.sin(Δλ/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

    return R * c;
  }

  private calculateDuration(
    start: { latitude: number; longitude: number },
    end: { latitude: number; longitude: number }
  ): number {
    const distance = this.calculateDistance(start, end);
    const averageSpeed = 30; // km/h
    return (distance / 1000) / averageSpeed * 3600; // Convert to seconds
  }

  private calculateETA(
    start: { latitude: number; longitude: number },
    end: { latitude: number; longitude: number }
  ): Date {
    const duration = this.calculateDuration(start, end);
    const eta = new Date();
    eta.setSeconds(eta.getSeconds() + duration);
    return eta;
  }

  private calculateCompletionTime(
    start: { latitude: number; longitude: number },
    end: { latitude: number; longitude: number }
  ): Date {
    const eta = this.calculateETA(start, end);
    const completion = new Date(eta);
    completion.setMinutes(completion.getMinutes() + 30); // Add 30 minutes for service
    return completion;
  }

  private calculateProgress(
    current: { latitude: number; longitude: number },
    destination: { latitude: number; longitude: number }
  ): number {
    // Simple progress calculation based on distance
    const totalDistance = this.calculateDistance(
      { latitude: 0, longitude: 0 },
      destination
    );
    const remainingDistance = this.calculateDistance(current, destination);
    return Math.max(0, Math.min(100, ((totalDistance - remainingDistance) / totalDistance) * 100));
  }

  private generatePolyline(
    start: { latitude: number; longitude: number },
    end: { latitude: number; longitude: number }
  ): string {
    // Simplified polyline generation
    const points = [
      [start.latitude, start.longitude],
      [end.latitude, end.longitude]
    ];
    return JSON.stringify(points);
  }

  private getTrafficLevel(): 'low' | 'medium' | 'high' {
    const levels: ('low' | 'medium' | 'high')[] = ['low', 'medium', 'high'];
    return levels[Math.floor(Math.random() * levels.length)];
  }

  private formatETA(eta: Date): string {
    const now = new Date();
    const diff = eta.getTime() - now.getTime();
    const minutes = Math.floor(diff / (1000 * 60));
    
    if (minutes < 1) return 'Arriving now';
    if (minutes < 60) return `${minutes} min`;
    
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = minutes % 60;
    return `${hours}h ${remainingMinutes}m`;
  }

  private toRadians(degrees: number): number {
    return degrees * (Math.PI / 180);
  }

  private sendNotification(
    trackingId: string,
    notificationData: Omit<TrackingNotification, 'id' | 'timestamp' | 'read'>
  ): void {
    const tracking = this.trackingData.get(trackingId);
    if (!tracking) return;

    const notification: TrackingNotification = {
      id: `notification_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      ...notificationData,
      timestamp: new Date(),
      read: false
    };

    tracking.notifications.push(notification);
    this.trackingData.set(trackingId, tracking);

    // Notify listeners
    this.notificationListeners.forEach(listener => {
      try {
        listener(notification);
      } catch (error) {
        console.error('Error in notification listener:', error);
      }
    });
  }

  private notifyListeners(tracking: LiveTrackingData): void {
    this.listeners.forEach(listener => {
      try {
        listener(tracking);
      } catch (error) {
        console.error('Error in tracking listener:', error);
      }
    });
  }

  // Cleanup
  cleanup(): void {
    this.updateIntervals.forEach(interval => clearInterval(interval));
    this.updateIntervals.clear();
    this.trackingData.clear();
    this.animations.clear();
    this.listeners = [];
    this.notificationListeners = [];
  }
}

export const enhancedLiveTrackingService = EnhancedLiveTrackingService.getInstance();
