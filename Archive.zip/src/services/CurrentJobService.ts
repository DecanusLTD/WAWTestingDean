import AsyncStorage from '@react-native-async-storage/async-storage';
import { Booking } from './BookingService';

export interface CurrentJob {
  id: string;
  bookingId: string;
  customerId: string;
  valeterId: string;
  serviceType: string;
  serviceName: string;
  vehicleType: string;
  vehicleInfo?: string;
  location: {
    address: string;
    latitude: number;
    longitude: number;
  };
  price: number;
  status: 'assigned' | 'en_route' | 'arrived' | 'in_progress' | 'completed';
  specialInstructions?: string;
  estimatedArrival?: string;
  scheduledDate?: string;
  scheduledTime?: string;
  createdAt: string;
  updatedAt: string;
}

class CurrentJobService {
  private static instance: CurrentJobService;
  private listeners: Map<string, (currentJob: CurrentJob | null) => void> = new Map();

  static getInstance(): CurrentJobService {
    if (!CurrentJobService.instance) {
      CurrentJobService.instance = new CurrentJobService();
    }
    return CurrentJobService.instance;
  }

  // Get current active job for a valeter
  async getCurrentJob(valeterId: string): Promise<CurrentJob | null> {
    try {
      const currentJobJson = await AsyncStorage.getItem(`current_job_${valeterId}`);
      if (!currentJobJson) return null;
      
      const currentJob = JSON.parse(currentJobJson);
      
      // Check if job is still active (not completed or cancelled)
      if (currentJob.status === 'completed' || currentJob.status === 'cancelled') {
        await this.clearCurrentJob(valeterId);
        return null;
      }
      
      return currentJob;
    } catch (error) {
      console.error('Error loading current job:', error);
      return null;
    }
  }

  // Set current job for a valeter
  async setCurrentJob(valeterId: string, booking: Booking): Promise<void> {
    try {
      const currentJob: CurrentJob = {
        id: `current_${booking.id}`,
        bookingId: booking.id,
        customerId: booking.customerId,
        valeterId: valeterId,
        serviceType: booking.serviceType,
        serviceName: booking.serviceName,
        vehicleType: booking.vehicleType,
        vehicleInfo: booking.vehicleInfo,
        location: booking.location,
        price: booking.price,
        status: booking.status as CurrentJob['status'],
        specialInstructions: booking.specialInstructions,
        estimatedArrival: booking.estimatedArrival,
        scheduledDate: booking.scheduledDate,
        scheduledTime: booking.scheduledTime,
        createdAt: booking.createdAt,
        updatedAt: booking.updatedAt,
      };

      await AsyncStorage.setItem(`current_job_${valeterId}`, JSON.stringify(currentJob));
      this.notifyListeners(valeterId, currentJob);
    } catch (error) {
      console.error('Error setting current job:', error);
    }
  }

  // Update current job status
  async updateCurrentJobStatus(valeterId: string, status: CurrentJob['status'], updates?: Partial<CurrentJob>): Promise<CurrentJob | null> {
    try {
      const currentJob = await this.getCurrentJob(valeterId);
      if (!currentJob) return null;

      const updatedJob: CurrentJob = {
        ...currentJob,
        ...updates,
        status,
        updatedAt: new Date().toISOString(),
      };

      await AsyncStorage.setItem(`current_job_${valeterId}`, JSON.stringify(updatedJob));
      this.notifyListeners(valeterId, updatedJob);
      
      return updatedJob;
    } catch (error) {
      console.error('Error updating current job status:', error);
      return null;
    }
  }

  // Clear current job (when completed or cancelled)
  async clearCurrentJob(valeterId: string): Promise<void> {
    try {
      await AsyncStorage.removeItem(`current_job_${valeterId}`);
      this.notifyListeners(valeterId, null);
    } catch (error) {
      console.error('Error clearing current job:', error);
    }
  }

  // Get most recent job for a valeter (including completed ones)
  async getMostRecentJob(valeterId: string): Promise<CurrentJob | null> {
    try {
      // First try to get current active job
      const currentJob = await this.getCurrentJob(valeterId);
      if (currentJob) return currentJob;

      // If no current job, get the most recent completed job
      const recentJobsJson = await AsyncStorage.getItem(`recent_jobs_${valeterId}`);
      if (!recentJobsJson) return null;

      const recentJobs: CurrentJob[] = JSON.parse(recentJobsJson);
      return recentJobs.length > 0 ? recentJobs[0] : null;
    } catch (error) {
      console.error('Error loading most recent job:', error);
      return null;
    }
  }

  // Add job to recent jobs history
  async addToRecentJobs(valeterId: string, job: CurrentJob): Promise<void> {
    try {
      const recentJobsJson = await AsyncStorage.getItem(`recent_jobs_${valeterId}`);
      const recentJobs: CurrentJob[] = recentJobsJson ? JSON.parse(recentJobsJson) : [];

      // Add to beginning of array
      recentJobs.unshift(job);

      // Keep only last 10 jobs
      const trimmedJobs = recentJobs.slice(0, 10);

      await AsyncStorage.setItem(`recent_jobs_${valeterId}`, JSON.stringify(trimmedJobs));
    } catch (error) {
      console.error('Error adding to recent jobs:', error);
    }
  }

  // Subscribe to current job updates
  subscribeToCurrentJob(valeterId: string, callback: (currentJob: CurrentJob | null) => void): () => void {
    this.listeners.set(valeterId, callback);
    
    // Return unsubscribe function
    return () => {
      this.listeners.delete(valeterId);
    };
  }

  // Notify listeners of current job updates
  private notifyListeners(valeterId: string, currentJob: CurrentJob | null): void {
    const callback = this.listeners.get(valeterId);
    if (callback) {
      callback(currentJob);
    }
  }

  // Get job statistics for a valeter
  async getJobStats(valeterId: string): Promise<{
    totalJobs: number;
    completedJobs: number;
    totalEarnings: number;
    averageRating: number;
    currentStreak: number;
  }> {
    try {
      const recentJobsJson = await AsyncStorage.getItem(`recent_jobs_${valeterId}`);
      const recentJobs: CurrentJob[] = recentJobsJson ? JSON.parse(recentJobsJson) : [];

      const completedJobs = recentJobs.filter(job => job.status === 'completed');
      const totalEarnings = completedJobs.reduce((sum, job) => sum + job.price, 0);
      const averageRating = completedJobs.length > 0 
        ? completedJobs.reduce((sum, job) => sum + (job as any).rating || 0, 0) / completedJobs.length
        : 0;

      // Calculate current streak (consecutive completed jobs)
      let currentStreak = 0;
      for (const job of recentJobs) {
        if (job.status === 'completed') {
          currentStreak++;
        } else {
          break;
        }
      }

      return {
        totalJobs: recentJobs.length,
        completedJobs: completedJobs.length,
        totalEarnings,
        averageRating: Math.round(averageRating * 10) / 10,
        currentStreak,
      };
    } catch (error) {
      console.error('Error loading job stats:', error);
      return {
        totalJobs: 0,
        completedJobs: 0,
        totalEarnings: 0,
        averageRating: 0,
        currentStreak: 0,
      };
    }
  }
}

export const currentJobService = CurrentJobService.getInstance();
