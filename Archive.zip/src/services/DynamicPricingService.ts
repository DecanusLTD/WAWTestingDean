export interface LocationPricing {
  city: string;
  area: string;
  baseMultiplier: number;
  demandMultiplier: number;
  timeMultiplier: number;
  weatherMultiplier: number;
  servicePrices: {
    quickWash: { base: number; addons: AddonPrice[] };
    fullValet: { base: number; addons: AddonPrice[] };
    expressWash: { base: number; addons: AddonPrice[] };
  };
}

export interface AddonPrice {
  id: string;
  name: string;
  description: string;
  basePrice: number;
  locationMultiplier: number;
}

export interface PricingFactors {
  location: { city: string; area: string };
  timeOfDay: number; // 0-23
  dayOfWeek: number; // 0-6
  weather: 'sunny' | 'rainy' | 'cloudy' | 'snowy';
  demand: 'low' | 'medium' | 'high' | 'peak';
  vehicleSize: 'small' | 'medium' | 'large' | 'luxury';
  serviceType: 'quickWash' | 'fullValet' | 'expressWash';
  addons: string[];
}

export class DynamicPricingService {
  private static instance: DynamicPricingService;
  
  // UK Cities with pricing data based on market research
  private ukCities: LocationPricing[] = [
    {
      city: 'London',
      area: 'Central',
      baseMultiplier: 1.8,
      demandMultiplier: 1.2,
      timeMultiplier: 1.1,
      weatherMultiplier: 1.0,
      servicePrices: {
        quickWash: {
          base: 25,
          addons: [
            { id: 'wax', name: 'Wax Protection', description: 'Long-lasting shine', basePrice: 15, locationMultiplier: 1.2 },
            { id: 'interior', name: 'Interior Clean', description: 'Vacuum & wipe down', basePrice: 20, locationMultiplier: 1.3 },
            { id: 'tire', name: 'Tire Shine', description: 'Professional tire dressing', basePrice: 10, locationMultiplier: 1.1 },
            { id: 'glass', name: 'Glass Polish', description: 'Crystal clear windows', basePrice: 12, locationMultiplier: 1.2 }
          ]
        },
        fullValet: {
          base: 45,
          addons: [
            { id: 'ceramic', name: 'Ceramic Coating', description: '9-month protection', basePrice: 80, locationMultiplier: 1.4 },
            { id: 'leather', name: 'Leather Treatment', description: 'Condition & protect', basePrice: 25, locationMultiplier: 1.3 },
            { id: 'engine', name: 'Engine Bay Clean', description: 'Professional engine detailing', basePrice: 35, locationMultiplier: 1.2 },
            { id: 'headlight', name: 'Headlight Restoration', description: 'Remove yellowing', basePrice: 30, locationMultiplier: 1.3 }
          ]
        },
        expressWash: {
          base: 35,
          addons: [
            { id: 'quick_wax', name: 'Quick Wax', description: 'Fast protection', basePrice: 12, locationMultiplier: 1.1 },
            { id: 'air_fresh', name: 'Air Freshener', description: 'Long-lasting scent', basePrice: 8, locationMultiplier: 1.0 }
          ]
        }
      }
    },
    {
      city: 'London',
      area: 'West',
      baseMultiplier: 1.6,
      demandMultiplier: 1.1,
      timeMultiplier: 1.05,
      weatherMultiplier: 1.0,
      servicePrices: {
        quickWash: { base: 22, addons: [] },
        fullValet: { base: 40, addons: [] },
        expressWash: { base: 32, addons: [] }
      }
    },
    {
      city: 'London',
      area: 'East',
      baseMultiplier: 1.4,
      demandMultiplier: 1.0,
      timeMultiplier: 1.0,
      weatherMultiplier: 1.0,
      servicePrices: {
        quickWash: { base: 20, addons: [] },
        fullValet: { base: 35, addons: [] },
        expressWash: { base: 28, addons: [] }
      }
    },
    {
      city: 'Manchester',
      area: 'Central',
      baseMultiplier: 1.3,
      demandMultiplier: 1.1,
      timeMultiplier: 1.05,
      weatherMultiplier: 1.1,
      servicePrices: {
        quickWash: { base: 18, addons: [] },
        fullValet: { base: 32, addons: [] },
        expressWash: { base: 25, addons: [] }
      }
    },
    {
      city: 'Birmingham',
      area: 'Central',
      baseMultiplier: 1.2,
      demandMultiplier: 1.0,
      timeMultiplier: 1.0,
      weatherMultiplier: 1.05,
      servicePrices: {
        quickWash: { base: 16, addons: [] },
        fullValet: { base: 28, addons: [] },
        expressWash: { base: 22, addons: [] }
      }
    },
    {
      city: 'Liverpool',
      area: 'Central',
      baseMultiplier: 1.1,
      demandMultiplier: 0.95,
      timeMultiplier: 0.95,
      weatherMultiplier: 1.1,
      servicePrices: {
        quickWash: { base: 15, addons: [] },
        fullValet: { base: 26, addons: [] },
        expressWash: { base: 20, addons: [] }
      }
    },
    {
      city: 'Leeds',
      area: 'Central',
      baseMultiplier: 1.1,
      demandMultiplier: 0.95,
      timeMultiplier: 0.95,
      weatherMultiplier: 1.05,
      servicePrices: {
        quickWash: { base: 15, addons: [] },
        fullValet: { base: 26, addons: [] },
        expressWash: { base: 20, addons: [] }
      }
    },
    {
      city: 'Sheffield',
      area: 'Central',
      baseMultiplier: 1.0,
      demandMultiplier: 0.9,
      timeMultiplier: 0.9,
      weatherMultiplier: 1.05,
      servicePrices: {
        quickWash: { base: 14, addons: [] },
        fullValet: { base: 24, addons: [] },
        expressWash: { base: 18, addons: [] }
      }
    },
    {
      city: 'Edinburgh',
      area: 'Central',
      baseMultiplier: 1.2,
      demandMultiplier: 1.05,
      timeMultiplier: 1.0,
      weatherMultiplier: 1.15,
      servicePrices: {
        quickWash: { base: 17, addons: [] },
        fullValet: { base: 30, addons: [] },
        expressWash: { base: 23, addons: [] }
      }
    },
    {
      city: 'Glasgow',
      area: 'Central',
      baseMultiplier: 1.1,
      demandMultiplier: 1.0,
      timeMultiplier: 0.95,
      weatherMultiplier: 1.15,
      servicePrices: {
        quickWash: { base: 16, addons: [] },
        fullValet: { base: 28, addons: [] },
        expressWash: { base: 21, addons: [] }
      }
    },
    {
      city: 'Cardiff',
      area: 'Central',
      baseMultiplier: 1.0,
      demandMultiplier: 0.95,
      timeMultiplier: 0.95,
      weatherMultiplier: 1.1,
      servicePrices: {
        quickWash: { base: 15, addons: [] },
        fullValet: { base: 26, addons: [] },
        expressWash: { base: 20, addons: [] }
      }
    },
    {
      city: 'Bristol',
      area: 'Central',
      baseMultiplier: 1.1,
      demandMultiplier: 1.0,
      timeMultiplier: 1.0,
      weatherMultiplier: 1.05,
      servicePrices: {
        quickWash: { base: 16, addons: [] },
        fullValet: { base: 28, addons: [] },
        expressWash: { base: 22, addons: [] }
      }
    }
  ];

  static getInstance(): DynamicPricingService {
    if (!DynamicPricingService.instance) {
      DynamicPricingService.instance = new DynamicPricingService();
    }
    return DynamicPricingService.instance;
  }

  calculatePrice(factors: PricingFactors): {
    basePrice: number;
    addonPrices: { id: string; name: string; price: number }[];
    totalPrice: number;
    breakdown: {
      base: number;
      location: number;
      time: number;
      demand: number;
      weather: number;
      addons: number;
    };
  } {
    const location = this.getLocationPricing(factors.location.city, factors.location.area);
    if (!location) {
      throw new Error(`Location not found: ${factors.location.city}, ${factors.location.area}`);
    }

    // Base price calculation
    const servicePrice = location.servicePrices[factors.serviceType];
    let basePrice = servicePrice.base;

    // Apply multipliers
    const locationMultiplier = location.baseMultiplier;
    const timeMultiplier = this.getTimeMultiplier(factors.timeOfDay, factors.dayOfWeek);
    const demandMultiplier = this.getDemandMultiplier(factors.demand);
    const weatherMultiplier = this.getWeatherMultiplier(factors.weather);
    const vehicleMultiplier = this.getVehicleMultiplier(factors.vehicleSize);

    // Calculate final base price
    const adjustedBasePrice = basePrice * locationMultiplier * timeMultiplier * demandMultiplier * weatherMultiplier * vehicleMultiplier;

    // Calculate addon prices
    const addonPrices = factors.addons.map(addonId => {
      const addon = servicePrice.addons.find(a => a.id === addonId);
      if (!addon) return null;
      
      const addonPrice = addon.basePrice * addon.locationMultiplier * locationMultiplier;
      return { id: addonId, name: addon.name, price: addonPrice };
    }).filter(Boolean);

    const totalAddonPrice = addonPrices.reduce((sum, addon) => sum + addon!.price, 0);
    const totalPrice = adjustedBasePrice + totalAddonPrice;

    return {
      basePrice: adjustedBasePrice,
      addonPrices,
      totalPrice: Math.round(totalPrice),
      breakdown: {
        base: basePrice,
        location: locationMultiplier,
        time: timeMultiplier,
        demand: demandMultiplier,
        weather: weatherMultiplier,
        addons: totalAddonPrice
      }
    };
  }

  private getLocationPricing(city: string, area: string): LocationPricing | undefined {
    return this.ukCities.find(loc => 
      loc.city.toLowerCase() === city.toLowerCase() && 
      loc.area.toLowerCase() === area.toLowerCase()
    );
  }

  private getTimeMultiplier(timeOfDay: number, dayOfWeek: number): number {
    // Peak hours: 7-9 AM, 5-7 PM on weekdays
    const isWeekday = dayOfWeek >= 1 && dayOfWeek <= 5;
    const isPeakHour = (timeOfDay >= 7 && timeOfDay <= 9) || (timeOfDay >= 17 && timeOfDay <= 19);
    
    if (isWeekday && isPeakHour) return 1.2;
    if (isWeekday) return 1.1;
    if (isPeakHour) return 1.15;
    return 1.0;
  }

  private getDemandMultiplier(demand: string): number {
    switch (demand) {
      case 'low': return 0.9;
      case 'medium': return 1.0;
      case 'high': return 1.15;
      case 'peak': return 1.3;
      default: return 1.0;
    }
  }

  private getWeatherMultiplier(weather: string): number {
    switch (weather) {
      case 'rainy': return 1.2; // Higher demand in bad weather
      case 'snowy': return 1.3;
      case 'sunny': return 0.95; // Slightly lower in good weather
      case 'cloudy': return 1.0;
      default: return 1.0;
    }
  }

  private getVehicleMultiplier(vehicleSize: string): number {
    switch (vehicleSize) {
      case 'small': return 0.9;
      case 'medium': return 1.0;
      case 'large': return 1.2;
      case 'luxury': return 1.4;
      default: return 1.0;
    }
  }

  getAvailableCities(): string[] {
    return [...new Set(this.ukCities.map(loc => loc.city))];
  }

  getAreasForCity(city: string): string[] {
    return this.ukCities
      .filter(loc => loc.city.toLowerCase() === city.toLowerCase())
      .map(loc => loc.area);
  }

  getAddonsForService(city: string, area: string, serviceType: string): AddonPrice[] {
    const location = this.getLocationPricing(city, area);
    if (!location) return [];
    
    return location.servicePrices[serviceType as keyof typeof location.servicePrices]?.addons || [];
  }

  // Get estimated price range for a service in a location
  getPriceRange(city: string, area: string, serviceType: string): {
    min: number;
    max: number;
    typical: number;
  } {
    const location = this.getLocationPricing(city, area);
    if (!location) return { min: 0, max: 0, typical: 0 };

    const basePrice = location.servicePrices[serviceType as keyof typeof location.servicePrices]?.base || 0;
    const minMultiplier = 0.8; // Low demand, off-peak
    const maxMultiplier = 1.5; // High demand, peak hours
    const typicalMultiplier = 1.1; // Average conditions

    return {
      min: Math.round(basePrice * location.baseMultiplier * minMultiplier),
      max: Math.round(basePrice * location.baseMultiplier * maxMultiplier),
      typical: Math.round(basePrice * location.baseMultiplier * typicalMultiplier)
    };
  }
}

export const dynamicPricingService = DynamicPricingService.getInstance();
