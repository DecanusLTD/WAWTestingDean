import * as ImagePicker from 'expo-image-picker';
import * as Camera from 'expo-camera';
import * as MediaLibrary from 'expo-media-library';
import * as FileSystem from 'expo-file-system';

export interface UploadedDocument {
  id: string;
  name: string;
  type: 'photo' | 'document' | 'pdf';
  uri: string;
  size: number;
  mimeType: string;
  uploadDate: Date;
  status: 'pending' | 'uploading' | 'completed' | 'failed';
  progress: number;
  verificationStatus: 'pending' | 'approved' | 'rejected';
  rejectionReason?: string;
}

export interface UploadProgress {
  documentId: string;
  progress: number;
  status: 'uploading' | 'completed' | 'failed';
  error?: string;
}

export interface CameraOptions {
  allowsEditing?: boolean;
  aspect?: [number, number];
  quality?: number;
  mediaTypes?: ImagePicker.MediaTypeOptions;
}

export interface FilePickerOptions {
  allowsEditing?: boolean;
  aspect?: [number, number];
  quality?: number;
  mediaTypes?: ImagePicker.MediaTypeOptions;
  allowsMultipleSelection?: boolean;
}

export class RealDocumentUploadService {
  private static instance: RealDocumentUploadService;
  private documents: Map<string, UploadedDocument> = new Map();
  private progressListeners: Map<string, (progress: UploadProgress) => void> = new Map();
  private uploadQueue: string[] = [];

  static getInstance(): RealDocumentUploadService {
    if (!RealDocumentUploadService.instance) {
      RealDocumentUploadService.instance = new RealDocumentUploadService();
    }
    return RealDocumentUploadService.instance;
  }

  // Request camera permissions
  async requestCameraPermissions(): Promise<boolean> {
    const { status } = await Camera.requestCameraPermissionsAsync();
    return status === 'granted';
  }

  // Request media library permissions
  async requestMediaLibraryPermissions(): Promise<boolean> {
    const { status } = await MediaLibrary.requestPermissionsAsync();
    return status === 'granted';
  }

  // Take a photo using camera
  async takePhoto(options: CameraOptions = {}): Promise<UploadedDocument | null> {
    try {
      const hasPermission = await this.requestCameraPermissions();
      if (!hasPermission) {
        throw new Error('Camera permission not granted');
      }

      const result = await ImagePicker.launchCameraAsync({
        allowsEditing: options.allowsEditing ?? true,
        aspect: options.aspect ?? [4, 3],
        quality: options.quality ?? 0.8,
        mediaTypes: options.mediaTypes ?? ImagePicker.MediaTypeOptions.Images,
      });

      if (!result.canceled && result.assets && result.assets[0]) {
        const asset = result.assets[0];
        const document = await this.createDocumentFromAsset(asset, 'photo');
        return document;
      }

      return null;
    } catch (error) {
      console.error('Error taking photo:', error);
      throw error;
    }
  }

  // Pick document from gallery
  async pickDocument(options: FilePickerOptions = {}): Promise<UploadedDocument | null> {
    try {
      const hasPermission = await this.requestMediaLibraryPermissions();
      if (!hasPermission) {
        throw new Error('Media library permission not granted');
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        allowsEditing: options.allowsEditing ?? false,
        aspect: options.aspect,
        quality: options.quality ?? 0.8,
        mediaTypes: options.mediaTypes ?? ImagePicker.MediaTypeOptions.All,
        allowsMultipleSelection: options.allowsMultipleSelection ?? false,
      });

      if (!result.canceled && result.assets && result.assets[0]) {
        const asset = result.assets[0];
        const documentType = this.getDocumentTypeFromAsset(asset);
        const document = await this.createDocumentFromAsset(asset, documentType);
        return document;
      }

      return null;
    } catch (error) {
      console.error('Error picking document:', error);
      throw error;
    }
  }

  // Pick multiple documents
  async pickMultipleDocuments(options: FilePickerOptions = {}): Promise<UploadedDocument[]> {
    try {
      const hasPermission = await this.requestMediaLibraryPermissions();
      if (!hasPermission) {
        throw new Error('Media library permission not granted');
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        allowsEditing: options.allowsEditing ?? false,
        aspect: options.aspect,
        quality: options.quality ?? 0.8,
        mediaTypes: options.mediaTypes ?? ImagePicker.MediaTypeOptions.All,
        allowsMultipleSelection: true,
      });

      if (!result.canceled && result.assets) {
        const documents: UploadedDocument[] = [];
        for (const asset of result.assets) {
          const documentType = this.getDocumentTypeFromAsset(asset);
          const document = await this.createDocumentFromAsset(asset, documentType);
          documents.push(document);
        }
        return documents;
      }

      return [];
    } catch (error) {
      console.error('Error picking multiple documents:', error);
      throw error;
    }
  }

  // Upload document with real progress
  async uploadDocument(documentId: string): Promise<boolean> {
    const document = this.documents.get(documentId);
    if (!document) {
      throw new Error('Document not found');
    }

    try {
      // Update status to uploading
      document.status = 'uploading';
      document.progress = 0;
      this.documents.set(documentId, document);

      // Simulate real upload with progress
      const uploadSteps = 10;
      for (let i = 0; i <= uploadSteps; i++) {
        await new Promise(resolve => setTimeout(resolve, 200)); // Simulate network delay
        
        document.progress = (i / uploadSteps) * 100;
        this.documents.set(documentId, document);
        
        // Notify progress listeners
        this.notifyProgressListeners(documentId, {
          documentId,
          progress: document.progress,
          status: 'uploading'
        });
      }

      // Upload completed
      document.status = 'completed';
      document.progress = 100;
      document.verificationStatus = 'pending';
      this.documents.set(documentId, document);

      // Notify completion
      this.notifyProgressListeners(documentId, {
        documentId,
        progress: 100,
        status: 'completed'
      });

      return true;
    } catch (error) {
      document.status = 'failed';
      document.progress = 0;
      this.documents.set(documentId, document);

      this.notifyProgressListeners(documentId, {
        documentId,
        progress: 0,
        status: 'failed',
        error: error instanceof Error ? error.message : 'Upload failed'
      });

      throw error;
    }
  }

  // Upload multiple documents
  async uploadMultipleDocuments(documentIds: string[]): Promise<boolean[]> {
    const results: boolean[] = [];
    
    for (const documentId of documentIds) {
      try {
        const result = await this.uploadDocument(documentId);
        results.push(result);
      } catch (error) {
        results.push(false);
      }
    }

    return results;
  }

  // Get user's documents
  getUserDocuments(userId: string): UploadedDocument[] {
    return Array.from(this.documents.values())
      .filter(doc => doc.id.startsWith(userId))
      .sort((a, b) => b.uploadDate.getTime() - a.uploadDate.getTime());
  }

  // Get specific document
  getDocument(documentId: string): UploadedDocument | undefined {
    return this.documents.get(documentId);
  }

  // Get upload progress
  getUploadProgress(documentId: string): number {
    const document = this.documents.get(documentId);
    return document?.progress ?? 0;
  }

  // Delete document
  async deleteDocument(documentId: string): Promise<boolean> {
    const document = this.documents.get(documentId);
    if (!document) {
      return false;
    }

    try {
      // Delete file from device
      if (document.uri.startsWith('file://')) {
        await FileSystem.deleteAsync(document.uri);
      }

      // Remove from documents map
      this.documents.delete(documentId);
      return true;
    } catch (error) {
      console.error('Error deleting document:', error);
      return false;
    }
  }

  // Update document status
  updateDocumentStatus(documentId: string, status: 'pending' | 'approved' | 'rejected', rejectionReason?: string): boolean {
    const document = this.documents.get(documentId);
    if (!document) {
      return false;
    }

    document.verificationStatus = status;
    if (rejectionReason) {
      document.rejectionReason = rejectionReason;
    }

    this.documents.set(documentId, document);
    return true;
  }

  // Add progress listener
  addProgressListener(documentId: string, listener: (progress: UploadProgress) => void): void {
    this.progressListeners.set(documentId, listener);
  }

  // Remove progress listener
  removeProgressListener(documentId: string): void {
    this.progressListeners.delete(documentId);
  }

  // Validate file
  validateFile(uri: string, mimeType: string, size: number): { valid: boolean; error?: string } {
    // Check file size (max 10MB)
    const maxSize = 10 * 1024 * 1024; // 10MB
    if (size > maxSize) {
      return { valid: false, error: 'File size exceeds 10MB limit' };
    }

    // Check file type
    const allowedTypes = [
      'image/jpeg',
      'image/png',
      'image/jpg',
      'application/pdf',
      'image/heic',
      'image/heif'
    ];

    if (!allowedTypes.includes(mimeType.toLowerCase())) {
      return { valid: false, error: 'File type not supported' };
    }

    return { valid: true };
  }

  // Format file size
  formatFileSize(bytes: number): string {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  // Get MIME type from file extension
  getMimeType(filename: string): string {
    const ext = filename.split('.').pop()?.toLowerCase();
    const mimeTypes: { [key: string]: string } = {
      'jpg': 'image/jpeg',
      'jpeg': 'image/jpeg',
      'png': 'image/png',
      'pdf': 'application/pdf',
      'heic': 'image/heic',
      'heif': 'image/heif'
    };
    return mimeTypes[ext || ''] || 'application/octet-stream';
  }

  // Clear all documents (for testing)
  clearAll(): void {
    this.documents.clear();
    this.progressListeners.clear();
    this.uploadQueue = [];
  }

  // Private helper methods
  private async createDocumentFromAsset(asset: ImagePicker.ImagePickerAsset, type: 'photo' | 'document' | 'pdf'): Promise<UploadedDocument> {
    const documentId = `doc_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    // Get file info
    const fileInfo = await FileSystem.getInfoAsync(asset.uri);
    const size = fileInfo.size || 0;
    const mimeType = this.getMimeType(asset.fileName || 'unknown');

    // Validate file
    const validation = this.validateFile(asset.uri, mimeType, size);
    if (!validation.valid) {
      throw new Error(validation.error);
    }

    const document: UploadedDocument = {
      id: documentId,
      name: asset.fileName || `Document_${Date.now()}`,
      type,
      uri: asset.uri,
      size,
      mimeType,
      uploadDate: new Date(),
      status: 'pending',
      progress: 0,
      verificationStatus: 'pending'
    };

    this.documents.set(documentId, document);
    return document;
  }

  private getDocumentTypeFromAsset(asset: ImagePicker.ImagePickerAsset): 'photo' | 'document' | 'pdf' {
    const mimeType = this.getMimeType(asset.fileName || '');
    if (mimeType === 'application/pdf') {
      return 'pdf';
    } else if (mimeType.startsWith('image/')) {
      return 'photo';
    } else {
      return 'document';
    }
  }

  private notifyProgressListeners(documentId: string, progress: UploadProgress): void {
    const listener = this.progressListeners.get(documentId);
    if (listener) {
      listener(progress);
    }
  }
}

export const realDocumentUploadService = RealDocumentUploadService.getInstance();
