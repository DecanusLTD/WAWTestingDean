import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  Switch,
  Image,
} from 'react-native';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
// import * as Haptics from 'expo-haptics';

export default function DriverProfile() {
  const { user, updateUser } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [profileImage, _setProfileImage] = useState(user?.profileImage || null);
  const [formData, setFormData] = useState({
    firstName: user?.firstName || '',
    lastName: user?.lastName || '',
    email: user?.email || '',
    phone: user?.phone || '',
    vehicleInfo: user?.vehicleInfo || '',
    licensePlate: user?.licensePlate || '',
  });
  const [notifications, setNotifications] = useState(true);
  const [locationSharing, setLocationSharing] = useState(true);

  const handleSave = async () => {
    try {
      await updateUser(formData);
      setIsEditing(false);
      Alert.alert('Success', 'Profile updated successfully!');
    } catch (error) {
      Alert.alert('Error', 'Failed to update profile. Please try again.');
    }
  };

  const handleCancel = () => {
    setFormData({
      firstName: user?.firstName || '',
      lastName: user?.lastName || '',
      email: user?.email || '',
      phone: user?.phone || '',
      vehicleInfo: user?.vehicleInfo || '',
      licensePlate: user?.licensePlate || '',
    });
    setIsEditing(false);
  };

  const handleLogout = async () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Logout', 
          style: 'destructive',
          onPress: async () => {
            // This will be handled by the auth context
            router.replace('/login');
          }
        }
      ]
    );
  };

  const updateFormData = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleUploadPhoto = () => {
    Alert.alert(
      'Upload Photo',
      'Choose an option',
      [
        { text: '📷 Camera', onPress: () => {
          // // Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
          // Simulate camera capture
          setTimeout(() => {
            Alert.alert('Success', 'Profile photo updated from camera!');
          }, 1000);
        }},
        { text: '📁 Photo Library', onPress: () => {
          // // Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
          // Simulate photo selection
          setTimeout(() => {
            Alert.alert('Success', 'Profile photo updated from library!');
          }, 800);
        }},
        { text: 'Cancel', style: 'cancel' }
      ]
    );
  };

  const handleChangePassword = () => {
    Alert.alert('Change Password', 'Password change functionality will be implemented');
  };

  const handleTermsOfService = () => {
    router.push('/terms-of-service');
  };

  const handlePrivacyPolicy = () => {
    router.push('/privacy-policy');
  };

  const handleHelpSupport = () => {
    router.push('/help-support');
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerTop}>
          <TouchableOpacity onPress={() => router.back()}>
            <Text style={styles.backButton}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Profile</Text>
          <TouchableOpacity onPress={handleLogout}>
            <Text style={styles.logoutButton}>🚪</Text>
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView style={styles.scrollContainer} contentContainerStyle={styles.scrollContent}>
        {/* Profile Picture Section */}
        <View style={styles.profileSection}>
          <TouchableOpacity style={styles.profileImageContainer} onPress={handleUploadPhoto}>
            {profileImage ? (
              <Image source={{ uri: profileImage }} style={styles.profileImage} />
            ) : (
              <View style={styles.profileImage}>
                <Text style={styles.profileInitial}>
                  {user?.firstName?.charAt(0)}{user?.lastName?.charAt(0)}
                </Text>
              </View>
            )}
            <View style={styles.uploadOverlay}>
              <Text style={styles.uploadText}>📷</Text>
            </View>
          </TouchableOpacity>
          <Text style={styles.profileName}>
            {user?.firstName} {user?.lastName}
          </Text>
          <Text style={styles.profileStatus}>Active Valeter</Text>
        </View>

        {/* Personal Information */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Personal Information</Text>
            <TouchableOpacity 
              style={styles.editButton} 
              onPress={() => setIsEditing(!isEditing)}
            >
              <Text style={styles.editButtonText}>
                {isEditing ? 'Cancel' : 'Edit'}
              </Text>
            </TouchableOpacity>
          </View>

          <View style={styles.formContainer}>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>First Name</Text>
              <TextInput
                style={[styles.input, !isEditing && styles.inputDisabled]}
                value={formData.firstName}
                onChangeText={(text) => updateFormData('firstName', text)}
                editable={isEditing}
                placeholder="Enter first name"
                placeholderTextColor="#87CEEB"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Last Name</Text>
              <TextInput
                style={[styles.input, !isEditing && styles.inputDisabled]}
                value={formData.lastName}
                onChangeText={(text) => updateFormData('lastName', text)}
                editable={isEditing}
                placeholder="Enter last name"
                placeholderTextColor="#87CEEB"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Email</Text>
              <TextInput
                style={[styles.input, !isEditing && styles.inputDisabled]}
                value={formData.email}
                onChangeText={(text) => updateFormData('email', text)}
                editable={isEditing}
                placeholder="Enter email"
                placeholderTextColor="#87CEEB"
                keyboardType="email-address"
                autoCapitalize="none"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Phone</Text>
              <TextInput
                style={[styles.input, !isEditing && styles.inputDisabled]}
                value={formData.phone}
                onChangeText={(text) => updateFormData('phone', text)}
                editable={isEditing}
                placeholder="Enter phone number"
                placeholderTextColor="#87CEEB"
                keyboardType="phone-pad"
              />
            </View>
          </View>

          {isEditing && (
            <View style={styles.saveButtons}>
              <TouchableOpacity style={styles.saveButton} onPress={handleSave}>
                <Text style={styles.saveButtonText}>Save Changes</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.cancelButton} onPress={handleCancel}>
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>

        {/* Account Information */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Account Information</Text>
          
          <View style={styles.accountInfoCard}>
            <View style={styles.accountInfoRow}>
              <Text style={styles.accountInfoLabel}>Account ID:</Text>
              <Text style={styles.accountInfoValue}>{user?.id || '126546fghfdsvvfg'}</Text>
            </View>
            <View style={styles.accountInfoRow}>
              <Text style={styles.accountInfoLabel}>Account Type:</Text>
              <Text style={styles.accountInfoValue}>Valeter</Text>
            </View>
            <View style={styles.accountInfoRow}>
              <Text style={styles.accountInfoLabel}>Member Since:</Text>
              <Text style={styles.accountInfoValue}>January 2024</Text>
            </View>
          </View>
        </View>

        {/* Van Information */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Van Information</Text>
          
          <View style={styles.vehicleCard}>
            <View style={styles.vehicleHeader}>
              <Text style={styles.vehicleIcon}>🚐</Text>
              <Text style={styles.vehicleTitle}>Current Van</Text>
            </View>
            
            <View style={styles.vehicleInfo}>
              <Text style={styles.vehicleText}>
                <Text style={styles.vehicleLabel}>Model: </Text>
                {user?.vehicleInfo || 'Ford Transit 2022'}
              </Text>
              <Text style={styles.vehicleText}>
                <Text style={styles.vehicleLabel}>License Plate: </Text>
                {user?.licensePlate || 'Waw-2024'}
              </Text>
              <Text style={styles.vehicleText}>
                <Text style={styles.vehicleLabel}>Status: </Text>
                <Text style={styles.statusActive}>Active</Text>
              </Text>
            </View>
            
            <TouchableOpacity style={styles.editVehicleButton}>
              <Text style={styles.editVehicleButtonText}>Edit Van</Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.documentsButton}
              onPress={() => router.push('/valeter-documents')}
            >
              <Text style={styles.documentsButtonText}>📋 Required Documents</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Settings */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Settings</Text>
          
          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingIcon}>🔔</Text>
              <View style={styles.settingText}>
                <Text style={styles.settingTitle}>Push Notifications</Text>
                <Text style={styles.settingDescription}>Receive wash requests and updates</Text>
              </View>
            </View>
            <Switch
              value={notifications}
              onValueChange={setNotifications}
              trackColor={{ false: '#2d2d2d', true: '#87CEEB' }}
              thumbColor={notifications ? '#0A1929' : '#f4f3f4'}
            />
          </View>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingIcon}>📍</Text>
              <View style={styles.settingText}>
                <Text style={styles.settingTitle}>Location Sharing</Text>
                <Text style={styles.settingDescription}>Share location with customers</Text>
              </View>
            </View>
            <Switch
              value={locationSharing}
              onValueChange={setLocationSharing}
              trackColor={{ false: '#2d2d2d', true: '#87CEEB' }}
              thumbColor={locationSharing ? '#0A1929' : '#f4f3f4'}
            />
          </View>
        </View>

        {/* Account Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Account</Text>
          
          <TouchableOpacity style={styles.actionButton} onPress={handleChangePassword}>
            <Text style={styles.actionIcon}>🔒</Text>
            <Text style={styles.actionText}>Change Password</Text>
            <Text style={styles.actionArrow}>→</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.actionButton} onPress={handleTermsOfService}>
            <Text style={styles.actionIcon}>📋</Text>
            <Text style={styles.actionText}>Terms of Service</Text>
            <Text style={styles.actionArrow}>→</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.actionButton} onPress={handlePrivacyPolicy}>
            <Text style={styles.actionIcon}>🛡️</Text>
            <Text style={styles.actionText}>Privacy Policy</Text>
            <Text style={styles.actionArrow}>→</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.actionButton} onPress={handleHelpSupport}>
            <Text style={styles.actionIcon}>❓</Text>
            <Text style={styles.actionText}>Help & Support</Text>
            <Text style={styles.actionArrow}>→</Text>
          </TouchableOpacity>
        </View>

        {/* Logout Section */}
        <View style={styles.logoutSection}>
          <TouchableOpacity style={styles.logoutButtonLarge} onPress={handleLogout}>
                          <Text style={styles.logoutButtonLargeText}>🚪 Log Out</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  header: {
    backgroundColor: '#1E3A8A',
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  backButton: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: '600',
  },
  headerTitle: {
    color: '#fff',
    fontSize: 20,
    fontWeight: 'bold',
  },
  logoutButton: {
    color: '#87CEEB',
    fontSize: 20,
  },
  scrollContainer: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  profileSection: {
    alignItems: 'center',
    marginBottom: 30,
  },
  profileImage: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#87CEEB',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 15,
  },
  profileInitial: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#0A1929',
  },
  profileName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 5,
  },
  profileStatus: {
    fontSize: 16,
    color: '#87CEEB',
  },
  section: {
    marginBottom: 30,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#87CEEB',
  },
  editButton: {
    backgroundColor: '#87CEEB',
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 8,
  },
  editButtonText: {
    color: '#0A1929',
    fontWeight: 'bold',
  },
  formContainer: {
    backgroundColor: '#1E3A8A',
    borderRadius: 15,
    padding: 20,
  },
  inputGroup: {
    marginBottom: 15,
  },
  inputLabel: {
    fontSize: 16,
    color: '#87CEEB',
    marginBottom: 8,
    fontWeight: '600',
  },
  input: {
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 15,
    fontSize: 16,
    color: '#fff',
    borderWidth: 1,
    borderColor: 'rgba(135, 206, 235, 0.3)',
  },
  inputDisabled: {
    opacity: 0.7,
  },
  saveButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 15,
  },
  saveButton: {
    backgroundColor: '#87CEEB',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 10,
    flex: 1,
    marginRight: 10,
    alignItems: 'center',
  },
  saveButtonText: {
    color: '#0A1929',
    fontWeight: 'bold',
  },
  cancelButton: {
    backgroundColor: '#FF6B6B',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 10,
    flex: 1,
    marginLeft: 10,
    alignItems: 'center',
  },
  cancelButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  vehicleCard: {
    backgroundColor: '#1E3A8A',
    borderRadius: 15,
    padding: 20,
  },
  vehicleHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  vehicleIcon: {
    fontSize: 24,
    marginRight: 10,
  },
  vehicleTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
  },
  vehicleInfo: {
    marginBottom: 15,
  },
  vehicleText: {
    fontSize: 16,
    color: '#fff',
    marginBottom: 8,
  },
  vehicleLabel: {
    color: '#87CEEB',
    fontWeight: '600',
  },
  statusActive: {
    color: '#4CAF50',
    fontWeight: 'bold',
  },
  editVehicleButton: {
    backgroundColor: '#87CEEB',
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 8,
    alignSelf: 'flex-start',
  },
  editVehicleButtonText: {
    color: '#0A1929',
    fontWeight: 'bold',
  },
  documentsButton: {
    backgroundColor: '#FF9800',
    borderRadius: 8,
    paddingVertical: 10,
    paddingHorizontal: 15,
    alignItems: 'center',
    marginTop: 10,
  },
  documentsButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
  settingItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#1E3A8A',
    borderRadius: 15,
    padding: 20,
    marginBottom: 15,
  },
  settingInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  settingIcon: {
    fontSize: 20,
    marginRight: 15,
  },
  settingText: {
    flex: 1,
  },
  settingTitle: {
    fontSize: 16,
    color: '#fff',
    fontWeight: '600',
    marginBottom: 2,
  },
  settingDescription: {
    fontSize: 14,
    color: '#B0E0E6',
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1E3A8A',
    borderRadius: 15,
    padding: 20,
    marginBottom: 15,
  },
  actionIcon: {
    fontSize: 20,
    marginRight: 15,
  },
  actionText: {
    fontSize: 16,
    color: '#fff',
    fontWeight: '600',
    flex: 1,
  },
  actionArrow: {
    fontSize: 18,
    color: '#87CEEB',
  },
  logoutSection: {
    marginTop: 20,
  },
  logoutButtonLarge: {
    backgroundColor: '#FF6B6B',
    paddingVertical: 15,
    paddingHorizontal: 20,
    borderRadius: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 4,
  },
  logoutButtonLargeText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  accountInfoCard: {
    backgroundColor: '#1E3A8A',
    borderRadius: 15,
    padding: 20,
  },
  accountInfoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  accountInfoLabel: {
    fontSize: 14,
    color: '#B0E0E6',
    fontWeight: '500',
  },
  accountInfoValue: {
    fontSize: 14,
    color: '#87CEEB',
    fontWeight: '600',
  },
  profileImageContainer: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#1E3A8A',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    borderWidth: 3,
    borderColor: '#87CEEB',
  },
  uploadOverlay: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    backgroundColor: '#87CEEB',
    borderRadius: 15,
    width: 30,
    height: 30,
    justifyContent: 'center',
    alignItems: 'center',
  },
  uploadText: {
    fontSize: 16,
    color: '#0A1929',
  },
});


