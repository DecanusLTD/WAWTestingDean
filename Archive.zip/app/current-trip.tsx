// app/current-trip.tsx
import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  Animated,
  Dimensions,
  Alert,
} from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../src/providers/enhanced-auth-context';
import { LinearGradient } from 'expo-linear-gradient';
import { supabase } from '../src/lib/supabase';
import { hapticFeedback } from '../src/services/HapticFeedbackService';
import * as Location from 'expo-location';
import MapView, { Marker, Polyline, Region, LatLng } from 'react-native-maps';

const MAPBOX_TOKEN = 'pk.eyJ1IjoidHlzb24tMXN0IiwiYSI6ImNtZWtkaTk5dTAxYW0yaXF0bDVieTV6YTEifQ.-HXgTa_8yHcMRQzAeJBfFg ';
const { width, height } = Dimensions.get('window');

/* ---------------- Types ---------------- */

type BookingStatus =
  | 'scheduled'
  | 'valeter_assigned'
  | 'en_route'
  | 'arrived'
  | 'in_progress'
  | 'completed'
  | 'cancelled';

type DbBooking = {
  id: string;
  user_id: string;
  service_type: string;
  price: number;
  status: BookingStatus;    // enum booking_status
  location_address: string | null;
  location_lat: number | null;
  location_lng: number | null;
  created_at: string;
  updated_at: string;
  valeter_id: string | null;
  eta_minutes: number | null;
  driver_lat: number | null;
  driver_lng: number | null;
  driver_location: string | null;
};

/* ---------------- Polyline6 decoder (no deps) ---------------- */
// Based on Google/Mapbox polyline algorithm with 1e6 precision
function decodePolyline6(polyline: string): LatLng[] {
  let index = 0;
  const len = polyline.length;
  let lat = 0;
  let lng = 0;
  const coords: LatLng[] = [];

  const shiftAndMask = () => {
    let result = 0;
    let shift = 0;
    let b: number;
    do {
      b = polyline.charCodeAt(index++) - 63;
      result |= (b & 0x1f) << shift;
      shift += 5;
    } while (b >= 0x20);
    return (result & 1) ? ~(result >> 1) : (result >> 1);
  };

  while (index < len) {
    lat += shiftAndMask();
    lng += shiftAndMask();
    coords.push({ latitude: lat / 1e6, longitude: lng / 1e6 });
  }
  return coords;
}

/* ---------------- Mapbox helpers ---------------- */

async function fetchMapboxRoute(origin: { lat: number; lng: number }, dest: { lat: number; lng: number }) {
  if (!MAPBOX_TOKEN) throw new Error('Missing EXPO_PUBLIC_MAPBOX_TOKEN');

  const url =
    `https://api.mapbox.com/directions/v5/mapbox/driving/` +
    `${origin.lng},${origin.lat};${dest.lng},${dest.lat}` +
    `?alternatives=false&geometries=polyline6&overview=full&steps=false&access_token=${MAPBOX_TOKEN}`;

  const res = await fetch(url);
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Mapbox Directions error ${res.status}: ${body}`);
  }
  const json = await res.json();
  const route = json?.routes?.[0];
  if (!route) throw new Error('No route returned from Mapbox');

  const coords = decodePolyline6(route.geometry);
  const durationSec = route.duration as number; // seconds
  const distanceMeters = route.distance as number;

  return {
    coords,
    durationMin: Math.max(1, Math.round(durationSec / 60)),
    distanceKm: Math.round((distanceMeters / 1000) * 10) / 10,
  };
}

/* ---------------- Component ---------------- */

export default function CurrentTrip() {
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const bookingIdParam = params.bookingId as string | undefined;

  const [booking, setBooking] = useState<DbBooking | null>(null);
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);
  const [loading, setLoading] = useState(true);

  // map/route state
  const [routeCoords, setRouteCoords] = useState<LatLng[] | null>(null);
  const [distanceKm, setDistanceKm] = useState<number | null>(null);
  const [region, setRegion] = useState<Region | undefined>(undefined);

  // animations
  const slideAnim = useRef(new Animated.Value(0)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const cardSlideAnim = useRef(new Animated.Value(0)).current;

  /* --------- next status + labels --------- */

  const getNextBookingStatus = (s: BookingStatus | undefined): BookingStatus | null => {
    switch (s) {
      case 'en_route':        return 'arrived';
      case 'arrived':         return 'in_progress';
      case 'in_progress':     return 'completed';
      case 'completed':
      case 'cancelled':       return null;
      case 'scheduled':
      case 'valeter_assigned':
      default:                return 'en_route';
    }
  };

  const getNextStatusText = (current: BookingStatus | undefined): string => {
    const next = getNextBookingStatus(current);
    if (!next) return 'Completed!';
    switch (next) {
      case 'en_route':     return 'On the way';
      case 'arrived':      return 'Mark as arriving';
      case 'in_progress':  return 'Mark as in progress';
      case 'completed':    return 'Mark as completed';
      default:             return 'Update';
    }
  };

  const getStatusText = (status: BookingStatus | undefined) => {
    switch (status) {
      case 'en_route':       return 'On the way!';
      case 'arrived':        return 'Arrived!';
      case 'in_progress':    return 'Washing in progress';
      case 'completed':      return 'Wash completed!';
      case 'cancelled':      return 'Cancelled';
      case 'valeter_assigned':
      case 'scheduled':
      default:               return 'Ready to start';
    }
  };

  const getStatusColor = (status: BookingStatus | undefined) => {
    switch (status) {
      case 'en_route':      return '#10B981';
      case 'arrived':       return '#3B82F6';
      case 'in_progress':   return '#8B5CF6';
      case 'completed':     return '#059669';
      case 'cancelled':     return '#EF4444';
      default:              return '#6B7280';
    }
  };

  const getStatusIcon = (next: BookingStatus | null) => {
    switch (next) {
      case 'en_route':     return '🚗';
      case 'arrived':      return '📍';
      case 'in_progress':  return '🧽';
      case 'completed':    return '✨';
      default:             return '—';
    }
  };

  /* ---------------- Data load ---------------- */

  const fetchCurrentJob = async () => {
    if (!user) return;
    setLoading(true);
    try {
      let row: DbBooking | null = null;

      if (bookingIdParam) {
        const { data, error } = await supabase
          .from('bookings')
          .select('*')
          .eq('id', bookingIdParam)
          .maybeSingle<DbBooking>();
        if (error) throw error;
        row = data ?? null;
      } else {
        const { data, error } = await supabase
          .from('bookings')
          .select('*')
          .or(`valeter_id.eq.${user.id},user_id.eq.${user.id}`)
          .in('status', ['scheduled', 'valeter_assigned', 'en_route', 'arrived', 'in_progress'])
          .order('created_at', { ascending: false })
          .limit(1)
          .returns<DbBooking[]>();
        if (error) throw error;
        row = data?.[0] ?? null;
      }

      setBooking(row);

      // seed map region
      if (row?.location_lat && row?.location_lng) {
        setRegion({
          latitude: row.location_lat,
          longitude: row.location_lng,
          latitudeDelta: 0.05,
          longitudeDelta: 0.05,
        });
      }
    } catch (e) {
      console.error('[CurrentTrip] load error:', e);
      setBooking(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCurrentJob();

    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1.1, duration: 1000, useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 1, duration: 1000, useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Realtime updates
  useEffect(() => {
    if (!booking?.id) return;
    const channel = supabase
      .channel(`booking:${booking.id}`)
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'bookings', filter: `id=eq.${booking.id}` },
        (payload) => setBooking(payload.new as DbBooking)
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [booking?.id]);

  /* ---------------- Roles ---------------- */

  const isValeter = Boolean(user && booking && user.id === booking.valeter_id);
  const isCustomer = Boolean(user && booking && user.id === booking.user_id);

  /* ---------------- Actions ---------------- */

  const handleBack = () => router.back();

  const handleCall = async () => {
    try { await hapticFeedback('medium'); } catch {}
    Alert.alert('Call', 'Calling customer...');
  };

  const handleMessage = async () => {
    try { await hapticFeedback('medium'); } catch {}
    router.push('/chat-screen');
  };

  const handleExpand = async () => {
    try { await hapticFeedback('light'); } catch {}
    Animated.timing(slideAnim, {
      toValue: (slideAnim as any)._value ? 0 : 1,
      duration: 300,
      useNativeDriver: false,
    }).start();
  };

  const handleMinimize = async () => {
    try { await hapticFeedback('light'); } catch {}
    const to = ((cardSlideAnim as any)._value ?? 0) ? 0 : 1;
    Animated.timing(cardSlideAnim, { toValue: to, duration: 300, useNativeDriver: true }).start();
  };

  /* ---------------- Driver + Mapbox ---------------- */

  async function getDriverPosition() {
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') throw new Error('Location permission not granted');
    const pos = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
    const lat = pos.coords.latitude;
    const lng = pos.coords.longitude;
    let driverLocation: string | null = null;
    try {
      const rg = await Location.reverseGeocodeAsync({ latitude: lat, longitude: lng });
      if (rg && rg[0]) {
        const r = rg[0];
        driverLocation = [r.name, r.city ?? r.subregion, r.region].filter(Boolean).join(', ') || null;
      }
    } catch {}
    return { lat, lng, driverLocation };
  }

  /**
   * Only the assigned valeter can update.
   * Sequence:
   *   scheduled/valeter_assigned -> en_route (Mapbox route + ETA, write driver_* + eta_minutes)
   *   en_route -> arrived        (eta_minutes = 0)
   *   arrived -> in_progress
   *   in_progress -> completed
   */
  const updateToNextStatus = async () => {
    if (!booking) return;

    if (!isValeter) {
      Alert.alert('Read-only', 'Only the assigned valeter can update the job status.');
      return;
    }

    const current = booking.status;
    const next = getNextBookingStatus(current);
    if (!next) return;

    try { await hapticFeedback('medium'); } catch {}

    const confirmCopy: Record<BookingStatus, string> = {
      en_route: 'Start driving to the customer?',
      arrived: 'Mark as arriving (arrived at location)?',
      in_progress: 'Start the wash now?',
      completed: 'Mark this job completed?',
      scheduled: 'Start the journey?',
      valeter_assigned: 'Start the journey?',
      cancelled: 'This job is cancelled.',
    };

    const message =
      current === 'scheduled' || current === 'valeter_assigned'
        ? confirmCopy.scheduled
        : confirmCopy[next];

    const go = async () => {
      setIsUpdatingStatus(true);
      try {
        const payload: Record<string, any> = {
          status: next,
          updated_at: new Date().toISOString(),
        };

        // When going en_route: get driver pos, call Mapbox, draw route, and save ETA.
        if (next === 'en_route') {
          if (!(booking.location_lat && booking.location_lng)) {
            throw new Error('This booking has no destination lat/lng set.');
          }

          const { lat, lng, driverLocation } = await getDriverPosition();

          // Mapbox route + ETA
          let mapboxEtaMin: number | null = null;
          try {
            const route = await fetchMapboxRoute(
              { lat, lng },
              { lat: booking.location_lat, lng: booking.location_lng }
            );
            setRouteCoords(route.coords);
            setDistanceKm(route.distanceKm);

            // fit the map between points
            if (!region) {
              const midLat = (lat + booking.location_lat) / 2;
              const midLng = (lng + booking.location_lng) / 2;
              setRegion({
                latitude: midLat,
                longitude: midLng,
                latitudeDelta: Math.abs(lat - booking.location_lat) * 1.8 || 0.05,
                longitudeDelta: Math.abs(lng - booking.location_lng) * 1.8 || 0.05,
              });
            }

            mapboxEtaMin = route.durationMin;
          } catch (mbxErr) {
            console.warn('[CurrentTrip] Mapbox route failed:', mbxErr);
          }

          payload.driver_lat = lat;
          payload.driver_lng = lng;
          payload.driver_location = driverLocation;
          if (mapboxEtaMin != null) payload.eta_minutes = mapboxEtaMin;
        } else if (next === 'arrived') {
          payload.eta_minutes = 0;
        }

        const { data, error } = await supabase
          .from('bookings')
          .update(payload)
          .eq('id', booking.id)
          .select()
          .single();

        if (error) throw error;

        setBooking(data as DbBooking);

        const okMsg: Record<BookingStatus, string> = {
          en_route: '🚗 Marked as on the way! (ETA updated)',
          arrived: '📍 Marked as arriving (ETA set to 0)',
          in_progress: '🧽 Marked as in progress.',
          completed: '✨ Marked as completed.',
          scheduled: 'Ready.',
          valeter_assigned: 'Ready.',
          cancelled: 'Cancelled.',
        };
        Alert.alert('Status Updated', okMsg[next] ?? 'Updated.');
      } catch (e) {
        console.error('[CurrentTrip] status update error:', e);
        await fetchCurrentJob();
        Alert.alert('Update Failed', (e as Error)?.message || 'Failed to update status. Please try again.');
      } finally {
        setIsUpdatingStatus(false);
      }
    };

    Alert.alert('Confirm Status Update', message, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Confirm', onPress: go },
    ]);
  };

  /* ---------------- Render ---------------- */

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Loading trip details...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!booking) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />
        <View style={styles.noJobContainer}>
          <Text style={styles.noJobIcon}>🧽</Text>
          <Text style={styles.noJobTitle}>No job active</Text>
          <Text style={styles.noJobText}>
            You don’t have an active job right now. Head to the Jobs screen to accept one.
          </Text>
          <TouchableOpacity style={styles.noJobBtn} onPress={() => router.replace('/jobs')}>
            <LinearGradient colors={['#3B82F6', '#2563EB']} style={styles.noJobBtnGrad}>
              <Text style={styles.noJobBtnText}>Browse Jobs</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const currentStatus = booking.status;
  const nextStatus = getNextBookingStatus(currentStatus);
  const buttonLabel = getNextStatusText(currentStatus);

  // Map center logic
  const showDriver = booking.driver_lat != null && booking.driver_lng != null;
  const showDest = booking.location_lat != null && booking.location_lng != null;

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={handleBack}>
          <Text style={styles.backIcon}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Current Trip</Text>
        <View style={styles.headerSpacer} />
      </View>

      {/* Map Section */}
      <View style={styles.mapSection}>
        {showDest ? (
          <MapView
            style={StyleSheet.absoluteFill}
            initialRegion={
              region || {
                latitude: booking.location_lat!,
                longitude: booking.location_lng!,
                latitudeDelta: 0.05,
                longitudeDelta: 0.05,
              }
            }
            onRegionChangeComplete={setRegion}
          >
            {showDest && (
              <Marker
                coordinate={{ latitude: booking.location_lat!, longitude: booking.location_lng! }}
                title="Customer"
                description={booking.location_address ?? 'Destination'}
              />
            )}
            {showDriver && (
              <Marker
                coordinate={{ latitude: booking.driver_lat!, longitude: booking.driver_lng! }}
                title="You"
                description={booking.driver_location ?? 'Current position'}
                pinColor="#10B981"
              />
            )}
            {routeCoords && routeCoords.length > 1 && (
              <Polyline coordinates={routeCoords} strokeWidth={5} />
            )}
          </MapView>
        ) : (
          <View style={styles.mapPlaceholder}>
            <Text style={styles.mapPlaceholderIcon}>🗺️</Text>
            <Text style={styles.mapPlaceholderText}>No destination set</Text>
            <Text style={styles.mapPlaceholderSubtext}>Add location_lat/lng to booking</Text>
          </View>
        )}

        <View style={styles.mapOverlay}>
          <TouchableOpacity style={styles.expandButton} onPress={handleExpand}>
            <Text style={styles.expandIcon}>{(slideAnim as any)._value ? '↓' : '↑'}</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Job Card */}
      <Animated.View
        style={[
          styles.customerCard,
          {
            transform: [
              { translateY: slideAnim.interpolate({ inputRange: [0, 1], outputRange: [0, -200] }) },
              { translateY: cardSlideAnim.interpolate({ inputRange: [0, 1], outputRange: [0, 80] }) },
            ],
          },
        ]}
      >
        <LinearGradient colors={['#1E3A8A', '#87CEEB']} style={styles.customerGradient}>
          {/* Status Bar */}
          <View style={styles.statusBar}>
            <Animated.View
              style={[
                styles.statusIndicator,
                { backgroundColor: getStatusColor(currentStatus), transform: [{ scale: pulseAnim }] },
              ]}
            />
            <Text style={styles.statusText}>{getStatusText(currentStatus)}</Text>
            <Text style={styles.etaText}>
              {distanceKm != null ? `${distanceKm} km • ` : ''}
              ETA: {booking.eta_minutes != null ? `${booking.eta_minutes} min` : '—'}
            </Text>
            <TouchableOpacity style={styles.minimizeButton} onPress={handleMinimize}>
              <Text style={styles.minimizeIcon}>{((cardSlideAnim as any)._value ?? 0) ? '⬇️' : '⬆️'}</Text>
            </TouchableOpacity>
          </View>

          {/* Basic Info */}
          <View style={styles.customerSection}>
            <View style={styles.customerInfo}>
              <Text style={styles.customerPhoto}>👤</Text>
              <View style={styles.customerDetails}>
                <Text style={styles.customerName}>{booking.location_address || 'Customer location'}</Text>
                <Text style={styles.serviceInfo}>
                  {booking.service_type} • £{Number(booking.price || 0).toFixed(2)}
                </Text>
              </View>
            </View>

            <View style={styles.actionButtons}>
              <TouchableOpacity style={styles.actionButton} onPress={handleCall}>
                <Text style={styles.actionIcon}>📞</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.actionButton} onPress={handleMessage}>
                <Text style={styles.actionIcon}>💬</Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Progress Bar */}
          <View style={styles.progressSection}>
            <View style={styles.progressBar}>
              <View
                style={[
                  styles.progressFill,
                  {
                    width: `${
                      currentStatus === 'scheduled' || currentStatus === 'valeter_assigned'
                        ? 10
                        : currentStatus === 'en_route'
                        ? 40
                        : currentStatus === 'arrived'
                        ? 65
                        : currentStatus === 'in_progress'
                        ? 90
                        : 100
                    }%`,
                    backgroundColor: getStatusColor(currentStatus),
                  },
                ]}
              />
            </View>
            <View style={styles.progressLabels}>
              <Text style={styles.progressLabel}>On the way</Text>
              <Text style={styles.progressLabel}>Nearly there</Text>
              <Text style={styles.progressLabel}>Washing</Text>
              <Text style={styles.progressLabel}>Complete</Text>
            </View>
          </View>

          {/* Location */}
          <View style={styles.instructionsContainer}>
            <Text style={styles.instructionsTitle}>Location</Text>
            <Text style={styles.instructionsText}>
              {booking.location_address || 'No address provided'}
            </Text>
          </View>
        </LinearGradient>
      </Animated.View>

      {/* Status controls: shown ONLY to the assigned valeter */}
      {isValeter ? (
        <View style={styles.statusButtonsContainer}>
          <TouchableOpacity
            style={[
              styles.progressButton,
              {
                backgroundColor:
                  isUpdatingStatus
                    ? '#6B7280'
                    : nextStatus
                    ? getStatusColor(nextStatus)
                    : getStatusColor('completed'),
                opacity: isUpdatingStatus ? 0.7 : nextStatus ? 1 : 0.8,
              },
            ]}
            onPress={() => !isUpdatingStatus && nextStatus && updateToNextStatus()}
            activeOpacity={0.8}
            disabled={isUpdatingStatus || !nextStatus}
          >
            <Animated.View style={[styles.progressButtonContent, { transform: [{ scale: pulseAnim }] }]}>
              <Text style={styles.progressButtonIcon}>
                {isUpdatingStatus ? '⏳' : getStatusIcon(nextStatus)}
              </Text>
              <Text style={styles.progressButtonText}>
                {isUpdatingStatus ? 'Updating...' : getNextStatusText(currentStatus)}
              </Text>
            </Animated.View>
          </TouchableOpacity>

          <View style={styles.currentStatusIndicator}>
            <Text style={styles.currentStatusText}>Current: {getStatusText(currentStatus)}</Text>
          </View>
        </View>
      ) : (
        <View className="readonlyRibbon" style={styles.readonlyRibbon}>
          <Text style={styles.readonlyText}>Live status updates — read only</Text>
        </View>
      )}
    </SafeAreaView>
  );
}

/* ---------------- styles ---------------- */
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A1929' },

  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  loadingText: { color: '#FFFFFF', fontSize: 18 },

  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 20, paddingVertical: 16,
    borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.1)',
  },
  backButton: {
    width: 40, height: 40, borderRadius: 20, backgroundColor: 'rgba(255,255,255,0.1)',
    justifyContent: 'center', alignItems: 'center',
  },
  backIcon: { color: '#F9FAFB', fontSize: 20, fontWeight: 'bold' },
  headerTitle: { color: '#F9FAFB', fontSize: 20, fontWeight: 'bold' },
  headerSpacer: { width: 40 },

  mapSection: { flex: 1, position: 'relative', marginBottom: 360 },
  mapPlaceholder: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#1E3A8A' },
  mapPlaceholderIcon: { fontSize: 64, marginBottom: 16 },
  mapPlaceholderText: { color: '#FFFFFF', fontSize: 20, fontWeight: 'bold', marginBottom: 8 },
  mapPlaceholderSubtext: { color: '#E0E7FF', fontSize: 14, marginBottom: 4 },

  mapOverlay: { position: 'absolute', top: 20, right: 20 },
  expandButton: {
    width: 44, height: 44, borderRadius: 22, backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center', alignItems: 'center',
  },
  expandIcon: { color: '#FFFFFF', fontSize: 18, fontWeight: 'bold' },

  customerCard: {
    position: 'absolute', bottom: 0, left: 0, right: 0, backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 20, borderTopRightRadius: 20, shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 }, shadowOpacity: 0.3, shadowRadius: 8,
    elevation: 8, height: 280, zIndex: 2,
  },
  customerGradient: { borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 20, height: '100%' },

  statusBar: { flexDirection: 'row', alignItems: 'center', marginBottom: 16 },
  statusIndicator: { width: 12, height: 12, borderRadius: 6, marginRight: 8 },
  statusText: { color: '#FFFFFF', fontSize: 16, fontWeight: 'bold', flex: 1 },
  etaText: { color: '#E0E7FF', fontSize: 14 },
  minimizeButton: { marginLeft: 'auto', padding: 8, borderRadius: 20, backgroundColor: 'rgba(255,255,255,0.2)' },
  minimizeIcon: { fontSize: 16, color: '#FFFFFF' },

  customerSection: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  customerInfo: { flex: 1, flexDirection: 'row', alignItems: 'center' },
  customerPhoto: { fontSize: 32, marginRight: 8 },
  customerDetails: { flex: 1 },
  customerName: { color: '#FFFFFF', fontSize: 16, fontWeight: 'bold', marginBottom: 2 },
  serviceInfo: { color: '#E0E7FF', fontSize: 12 },
  actionButtons: { flexDirection: 'row', gap: 8 },
  actionButton: {
    width: 44, height: 44, borderRadius: 22, backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center', alignItems: 'center',
  },
  actionIcon: { fontSize: 20 },

  progressSection: { marginBottom: 16 },
  progressBar: { height: 4, backgroundColor: 'rgba(255,255,255,0.2)', borderRadius: 2, marginBottom: 8 },
  progressFill: { height: '100%', borderRadius: 2 },
  progressLabels: { flexDirection: 'row', justifyContent: 'space-between' },
  progressLabel: { color: '#E0E7FF', fontSize: 10, textAlign: 'center', flex: 1 },

  instructionsContainer: { backgroundColor: 'rgba(255,255,255,0.1)', borderRadius: 8, padding: 12 },
  instructionsTitle: { color: '#FFFFFF', fontSize: 12, fontWeight: 'bold', marginBottom: 4 },
  instructionsText: { color: '#E0E7FF', fontSize: 12, lineHeight: 16 },

  // Valeter control bar
  statusButtonsContainer: {
    position: 'absolute', bottom: 280, left: 0, right: 0, height: 60, zIndex: 1,
  },
  progressButton: {
    borderRadius: 0, padding: 0, alignItems: 'center', justifyContent: 'center',
    height: '100%', width: '100%',
  },
  progressButtonContent: { alignItems: 'center', justifyContent: 'center' },
  progressButtonIcon: { fontSize: 18, marginBottom: 4 },
  progressButtonText: {
    fontSize: 14, fontWeight: '700', color: '#FFFFFF', textAlign: 'center',
    textShadowColor: 'rgba(0,0,0,0.2)', textShadowOffset: { width: 0, height: 1 }, textShadowRadius: 1,
  },
  currentStatusIndicator: { position: 'absolute', top: -30, left: 0, right: 0, alignItems: 'center', paddingVertical: 8 },
  currentStatusText: { color: '#E0E7FF', fontSize: 12, fontWeight: '500', textAlign: 'center' },

  // Read-only ribbon
  readonlyRibbon: {
    position: 'absolute',
    bottom: 280,
    left: 0,
    right: 0,
    paddingVertical: 10,
    alignItems: 'center',
    backgroundColor: 'rgba(59,130,246,0.25)',
  },
  readonlyText: { color: '#E0E7FF', fontSize: 12, fontWeight: '600' },

  // Empty state
  noJobContainer: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 24 },
  noJobIcon: { fontSize: 56, marginBottom: 12 },
  noJobTitle: { color: '#FFFFFF', fontSize: 20, fontWeight: 'bold', marginBottom: 8 },
  noJobText: { color: '#E0E7FF', fontSize: 14, textAlign: 'center', lineHeight: 20, marginBottom: 16 },
  noJobBtn: { borderRadius: 10, overflow: 'hidden' },
  noJobBtnGrad: { paddingVertical: 12, paddingHorizontal: 20, borderRadius: 10 },
  noJobBtnText: { color: '#FFFFFF', fontSize: 14, fontWeight: 'bold' },
});