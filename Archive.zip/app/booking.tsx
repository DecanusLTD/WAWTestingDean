import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  ScrollView,
  Alert,
  TextInput,
} from 'react-native';
import { router } from 'expo-router';
import { useAuth } from '../src/providers/enhanced-auth-context';
import { simulationService, SimulationJob } from '../src/services/SimulationService';
import { pricingEngine } from '../src/utils/pricing-engine';

interface ServiceOption {
  id: 'wash' | 'valet' | 'priority_wash';
  name: string;
  description: string;
  price: number;
  duration: string;
  icon: string;
}

const serviceOptions: ServiceOption[] = [
  {
    id: 'wash',
    name: 'Basic Wash',
    description: 'Exterior wash and dry',
    price: 20,
    duration: '30 min',
    icon: '🚗'
  },
  {
    id: 'valet',
    name: 'Full Valet',
    description: 'Interior and exterior deep clean',
    price: 35,
    duration: '45 min',
    icon: '✨'
  },
  {
    id: 'priority_wash',
    name: 'Priority Wash',
    description: 'Express service with priority booking',
    price: 45,
    duration: '15 min',
    icon: '⚡'
  }
];

export default function BookingScreen() {
  const { user } = useAuth();
  const [selectedService, setSelectedService] = useState<ServiceOption | null>(null);
  const [selectedLocation, setSelectedLocation] = useState<string>('');
  const [isBooking, setIsBooking] = useState(false);

  // Add user to simulation service
  if (user && !simulationService.getUser(user.id)) {
    simulationService.addUser({
      id: user.id,
      name: user.name,
      email: user.email,
      userType: user.userType,
      location: { lat: 51.5074, lng: -0.1278 },
      isOnline: true,
      rating: 4.8,
      jobsCompleted: 0,
      phone: user.phone || '+44 7700 900000'
    });
  }

  const handleBookService = async () => {
    if (!selectedService || !selectedLocation) {
      Alert.alert('Error', 'Please select a service and location');
      return;
    }

    try {
      setIsBooking(true);

      const pricingFactors = {
        location: 'London', // Default location
        timeOfDay: pricingEngine.getTimeOfDay(),
        dayOfWeek: pricingEngine.getDayOfWeek(),
        demand: pricingEngine.getDemandLevel('London', pricingEngine.getTimeOfDay(), pricingEngine.getDayOfWeek()),
        weather: 'sunny' as const, // Default weather
        vehicleSize: 'medium' as const, // Default vehicle size
        serviceType: selectedService.id as 'wash' | 'valet' | 'priority_wash'
      };

      const priceBreakdown = pricingEngine.calculatePrice(pricingFactors);
      const finalPrice = Math.round(priceBreakdown.totalPrice);

      simulationService.createJob(
        user!.id,
        selectedService.id as 'wash' | 'valet' | 'priority_wash',
        {
          lat: 51.5074,
          lng: -0.1278,
          address: selectedLocation
        },
        finalPrice
      );

      Alert.alert(
        'Booking Successful!',
        `Your ${selectedService.name} has been booked for £${finalPrice}. We're finding you a valeter...`,
        [
          {
            text: 'Track Service',
            onPress: () => router.push('/tracking')
          }
        ]
      );

    } catch (error) {
      Alert.alert('Error', 'Failed to book service. Please try again.');
    } finally {
      setIsBooking(false);
    }
  };

  if (false) { // isLoading state variable was removed
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Creating your booking...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Book a Service</Text>
          <View style={styles.placeholder} />
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Choose Your Service</Text>
          <View style={styles.serviceOptionsContainer}>
            {serviceOptions.map((service) => (
              <TouchableOpacity
                key={service.id}
                style={[
                  styles.serviceCard,
                  selectedService?.id === service.id && styles.selectedServiceCard,
                ]}
                onPress={() => setSelectedService(service)}
              >
                <Text style={styles.serviceIcon}>{service.icon}</Text>
                <View style={styles.serviceInfo}>
                  <Text style={styles.serviceName}>{service.name}</Text>
                  <Text style={styles.serviceDescription}>{service.description}</Text>
                  <Text style={styles.servicePrice}>From £{service.price}</Text>
                  <Text style={styles.serviceTime}>~{service.duration}</Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Where are you?</Text>
          <View style={styles.locationInputContainer}>
            <Text style={styles.locationIcon}>📍</Text>
            <TextInput
              style={styles.locationInput}
              placeholder="Enter your location (e.g., London, UK)"
              placeholderTextColor="#B0E0E6"
              value={selectedLocation}
              onChangeText={setSelectedLocation}
            />
          </View>
        </View>

        {selectedService && selectedLocation && (
          <TouchableOpacity
            style={styles.bookButton}
            onPress={handleBookService}
            disabled={isBooking}
          >
            <Text style={styles.bookButtonText}>
              {isBooking ? 'Booking...' : `Book ${selectedService.name} - £${selectedService.price}`}
            </Text>
          </TouchableOpacity>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 10,
  },
  backButton: {
    padding: 10,
  },
  backButtonText: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: 'bold',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#87CEEB',
  },
  placeholder: {
    width: 50,
  },
  section: {
    padding: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#87CEEB',
    marginBottom: 15,
  },
  serviceOptionsContainer: {
    gap: 15,
  },
  serviceCard: {
    flexDirection: 'row',
    backgroundColor: '#1E3A8A',
    padding: 20,
    borderRadius: 15,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'transparent',
  },
  selectedServiceCard: {
    borderColor: '#87CEEB',
    backgroundColor: '#2E4A8A',
  },
  serviceIcon: {
    fontSize: 30,
    marginRight: 15,
  },
  serviceInfo: {
    flex: 1,
  },
  serviceName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#87CEEB',
    marginBottom: 5,
  },
  serviceDescription: {
    fontSize: 14,
    color: '#B0E0E6',
    marginBottom: 5,
  },
  servicePrice: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#87CEEB',
  },
  serviceTime: {
    fontSize: 12,
    color: '#B0E0E6',
  },
  locationInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1E3A8A',
    paddingHorizontal: 15,
    paddingVertical: 15,
    borderRadius: 15,
  },
  locationIcon: {
    fontSize: 20,
    marginRight: 10,
  },
  locationInput: {
    flex: 1,
    fontSize: 16,
    color: '#fff',
  },
  bookButton: {
    backgroundColor: '#87CEEB',
    margin: 20,
    padding: 15,
    borderRadius: 15,
    alignItems: 'center',
  },
  bookButtonText: {
    color: '#0A1929',
    fontSize: 18,
    fontWeight: 'bold',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: '#87CEEB',
    fontSize: 16,
  },
});
