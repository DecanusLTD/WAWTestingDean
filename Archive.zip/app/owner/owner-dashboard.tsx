import React from 'react';
import EnhancedCustomerDashboard from '../../src/components/dashboard/EnhancedCustomerDashboard';

export default function OwnerDashboard() {
  return <EnhancedCustomerDashboard />;
}
