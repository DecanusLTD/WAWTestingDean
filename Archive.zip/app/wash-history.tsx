// app/wash-history.tsx (or wherever this screen lives)
import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  StatusBar,
  ActivityIndicator,
  Alert,
  RefreshControl,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useAuth } from '../src/providers/enhanced-auth-context';
import { washCompletionService, WashCompletion } from '../src/services/WashCompletionService';

type CompletedStatus =
  | 'completed'
  | 'rated'
  | 'tipped'
  | 'closed'
  | 'archived'
  | 'complete'; // being tolerant

const COMPLETED_STATUSES = new Set<CompletedStatus>([
  'completed',
  'rated',
  'tipped',
  'closed',
  'archived',
  'complete',
]);

export default function WashHistoryScreen() {
    console.log('his');
  const { user } = useAuth();
  const [washCompletions, setWashCompletions] = useState<WashCompletion[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadWashHistory();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  const formatCurrency = (n?: number | null) =>
    typeof n === 'number' ? `£${n.toFixed(2).replace(/\.00$/, '')}` : '—';

  const isCompleted = (wc: WashCompletion) =>
    COMPLETED_STATUSES.has((wc?.status as CompletedStatus) ?? 'completed');

  const sortByCompletedAtDesc = (a: WashCompletion, b: WashCompletion) => {
    const ta = new Date(a.completedAt ?? a.createdAt ?? 0).getTime();
    const tb = new Date(b.completedAt ?? b.createdAt ?? 0).getTime();
    return tb - ta;
  };

  const loadWashHistory = async () => {
    if (!user?.id) {
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      // Service already scopes to customer; we filter to "completed-like"
      const all = await washCompletionService.getCustomerWashCompletions(user.id);
      const onlyCompleted = (all || []).filter(isCompleted).sort(sortByCompletedAtDesc);
      setWashCompletions(onlyCompleted);
    } catch (error) {
      console.error('Error loading wash history:', error);
      Alert.alert('Error', 'Failed to load wash history');
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = useCallback(async () => {
    try {
      setRefreshing(true);
      await loadWashHistory();
    } finally {
      setRefreshing(false);
    }
  }, []);

  const handleRateWash = (washCompletionId: string) => {
    router.push(`/wash-rating?washCompletionId=${washCompletionId}`);
  };

  const formatDate = (dateLike: Date | string | number | undefined) => {
    const d = dateLike ? new Date(dateLike) : new Date();
    return d.toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getRatingText = (rating?: number | null) => {
    switch (rating) {
      case 1: return 'Poor';
      case 2: return 'Fair';
      case 3: return 'Good';
      case 4: return 'Very Good';
      case 5: return 'Excellent';
      default: return 'Not Rated';
    }
  };

  // Aggregates
  const total = washCompletions.length;
  const rated = washCompletions.filter(w => (w as any).rating).length;
  const tipped = washCompletions.filter(w => (w as any).tipAmount && (w as any).tipAmount > 0).length;
  const totalSpent = washCompletions.reduce((sum, w) => sum + (Number((w as any).price) || 0), 0);
  const avgRating = (() => {
    const ratings = washCompletions.map(w => Number((w as any).rating)).filter(n => n > 0);
    if (!ratings.length) return 0;
    return Math.round((ratings.reduce((a, b) => a + b, 0) / ratings.length) * 10) / 10;
  })();

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#FFFFFF" />
        <Text style={styles.loadingText}>Loading wash history...</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0A1929" />
      <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />

      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Text style={styles.backButtonText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Wash History</Text>
        <View style={styles.placeholder} />
      </View>

      <ScrollView
        style={styles.content}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#fff" />}
        contentContainerStyle={{ paddingBottom: 28 }}
      >
        {washCompletions.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyIcon}>🚗</Text>
            <Text style={styles.emptyTitle}>No Completed Washes</Text>
            <Text style={styles.emptyText}>
              Once you complete a wash, it’ll appear here.
            </Text>
            <TouchableOpacity
              style={styles.bookFirstWashButton}
              onPress={() => router.push('/priority-wash')}
            >
              <Text style={styles.bookFirstWashIcon}>⭐</Text>
              <Text style={styles.bookFirstWashText}>Book a Wash</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <>
            {/* Stats */}
            <View style={styles.statsContainer}>
              <View style={styles.statCard}>
                <Text style={styles.statNumber}>{total}</Text>
                <Text style={styles.statLabel}>Total Washes</Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statNumber}>{rated}</Text>
                <Text style={styles.statLabel}>Rated</Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statNumber}>{tipped}</Text>
                <Text style={styles.statLabel}>Tipped</Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statNumber}>{avgRating ? `${avgRating}⭐` : '—'}</Text>
                <Text style={styles.statLabel}>Avg Rating</Text>
              </View>
            </View>

            <View style={[styles.totalsPill]}>
              <Text style={styles.totalsPillText}>Total Spent: {formatCurrency(totalSpent)}</Text>
            </View>

            <Text style={styles.sectionTitle}>All Completed Washes</Text>

            {washCompletions.map((completion) => {
              const rating = Number((completion as any).rating) || 0;
              const serviceName = (completion as any).serviceName ?? (completion as any).service_type ?? 'Car Wash';
              const price = Number((completion as any).price) || 0;
              const valeterName = (completion as any).valeterName ?? (completion as any).valeter_name;
              const org = (completion as any).valeterOrganization ?? (completion as any).valeter_org;
              const address = (completion as any).address ?? (completion as any).location?.address;

              return (
                <View key={completion.id} style={styles.washCard}>
                  <View style={styles.washHeader}>
                    <View style={styles.washInfo}>
                      <Text style={styles.washService}>{serviceName}</Text>
                      <Text style={styles.washDate}>{formatDate(completion.completedAt)}</Text>
                      <Text style={styles.washId}>#{String(completion.id).slice(-6)}</Text>
                    </View>
                    <View style={styles.washStatus}>
                      <Text style={styles.statusCompleted}>
                        {(completion.status || 'completed').toString().replace(/_/g, ' ')}
                      </Text>
                      {price > 0 ? <Text style={styles.priceText}>{formatCurrency(price)}</Text> : null}
                    </View>
                  </View>

                  {(valeterName || org) && (
                    <Text style={styles.valeterLine}>
                      🧽 {valeterName ?? 'Valeter'} {org ? `• ${org}` : ''}
                    </Text>
                  )}
                  {address ? <Text style={styles.addressLine}>📍 {address}</Text> : null}

                  {completion.notes ? (
                    <View style={styles.notesContainer}>
                      <Text style={styles.notesTitle}>Valeter Notes:</Text>
                      <Text style={styles.notesText}>{completion.notes}</Text>
                    </View>
                  ) : null}

                  {(completion as any).photos?.length ? (
                    <View style={styles.photosContainer}>
                      <Text style={styles.photosTitle}>
                        Photos {(completion as any).photos.length ? `(${(completion as any).photos.length})` : ''}
                      </Text>
                      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                        {(completion as any).photos.map((photo: any, index: number) => (
                          <View key={index} style={styles.photoContainer}>
                            <View style={styles.photoPlaceholder}>
                              <Text style={styles.photoPlaceholderText}>📸</Text>
                              <Text style={styles.photoPlaceholderLabel}>Photo {index + 1}</Text>
                            </View>
                          </View>
                        ))}
                      </ScrollView>
                    </View>
                  ) : null}

                  {rating > 0 ? (
                    <View style={styles.ratingContainer}>
                      <View style={styles.ratingInfo}>
                        <Text style={styles.ratingStars}>{'⭐'.repeat(rating)}</Text>
                        <Text style={styles.ratingText}>{getRatingText(rating)}</Text>
                      </View>
                      {(completion as any).customerReview ? (
                        <Text style={styles.reviewText}>"{(completion as any).customerReview}"</Text>
                      ) : null}
                      {(completion as any).tipAmount && (completion as any).tipAmount > 0 ? (
                        <View style={styles.tipContainer}>
                          <Text style={styles.tipIcon}>💰</Text>
                          <Text style={styles.tipText}>
                            {formatCurrency((completion as any).tipAmount)} tip given
                          </Text>
                        </View>
                      ) : null}
                    </View>
                  ) : (
                    <TouchableOpacity
                      style={styles.rateButton}
                      onPress={() => handleRateWash(completion.id)}
                    >
                      <Text style={styles.rateButtonIcon}>⭐</Text>
                      <Text style={styles.rateButtonText}>Rate This Wash</Text>
                    </TouchableOpacity>
                  )}
                </View>
              );
            })}
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A1929' },

  loadingContainer: {
    flex: 1, backgroundColor: '#0A1929', justifyContent: 'center', alignItems: 'center',
  },
  loadingText: { color: '#FFFFFF', fontSize: 16, marginTop: 16 },

  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 20, paddingTop: 20, paddingBottom: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderBottomColor: 'rgba(255, 255, 255, 0.2)', borderBottomWidth: 1,
  },
  backButton: { paddingVertical: 8, paddingHorizontal: 12 },
  backButtonText: { color: '#FFFFFF', fontSize: 16, fontWeight: '600' },
  headerTitle: { color: '#FFFFFF', fontSize: 20, fontWeight: 'bold', textAlign: 'center' },
  placeholder: { width: 60 },

  content: { flex: 1, paddingHorizontal: 20 },

  emptyContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', paddingVertical: 60 },
  emptyIcon: { fontSize: 64, marginBottom: 16 },
  emptyTitle: { color: '#FFFFFF', fontSize: 24, fontWeight: 'bold', marginBottom: 8 },
  emptyText: { color: '#87CEEB', fontSize: 16, textAlign: 'center', marginBottom: 32, paddingHorizontal: 20 },
  bookFirstWashButton: {
    backgroundColor: '#4CAF50', borderRadius: 12, paddingVertical: 16, paddingHorizontal: 24,
    alignItems: 'center', flexDirection: 'row',
  },
  bookFirstWashIcon: { fontSize: 20, marginRight: 8 },
  bookFirstWashText: { color: '#FFFFFF', fontSize: 18, fontWeight: 'bold' },

  statsContainer: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', marginVertical: 20, gap: 8 },
  statCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)', borderRadius: 12, padding: 16, alignItems: 'center',
    flex: 1, minWidth: 120,
  },
  statNumber: { color: '#FFFFFF', fontSize: 20, fontWeight: 'bold', marginBottom: 4 },
  statLabel: { color: '#87CEEB', fontSize: 12 },

  totalsPill: {
    alignSelf: 'flex-start', backgroundColor: 'rgba(255,255,255,0.08)', borderRadius: 999, paddingVertical: 6, paddingHorizontal: 12, marginBottom: 8,
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.12)',
  },
  totalsPillText: { color: '#E5E7EB', fontSize: 12, fontWeight: '600' },

  sectionTitle: { color: '#FFFFFF', fontSize: 20, fontWeight: 'bold', marginVertical: 12 },

  washCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)', borderRadius: 12, padding: 16, marginBottom: 16,
    borderWidth: 1, borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  washHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  washInfo: { flex: 1 },
  washService: { color: '#fff', fontSize: 16, fontWeight: '700' },
  washDate: { color: '#FFFFFF', fontSize: 14, fontWeight: '600', marginTop: 2 },
  washId: { color: '#87CEEB', fontSize: 12, marginTop: 4 },
  washStatus: { alignItems: 'flex-end' },
  statusCompleted: { color: '#10B981', fontSize: 12, fontWeight: '700', textTransform: 'capitalize' },
  priceText: { color: '#F9FAFB', fontSize: 12, fontWeight: '600', marginTop: 4 },

  valeterLine: { color: '#BFE0FF', marginBottom: 6 },
  addressLine: { color: '#93C5FD', marginBottom: 8 },

  notesContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)', borderRadius: 8, padding: 12, marginBottom: 10,
  },
  notesTitle: { color: '#FFFFFF', fontSize: 14, fontWeight: '600', marginBottom: 4 },
  notesText: { color: '#87CEEB', fontSize: 14, lineHeight: 20 },

  photosContainer: { marginBottom: 12 },
  photosTitle: { color: '#FFFFFF', fontSize: 14, fontWeight: '600', marginBottom: 8 },
  photoContainer: { marginRight: 8 },
  photoPlaceholder: {
    width: 80, height: 80, backgroundColor: 'rgba(255, 255, 255, 0.1)', borderRadius: 8,
    alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  photoPlaceholderText: { fontSize: 20, marginBottom: 2 },
  photoPlaceholderLabel: { color: '#87CEEB', fontSize: 10 },

  ratingContainer: { backgroundColor: 'rgba(255, 255, 255, 0.05)', borderRadius: 8, padding: 12 },
  ratingInfo: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  ratingStars: { fontSize: 16, marginRight: 8 },
  ratingText: { color: '#FFFFFF', fontSize: 14, fontWeight: '600' },
  reviewText: { color: '#87CEEB', fontSize: 14, fontStyle: 'italic', marginBottom: 8 },
  tipContainer: { flexDirection: 'row', alignItems: 'center' },
  tipIcon: { fontSize: 16, marginRight: 4 },
  tipText: { color: '#10B981', fontSize: 14, fontWeight: '600' },

  rateButton: {
    backgroundColor: '#4CAF50', borderRadius: 8, paddingVertical: 12, paddingHorizontal: 16,
    alignItems: 'center', flexDirection: 'row', justifyContent: 'center',
  },
  rateButtonIcon: { fontSize: 16, marginRight: 8 },
  rateButtonText: { color: '#FFFFFF', fontSize: 14, fontWeight: '600' },
});