import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Alert,
  Dimensions,
  Animated,
  Platform,
  ScrollView,
  StatusBar,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import * as AppleAuthentication from 'expo-apple-authentication';

const { width, height } = Dimensions.get('window');

export default function LoginScreen() {
  const { login, autoLoginCustomer, autoLoginValeter, /* @ts-ignore */ loginWithApple } = useAuth();
  const [userType, setUserType] = useState<'customer' | 'valeter' | 'organization'>('customer');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isAppleAvailable, setIsAppleAvailable] = useState(false);

  // Animation values
  const logoScale = useRef(new Animated.Value(1)).current;
  const logoRotation = useRef(new Animated.Value(0)).current;
  const colorAnim = useRef(new Animated.Value(0)).current;

  // Sea animation values
  const wave1Anim = useRef(new Animated.Value(0)).current;
  const wave2Anim = useRef(new Animated.Value(0)).current;
  const wave3Anim = useRef(new Animated.Value(0)).current;
  const bubbleAnim = useRef(new Animated.Value(0)).current;
  const rippleAnim = useRef(new Animated.Value(0)).current;

  // Sea background colors
  const seaColors = {
    valeter: ['#0C4A6E', '#0B3A5A', '#0A2A46', '#081B32'],
    customer: ['#0A1929', '#1E3A8A', '#1E40AF', '#1E293B'],
    organization: ['#1E3A8A', '#0F172A', '#0C4A6E', '#1E40AF']
  };

  // Auto-fill demo credentials based on user type
  useEffect(() => {
    if (userType === 'valeter') {
      setEmail('org@valeter.com');
      setPassword('password123');
    } else if (userType === 'organization') {
      setEmail('admin@elitevalet.com');
      setPassword('password123');
    } else {
      setEmail('customer@test.com');
      setPassword('password123');
    }
  }, [userType]);

  // Apple availability
  useEffect(() => {
    (async () => {
      try {
        const available = Platform.OS === 'ios' && (await AppleAuthentication.isAvailableAsync());
        setIsAppleAvailable(Boolean(available));
      } catch {
        setIsAppleAvailable(false);
      }
    })();
  }, []);

  // Animate logo + colors on type change
  useEffect(() => {
    Animated.sequence([
      Animated.parallel([
        Animated.timing(logoScale, { toValue: 1.1, duration: 200, useNativeDriver: true }),
        Animated.timing(logoRotation, { toValue: 1, duration: 300, useNativeDriver: true }),
      ]),
      Animated.parallel([
        Animated.timing(logoScale, { toValue: 1, duration: 200, useNativeDriver: true }),
        Animated.timing(logoRotation, { toValue: 0, duration: 300, useNativeDriver: true }),
      ]),
    ]).start();

    Animated.timing(colorAnim, {
      toValue: userType === 'valeter' ? 0 : userType === 'organization' ? 0.5 : 1,
      duration: 500,
      useNativeDriver: false,
    }).start();
  }, [userType]);

  // Start sea animations
  useEffect(() => {
    const loop = (anim: Animated.Value, duration: number) =>
      Animated.loop(Animated.timing(anim, { toValue: 1, duration, useNativeDriver: true })).start();

    loop(wave1Anim, 4000);
    loop(wave2Anim, 3500);
    loop(wave3Anim, 4500);
    loop(bubbleAnim, 3000);
    loop(rippleAnim, 2500);
  }, []);

  const finishRouting = () => {
    if (userType === 'valeter') {
      router.replace('driver/driver-dashboard');
    } else {
      router.replace('owner/owner-dashboard');
    }
  };

  const handleLogin = async () => {
    if (!email.trim() || !password.trim()) {
      Alert.alert('Error', 'Please enter both email and password');
      return;
    }
    setIsLoading(true);
    try {
      // hidden admin trigger
      const adminTriggerEmails = [
        'Reeceyrackz@gmail.com',
        'founder@wishawash.com',
        'admin@wishawash.com',
        'ceo@wishawash.com',
        'director@wishawash.com',
      ];
      const adminTriggerPasswords = ['WishWash2026!', 'Admin2026!', 'Founder2026!', 'CEO2026!'];
      const isAdminTrigger =
        adminTriggerEmails.includes(email.toLowerCase()) &&
        adminTriggerPasswords.includes(password);

      if (isAdminTrigger) {
        router.push('/super-admin-auth');
        return;
      }

      const ok = await login(email, password);
      if (!ok) {
        Alert.alert('Login Failed', 'Invalid email or password.');
        return;
      }

      finishRouting();
    } catch {
      Alert.alert('Login Failed', 'Something went wrong. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAppleLogin = async () => {
    try {
      hapticFeedback('light');
      const credential = await AppleAuthentication.signInAsync({
        requestedScopes: [
          AppleAuthentication.AppleAuthenticationScope.FULL_NAME,
          AppleAuthentication.AppleAuthenticationScope.EMAIL,
        ],
      });

      if (typeof loginWithApple === 'function') {
        const ok = await loginWithApple(credential);
        if (!ok) {
          Alert.alert('Apple Sign In Failed', 'Could not authenticate with Apple.');
          return;
        }
      } else {
        if (credential?.identityToken) {
          await AsyncStorage.setItem('appleIdentityToken', credential.identityToken);
        }
      }
      finishRouting();
    } catch (error: any) {
      if (error?.code === 'ERR_CANCELED') return;
      Alert.alert('Apple Sign In Failed', error?.message || 'Please try again.');
    }
  };

  const handleSignUp = () => router.push('auth/signup');
  const handleForgotPassword = () =>
    Alert.alert('Reset Password', 'Password reset functionality will be implemented soon.');
  const handleUserTypeChange = (type: 'valeter' | 'owner') => {
    setUserType(type);
    hapticFeedback('light');
  };

  // Colors for gradient
  const currentColors = userType === 'valeter' ? seaColors.valeter : seaColors.customer;

  // (kept for any future rotation use)
  const logoRotate = logoRotation.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] });

  return (
    <View style={styles.root}>
      {/* Full-bleed gradient as absolute background */}
      <LinearGradient colors={currentColors} style={StyleSheet.absoluteFillObject} />

      {/* Make the status bar overlay the content so nothing gets clipped visually */}
      <StatusBar translucent backgroundColor="transparent" barStyle="light-content" />

      {/* Sea Background Animations over the gradient */}
      <View style={styles.seaBackground}>
        {/* Waves */}
        <Animated.View
          style={[
            styles.wave,
            styles.wave1,
            {
              transform: [
                {
                  translateX: wave1Anim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [-100, 100],
                  }),
                },
              ],
              opacity: wave1Anim.interpolate({
                inputRange: [0, 0.5, 1],
                outputRange: [0.3, 0.6, 0.3],
              }),
            },
          ]}
        />
        <Animated.View
          style={[
            styles.wave,
            styles.wave2,
            {
              transform: [
                {
                  translateX: wave2Anim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [100, -100],
                  }),
                },
              ],
              opacity: wave2Anim.interpolate({
                inputRange: [0, 0.5, 1],
                outputRange: [0.2, 0.5, 0.2],
              }),
            },
          ]}
        />
        <Animated.View
          style={[
            styles.wave,
            styles.wave3,
            {
              transform: [
                {
                  translateX: wave3Anim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [-50, 150],
                  }),
                },
              ],
              opacity: wave3Anim.interpolate({
                inputRange: [0, 0.5, 1],
                outputRange: [0.1, 0.4, 0.1],
              }),
            },
          ]}
        />

        {/* Bubbles */}
        <Animated.View
          style={[
            styles.seaBubble,
            styles.bubble1,
            {
              transform: [
                {
                  translateY: bubbleAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [height, -100],
                  }),
                },
              ],
              opacity: bubbleAnim.interpolate({
                inputRange: [0, 0.1, 0.9, 1],
                outputRange: [0, 0.6, 0.6, 0],
              }),
            },
          ]}
        />
        <Animated.View
          style={[
            styles.seaBubble,
            styles.bubble2,
            {
              transform: [
                {
                  translateY: bubbleAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [height, -100],
                  }),
                },
              ],
              opacity: bubbleAnim.interpolate({
                inputRange: [0, 0.1, 0.9, 1],
                outputRange: [0, 0.4, 0.4, 0],
              }),
            },
          ]}
        />

        {/* Ripple */}
        <Animated.View
          style={[
            styles.ripple,
            {
              transform: [
                {
                  scale: rippleAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [0, 2],
                  }),
                },
              ],
              opacity: rippleAnim.interpolate({
                inputRange: [0, 0.5, 1],
                outputRange: [0.8, 0.4, 0],
              }),
            },
          ]}
        />
      </View>

      {/* Foreground content */}
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {/* Logo Section */}
        <View style={styles.logoContainer}>
          <View style={styles.titleBubble}>
            <View style={styles.titleContainer}>
              <Text style={styles.titleWish}>Wish</Text>
              <Text style={styles.titleA}> a </Text>
              <Text style={styles.titleWash}>Wash</Text>
              <Text style={styles.spongeAtEnd}>🧽</Text>
            </View>
          </View>
          <Text style={styles.sloganText}>Your Wish Our Wash 🚿</Text>
        </View>

        {/* User Type Selection */}
        <View style={styles.userTypeContainer}>
          <TouchableOpacity
            style={[styles.userTypeButton, userType === 'valeter' && styles.userTypeButtonActive]}
            onPress={() => handleUserTypeChange('valeter')}
          >
            <Text style={styles.userTypeIcon}>🧽</Text>
            <Text style={[styles.userTypeText, userType === 'valeter' && styles.userTypeTextActive]}>
              Valeter
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.userTypeButton, userType === 'owner' && styles.userTypeButtonActive]}
            onPress={() => handleUserTypeChange('owner')}
          >
            <Text style={styles.userTypeIcon}>👤</Text>
            <Text style={[styles.userTypeText, userType === 'owner' && styles.userTypeTextActive]}>
              Customer
            </Text>
          </TouchableOpacity>
        </View>

        {/* Login Form */}
        <View style={styles.formContainer}>
          <View style={styles.inputContainer}>
            <Text style={styles.inputLabel}>Email</Text>
            <TextInput
              style={styles.input}
              placeholder="Enter your email"
              placeholderTextColor="rgba(255, 255, 255, 0.7)"
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
              autoCapitalize="none"
              autoCorrect={false}
              onSubmitEditing={handleLogin}
            />
          </View>

          <View style={styles.inputContainer}>
            <Text style={styles.inputLabel}>Password</Text>
            <TextInput
              style={styles.input}
              placeholder="Enter your password"
              placeholderTextColor="rgba(255, 255, 255, 0.7)"
              value={password}
              onChangeText={setPassword}
              secureTextEntry
              onSubmitEditing={handleLogin}
            />
          </View>

          <TouchableOpacity
            style={[styles.loginButton, isLoading && styles.loginButtonDisabled]}
            onPress={handleLogin}
            disabled={isLoading}
          >
            <Text style={styles.loginButtonText}>
              {isLoading ? 'Signing In...' : 'Sign In'}
            </Text>
          </TouchableOpacity>

          {/* OR divider */}
          {isAppleAvailable && (
            <View style={styles.dividerRow}>
              <View style={styles.dividerLine} />
              <Text style={styles.dividerText}>OR</Text>
              <View style={styles.dividerLine} />
            </View>
          )}

          {/* Apple Sign In */}
          {isAppleAvailable && (
            <View style={styles.socialBlock}>
              <AppleAuthentication.AppleAuthenticationButton
                buttonType={AppleAuthentication.AppleAuthenticationButtonType.SIGN_IN}
                buttonStyle={AppleAuthentication.AppleAuthenticationButtonStyle.WHITE}
                cornerRadius={8}
                style={styles.appleButton}
                onPress={handleAppleLogin}
              />
            </View>
          )}

          <TouchableOpacity style={styles.forgotPasswordButton} onPress={handleForgotPassword}>
            <Text style={styles.forgotPasswordText}>Forgot Password?</Text>
          </TouchableOpacity>
        </View>

        {/* Sign Up Section */}
        <View style={styles.signUpContainer}>
          <Text style={styles.signUpText}>Don't have an account?</Text>
          <TouchableOpacity onPress={handleSignUp}>
            <Text style={styles.signUpLink}>Sign Up</Text>
          </TouchableOpacity>
        </View>

        {/* Organization login removed */}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  // Root fills screen; gradient is absolute behind everything
  root: {
    flex: 1,
    backgroundColor: 'black', // fallback under gradient
  },

  // Animated background
  seaBackground: {
    ...StyleSheet.absoluteFillObject,
    overflow: 'hidden',
  },
  wave: {
    position: 'absolute',
    height: 20,
    borderRadius: 10,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
  },
  wave1: { top: '20%', left: 0, right: 0 },
  wave2: { top: '40%', left: 0, right: 0 },
  wave3: { top: '60%', left: 0, right: 0 },
  seaBubble: {
    position: 'absolute',
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 50,
  },
  bubble1: { width: 60, height: 60, left: '20%' },
  bubble2: { width: 40, height: 40, right: '30%' },
  ripple: {
    position: 'absolute',
    bottom: '30%',
    left: '50%',
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    marginLeft: -10,
  },

  // Foreground content
  scrollContent: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: 24,
    paddingTop: StatusBar.currentHeight ? StatusBar.currentHeight + 12 : 36, // avoid notch/top cut
    paddingBottom: 36, // avoid bottom cut
  },

  logoContainer: { alignItems: 'center', marginBottom: 40 },
  logoRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 20 },
  bubbleContainer: { marginRight: 15 },
  soapBubble: {
    width: 70,
    height: 70,
    borderRadius: 35,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.6)',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 6,
  },
  spongeInBubble: { fontSize: 32 },
  bubbleShine: { position: 'absolute', top: 8, right: 8 },
  shineText: { fontSize: 14 },
  wawContainer: { alignItems: 'flex-start' },
  wawText: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 4,
    textShadowColor: 'rgba(0, 0, 0, 0.3)',
    textShadowOffset: { width: 2, height: 2 },
    textShadowRadius: 4,
  },
  titleBubble: {
    backgroundColor: 'rgba(128, 128, 128, 0.3)',
    borderRadius: 20,
    paddingHorizontal: 20,
    paddingVertical: 12,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 4,
  },
  titleContainer: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
  titleWish: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#0A1929',
    textShadowColor: 'rgba(255, 255, 255, 1)',
    textShadowOffset: { width: 3, height: 3 },
    textShadowRadius: 6,
  },
  titleA: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#FFFFFF',
    textShadowColor: 'rgba(0, 0, 0, 1)',
    textShadowOffset: { width: 3, height: 3 },
    textShadowRadius: 6,
  },
  titleWash: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#0EA5E9',
    textShadowColor: 'rgba(0, 0, 0, 1)',
    textShadowOffset: { width: 3, height: 3 },
    textShadowRadius: 6,
  },
  spongeAtEnd: {
    fontSize: 32,
    marginLeft: 8,
    textShadowColor: 'rgba(0, 0, 0, 1)',
    textShadowOffset: { width: 3, height: 3 },
    textShadowRadius: 6,
  },

  sloganText: {
    fontSize: 14,
    color: '#FFFFFF',
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 8,
    textShadowColor: 'rgba(0, 0, 0, 0.3)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  subtitle: {
    fontSize: 18,
    color: '#FFFFFF',
    textAlign: 'center',
    fontWeight: '600',
    textShadowColor: 'rgba(0, 0, 0, 0.3)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },

  userTypeContainer: {
    flexDirection: 'row',
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 12,
    padding: 4,
    marginBottom: 32,
  },
  userTypeButton: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  userTypeButtonActive: {
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    borderColor: '#FFFFFF',
    borderWidth: 1,
  },
  userTypeIcon: { fontSize: 18, marginBottom: 4 },
  userTypeText: { fontSize: 14, fontWeight: '600', color: '#FFFFFF' },
  userTypeTextActive: {
    fontWeight: 'bold',
    textShadowColor: 'rgba(0, 0, 0, 0.3)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },

  formContainer: { marginBottom: 32 },
  inputContainer: { marginBottom: 20 },
  inputLabel: { fontSize: 16, fontWeight: '600', color: '#FFFFFF', marginBottom: 8 },
  input: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 12,
    paddingHorizontal: 20,
    paddingVertical: 15,
    fontSize: 16,
    color: '#FFFFFF',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.3)',
  },
  loginButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    borderRadius: 12,
    paddingVertical: 18,
    alignItems: 'center',
    marginBottom: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.5)',
  },
  loginButtonDisabled: { opacity: 0.6 },
  loginButtonText: { color: '#FFFFFF', fontSize: 18, fontWeight: 'bold' },

  // "OR" divider
  dividerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    marginTop: 4,
    gap: 12,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: 'rgba(255,255,255,0.4)',
  },
  dividerText: {
    color: '#FFFFFF',
    fontWeight: '700',
    letterSpacing: 1,
  },

  socialBlock: { width: '100%', marginBottom: 16 },
  appleButton: { width: '100%', height: 44 },

  forgotPasswordButton: { alignItems: 'center', paddingVertical: 10 },
  forgotPasswordText: { color: '#FFFFFF', fontSize: 14, textDecorationLine: 'underline' },

  signUpContainer: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginBottom: 24 },
  signUpText: { color: '#FFFFFF', fontSize: 16, marginRight: 5 },
  signUpLink: { color: '#FFFFFF', fontSize: 16, fontWeight: 'bold', textDecorationLine: 'underline' },
});