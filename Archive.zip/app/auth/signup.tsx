import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  Animated,
  KeyboardAvoidingView,
  Platform,
  Alert,
  ScrollView,
  SafeAreaView,
  StatusBar,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import * as AppleAuthentication from 'expo-apple-authentication';

const { height } = Dimensions.get('window');

export default function SignupScreen() {
  const { register, /* @ts-ignore */ registerWithApple } = useAuth();
  const [userType, setUserType] = useState<'customer' | 'valeter'>('customer');
  const [formData, setFormData] = useState({ name: '', email: '', password: '' });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isAppleAvailable, setIsAppleAvailable] = useState(false);

  // Animations
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  // Sea animation values
  const wave1Anim = useRef(new Animated.Value(0)).current;
  const wave2Anim = useRef(new Animated.Value(0)).current;
  const wave3Anim = useRef(new Animated.Value(0)).current;
  const bubbleAnim = useRef(new Animated.Value(0)).current;
  const rippleAnim = useRef(new Animated.Value(0)).current;

  const seaColors = {
    valeter: ['#0C4A6E', '#0B3A5A', '#0A2A46', '#081B32'],
    customer: ['#0A1929', '#1E3A8A', '#1E40AF', '#1E293B'],
  };

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 800, useNativeDriver: true }),
      Animated.timing(slideAnim, { toValue: 0, duration: 600, useNativeDriver: true }),
    ]).start();
  }, []);

  // Apple availability
  useEffect(() => {
    (async () => {
      try {
        const available = Platform.OS === 'ios' && (await AppleAuthentication.isAvailableAsync());
        setIsAppleAvailable(Boolean(available));
      } catch {
        setIsAppleAvailable(false);
      }
    })();
  }, []);

  // Start sea animations
  useEffect(() => {
    const loop = (anim: Animated.Value, duration: number) =>
      Animated.loop(Animated.timing(anim, { toValue: 1, duration, useNativeDriver: true })).start();

    loop(wave1Anim, 8000);
    loop(wave2Anim, 10000);
    loop(wave3Anim, 12000);
    loop(bubbleAnim, 6000);
    loop(rippleAnim, 4000);
  }, []);

  const updateFormData = (field: keyof typeof formData, value: string) =>
    setFormData(prev => ({ ...prev, [field]: value }));

  const validateForm = () => {
    if (!formData.name || !formData.email || !formData.password) {
      Alert.alert('Error', 'Please fill in all required fields');
      return false;
    }
    if (!formData.email.includes('@')) {
      Alert.alert('Error', 'Please enter a valid email address');
      return false;
    }
    if (formData.password.length < 6) {
      Alert.alert('Error', 'Password must be at least 6 characters');
      return false;
    }
    return true;
  };

  const handleSignup = async () => {
    if (!validateForm()) return;

    setIsLoading(true);
    setError(null);
    try {
      const success = await register({
        email: formData.email,
        name: formData.name,
        userType,
        password: formData.password,
      });

      if (success) {
        Alert.alert('Success!', 'Account created! Please verify your email.', [
          { text: 'OK', onPress: () => router.replace('/login') },
        ]);
      } else {
        setError('Failed to create account. Please try again.');
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to create account. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAppleSignup = async () => {
    try {
      hapticFeedback('light');
      const cred = await AppleAuthentication.signInAsync({
        requestedScopes: [
          AppleAuthentication.AppleAuthenticationScope.FULL_NAME,
          AppleAuthentication.AppleAuthenticationScope.EMAIL,
        ],
      });

      if (typeof registerWithApple === 'function') {
        const ok = await registerWithApple(cred, { userType });
        if (!ok) {
          Alert.alert('Apple Sign Up Failed', 'Could not create your account with Apple.');
          return;
        }
      } else {
        // If you haven’t implemented registerWithApple yet:
        Alert.alert(
          'Apple Sign Up',
          'Apple credential received. Wire this to your backend via registerWithApple to finish sign up.'
        );
        return;
      }

      // success -> go to app or login
      router.replace('/login');
    } catch (error: any) {
      if (error?.code === 'ERR_CANCELED') return;
      Alert.alert('Apple Sign Up Failed', error?.message || 'Please try again.');
    }
  };

  const currentColors = userType === 'valeter' ? seaColors.valeter : seaColors.customer;

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="light-content" />
      <KeyboardAvoidingView style={styles.keyboardAvoidingView} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
        <LinearGradient colors={currentColors} style={styles.container}>
          {/* Sea Background Animations */}
          <View style={styles.seaBackground}>
            {/* Waves */}
            <Animated.View
              style={[
                styles.wave,
                styles.wave1,
                {
                  transform: [
                    {
                      translateX: wave1Anim.interpolate({ inputRange: [0, 1], outputRange: [-100, 100] }),
                    },
                  ],
                  opacity: wave1Anim.interpolate({ inputRange: [0, 0.5, 1], outputRange: [0.3, 0.6, 0.3] }),
                },
              ]}
            />
            <Animated.View
              style={[
                styles.wave,
                styles.wave2,
                {
                  transform: [
                    {
                      translateX: wave2Anim.interpolate({ inputRange: [0, 1], outputRange: [100, -100] }),
                    },
                  ],
                  opacity: wave2Anim.interpolate({ inputRange: [0, 0.5, 1], outputRange: [0.2, 0.5, 0.2] }),
                },
              ]}
            />
            <Animated.View
              style={[
                styles.wave,
                styles.wave3,
                {
                  transform: [
                    {
                      translateX: wave3Anim.interpolate({ inputRange: [0, 1], outputRange: [-50, 150] }),
                    },
                  ],
                  opacity: wave3Anim.interpolate({ inputRange: [0, 0.5, 1], outputRange: [0.1, 0.4, 0.1] }),
                },
              ]}
            />
            {/* Bubbles */}
            <Animated.View
              style={[
                styles.seaBubble,
                styles.bubble1,
                {
                  transform: [{ translateY: bubbleAnim.interpolate({ inputRange: [0, 1], outputRange: [height, -100] }) }],
                  opacity: bubbleAnim.interpolate({ inputRange: [0, 0.1, 0.9, 1], outputRange: [0, 0.6, 0.6, 0] }),
                },
              ]}
            />
            <Animated.View
              style={[
                styles.seaBubble,
                styles.bubble2,
                {
                  transform: [{ translateY: bubbleAnim.interpolate({ inputRange: [0, 1], outputRange: [height, -100] }) }],
                  opacity: bubbleAnim.interpolate({ inputRange: [0, 0.1, 0.9, 1], outputRange: [0, 0.4, 0.4, 0] }),
                },
              ]}
            />
            {/* Ripple */}
            <Animated.View
              style={[
                styles.ripple,
                {
                  transform: [{ scale: rippleAnim.interpolate({ inputRange: [0, 1], outputRange: [0, 2] }) }],
                  opacity: rippleAnim.interpolate({ inputRange: [0, 0.5, 1], outputRange: [0.8, 0.4, 0] }),
                },
              ]}
            />
          </View>

          <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
            {/* Logo */}
            <View style={styles.logoContainer}>
              <View style={styles.titleBubble}>
                <View style={styles.titleContainer}>
                  <Text style={styles.titleWish}>Wish</Text>
                  <Text style={styles.titleA}> a </Text>
                  <Text style={styles.titleWash}>Wash</Text>
                  <Text style={styles.spongeAtEnd}>🧽</Text>
                </View>
              </View>
              <Text style={styles.sloganText}>Your Wish Our Wash 🚿</Text>
            </View>

            {/* User type (no business) */}
            <View style={styles.userTypeContainer}>
              <TouchableOpacity
                style={[styles.userTypeButton, userType === 'customer' && styles.userTypeButtonActive]}
                onPress={() => {
                  setUserType('customer');
                  hapticFeedback('light');
                }}
              >
                <Text style={styles.userTypeIcon}>🚗</Text>
                <Text style={[styles.userTypeText, userType === 'customer' && styles.userTypeTextActive]}>Customer</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.userTypeButton, userType === 'valeter' && styles.userTypeButtonActive]}
                onPress={() => {
                  setUserType('valeter');
                  hapticFeedback('light');
                }}
              >
                <Text style={styles.userTypeIcon}>🧽</Text>
                <Text style={[styles.userTypeText, userType === 'valeter' && styles.userTypeTextActive]}>Valeter</Text>
              </TouchableOpacity>
            </View>

            {/* Form */}
            <Animated.View style={[styles.formContainer, { opacity: fadeAnim, transform: [{ translateY: slideAnim }] }]}>
              <View style={styles.inputContainer}>
                <Text style={styles.inputLabel}>Full Name</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Enter your full name"
                  placeholderTextColor="#87CEEB"
                  value={formData.name}
                  onChangeText={(v) => updateFormData('name', v)}
                  autoCapitalize="words"
                />
              </View>

              <View style={styles.inputContainer}>
                <Text style={styles.inputLabel}>Email Address</Text>
                <TextInput
                  style={styles.input}
                  placeholder="your@email.com"
                  placeholderTextColor="#87CEEB"
                  value={formData.email}
                  onChangeText={(v) => updateFormData('email', v)}
                  keyboardType="email-address"
                  autoCapitalize="none"
                />
              </View>

              <View style={styles.inputContainer}>
                <Text style={styles.inputLabel}>Password</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Create a password (min 6 characters)"
                  placeholderTextColor="#87CEEB"
                  value={formData.password}
                  onChangeText={(v) => updateFormData('password', v)}
                  secureTextEntry
                />
              </View>

              {/* Error */}
              {error && (
                <View style={styles.errorContainer}>
                  <Text style={styles.errorText}>⚠️ {error}</Text>
                </View>
              )}

              {/* Create Account button (moved up) */}
              <TouchableOpacity
                style={[styles.primaryButton, isLoading && styles.primaryButtonDisabled]}
                onPress={handleSignup}
                disabled={isLoading}
              >
                <Text style={styles.primaryButtonText}>{isLoading ? 'Creating Account...' : 'Create Account'}</Text>
              </TouchableOpacity>

              {/* OR divider */}
              {isAppleAvailable && (
                <View style={styles.dividerRow}>
                  <View style={styles.dividerLine} />
                  <Text style={styles.dividerText}>OR</Text>
                  <View style={styles.dividerLine} />
                </View>
              )}

              {/* Sign up with Apple */}
              {isAppleAvailable && (
                <AppleAuthentication.AppleAuthenticationButton
                  buttonType={AppleAuthentication.AppleAuthenticationButtonType.SIGN_UP}
                  buttonStyle={AppleAuthentication.AppleAuthenticationButtonStyle.WHITE}
                  cornerRadius={8}
                  style={styles.appleButton}
                  onPress={handleAppleSignup}
                />
              )}

              {/* Terms */}
              <View style={styles.termsContainer}>
                <Text style={styles.termsText}>
                  By creating an account, you agree to our <Text style={styles.termsLink}>Terms of Service</Text> and{' '}
                  <Text style={styles.termsLink}>Privacy Policy</Text>
                </Text>
              </View>

              {/* Login link */}
              <View style={styles.loginContainer}>
                <Text style={styles.loginText}>Already have an account? </Text>
                <TouchableOpacity onPress={() => router.replace('/login')}>
                  <Text style={styles.loginLink}>Sign In</Text>
                </TouchableOpacity>
              </View>
            </Animated.View>
          </ScrollView>
        </LinearGradient>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: '#0A1929' },
  keyboardAvoidingView: { flex: 1 },
  container: { flex: 1 },

  seaBackground: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, overflow: 'hidden' },
  wave: { position: 'absolute', width: 200, height: 200, borderRadius: 100, backgroundColor: 'rgba(255, 255, 255, 0.1)' },
  wave1: { top: '20%', left: '10%' },
  wave2: { top: '60%', right: '15%' },
  wave3: { bottom: '30%', left: '20%' },
  seaBubble: { position: 'absolute', width: 20, height: 20, borderRadius: 10, backgroundColor: 'rgba(255, 255, 255, 0.3)' },
  bubble1: { left: '20%' },
  bubble2: { right: '25%' },
  ripple: {
    position: 'absolute',
    width: 100, height: 100, borderRadius: 50, borderWidth: 2, borderColor: 'rgba(255, 255, 255, 0.2)',
    top: '50%', left: '50%', marginLeft: -50, marginTop: -50,
  },

  scrollContent: { flexGrow: 1, paddingHorizontal: 20, paddingTop: 40, paddingBottom: 40 },

  userTypeContainer: {
    flexDirection: 'row',
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 12,
    padding: 4,
    marginBottom: 24,
  },
  userTypeButton: { flex: 1, alignItems: 'center', paddingVertical: 16, paddingHorizontal: 20, borderRadius: 10 },
  userTypeButtonActive: { backgroundColor: 'rgba(255, 255, 255, 0.9)' },
  userTypeIcon: { fontSize: 28, marginBottom: 6 },
  userTypeText: { fontSize: 12, fontWeight: '600', color: '#FFFFFF', textAlign: 'center' },
  userTypeTextActive: { color: '#0A1929' },

  formContainer: { marginBottom: 20 },
  inputContainer: { marginBottom: 16 },
  inputLabel: { fontSize: 16, fontWeight: '600', color: '#FFFFFF', marginBottom: 8 },
  input: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 15,
    fontSize: 14,
    color: '#FFFFFF',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },

  // OR divider + Apple
  dividerRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 16, marginTop: 4, gap: 12 },
  dividerLine: { flex: 1, height: 1, backgroundColor: 'rgba(255,255,255,0.4)' },
  dividerText: { color: '#FFFFFF', fontWeight: '700', letterSpacing: 1 },
  appleButton: { width: '100%', height: 44, marginBottom: 12 },

  // Terms
  termsContainer: { marginTop: 16, padding: 15, backgroundColor: 'rgba(135, 206, 235, 0.1)', borderRadius: 12 },
  termsText: { color: '#B0E0E6', fontSize: 14, lineHeight: 20, textAlign: 'center' },
  termsLink: { color: '#87CEEB', textDecorationLine: 'underline' },

  // Buttons
  primaryButton: {
    backgroundColor: '#87CEEB',
    borderRadius: 16,
    paddingVertical: 18,
    paddingHorizontal: 30,
    alignItems: 'center',
    marginTop: 8,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  primaryButtonDisabled: { opacity: 0.7 },
  primaryButtonText: { fontSize: 18, fontWeight: 'bold', color: '#0A1929' },

  // Login link
  loginContainer: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginTop: 24 },
  loginText: { color: '#B0E0E6', fontSize: 16 },
  loginLink: { color: '#87CEEB', fontSize: 16, fontWeight: 'bold', textDecorationLine: 'underline' },

  // Logo + heading bits (kept as-is)
  logoContainer: { alignItems: 'center', marginBottom: 20 },
  logoRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 20 },
  bubbleContainer: { marginRight: 15 },
  soapBubble: {
    width: 70, height: 70, borderRadius: 35, backgroundColor: 'rgba(255, 255, 255, 0.3)',
    borderWidth: 2, borderColor: 'rgba(255, 255, 255, 0.6)', alignItems: 'center', justifyContent: 'center',
    position: 'relative', shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.2, shadowRadius: 6, elevation: 6,
  },
  spongeInBubble: { fontSize: 32 },
  bubbleShine: { position: 'absolute', top: 8, right: 8 },
  shineText: { fontSize: 14 },
  wawContainer: { alignItems: 'flex-start' },
  wawText: { fontSize: 28, fontWeight: 'bold', color: '#FFFFFF', marginBottom: 4, textShadowColor: 'rgba(0, 0, 0, 0.3)', textShadowOffset: { width: 2, height: 2 }, textShadowRadius: 4 },
  titleBubble: {
    backgroundColor: 'rgba(128, 128, 128, 0.3)', borderRadius: 20, paddingHorizontal: 20, paddingVertical: 12,
    marginBottom: 8, borderWidth: 1, borderColor: 'rgba(255, 255, 255, 0.2)', shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.2, shadowRadius: 4, elevation: 4,
  },
  titleContainer: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
  titleWish: { fontSize: 32, fontWeight: 'bold', color: '#0A1929', textShadowColor: 'rgba(255, 255, 255, 1)', textShadowOffset: { width: 3, height: 3 }, textShadowRadius: 6 },
  titleA: { fontSize: 32, fontWeight: 'bold', color: '#FFFFFF', textShadowColor: 'rgba(0, 0, 0, 1)', textShadowOffset: { width: 3, height: 3 }, textShadowRadius: 6 },
  titleWash: { fontSize: 32, fontWeight: 'bold', color: '#0EA5E9', textShadowColor: 'rgba(0, 0, 0, 1)', textShadowOffset: { width: 3, height: 3 }, textShadowRadius: 6 },
  spongeAtEnd: { fontSize: 32, marginLeft: 8, textShadowColor: 'rgba(0, 0, 0, 1)', textShadowOffset: { width: 3, height: 3 }, textShadowRadius: 6 },

  sloganText: {
    fontSize: 14, color: '#FFFFFF', fontWeight: '600', textAlign: 'center', marginBottom: 8,
    textShadowColor: 'rgba(0, 0, 0, 0.3)', textShadowOffset: { width: 1, height: 1 }, textShadowRadius: 2,
  },
  subtitle: { fontSize: 18, color: '#B0E0E6', fontWeight: '500' },

  errorContainer: {
    backgroundColor: 'rgba(255, 59, 48, 0.1)', borderWidth: 1, borderColor: '#FF3B30', borderRadius: 8, padding: 12, marginBottom: 12,
  },
  errorText: { color: '#FF3B30', fontSize: 14, textAlign: 'center', fontWeight: '500' },
});