import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Animated,
  Dimensions,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import BookingService from '../../src/services/BookingService';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;

type BookingStatus =
  | 'pending'
  | 'scheduled'
  | 'confirmed'
  | 'valeter_assigned'
  | 'en_route'
  | 'arrived'
  | 'in_progress'
  | 'completed'
  | 'cancelled';

export default function ValeterSearch() {
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const bookingId = params.bookingId as string;

  const [booking, setBooking] = useState<any | null>(null);
  const [status, setStatus] = useState<BookingStatus>('pending');
  const [info, setInfo] = useState<{ address?: string; price?: number; service?: string }>(
    {}
  );

  // animations
  const pulseAnim = useRef(new Animated.Value(0)).current;
  const searchAnim = useRef(new Animated.Value(0)).current;
  const dotAnim = useRef(new Animated.Value(0)).current;

  // ---------- helpers ----------
  const loadOnce = async () => {
    try {
      let row: any | null = null;
      if ((BookingService as any).getBookingById) {
        row = await (BookingService as any).getBookingById(bookingId);
      } else if (user) {
        row = await BookingService.getBooking(bookingId, user.id);
      }
      if (row) {
        setBooking(row);
        // map DB columns if needed
        const s: BookingStatus =
          row.status ||
          row.booking_status ||
          'pending';
        setStatus(s);
        setInfo({
          address:
            row.location_address ||
            row.location?.address ||
            undefined,
          price: Number(row.price ?? row.total ?? row.amount ?? 0),
          service: row.service_name || row.serviceName || row.service_type,
        });
      }
    } catch (e: any) {
      console.warn('[ValeterSearch] initial load error:', e?.message || e);
    }
  };

  const shouldJumpToTracking = (s: BookingStatus) =>
    s === 'valeter_assigned' || s === 'en_route' || s === 'arrived' || s === 'in_progress';

  const goTrack = () =>
    router.replace({
      pathname: '/uber-tracking',
      params: { bookingId },
    });

  // ---------- subscribe to booking changes ----------
  useEffect(() => {
    if (!bookingId) {
      Alert.alert('Booking', 'No booking ID provided.');
      router.back();
      return;
    }
    loadOnce();

    // live subscription (preferred)
    let unsubscribe: (() => void) | undefined;
    if ((BookingService as any).subscribeToBooking) {
      unsubscribe = (BookingService as any).subscribeToBooking(
        bookingId,
        (row: any) => {
          if (!row) return;
          setBooking(row);
          const s: BookingStatus = row.status || 'pending';
          setStatus(s);
          setInfo((prev) => ({
            address:
              row.location_address ??
              row.location?.address ??
              prev.address,
            price: Number(row.price ?? prev.price ?? 0),
            service: row.service_name || row.serviceName || row.service_type || prev.service,
          }));
        }
      );
    }

    // fallback: poll if no realtime available
    let pollTimer: NodeJS.Timer | undefined;
    if (!unsubscribe) {
      pollTimer = setInterval(loadOnce, 2000);
    }

    return () => {
      if (unsubscribe) unsubscribe();
      if (pollTimer) clearInterval(pollTimer);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bookingId, user?.id]);

  // ---------- react to important status changes ----------
  useEffect(() => {
    if (!status) return;
    if (shouldJumpToTracking(status)) {
      // brief visual confirmation, then move
      setTimeout(goTrack, 450);
    }
  }, [status]);

  // ---------- animations ----------
  useEffect(() => {
    const pulseLoop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1, duration: 1500, useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 0, duration: 1500, useNativeDriver: true }),
      ])
    );

    const searchLoop = Animated.loop(
      Animated.sequence([
        Animated.timing(searchAnim, { toValue: 1, duration: 2000, useNativeDriver: true }),
        Animated.timing(searchAnim, { toValue: 0, duration: 2000, useNativeDriver: true }),
      ])
    );

    const dotLoop = Animated.loop(
      Animated.sequence([
        Animated.timing(dotAnim, { toValue: 1, duration: 1000, useNativeDriver: true }),
        Animated.timing(dotAnim, { toValue: 0, duration: 1000, useNativeDriver: true }),
      ])
    );

    pulseLoop.start();
    searchLoop.start();
    dotLoop.start();

    return () => {
      pulseLoop.stop();
      searchLoop.stop();
      dotLoop.stop();
    };
  }, []);

  // ---------- UI helpers ----------
  const statusLines = (() => {
    switch (status) {
      case 'pending':
      case 'scheduled':
      case 'confirmed':
        return ['📍 Scanning your area', '🚗 Checking vehicle compatibility', '⭐ Finding top-rated valeters'];
      case 'valeter_assigned':
        return ['✅ Valeter found', '📲 Setting up live tracking', '🚗 Preparing to head your way'];
      case 'en_route':
        return ['🚗 Valeter is en route', '📍 Live location available', '🕒 See ETA on the next screen'];
      case 'arrived':
        return ['📍 Valeter has arrived', '🔔 We’ve notified them you’re ready', '🧽 Service starting shortly'];
      case 'in_progress':
        return ['🧼 Service in progress', '✨ Sit tight — we’ll keep you updated'];
      case 'completed':
        return ['✅ Service completed', '🧾 Receipt available in your bookings'];
      case 'cancelled':
        return ['⚠️ Booking cancelled'];
      default:
        return ['🔄 Updating booking status…'];
    }
  })();

  const headline = (() => {
    switch (status) {
      case 'valeter_assigned':
        return 'Valeter Found';
      case 'en_route':
        return 'Valeter On The Way';
      case 'arrived':
        return 'Your Valeter Is Here';
      case 'in_progress':
        return 'Getting Your Car Sparkling';
      case 'completed':
        return 'All Done!';
      case 'cancelled':
        return 'Booking Cancelled';
      default:
        return 'Finding Your Valeter';
    }
  })();

  const sub =
    status === 'pending' || status === 'scheduled' || status === 'confirmed'
      ? 'Searching for available valeters in your area…'
      : status === 'valeter_assigned'
      ? 'We’re setting up live tracking for you.'
      : status === 'en_route'
      ? 'Tap continue if you’re not redirected automatically.'
      : status === 'arrived'
      ? 'Head outside when you’re ready.'
      : status === 'in_progress'
      ? 'Relax — we’ll ping you when it’s complete.'
      : status === 'completed'
      ? 'Thanks for booking with us.'
      : 'If this was a mistake, you can make a new booking.';

  // ---------- render ----------
  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <LinearGradient colors={['#0A1929', '#1E3A8A']} style={styles.gradient}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>{headline}</Text>
          <Text style={styles.headerSubtitle}>{sub}</Text>

          {/* small context row */}
          <View style={styles.metaRow}>
            {info.service ? <Text style={styles.metaChip}>🧴 {info.service}</Text> : null}
            {Number.isFinite(info.price) ? (
              <Text style={styles.metaChip}>💷 £{Number(info.price).toFixed(0)}</Text>
            ) : null}
            {info.address ? <Text numberOfLines={1} style={[styles.metaChip, styles.metaAddress]}>📍 {info.address}</Text> : null}
          </View>
        </View>

        {/* Main Content */}
        <View style={styles.content}>
          {/* Pulse Circle */}
          <Animated.View
            style={[
              styles.pulseCircle,
              {
                transform: [
                  {
                    scale: pulseAnim.interpolate({
                      inputRange: [0, 1],
                      outputRange: [1, 1.2],
                    }),
                  },
                ],
                opacity: pulseAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [0.7, 1],
                }),
              },
            ]}
          >
            <View style={styles.innerCircle}>
              <Text style={styles.searchIcon}>{shouldJumpToTracking(status) ? '✅' : '🔍'}</Text>
            </View>
          </Animated.View>

          {/* Message */}
          <View style={styles.messageContainer}>
            <Text style={styles.mainMessage}>
              {status === 'pending' || status === 'scheduled' || status === 'confirmed'
                ? 'Finding you a valeter'
                : headline}
            </Text>
            {(status === 'pending' || status === 'scheduled' || status === 'confirmed') && (
              <Animated.View style={styles.dotsContainer}>
                <Animated.Text
                  style={[
                    styles.dots,
                    {
                      opacity: dotAnim.interpolate({
                        inputRange: [0, 1],
                        outputRange: [0.3, 1],
                      }),
                    },
                  ]}
                >
                  ...
                </Animated.Text>
              </Animated.View>
            )}
          </View>

          {/* Status lines */}
          <View style={styles.statusContainer}>
            {statusLines.map((t, i) => (
              <Text key={i} style={styles.statusText}>{t}</Text>
            ))}
          </View>

          {/* Progress Indicator (kept) */}
          <View style={styles.progressContainer}>
            <View style={styles.progressBar}>
              <Animated.View
                style={[
                  styles.progressFill,
                  {
                    transform: [
                      {
                        scaleX: searchAnim.interpolate({
                          inputRange: [0, 1],
                          outputRange: [0, 1],
                        }),
                      },
                    ],
                  },
                ]}
              />
            </View>
            <Text style={styles.progressText}>
              {status === 'pending' || status === 'scheduled' || status === 'confirmed'
                ? 'Searching...'
                : shouldJumpToTracking(status)
                ? 'Redirecting to tracking…'
                : status === 'completed'
                ? 'Completed'
                : status === 'cancelled'
                ? 'Cancelled'
                : 'Updating…'}
            </Text>
          </View>

          {/* Safety net button in case redirect doesn’t happen */}
          {shouldJumpToTracking(status) && (
            <TouchableOpacity style={styles.ctaBtn} onPress={goTrack} activeOpacity={0.9}>
              <LinearGradient colors={['#10B981', '#059669']} style={styles.ctaGrad}>
                <Text style={styles.ctaText}>Open Live Tracking</Text>
              </LinearGradient>
            </TouchableOpacity>
          )}
        </View>
      </LinearGradient>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A1929' },
  gradient: { flex: 1 },

  header: { alignItems: 'center', paddingVertical: 20, paddingHorizontal: 16 },
  headerTitle: { color: '#F9FAFB', fontSize: isSmallScreen ? 20 : 24, fontWeight: 'bold' },
  headerSubtitle: { color: '#E5E7EB', fontSize: isSmallScreen ? 14 : 16, marginTop: 6, textAlign: 'center' },

  metaRow: { flexDirection: 'row', flexWrap: 'nowrap', gap: 8, marginTop: 12, maxWidth: '92%' },
  metaChip: {
    color: '#0A1929',
    backgroundColor: '#93C5FD',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    fontSize: 12,
    overflow: 'hidden',
  },
  metaAddress: { backgroundColor: '#87CEEB', maxWidth: '60%' },

  content: { flex: 1, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 32 },

  pulseCircle: {
    width: 120, height: 120, borderRadius: 60, backgroundColor: 'rgba(16,185,129,0.2)',
    justifyContent: 'center', alignItems: 'center', marginBottom: 36,
  },
  innerCircle: {
    width: 80, height: 80, borderRadius: 40, backgroundColor: '#10B981',
    justifyContent: 'center', alignItems: 'center',
  },
  searchIcon: { fontSize: 32 },

  messageContainer: { alignItems: 'center', marginBottom: 28 },
  mainMessage: { color: '#F9FAFB', fontSize: isSmallScreen ? 24 : 28, fontWeight: 'bold', textAlign: 'center' },
  dotsContainer: { height: 28, justifyContent: 'center' },
  dots: { color: '#10B981', fontSize: 24, fontWeight: 'bold' },

  statusContainer: { alignItems: 'center', marginBottom: 36, gap: 6 },
  statusText: { color: '#E5E7EB', fontSize: isSmallScreen ? 14 : 16, textAlign: 'center' },

  progressContainer: { alignItems: 'center', width: '100%' },
  progressBar: {
    width: '100%', height: 4, backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 2, marginBottom: 10, overflow: 'hidden',
  },
  progressFill: { width: '100%', height: '100%', backgroundColor: '#10B981', borderRadius: 2, transformOrigin: 'left' },
  progressText: { color: '#87CEEB', fontSize: isSmallScreen ? 14 : 16 },

  ctaBtn: { marginTop: 18, width: '100%', borderRadius: 12, overflow: 'hidden' },
  ctaGrad: { paddingVertical: 14, alignItems: 'center' },
  ctaText: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
});