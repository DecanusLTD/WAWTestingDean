import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  Animated,
  ScrollView,
  Alert,
} from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import ExpoMap from './components/ExpoMap';
import { enhancedLiveTrackingService } from '../src/services/EnhancedLiveTrackingService';

const { width, height } = Dimensions.get('window');

interface ServiceStatus {
  status: 'assigned' | 'en_route' | 'arrived' | 'in_progress' | 'completed';
  valeterId: string;
  valeterName: string;
  valeterPhoto: string;
  vehicleInfo: string;
  estimatedArrival: string;
  currentLocation: {
    latitude: number;
    longitude: number;
    address: string;
  };
  destination: {
    latitude: number;
    longitude: number;
    address: string;
  };
  serviceType: string;
  price: number;
}

interface LiveLocation {
  latitude: number;
  longitude: number;
  address: string;
}

export default function TrackingScreen() {
  const params = useLocalSearchParams();
  
  // Helper function to get service name from ID
  const getServiceName = (serviceId: string) => {
    const serviceMap: { [key: string]: string } = {
      '1': 'Express Wash',
      '2': 'Standard Valet',
      '3': 'Premium Valet',
      '4': 'Deep Clean'
    };
    return serviceMap[serviceId] || 'Premium Car Wash';
  };

  // Use route params if available (from unified booking), otherwise use defaults
  const [serviceStatus, setServiceStatus] = useState<ServiceStatus>({
    id: '1',
    status: 'en_route',
    valeterId: '126546fghfdsvvfg',
    valeterName: 'John Driver',
    valeterPhoto: '👨‍💼',
    vehicleInfo: 'Toyota Camry • ABC-1234',
    estimatedArrival: params.eta ? params.eta as string : '5 min',
    currentLocation: {
      latitude: 51.5074 + (Math.random() - 0.5) * 0.01,
      longitude: -0.1278 + (Math.random() - 0.5) * 0.01,
      address: 'Downtown Mall'
    },
    destination: {
      latitude: 51.5074 + 0.002,
      longitude: -0.1278 + 0.002,
      address: 'Your Location'
    },
    serviceType: params.serviceId ? getServiceName(params.serviceId as string) : 'Premium Car Wash',
    price: params.price ? parseFloat(params.price as string) : 25.00,
  });

  // Live tracking state
  const [valeterLocation, setValeterLocation] = useState<LiveLocation>({
    latitude: 51.5074 + (Math.random() - 0.5) * 0.01,
    longitude: -0.1278 + (Math.random() - 0.5) * 0.01,
    address: 'On the way to your location'
  });

  const [userLocation] = useState<LiveLocation>({
    latitude: 51.5074 + 0.002,
    longitude: -0.1278 + 0.002,
    address: 'Your Location'
  });

  const [showMap, setShowMap] = useState(true);
  const [isTracking, setIsTracking] = useState(false);
  const [trackingProgress, setTrackingProgress] = useState(0);
  
  // Rating and tip state
  const [rating, setRating] = useState<number>(0);
  const [selectedTip, setSelectedTip] = useState<number>(0);
  
  // Animation values
  const fadeAnim = new Animated.Value(0);
  const slideAnim = new Animated.Value(30);
  const progressAnim = new Animated.Value(0);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 1000,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      }),
    ]).start();

    // Start live tracking
    startLiveTracking();

    // Simulate status updates with more realistic timing
    const statusUpdates = [
      { status: 'en_route', time: 3000, progress: 25 },
      { status: 'arrived', time: 8000, progress: 50 },
      { status: 'in_progress', time: 13000, progress: 75 },
      { status: 'completed', time: 18000, progress: 100 },
    ];

    statusUpdates.forEach((update, index) => {
      setTimeout(() => {
        setServiceStatus(prev => ({ ...prev, status: update.status as ServiceStatus['status'] }));
        setTrackingProgress(update.progress);
        
        // Animate progress bar
        Animated.timing(progressAnim, {
          toValue: update.progress,
          duration: 1000,
          useNativeDriver: false,
        }).start();

        if (update.status === 'completed') {
          setIsTracking(false);
          setTimeout(() => {
            Alert.alert(
              'Service Completed! 🎉',
              'Your car wash is complete. Please rate your experience.',
              [
                {
                  text: 'Rate Now',
                  onPress: () => router.push('/owner-dashboard')
                },
                {
                  text: 'Later',
                  style: 'cancel'
                }
              ]
            );
          }, 2000);
        }
      }, update.time);
    });

    return () => {
      enhancedLiveTrackingService.stopTracking();
    };
  }, []);

  const startLiveTracking = () => {
    setIsTracking(true);
    enhancedLiveTrackingService.startTracking(serviceStatus.id);
    
    // Simulate valeter movement
    const moveInterval = setInterval(() => {
      if (isTracking && serviceStatus.status !== 'completed') {
        setValeterLocation(prev => ({
          latitude: prev.latitude + (Math.random() - 0.5) * 0.0001,
          longitude: prev.longitude + (Math.random() - 0.5) * 0.0001,
          address: getCurrentAddress(serviceStatus.status)
        }));
      } else {
        clearInterval(moveInterval);
      }
    }, 2000);

    return () => clearInterval(moveInterval);
  };

  const getCurrentAddress = (status: string) => {
    switch (status) {
      case 'en_route':
        return 'On the way to your location';
      case 'arrived':
        return 'Arrived at your location';
      case 'in_progress':
        return 'At your location - Service in progress';
      case 'completed':
        return 'Service completed';
      default:
        return 'On the way to your location';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'assigned':
        return '#FFA500';
      case 'en_route':
        return '#87CEEB';
      case 'arrived':
        return '#32CD32';
      case 'in_progress':
        return '#FFD700';
      case 'completed':
        return '#4CAF50';
      default:
        return '#87CEEB';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'assigned':
        return 'Valeter Assigned';
      case 'en_route':
        return 'Valeter on the way';
      case 'arrived':
        return 'Valeter Arrived';
      case 'in_progress':
        return 'Service in Progress';
      case 'completed':
        return 'Service completed';
      default:
        return 'On the way to your location';
    }
  };

  const getStatusDescription = (status: string) => {
    switch (status) {
      case 'assigned':
        return 'Your valeter has been assigned and is preparing to come to you';
      case 'en_route':
        return 'Your valeter is on the way to your location';
      case 'arrived':
        return 'Your valeter has arrived and is ready to start';
      case 'in_progress':
        return 'Your valeter is currently washing your vehicle';
      case 'completed':
        return 'Your service has been completed successfully';
      default:
        return 'Your valeter is on the way to your location';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'assigned':
        return '👨‍💼';
      case 'en_route':
        return '🚗';
      case 'arrived':
        return '📍';
      case 'in_progress':
        return '🧽';
      case 'completed':
        return '✅';
      default:
        return '⏳';
    }
  };

  const handleCallValeter = () => {
    Alert.alert('Call Valeter', 'Calling John Driver...');
  };

  const handleMessageValeter = () => {
    Alert.alert(
      'Message Valeter',
      'Chat feature coming soon! For now, you can call the valeter.',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Call Valeter', onPress: handleCallValeter }
      ]
    );
  };

  const handleCancelService = () => {
    Alert.alert(
      'Cancel Service',
      'Are you sure you want to cancel this service?',
      [
        { text: 'No', style: 'cancel' },
        { 
          text: 'Yes, Cancel', 
          style: 'destructive',
          onPress: () => {
            router.back();
          }
        }
      ]
    );
  };

  const handleToggleMap = () => {
    setShowMap(!showMap);
  };

  const handleViewReceipt = () => {
    router.push('/owner-dashboard');
  };

  const handleAmendBooking = () => {
    Alert.alert(
      'Amend Booking',
      'What would you like to change?',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Change Service', onPress: () => router.push('/unified-booking') },
        { text: 'Change Time', onPress: () => router.push('/unified-booking') },
        { text: 'Add Priority', onPress: () => router.push('/unified-booking') },
      ]
    );
  };

  const handleBookAnother = () => {
    router.push('/unified-booking');
  };

  // Rating and tip handlers
  const handleStarRating = (star: number) => {
    setRating(star);
  };

  const handleTipSelection = (tipPercent: number) => {
    setSelectedTip(tipPercent);
  };

  const handleSubmitRating = () => {
    Alert.alert(
      'Rating Submitted',
      `Thank you for your ${rating}-star rating!${selectedTip > 0 ? ` Tip of £${(serviceStatus.price * selectedTip / 100).toFixed(2)} added.` : ''}`,
      [{ text: 'OK', onPress: () => router.push('/owner-dashboard') }]
    );
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <Animated.View style={[styles.header, { opacity: fadeAnim }]}>
        <View style={styles.headerTop}>
          <View style={styles.headerLeft}>
            <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
              <Text style={styles.backButtonText}>← Back</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.dashboardButton} onPress={() => router.push('/owner-dashboard')}>
              <Text style={styles.dashboardButtonText}>🏠 Dashboard</Text>
            </TouchableOpacity>
          </View>
          <Text style={styles.headerTitle}>Live Service Tracking</Text>
          <View style={styles.placeholder} />
        </View>
      </Animated.View>

      {/* Main Content */}
      <ScrollView style={styles.scrollContainer} showsVerticalScrollIndicator={false}>
        <Animated.View 
          style={[
            styles.contentContainer,
            {
              opacity: fadeAnim,
              transform: [{ translateY: slideAnim }],
            }
          ]}
        >
          {/* Live GPS Map - Enhanced with real-time tracking */}
          {showMap && (
            <View style={styles.mapContainer}>
              <ExpoMap
                valeterLocation={valeterLocation}
                userLocation={userLocation}
                showMap={showMap}
                isCustomerView={true}
              />
              <View style={styles.mapOverlay}>
                <View style={styles.mapStatusBar}>
                  <Text style={styles.mapStatusText}>
                    {isTracking ? '🔄 Live Tracking Active' : '📍 Service Location'}
                  </Text>
                  <Text style={styles.mapStatusSubtext}>
                    {valeterLocation.address}
                  </Text>
                </View>
              </View>
            </View>
          )}

          {/* Live Progress Bar */}
          <View style={styles.progressCard}>
            <View style={styles.progressHeader}>
              <Text style={styles.progressTitle}>Service Progress</Text>
              <Text style={styles.progressPercentage}>{trackingProgress}%</Text>
            </View>
            <View style={styles.progressBarContainer}>
              <Animated.View 
                style={[
                  styles.progressBar,
                  {
                    width: progressAnim.interpolate({
                      inputRange: [0, 100],
                      outputRange: ['0%', '100%'],
                    }),
                    backgroundColor: getStatusColor(serviceStatus.status)
                  }
                ]} 
              />
            </View>
            <Text style={styles.progressStatus}>
              {getStatusText(serviceStatus.status)} • {serviceStatus.estimatedArrival}
            </Text>
          </View>

          {/* Service Details Card */}
          <View style={styles.serviceDetailsCard}>
            <Text style={styles.serviceDetailsTitle}>Service Details</Text>
            <View style={styles.serviceDetailsRow}>
              <Text style={styles.serviceDetailsLabel}>Service Type:</Text>
              <Text style={styles.serviceDetailsValue}>{serviceStatus.serviceType}</Text>
            </View>
            <View style={styles.serviceDetailsRow}>
              <Text style={styles.serviceDetailsLabel}>Vehicle:</Text>
              <Text style={styles.serviceDetailsValue}>{serviceStatus.vehicleInfo}</Text>
            </View>
            <View style={styles.serviceDetailsRow}>
              <Text style={styles.serviceDetailsLabel}>Location:</Text>
              <Text style={styles.serviceDetailsValue}>{serviceStatus.currentLocation.address}</Text>
            </View>
            <View style={styles.serviceDetailsRow}>
              <Text style={styles.serviceDetailsLabel}>Price:</Text>
              <Text style={styles.serviceDetailsValue}>£{serviceStatus.price.toFixed(2)}</Text>
            </View>
          </View>

          {/* Status Card */}
          <View style={styles.statusCard}>
            <View style={styles.statusHeader}>
              <View style={styles.statusIconContainer}>
                <Text style={styles.statusIcon}>{getStatusIcon(serviceStatus.status)}</Text>
              </View>
              <View style={styles.statusInfo}>
                <Text style={styles.statusText}>{getStatusText(serviceStatus.status)}</Text>
                <Text style={styles.etaText}>
                  {serviceStatus.status === 'en_route' ? `ETA: ${serviceStatus.estimatedArrival}` : 
                   serviceStatus.status === 'arrived' ? 'Valeter is here' :
                   serviceStatus.status === 'in_progress' ? 'Valeter is washing your car' :
                   'Valeter is on the way'
                }
                </Text>
              </View>
            </View>
            
            <View style={[
              styles.statusProgress,
              { backgroundColor: getStatusColor(serviceStatus.status) }
            ]} />
          </View>

          {/* Driver Info */}
          <View style={styles.driverCard}>
            <View style={styles.driverHeader}>
              <Text style={styles.driverTitle}>Your Valeter</Text>
              <View style={styles.driverRating}>
                <Text style={styles.ratingText}>⭐ 4.8</Text>
              </View>
            </View>
            
            <View style={styles.driverInfo}>
              <View style={styles.driverPhoto}>
                <Text style={styles.driverPhotoText}>{serviceStatus.valeterPhoto}</Text>
              </View>
              <View style={styles.driverDetails}>
                <Text style={styles.driverName}>{serviceStatus.valeterName}</Text>
                <Text style={styles.vehicleInfo}>{serviceStatus.vehicleInfo}</Text>
                <Text style={styles.currentLocation}>📍 {valeterLocation.address}</Text>
                {isTracking && (
                  <Text style={styles.gpsInfo}>
                    🔄 Live GPS Tracking Active
                  </Text>
                )}
              </View>
              <View style={styles.driverActions}>
                <TouchableOpacity style={styles.actionButton} onPress={handleCallValeter}>
                  <Text style={styles.actionIcon}>📞</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.actionButton} onPress={handleMessageValeter}>
                  <Text style={styles.actionIcon}>💬</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.actionButton} onPress={handleToggleMap}>
                  <Text style={styles.actionIcon}>{showMap ? '📋' : '🗺️'}</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>

          {/* Progress Timeline */}
          <View style={styles.timelineCard}>
            <Text style={styles.timelineTitle}>Service Progress</Text>
            
            <View style={styles.timeline}>
              <View style={[styles.timelineItem, serviceStatus.status !== 'assigned' && styles.timelineItemCompleted]}>
                <View style={[styles.timelineDot, serviceStatus.status !== 'assigned' && styles.timelineDotCompleted]} />
                <View style={styles.timelineContent}>
                  <Text style={styles.timelineText}>Valeter Assigned</Text>
                  <Text style={styles.timelineTime}>2:30 PM</Text>
                </View>
              </View>
              
              <View style={[styles.timelineItem, !['assigned'].includes(serviceStatus.status) && styles.timelineItemCompleted]}>
                <View style={[styles.timelineDot, !['assigned'].includes(serviceStatus.status) && styles.timelineDotCompleted]} />
                <View style={styles.timelineContent}>
                  <Text style={styles.timelineText}>Valeter on the way</Text>
                  <Text style={styles.timelineTime}>2:32 PM</Text>
                </View>
              </View>
              
              <View style={[styles.timelineItem, !['assigned', 'en_route'].includes(serviceStatus.status) && styles.timelineItemCompleted]}>
                <View style={[styles.timelineDot, !['assigned', 'en_route'].includes(serviceStatus.status) && styles.timelineDotCompleted]} />
                <View style={styles.timelineContent}>
                  <Text style={styles.timelineText}>Valeter Arrived</Text>
                  <Text style={styles.timelineTime}>2:37 PM</Text>
                </View>
              </View>
              
              <View style={[styles.timelineItem, !['assigned', 'en_route', 'arrived'].includes(serviceStatus.status) && styles.timelineItemCompleted]}>
                <View style={[styles.timelineDot, !['assigned', 'en_route', 'arrived'].includes(serviceStatus.status) && styles.timelineDotCompleted]} />
                <View style={styles.timelineContent}>
                  <Text style={styles.timelineText}>Service in Progress</Text>
                  <Text style={styles.timelineTime}>2:38 PM</Text>
                </View>
              </View>
              
              <View style={[styles.timelineItem, serviceStatus.status === 'completed' && styles.timelineItemCompleted]}>
                <View style={[styles.timelineDot, serviceStatus.status === 'completed' && styles.timelineDotCompleted]} />
                <View style={styles.timelineContent}>
                  <Text style={styles.timelineText}>Service Completed</Text>
                  <Text style={styles.timelineTime}>3:08 PM</Text>
                </View>
              </View>
            </View>
          </View>

          {/* Rating and Tip Section - Show when completed */}
          {serviceStatus.status === 'completed' && (
            <View style={styles.serviceCard}>
              <Text style={styles.serviceTitle}>⭐ Rate Your Experience</Text>
              <Text style={styles.serviceValue}>How was your service with {serviceStatus.valeterName}?</Text>
              
              {/* Star Rating */}
              <View style={styles.serviceInfo}>
                {[1, 2, 3, 4, 5].map((star) => (
                  <TouchableOpacity
                    key={star}
                    style={styles.serviceItem}
                    onPress={() => handleStarRating(star)}
                  >
                    <Text style={[styles.serviceValue, { color: star <= (rating || 0) ? '#FFD700' : '#9CA3AF', fontSize: 24 }]}>
                      ★
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
              
              {/* Tip Options */}
              <View style={styles.serviceInfo}>
                <Text style={styles.serviceLabel}>💝 Leave a Tip:</Text>
                <View style={styles.serviceInfo}>
                  {[0, 5, 10, 15, 20].map((tipPercent) => (
                    <TouchableOpacity
                      key={tipPercent}
                      style={[styles.serviceItem, selectedTip === tipPercent && { backgroundColor: '#4CAF50' }]}
                      onPress={() => handleTipSelection(tipPercent)}
                    >
                      <Text style={[styles.serviceValue, selectedTip === tipPercent && { color: '#FFFFFF' }]}>
                        {tipPercent === 0 ? 'No Tip' : `${tipPercent}%`}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>
              
              {/* Submit Rating Button */}
              <TouchableOpacity style={styles.primaryButton} onPress={handleSubmitRating}>
                <Text style={styles.primaryButtonText}>Submit Rating & Tip</Text>
              </TouchableOpacity>
            </View>
          )}

          {/* Photo Upload Requirement - Show when in progress */}
          {serviceStatus.status === 'in_progress' && (
            <View style={styles.serviceCard}>
              <Text style={styles.serviceTitle}>📸 Photo Verification Required</Text>
              <Text style={styles.serviceValue}>
                Your valeter will upload a photo of your clean car before completing the service
              </Text>
              
              <View style={styles.serviceInfo}>
                <Text style={styles.serviceLabel}>Status:</Text>
                <Text style={[styles.serviceValue, { color: '#F59E0B' }]}>⏳ Waiting for photo upload...</Text>
              </View>
              
              <View style={styles.serviceInfo}>
                <Text style={styles.serviceLabel}>Requirements:</Text>
                <Text style={styles.serviceValue}>• Photo will show the completed wash</Text>
                <Text style={styles.serviceValue}>• Ensures quality verification</Text>
                <Text style={styles.serviceValue}>• Required for service completion</Text>
              </View>
            </View>
          )}

          {/* Booking Management */}
          <View style={styles.bookingManagementCard}>
            <Text style={styles.bookingManagementTitle}>Booking Management</Text>
            
            <View style={styles.bookingManagementButtons}>
              <TouchableOpacity style={styles.bookingManagementButton} onPress={handleAmendBooking}>
                <Text style={styles.bookingManagementButtonIcon}>✏️</Text>
                <Text style={styles.bookingManagementButtonText}>Amend Booking</Text>
              </TouchableOpacity>
              
              <TouchableOpacity style={styles.bookingManagementButton} onPress={handleBookAnother}>
                <Text style={styles.bookingManagementButtonIcon}>➕</Text>
                <Text style={styles.bookingManagementButtonText}>Book Another</Text>
              </TouchableOpacity>
              
              <TouchableOpacity style={styles.bookingManagementButton} onPress={() => router.push('/unified-booking')}>
                <Text style={styles.bookingManagementButtonIcon}>🚀</Text>
                <Text style={styles.bookingManagementButtonText}>Priority Service</Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Action Buttons */}
          <View style={styles.actionButtons}>
            {serviceStatus.status === 'completed' ? (
              <TouchableOpacity style={styles.primaryButton} onPress={handleViewReceipt}>
                <Text style={styles.primaryButtonText}>View Receipt</Text>
              </TouchableOpacity>
            ) : (
              <TouchableOpacity style={styles.cancelButton} onPress={handleCancelService}>
                <Text style={styles.cancelButtonText}>Cancel Service</Text>
              </TouchableOpacity>
            )}
          </View>
        </Animated.View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  header: {
    backgroundColor: '#1E3A8A',
    paddingTop: 50,
    paddingHorizontal: 20,
    paddingBottom: 20,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  backButton: {
    padding: 10,
  },
  backButtonText: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: '600',
  },
  dashboardButton: {
    backgroundColor: 'rgba(135, 206, 235, 0.2)',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: 'rgba(135, 206, 235, 0.3)',
  },
  dashboardButtonText: {
    color: '#87CEEB',
    fontSize: 12,
    fontWeight: '600',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff',
  },
  placeholder: {
    width: 60,
  },
  scrollContainer: {
    flex: 1,
  },
  contentContainer: {
    padding: 20,
  },
  mapContainer: {
    backgroundColor: '#1E3A8A',
    borderRadius: 20,
    marginBottom: 20,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
    height: 250,
  },
  mapOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'rgba(10, 25, 41, 0.9)',
    padding: 15,
  },
  mapStatusBar: {
    alignItems: 'center',
  },
  mapStatusText: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  mapStatusSubtext: {
    color: '#B0E0E6',
    fontSize: 14,
  },
  progressCard: {
    backgroundColor: '#1E3A8A',
    borderRadius: 20,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  progressHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  progressTitle: {
    fontSize: 18,
    color: '#87CEEB',
    fontWeight: 'bold',
  },
  progressPercentage: {
    fontSize: 18,
    color: '#F9FAFB',
    fontWeight: 'bold',
  },
  progressBarContainer: {
    height: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 4,
    marginBottom: 10,
    overflow: 'hidden',
  },
  progressBar: {
    height: '100%',
    borderRadius: 4,
  },
  progressStatus: {
    fontSize: 14,
    color: '#B0E0E6',
    textAlign: 'center',
  },
  statusCard: {
    backgroundColor: '#1E3A8A',
    borderRadius: 20,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  statusHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  statusIconContainer: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: 'rgba(135, 206, 235, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  statusIcon: {
    fontSize: 28,
  },
  statusInfo: {
    flex: 1,
  },
  statusText: {
    fontSize: 20,
    color: '#fff',
    fontWeight: 'bold',
    marginBottom: 4,
  },
  etaText: {
    fontSize: 16,
    color: '#B0E0E6',
  },
  statusProgress: {
    height: 4,
    borderRadius: 2,
    width: '100%',
  },
  driverCard: {
    backgroundColor: '#1E3A8A',
    borderRadius: 20,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  driverHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  driverTitle: {
    fontSize: 18,
    color: '#87CEEB',
    fontWeight: 'bold',
  },
  driverRating: {
    backgroundColor: 'rgba(255, 193, 7, 0.2)',
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  ratingText: {
    fontSize: 12,
    color: '#FFC107',
    fontWeight: '600',
  },
  driverInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  driverPhoto: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: 'rgba(135, 206, 235, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  driverPhotoText: {
    fontSize: 24,
  },
  driverDetails: {
    flex: 1,
  },
  driverName: {
    fontSize: 18,
    color: '#fff',
    fontWeight: 'bold',
    marginBottom: 4,
  },
  vehicleInfo: {
    fontSize: 14,
    color: '#B0E0E6',
    marginBottom: 4,
  },
  currentLocation: {
    fontSize: 14,
    color: '#87CEEB',
  },
  driverActions: {
    flexDirection: 'row',
    gap: 10,
  },
  actionButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#87CEEB',
    justifyContent: 'center',
    alignItems: 'center',
  },
  actionIcon: {
    fontSize: 18,
  },
  serviceCard: {
    backgroundColor: '#1E3A8A',
    borderRadius: 20,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  serviceTitle: {
    fontSize: 18,
    color: '#87CEEB',
    fontWeight: 'bold',
    marginBottom: 15,
  },
  serviceInfo: {
    gap: 12,
  },
  serviceItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  serviceLabel: {
    fontSize: 14,
    color: '#B0E0E6',
  },
  serviceValue: {
    fontSize: 14,
    color: '#fff',
    fontWeight: '600',
  },
  timelineCard: {
    backgroundColor: '#1E3A8A',
    borderRadius: 20,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  timelineTitle: {
    fontSize: 18,
    color: '#87CEEB',
    fontWeight: 'bold',
    marginBottom: 15,
  },
  timeline: {
    gap: 20,
  },
  timelineItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  timelineItemCompleted: {
    opacity: 1,
  },
  timelineDot: {
    width: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    marginRight: 15,
    borderWidth: 2,
    borderColor: 'rgba(135, 206, 235, 0.3)',
  },
  timelineDotCompleted: {
    backgroundColor: '#87CEEB',
    borderColor: '#87CEEB',
  },
  timelineText: {
    fontSize: 14,
    color: '#fff',
    fontWeight: '600',
    marginBottom: 2,
  },
  timelineContent: {
    flex: 1,
    marginLeft: 15,
  },
  timelineTime: {
    fontSize: 12,
    color: '#B0E0E6',
  },
  // Service Details Styles
  serviceDetailsCard: {
    backgroundColor: 'rgba(30, 58, 138, 0.3)',
    borderRadius: 20,
    padding: 20,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: 'rgba(135, 206, 235, 0.1)',
  },
  serviceDetailsTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#87CEEB',
    marginBottom: 15,
    textAlign: 'center',
  },
  serviceDetailsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
    paddingBottom: 8,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(135, 206, 235, 0.1)',
  },
  serviceDetailsLabel: {
    fontSize: 14,
    color: '#B0E0E6',
    fontWeight: '500',
  },
  serviceDetailsValue: {
    fontSize: 14,
    color: '#fff',
    fontWeight: '600',
    textAlign: 'right',
    flex: 1,
    marginLeft: 10,
  },
  actionButtons: {
    marginBottom: 20,
  },
  bookingManagementCard: {
    backgroundColor: '#1E293B',
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  bookingManagementTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#F9FAFB',
    marginBottom: 16,
  },
  bookingManagementButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 12,
  },
  bookingManagementButton: {
    flex: 1,
    backgroundColor: '#374151',
    borderRadius: 8,
    padding: 12,
    alignItems: 'center',
  },
  bookingManagementButtonIcon: {
    fontSize: 20,
    marginBottom: 4,
  },
  bookingManagementButtonText: {
    fontSize: 12,
    color: '#F9FAFB',
    fontWeight: '600',
    textAlign: 'center',
  },
  primaryButton: {
    backgroundColor: '#87CEEB',
    borderRadius: 12,
    padding: 18,
    alignItems: 'center',
  },
  primaryButtonText: {
    color: '#0A1929',
    fontSize: 18,
    fontWeight: 'bold',
  },
  cancelButton: {
    backgroundColor: 'rgba(244, 67, 54, 0.2)',
    borderRadius: 12,
    padding: 18,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#F44336',
  },
  cancelButtonText: {
    color: '#F44336',
    fontSize: 18,
    fontWeight: 'bold',
  },
  gpsInfo: {
    fontSize: 12,
    color: '#87CEEB',
    marginTop: 4,
  },
});

