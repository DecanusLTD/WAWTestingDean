import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ScrollView,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { hapticFeedback } from '../src/services/HapticFeedbackService';
import { useAuth } from '../../src/providers/enhanced-auth-context';

const { width, height } = Dimensions.get('window');

interface BusinessFeature {
  id: string;
  icon: string;
  title: string;
  description: string;
  color: string;
}

interface BusinessStats {
  metric: string;
  value: string;
  color: string;
}

export default function BusinessWelcome() {
  const { user } = useAuth();
  const [currentStep, setCurrentStep] = useState(0);
  const [showFeatures, setShowFeatures] = useState(false);
  const [showStats, setShowStats] = useState(false);
  
  // Animation values
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const scaleAnim = useRef(new Animated.Value(0.8)).current;
  const buildingAnim = useRef(new Animated.Value(0)).current;
  const featureAnim = useRef(new Animated.Value(0)).current;
  const statsAnim = useRef(new Animated.Value(0)).current;

  const welcomeSteps = [
    {
      title: `Welcome to Business Management, ${user?.name?.split(' ')[0] || 'Business Owner'}! 🏢✨`,
      subtitle: 'Your business success starts here',
      description: 'Manage your valeting business efficiently with our comprehensive business dashboard and team management tools.',
      icon: '🏢',
      color: '#10B981',
    },
    {
      title: 'Team Management & Growth 👥',
      subtitle: 'Scale your business with confidence',
      description: 'Add valeters to your team, manage their schedules, and grow your business while we handle insurance and licensing.',
      icon: '👥',
      color: '#8B5CF6',
    },
    {
      title: 'Business Analytics & Insights 📊',
      subtitle: 'Make data-driven decisions',
      description: 'Track your business performance, monitor earnings, and get insights to optimize your operations and maximize profits.',
      icon: '📊',
      color: '#F59E0B',
    },
  ];

  const features: BusinessFeature[] = [
    {
      id: '1',
      icon: '👥',
      title: 'Team Management',
      description: 'Add, manage, and monitor your valeter team',
      color: '#10B981',
    },
    {
      id: '2',
      icon: '📊',
      title: 'Business Analytics',
      description: 'Track performance, earnings, and growth metrics',
      color: '#8B5CF6',
    },
    {
      id: '3',
      icon: '🛡️',
      title: 'Insurance Coverage',
      description: 'We handle insurance and licensing for your team',
      color: '#EF4444',
    },
    {
      id: '4',
      icon: '💰',
      title: 'Revenue Management',
      description: 'Track earnings, payouts, and financial reports',
      color: '#F59E0B',
    },
    {
      id: '5',
      icon: '📅',
      title: 'Schedule Management',
      description: 'Manage team schedules and assignments',
      color: '#06B6D4',
    },
    {
      id: '6',
      icon: '🏆',
      title: 'Performance Tracking',
      description: 'Monitor team performance and customer ratings',
      color: '#84CC16',
    },
  ];

  const businessStats: BusinessStats[] = [
    {
      metric: 'Team Members',
      value: '12',
      color: '#10B981',
    },
    {
      metric: 'Monthly Revenue',
      value: '£15,420',
      color: '#F59E0B',
    },
    {
      metric: 'Active Jobs',
      value: '47',
      color: '#8B5CF6',
    },
    {
      metric: 'Customer Rating',
      value: '4.8⭐',
      color: '#EF4444',
    },
  ];

  useEffect(() => {
    // Initial animation
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 1000,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 1000,
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnim, {
        toValue: 1,
        duration: 1000,
        useNativeDriver: true,
      }),
    ]).start();

    // Building animation
    Animated.loop(
      Animated.sequence([
        Animated.timing(buildingAnim, {
          toValue: 1,
          duration: 3000,
          useNativeDriver: true,
        }),
        Animated.timing(buildingAnim, {
          toValue: 0,
          duration: 3000,
          useNativeDriver: true,
        }),
      ])
    ).start();

    // Show features after initial animation
    setTimeout(() => {
      setShowFeatures(true);
      Animated.timing(featureAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }).start();
    }, 2000);

    // Show stats after features
    setTimeout(() => {
      setShowStats(true);
      Animated.timing(statsAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }).start();
    }, 3500);
  }, []);

  const handleGetStarted = async () => {
          try {
        await hapticFeedback('medium');
      } catch (error) {
        console.log('Haptic feedback not available');
      }
    router.replace('/business-dashboard');
  };

  const handleSkip = async () => {
          try {
        await hapticFeedback('light');
      } catch (error) {
        console.log('Haptic feedback not available');
      }
    router.replace('/business-dashboard');
  };

  const renderWelcomeStep = (step: any, index: number) => (
    <Animated.View
      key={index}
      style={[
        styles.welcomeStep,
        {
          opacity: fadeAnim,
          transform: [
            { translateY: slideAnim },
            { scale: scaleAnim },
          ],
        },
      ]}
    >
      <View style={[styles.stepIcon, { backgroundColor: step.color }]}>
        <Text style={styles.stepIconText}>{step.icon}</Text>
      </View>
      <Text style={styles.stepTitle}>{step.title}</Text>
      <Text style={styles.stepSubtitle}>{step.subtitle}</Text>
      <Text style={styles.stepDescription}>{step.description}</Text>
    </Animated.View>
  );

  const renderFeature = (feature: BusinessFeature, index: number) => (
    <Animated.View
      key={feature.id}
      style={[
        styles.featureCard,
        {
          opacity: featureAnim,
          transform: [
            {
              translateY: featureAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [50, 0],
              }),
            },
          ],
        },
      ]}
    >
      <View style={[styles.featureIcon, { backgroundColor: feature.color }]}>
        <Text style={styles.featureIconText}>{feature.icon}</Text>
      </View>
      <View style={styles.featureContent}>
        <Text style={styles.featureTitle}>{feature.title}</Text>
        <Text style={styles.featureDescription}>{feature.description}</Text>
      </View>
    </Animated.View>
  );

  const renderBusinessStat = (stat: BusinessStats, index: number) => (
    <Animated.View
      key={stat.metric}
      style={[
        styles.statCard,
        {
          opacity: statsAnim,
          transform: [
            {
              translateY: statsAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [30, 0],
              }),
            },
          ],
        },
      ]}
    >
      <View style={[styles.statHeader, { backgroundColor: stat.color }]}>
        <Text style={styles.statValue}>{stat.value}</Text>
      </View>
      <View style={styles.statContent}>
        <Text style={styles.statMetric}>{stat.metric}</Text>
      </View>
    </Animated.View>
  );

  return (
    <SafeAreaView style={styles.container}>
      {/* Background with animated buildings */}
      <View style={styles.background}>
        <LinearGradient
          colors={['#0A1929', '#1E3A8A', '#0A1929']}
          style={styles.gradient}
        />
        
        {/* Animated buildings */}
        <Animated.View
          style={[
            styles.building,
            styles.building1,
            {
              opacity: buildingAnim,
              transform: [
                {
                  translateY: buildingAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [-20, 20],
                  }),
                },
              ],
            },
          ]}
        />
        <Animated.View
          style={[
            styles.building,
            styles.building2,
            {
              opacity: buildingAnim.interpolate({
                inputRange: [0, 0.5, 1],
                outputRange: [0, 1, 0],
              }),
              transform: [
                {
                  translateY: buildingAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [-30, 30],
                  }),
                },
              ],
            },
          ]}
        />
        <Animated.View
          style={[
            styles.building,
            styles.building3,
            {
              opacity: buildingAnim.interpolate({
                inputRange: [0, 0.5, 1],
                outputRange: [0, 1, 0],
              }),
              transform: [
                {
                  translateY: buildingAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [-25, 25],
                  }),
                },
              ],
            },
          ]}
        />
      </View>

      {/* Content */}
      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Logo and Brand */}
        <View style={styles.logoSection}>
          <Animated.View
            style={[
              styles.logoContainer,
              {
                opacity: fadeAnim,
                transform: [
                  { scale: scaleAnim },
                ],
              },
            ]}
          >
            <Text style={styles.logo}>🏢</Text>
            <Text style={styles.brandName}>Wish a Wash</Text>
            <Text style={styles.tagline}>Business Management Platform</Text>
          </Animated.View>
        </View>

        {/* Welcome Steps */}
        <View style={styles.welcomeSection}>
          {welcomeSteps.map((step, index) => renderWelcomeStep(step, index))}
        </View>

        {/* Features Grid */}
        {showFeatures && (
          <View style={styles.featuresSection}>
            <Text style={styles.featuresTitle}>Business Management Tools</Text>
            <View style={styles.featuresGrid}>
              {features.map((feature, index) => renderFeature(feature, index))}
            </View>
          </View>
        )}

        {/* Business Stats */}
        {showStats && (
          <View style={styles.statsSection}>
            <Text style={styles.statsTitle}>Your Business Overview</Text>
            <Text style={styles.statsSubtitle}>
              Current performance metrics
            </Text>
            <View style={styles.statsGrid}>
              {businessStats.map((stat, index) => renderBusinessStat(stat, index))}
            </View>
          </View>
        )}

        {/* Action Buttons */}
        <View style={styles.actionSection}>
          <TouchableOpacity
            style={styles.getStartedButton}
            onPress={handleGetStarted}
            activeOpacity={0.8}
          >
            <LinearGradient
              colors={['#10B981', '#059669']}
              style={styles.getStartedGradient}
            >
              <Text style={styles.getStartedText}>Manage Business</Text>
              <Text style={styles.getStartedSubtext}>Access Dashboard</Text>
            </LinearGradient>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.skipButton}
            onPress={handleSkip}
            activeOpacity={0.7}
          >
            <Text style={styles.skipButtonText}>Skip for now</Text>
          </TouchableOpacity>
        </View>

        {/* Footer */}
        <View style={styles.footer}>
          <Text style={styles.footerText}>
            Join successful business owners who trust Wish a Wash to scale their valeting operations
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  background: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  gradient: {
    flex: 1,
  },
  building: {
    position: 'absolute',
    backgroundColor: 'rgba(135, 206, 235, 0.3)',
    shadowColor: '#87CEEB',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.6,
    shadowRadius: 8,
    elevation: 6,
  },
  building1: {
    width: 40,
    height: 80,
    left: '20%',
    top: '20%',
    borderRadius: 4,
  },
  building2: {
    width: 60,
    height: 120,
    left: '60%',
    top: '15%',
    borderRadius: 6,
  },
  building3: {
    width: 50,
    height: 100,
    left: '80%',
    top: '25%',
    borderRadius: 5,
  },
  content: {
    flex: 1,
    padding: 20,
  },
  logoSection: {
    alignItems: 'center',
    marginTop: 40,
    marginBottom: 40,
  },
  logoContainer: {
    alignItems: 'center',
  },
  logo: {
    fontSize: 80,
    marginBottom: 16,
  },
  brandName: {
    color: '#F9FAFB',
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  tagline: {
    color: '#87CEEB',
    fontSize: 18,
    fontWeight: '600',
  },
  welcomeSection: {
    marginBottom: 40,
  },
  welcomeStep: {
    alignItems: 'center',
    marginBottom: 30,
    paddingHorizontal: 20,
  },
  stepIcon: {
    width: 80,
    height: 80,
    borderRadius: 40,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  stepIconText: {
    fontSize: 36,
  },
  stepTitle: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 8,
    lineHeight: 30,
  },
  stepSubtitle: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 12,
  },
  stepDescription: {
    color: '#B0E0E6',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
  },
  featuresSection: {
    marginBottom: 40,
  },
  featuresTitle: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 24,
  },
  featuresGrid: {
    gap: 16,
  },
  featureCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  featureIcon: {
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  featureIconText: {
    fontSize: 24,
  },
  featureContent: {
    flex: 1,
  },
  featureTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  featureDescription: {
    color: '#B0E0E6',
    fontSize: 14,
    lineHeight: 18,
  },
  statsSection: {
    marginBottom: 40,
  },
  statsTitle: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 8,
  },
  statsSubtitle: {
    color: '#87CEEB',
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 24,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  statCard: {
    width: '48%',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  statHeader: {
    paddingVertical: 12,
    paddingHorizontal: 16,
    alignItems: 'center',
  },
  statValue: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  statContent: {
    padding: 16,
  },
  statMetric: {
    color: '#87CEEB',
    fontSize: 14,
    textAlign: 'center',
    fontWeight: '600',
  },
  actionSection: {
    marginBottom: 40,
  },
  getStartedButton: {
    marginBottom: 16,
    borderRadius: 16,
    overflow: 'hidden',
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  getStartedGradient: {
    paddingVertical: 20,
    paddingHorizontal: 32,
    alignItems: 'center',
  },
  getStartedText: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  getStartedSubtext: {
    color: '#FFFFFF',
    fontSize: 14,
    opacity: 0.9,
  },
  skipButton: {
    alignItems: 'center',
    paddingVertical: 12,
  },
  skipButtonText: {
    color: '#87CEEB',
    fontSize: 16,
    textDecorationLine: 'underline',
  },
  footer: {
    alignItems: 'center',
    paddingBottom: 40,
  },
  footerText: {
    color: '#B0E0E6',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
    fontStyle: 'italic',
  },
});
