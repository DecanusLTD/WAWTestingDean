// app/index.tsx
import React, { useEffect, useState } from 'react';
import { StyleSheet } from 'react-native';
import { router } from 'expo-router';
import { useAuth } from '../src/providers/enhanced-auth-context';
import AsyncStorage from '@react-native-async-storage/async-storage';
import LoadingScreen from '../src/components/LoadingScreen';

export default function HomeScreen() {
  const { user, isLoading, authReady } = useAuth();
  const [hasSeenOnboarding, setHasSeenOnboarding] = useState<boolean | null>(null);

  useEffect(() => {
    // Check if user has seen general onboarding
    const checkOnboardingStatus = async () => {
      try {
        const onboardingSeen = await AsyncStorage.getItem('onboarding_seen');
        setHasSeenOnboarding(onboardingSeen === 'true');
      } catch (error) {
        console.error('Error checking onboarding status:', error);
        setHasSeenOnboarding(false);
      }
    };
    checkOnboardingStatus();
  }, []);

  useEffect(() => {
    const handleRouting = async () => {
      // wait for both: bootstrap loading finished and reliable role (authReady)
      if (isLoading || !authReady || hasSeenOnboarding === null) return;

      if (user) {
        const userOnboardingKey = `${user.userType}_onboarding_seen`;
        const hasSeenUserOnboarding = await AsyncStorage.getItem(userOnboardingKey);

        if (hasSeenUserOnboarding === 'true') {
          // Go to correct dashboard by role
          if (user.userType === 'valeter') {
            router.replace('driver/driver-dashboard');
          } else if (user.userType === 'organization') {
            router.replace('organistion/organization-dashboard'); // keep your path name
          } else {
            // customer
            router.replace('owner/owner-dashboard'); // keep your existing customer dashboard path
          }
        } else {
          // Route to onboarding flow by role
          if (user.userType === 'valeter') {
            router.replace('valeter/valeter-onboarding');
          } else if (user.userType === 'organization') {
            router.replace('organistion/organization-onboarding'); // keep your path name
          } else {
            router.replace('customer/customer-onboarding');
          }
        }
      } else {
        // No user logged in
        if (hasSeenOnboarding) {
          router.replace('auth/login');
        } else {
          router.replace('/onboarding');
        }
      }
    };

    handleRouting();
  }, [user, isLoading, authReady, hasSeenOnboarding]);

  // Show loading screen while determining where to redirect
  return <LoadingScreen message="Initializing..." />;
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
});