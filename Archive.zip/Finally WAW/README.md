# Wish a Wash - Professional Car Valeting Platform

A comprehensive React Native mobile application for professional car valeting services, built with Expo and TypeScript.

## 🚗 Overview

Wish a Wash is a complete car valeting platform that connects customers with professional valeters. The app features real-time tracking, document management, payment processing, and a sophisticated rewards system.

## ✨ Key Features

### 🏠 Customer Features
- **Priority Wash Booking** - Step-by-step wizard with live ETA and GPS tracking
- **Instant Wash Booking** - Quick booking with real-time valeter matching
- **Live Tracking** - Real-time GPS tracking of valeter location
- **Wash History** - Complete history with photos, ratings, and reviews
- **Rewards System** - Points-based rewards for free washes and discounts
- **Vehicle Management** - Store and manage multiple vehicles
- **AI Chat Support** - Intelligent chatbot for customer assistance

### 👨‍🔧 Valeter Features
- **Professional Dashboard** - Complete job management and earnings tracking
- **Document Management** - Secure upload and verification of professional documents
- **Go Online/Offline** - Control availability with document verification
- **Wash Completion** - Photo upload and completion documentation
- **Earnings Tracking** - Real-time earnings, tips, and performance analytics
- **Professional Rewards** - Equipment upgrades, training, and business benefits
- **Working Area Management** - Set and manage service coverage areas

### 🏢 Organization Features
- **Team Management** - Add and manage multiple valeters
- **Document Verification** - Verify team member documents
- **Business Analytics** - Performance tracking and revenue analytics
- **Business Rewards** - Team bonuses, equipment subsidies, and training programs
- **Compliance Management** - Ensure all team members meet professional standards

### 🔧 Technical Features
- **Real-time GPS Tracking** - Live location updates and route optimization
- **Document Upload System** - Secure file upload with verification
- **Payment Integration** - Stripe payment processing with commission handling
- **AI Chat System** - Intelligent customer and valeter support
- **Push Notifications** - Real-time updates and alerts
- **Offline Support** - Core functionality works without internet
- **Multi-language Support** - UK English with internationalization ready

## 🛠️ Technology Stack

- **Framework**: React Native with Expo
- **Language**: TypeScript
- **Navigation**: Expo Router
- **State Management**: React Context + AsyncStorage
- **UI Components**: Custom components with LinearGradient
- **Maps**: Mapbox integration (ready for implementation)
- **Payments**: Stripe integration
- **Database**: Supabase (PostgreSQL)
- **File Storage**: Supabase Storage
- **Authentication**: Supabase Auth

## 📱 Screenshots

### Customer Dashboard
- Priority wash booking wizard
- Live tracking interface
- Wash history with photos
- Rewards and points system

### Valeter Dashboard
- Professional job management
- Document upload and verification
- Earnings and performance tracking
- Wash completion workflow

### Organization Dashboard
- Team management interface
- Business analytics
- Document verification system
- Performance monitoring

## 🚀 Getting Started

### Prerequisites
- Node.js (v18 or higher)
- npm or yarn
- Expo CLI
- iOS Simulator or Android Emulator (optional)

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/wish-a-wash.git
   cd wish-a-wash
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   ```bash
   cp env.example .env
   ```
   Edit `.env` with your configuration:
   ```
   EXPO_PUBLIC_SUPABASE_URL=your_supabase_url
   EXPO_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
   EXPO_PUBLIC_STRIPE_PUBLISHABLE_KEY=your_stripe_key
   EXPO_PUBLIC_MAPBOX_TOKEN=your_mapbox_token
   ```

4. **Start the development server**
   ```bash
   npx expo start
   ```

5. **Run on device/simulator**
   - Press `i` for iOS simulator
   - Press `a` for Android emulator
   - Scan QR code with Expo Go app

## 📋 Project Structure

```
wish-a-wash/
├── app/                    # Expo Router pages
│   ├── index.tsx          # Entry point
│   ├── login.tsx          # Authentication
│   ├── signup.tsx         # User registration
│   ├── owner-dashboard.tsx # Customer dashboard
│   ├── driver-dashboard.tsx # Valeter dashboard
│   ├── organization-dashboard.tsx # Business dashboard
│   ├── priority-wash.tsx  # Booking wizard
│   ├── current-trip.tsx   # Live tracking
│   └── ...                # Other screens
├── src/
│   ├── components/        # Reusable components
│   │   ├── dashboard/     # Dashboard components
│   │   ├── chat/          # Chat components
│   │   └── wash/          # Wash-related components
│   ├── services/          # Business logic services
│   │   ├── BookingService.ts
│   │   ├── ValeterStatusService.ts
│   │   ├── WashCompletionService.ts
│   │   └── ...            # Other services
│   ├── config/            # Configuration files
│   └── utils/             # Utility functions
├── assets/                # Images, fonts, icons
├── supabase-schema.sql    # Database schema
└── README.md             # This file
```

## 🔐 Authentication & Security

### User Types
- **Customer** - Book washes and track services
- **Valeter** - Professional service providers
- **Organization** - Business account managers
- **Super Admin** - Platform administrators

### Document Verification
- **ID Proof** - Government-issued identification
- **Selfie** - Real-time photo verification
- **Profile Photo** - Professional headshot
- **Disclaimer** - Legal agreement signature

### Data Privacy
- All documents are encrypted and stored securely
- Automatic data deletion on account closure
- GDPR compliant data handling
- Secure payment processing

## 💳 Payment System

### Customer Payments
- Stripe integration for secure payments
- Multiple payment methods support
- Automatic tip processing
- Refund handling

### Valeter Earnings
- Real-time earnings tracking
- Commission-based payment system
- Tip collection and distribution
- Weekly/monthly payout processing

## 📊 Analytics & Reporting

### Customer Analytics
- Booking history and patterns
- Spending analysis
- Service preferences
- Satisfaction metrics

### Valeter Analytics
- Performance tracking
- Earnings analysis
- Customer ratings
- Service completion rates

### Business Analytics
- Team performance metrics
- Revenue tracking
- Customer satisfaction scores
- Operational efficiency

## 🔧 Configuration

### Supabase Setup
1. Create a new Supabase project
2. Run the schema from `supabase-schema.sql`
3. Configure authentication providers
4. Set up storage buckets for documents

### Stripe Configuration
1. Create a Stripe account
2. Configure webhook endpoints
3. Set up payment methods
4. Configure commission rates

### Mapbox Integration
1. Create a Mapbox account
2. Generate access tokens
3. Configure map styles
4. Set up geocoding services

## 🧪 Testing

### Unit Tests
```bash
npm test
```

### E2E Tests
```bash
npm run test:e2e
```

### Manual Testing Checklist
- [ ] User registration and login
- [ ] Document upload and verification
- [ ] Booking flow completion
- [ ] Payment processing
- [ ] Live tracking functionality
- [ ] Wash completion workflow
- [ ] Rewards system
- [ ] Chat functionality

## 🚀 Deployment

### Expo Build
```bash
# Build for iOS
eas build --platform ios

# Build for Android
eas build --platform android
```

### App Store Deployment
1. Configure app.json with store details
2. Build production version
3. Submit to App Store/Play Store
4. Configure production environment variables

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

For support and questions:
- Create an issue in the GitHub repository
- Contact the development team
- Check the documentation in `/docs`

## 🔄 Version History

### v1.0.0 (Current)
- Complete customer booking system
- Valeter management platform
- Organization dashboard
- Real-time tracking
- Document verification
- Payment processing
- Rewards system
- AI chat support

## 🙏 Acknowledgments

- Expo team for the amazing framework
- Supabase for backend services
- Stripe for payment processing
- Mapbox for mapping services
- All contributors and testers

---

**Built with ❤️ for the car valeting industry**
