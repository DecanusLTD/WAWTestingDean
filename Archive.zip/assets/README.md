# Assets Directory

This directory contains static assets for the WAW (Wish A Wash) app.

## Structure
- `images/` - App images and icons
- `fonts/` - Custom fonts (if any)
- `icons/` - App icons and logos

## Usage
Assets in this directory can be imported and used throughout the app.

## Note
Currently using placeholder assets. Replace with actual app assets when available.
