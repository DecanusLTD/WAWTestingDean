import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import App from './App.tsx'
import WishAWashLayout from './pages/WishAWashLayout.tsx'
import DashboardPage from './pages/waw/DashboardPage.tsx'
import DocumentsPage from './pages/waw/DocumentsPage.tsx'
import BookingsPage from './pages/waw/BookingsPage.tsx'
import LocationsPage from './pages/waw/LocationsPage.tsx'
import OrgsPage from './pages/waw/OrgsPage.tsx'
import ValeterProfilePage from './pages/waw/ValeterProfilePage.tsx'
import 'bootstrap/dist/css/bootstrap.min.css'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <BrowserRouter>
      <Routes>
        {/* landing page / app picker */}
        <Route path="/" element={<App />} />

        {/* admin shell */}
        <Route path="/wish-a-wash" element={<WishAWashLayout />}>
          <Route index element={<Navigate to="dashboard" replace />} />
          <Route path="dashboard" element={<DashboardPage />} />
          <Route path="documents" element={<DocumentsPage />} />
          <Route path="bookings" element={<BookingsPage />} />

          {/* organisations area */}
          <Route path="organizations" element={<OrgsPage />} />
          {/* locations are now a sub-route of an org */}
          <Route path="locations" element={<LocationsPage />} />

          {/* valeter profile */}
          <Route path="valeters/:id" element={<ValeterProfilePage />} />
        </Route>
      </Routes>
    </BrowserRouter>
  </React.StrictMode>,
)