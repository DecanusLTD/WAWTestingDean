// src/App.tsx
import { useNavigate } from 'react-router-dom'

export default function App() {
  const navigate = useNavigate()

  return (
    <div
      style={{
        minHeight: '100vh',
        background: 'radial-gradient(circle at top, #013e7d, #001a3a 55%)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '1.5rem',
      }}
    >
      <div
        style={{
          width: '100%',
          maxWidth: 900,
        }}
      >
        {/* header */}
        <div className="d-flex flex-column flex-md-row justify-content-between align-items-start mb-4 gap-2">
          <div>
            <h1 className="text-white mb-1" style={{ fontWeight: 700 }}>
              Admin Portal
            </h1>
            <p className="text-white-50 mb-0">
              Pick the app you want to manage.
            </p>
          </div>
          <span
            className="badge bg-light text-dark"
            style={{ alignSelf: 'flex-start' }}
          >
            Wish Apps • internal
          </span>
        </div>

        {/* app grid */}
        <div className="row g-3">
          {/* Wish-a-Wash card */}
          <div className="col-12 col-md-6 col-lg-4">
            <button
              onClick={() => navigate('/wish-a-wash')}
              className="btn w-100 h-100 p-0 text-start"
              style={{
                background: 'linear-gradient(135deg, #0073ff 0%, #00c0ff 100%)',
                border: 'none',
                borderRadius: 18,
                overflow: 'hidden',
                boxShadow: '0 12px 30px rgba(0,0,0,0.25)',
              }}
            >
              <div className="p-3 d-flex flex-column gap-2" style={{ minHeight: 160 }}>
                <div
                  style={{
                    width: 44,
                    height: 44,
                    borderRadius: 14,
                    background: 'rgba(255,255,255,0.2)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: 20,
                  }}
                >
                  🪄
                </div>
                <div>
                  <h5 className="text-white mb-1">Wish-a-Wash</h5>
                  <p className="mb-0 text-white-75 small">
                    Manage bookings, valeters, locations, orgs.
                  </p>
                </div>
                <div className="mt-auto d-flex justify-content-between align-items-center">
                  <span className="badge bg-white text-primary">Active</span>
                  <span className="text-white-75 small">Open →</span>
                </div>
              </div>
            </button>
          </div>

          {/* placeholder for future apps */}
          <div className="col-12 col-md-6 col-lg-4">
            <div
              className="h-100"
              style={{
                background: 'rgba(255,255,255,0.06)',
                border: '1px dashed rgba(255,255,255,0.25)',
                borderRadius: 18,
                minHeight: 160,
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'center',
                alignItems: 'center',
                color: 'rgba(255,255,255,0.5)',
              }}
            >
              <span style={{ fontSize: 28, marginBottom: 6 }}>＋</span>
              <p className="mb-0 small">More admin apps coming soon</p>
            </div>
          </div>
        </div>

        {/* footer */}
        <p className="text-white-50 small mt-4 mb-0">
          Signed in as Admin • {new Date().getFullYear()}
        </p>
      </div>
    </div>
  )
}