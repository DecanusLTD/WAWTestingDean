import { useState } from 'react'
import { NavLink, Outlet } from 'react-router-dom'

export default function WishAWashLayout() {
  const [open, setOpen] = useState(false)

  return (
    <div className="d-flex" style={{ minHeight: '100vh', background: '#f3f4f6' }}>
      {/* Sidebar (desktop) */}
      <aside
        className={`d-none d-md-flex flex-column justify-content-between`}
        style={{
          width: '240px',
          background: 'linear-gradient(180deg, #013e7d 0%, #001a3a 100%)',
          color: 'white',
        }}
      >
        <Brand />
        <nav className="px-3 flex-grow-1">
          <SideLinks />
        </nav>
        <Footer />
      </aside>

      {/* Offcanvas-style sidebar for mobile */}
      {open && (
        <div
          className="d-md-none position-fixed top-0 start-0 h-100"
          style={{
            width: 230,
            background: 'linear-gradient(180deg, #013e7d 0%, #001a3a 100%)',
            zIndex: 1050,
          }}
        >
          <div className="p-3 d-flex justify-content-between align-items-center">
            <h5 className="mb-0 text-white">Wish-a-Wash</h5>
            <button className="btn btn-sm btn-light" onClick={() => setOpen(false)}>
              ✕
            </button>
          </div>
          <div className="px-3">
            <SideLinks onClickLink={() => setOpen(false)} />
          </div>
          <Footer />
        </div>
      )}

      {/* Main area */}
      <div className="flex-grow-1 d-flex flex-column" style={{ minWidth: 0 }}>
        {/* Top bar */}
        <header
          className="d-flex align-items-center justify-content-between px-3 px-md-4 py-3 bg-white border-bottom"
        >
          <div className="d-flex align-items-center gap-2">
            {/* mobile burger */}
            <button
              className="btn btn-sm btn-outline-secondary d-md-none"
              onClick={() => setOpen(true)}
            >
              ☰
            </button>
            <div>
              <h6 className="mb-0">Wish-a-Wash Admin</h6>
              <small className="text-muted d-none d-sm-block">
                Manage bookings, valeters, locations
              </small>
            </div>
          </div>
          <div className="d-flex align-items-center gap-2">
            <span className="badge text-bg-primary d-none d-sm-inline">3 alerts</span>
            <div
              style={{
                width: 32,
                height: 32,
                borderRadius: '50%',
                background:
                  'url(https://ui-avatars.com/api/?name=Admin&background=0f172a&color=fff) center/cover',
              }}
            />
          </div>
        </header>

        {/* Routed content */}
        <main className="flex-grow-1 p-3 p-md-4" style={{ background: '#f3f4f6' }}>
          <Outlet />
        </main>
      </div>
    </div>
  )
}

function Brand() {
  return (
    <div className="px-3 py-3 border-bottom border-secondary-subtle">
      <h5 className="mb-0">Wish-a-Wash</h5>
      <small className="text-secondary">Admin Portal</small>
    </div>
  )
}

function Footer() {
  return (
    <div className="px-3 py-3 border-top border-secondary-subtle small text-secondary">
      Wish Admin • v1
    </div>
  )
}

function SideLinks({ onClickLink }: { onClickLink?: () => void } = {}) {
  return (
    <>
      <SideLink to="dashboard" label="Dashboard" icon="📊" onClick={onClickLink} />
      <SideLink to="documents" label="Valeter Docs" icon="🪄" onClick={onClickLink} />
      <SideLink to="bookings" label="Bookings" icon="🚗" onClick={onClickLink} />
      <SideLink to="locations" label="Locations" icon="📍" onClick={onClickLink} />
      <SideLink to="organizations" label="Organisations" icon="🏢" onClick={onClickLink} />
    </>
  )
}

function SideLink({
  to,
  label,
  icon,
  onClick,
}: {
  to: string
  label: string
  icon: string
  onClick?: () => void
}) {
  return (
    <NavLink
      to={to}
      onClick={onClick}
      className={({ isActive }) =>
        `d-flex align-items-center gap-2 px-2 py-2 rounded text-decoration-none mb-1 ${
          isActive ? 'bg-light text-dark' : 'text-white-50'
        }`
      }
    >
      <span>{icon}</span>
      <span className="small">{label}</span>
    </NavLink>
  )
}