// src/pages/waw/DashboardPage.tsx
import { useEffect, useState } from 'react'
import { supabase } from '../../lib/supabaseClient'

type ActivityDay = {
  date: string // e.g. "2025-11-11"
  totalBookings: number
  totalRevenue: number
  completed: number
  scheduled: number
}

export default function DashboardPage() {
  const [stats, setStats] = useState({
    totalBookings: 0,
    totalRevenue: 0,
    pendingDocs: 0,
    pendingOrgs: 0,
  })
  const [activity, setActivity] = useState<ActivityDay[]>([])
  const [loading, setLoading] = useState(true)
  const [activityLoading, setActivityLoading] = useState(true)

  useEffect(() => {
    const load = async () => {
      const [
        { count: totalBookings },
        { data: revenueRows },
        { count: pendingDocs },
        { count: pendingOrgs },
      ] = await Promise.all([
        supabase.from('bookings').select('id', { count: 'exact', head: true }),
        supabase
          .from('bookings')
          .select('price, status')
          .in('status', ['completed', 'in_progress']),
        supabase
          .from('valeter_documents')
          .select('id', { count: 'exact', head: true })
          .eq('status', 'pending'),
        supabase
          .from('organizations')
          .select('id', { count: 'exact', head: true })
          .eq('status', 'pending'),
      ])

      const totalRevenue = (revenueRows || []).reduce(
        (sum, r) => sum + Number(r.price || 0),
        0
      )

      setStats({
        totalBookings: totalBookings || 0,
        totalRevenue,
        pendingDocs: pendingDocs || 0,
        pendingOrgs: pendingOrgs || 0,
      })
      setLoading(false)
    }

    load()
  }, [])

  // load recent bookings for activity
  useEffect(() => {
    const loadActivity = async () => {
      setActivityLoading(true)

      const { data, error } = await supabase
        .from('bookings')
        .select('id, price, status, created_at, completed_at')
        .order('created_at', { ascending: false })
        .limit(100)

      if (!error && data) {
        // group by date (YYYY-MM-DD)
        const grouped: Record<string, ActivityDay> = {}

        data.forEach((b) => {
          const d = new Date(b.created_at)
          const key = d.toISOString().slice(0, 10) // "2025-11-11"

          if (!grouped[key]) {
            grouped[key] = {
              date: key,
              totalBookings: 0,
              totalRevenue: 0,
              completed: 0,
              scheduled: 0,
            }
          }

          grouped[key].totalBookings += 1
          grouped[key].totalRevenue += Number(b.price || 0)
          if (b.status === 'completed') {
            grouped[key].completed += 1
          }
          if (b.status === 'scheduled' || b.status === 'in_progress') {
            grouped[key].scheduled += 1
          }
        })

        // sort by date desc and take last 7 days
        const days = Object.values(grouped)
          .sort((a, b) => (a.date < b.date ? 1 : -1))
          .slice(0, 7)

        setActivity(days)
      } else {
        setActivity([])
      }

      setActivityLoading(false)
    }

    loadActivity()
  }, [])

  return (
    <div className="container-fluid px-0">
      {/* top cards */}
      <div className="row g-3 mb-4">
        <div className="col-12 col-md-6 col-lg-3">
          <GradientCard
            title="Total bookings"
            value={loading ? '…' : stats.totalBookings.toString()}
            gradient="linear-gradient(135deg, #00c97c 0%, #00e0a8 100%)"
            icon="📦"
          />
        </div>
        <div className="col-12 col-md-6 col-lg-3">
          <GradientCard
            title="Total revenue"
            value={loading ? '…' : `£${stats.totalRevenue.toFixed(2)}`}
            gradient="linear-gradient(135deg, #0073ff 0%, #00c0ff 100%)"
            icon="💷"
          />
        </div>
        <div className="col-12 col-md-6 col-lg-3">
          <GradientCard
            title="Pending documents"
            value={loading ? '…' : stats.pendingDocs.toString()}
            gradient="linear-gradient(135deg, #0ea5e9 0%, #38bdf8 100%)"
            icon="📄"
          />
        </div>
        <div className="col-12 col-md-6 col-lg-3">
          <GradientCard
            title="Pending organisations"
            value={loading ? '…' : stats.pendingOrgs.toString()}
            gradient="linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)"
            icon="🏢"
          />
        </div>
      </div>

      {/* lower area */}
      <div className="row g-3">
        {/* activity */}
        <div className="col-12 col-lg-8">
          <div
            className="card shadow-sm border-0"
            style={{
              background: '#ffffff',
              borderRadius: 18,
            }}
          >
            <div
              className="card-header bg-white d-flex justify-content-between align-items-center"
              style={{ borderTopLeftRadius: 18, borderTopRightRadius: 18 }}
            >
              <h6 className="mb-0">Activity</h6>
              <small className="text-muted">Last 7 days</small>
            </div>
            <div className="card-body" style={{ minHeight: 200 }}>
              {activityLoading ? (
                <p className="text-muted small mb-0">Loading activity…</p>
              ) : activity.length === 0 ? (
                <p className="text-muted small mb-0">No recent bookings.</p>
              ) : (
                <ul className="list-unstyled mb-0">
                  {activity.map((day) => (
                    <li
                      key={day.date}
                      className="d-flex justify-content-between align-items-center py-2 border-bottom"
                      style={{ fontSize: '0.8rem' }}
                    >
                      <div>
                        <strong>{formatDate(day.date)}</strong>
                        <span className="text-muted ms-2">
                          {day.totalBookings} booking{day.totalBookings !== 1 ? 's' : ''}
                        </span>
                      </div>
                      <div className="d-flex align-items-center gap-2">
                        <span className="badge text-bg-light">
                          £{day.totalRevenue.toFixed(2)}
                        </span>
                        {day.completed > 0 && (
                          <span className="badge text-bg-success">
                            {day.completed} done
                          </span>
                        )}
                        {day.scheduled > 0 && (
                          <span className="badge text-bg-warning">
                            {day.scheduled} in progress
                          </span>
                        )}
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>

        {/* right column */}
        <div className="col-12 col-lg-4">
          <div
            className="card shadow-sm border-0 mb-3"
            style={{ background: '#ffffff', borderRadius: 18 }}
          >
            <div
              className="card-header bg-white"
              style={{ borderTopLeftRadius: 18, borderTopRightRadius: 18 }}
            >
              <h6 className="mb-0">Quick actions</h6>
            </div>
            <div className="card-body d-grid gap-2">
              <button
                className="btn btn-sm"
                style={{
                  background: 'linear-gradient(135deg, #00c97c 0%, #00e0a8 100%)',
                  color: '#fff',
                  border: 'none',
                  borderRadius: 9999,
                }}
              >
                Review documents
              </button>
              <button
                className="btn btn-sm btn-outline-secondary"
                style={{ borderRadius: 14 }}
              >
                Check locations
              </button>
              <button
                className="btn btn-sm btn-outline-secondary"
                style={{ borderRadius: 14 }}
              >
                View bookings
              </button>
            </div>
          </div>

          <div
            className="card shadow-sm border-0"
            style={{ background: '#ffffff', borderRadius: 18 }}
          >
            <div
              className="card-header bg-white"
              style={{ borderTopLeftRadius: 18, borderTopRightRadius: 18 }}
            >
              <h6 className="mb-0">System status</h6>
            </div>
            <div className="card-body">
              <StatusRow label="Supabase" value="Online" variant="success" />
              <StatusRow label="Storage" value="OK" variant="success" />
              <StatusRow label="Valeter docs" value="Needs review" variant="warning" />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

function GradientCard({
  title,
  value,
  gradient,
  icon,
}: {
  title: string
  value: string
  gradient: string
  icon?: string
}) {
  return (
    <div
      className="h-100"
      style={{
        background: gradient,
        borderRadius: 18,
        boxShadow: '0 12px 30px rgba(0,0,0,0.12)',
        color: '#fff',
      }}
    >
      <div className="p-3 d-flex flex-column gap-1">
        <div className="d-flex justify-content-between align-items-center">
          <p
            className="mb-0"
            style={{ fontSize: 12, textTransform: 'uppercase', opacity: 0.85 }}
          >
            {title}
          </p>
          {icon ? <span style={{ fontSize: 20 }}>{icon}</span> : null}
        </div>
        <h3 className="mb-0" style={{ fontWeight: 700 }}>
          {value}
        </h3>
      </div>
    </div>
  )
}

function StatusRow({
  label,
  value,
  variant,
}: {
  label: string
  value: string
  variant: 'success' | 'warning' | 'danger'
}) {
  const colors: Record<typeof variant, string> = {
    success: '#22c55e',
    warning: '#f97316',
    danger: '#ef4444',
  }
  return (
    <div className="d-flex justify-content-between align-items-center mb-2">
      <span className="small text-muted">{label}</span>
      <span
        className="badge"
        style={{
          background: colors[variant],
          color: '#fff',
          borderRadius: 9999,
        }}
      >
        {value}
      </span>
    </div>
  )
}

function formatDate(isoDate: string) {
  // isoDate = "2025-11-11"
  const d = new Date(isoDate)
  return d.toLocaleDateString(undefined, {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  })
}