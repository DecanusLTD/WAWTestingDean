// src/pages/waw/LocationsPage.tsx
import { useEffect, useState } from 'react'
import { supabase } from '../../lib/supabaseClient'

type Location = {
  id: string
  name: string
  address: string
  status: string
  base_price: number
  priority_price: number
  wait_time_minutes: number | null
  organization_id: string | null
  organizations: {
    name: string
  } | null
}

export default function LocationsPage() {
  const [locations, setLocations] = useState<Location[]>([])
  const [loading, setLoading] = useState(true)
  const [openOrg, setOpenOrg] = useState<string | null>(null)

  useEffect(() => {
    const load = async () => {
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select(
          `
          id,
          name,
          address,
          status,
          base_price,
          priority_price,
          wait_time_minutes,
          organization_id,
          organizations ( name )
        `
        )
        .order('created_at', { ascending: false })
        .limit(100)

      if (!error) {
        setLocations((data || []) as Location[])
      }
      setLoading(false)
    }

    load()
  }, [])

  // group by organization_id
  const groups: Record<string, Location[]> = locations.reduce((acc, loc) => {
    const key = loc.organization_id || 'unassigned'
    if (!acc[key]) acc[key] = []
    acc[key].push(loc)
    return acc
  }, {} as Record<string, Location[]>)

  const orgKeys = Object.keys(groups)

  return (
    <div className="container-fluid px-0">
      <h1 className="h4 mb-3">Locations</h1>
      <p className="text-muted mb-4">
        Managed car wash locations and their current status.
      </p>

      <div className="card shadow-sm border-0">
        <div className="card-header bg-white d-flex justify-content-between align-items-center">
          <h6 className="mb-0">Car wash locations</h6>
          <span className="badge text-bg-secondary">{locations.length} total</span>
        </div>

        {loading ? (
          <p className="p-3 mb-0">Loading…</p>
        ) : orgKeys.length === 0 ? (
          <p className="p-3 mb-0 text-muted">No locations found.</p>
        ) : (
          <div className="list-group list-group-flush">
            {orgKeys.map((orgId) => {
              const orgLocations = groups[orgId]
              const first = orgLocations[0]
              const orgName =
                orgId === 'unassigned'
                  ? 'Unassigned'
                  : first.organizations?.name || 'Unknown organisation'
              const isOpen = openOrg === orgId

              // tiny status counts per org
              const statusCounts = orgLocations.reduce(
                (acc, l) => {
                  acc[l.status] = (acc[l.status] || 0) + 1
                  return acc
                },
                {} as Record<string, number>
              )

              return (
                <div key={orgId} className="list-group-item bg-white">
                  <div className="d-flex justify-content-between align-items-center flex-wrap">
                    <div className="d-flex align-items-center gap-2 flex-wrap">
                      <span className="fw-semibold">{orgName}</span>
                      <span className="badge text-bg-light">
                        {orgLocations.length} location
                        {orgLocations.length > 1 ? 's' : ''}
                      </span>
                      {/* status counts */}
                      <OrgStatusCount label="green" count={statusCounts.green} />
                      <OrgStatusCount label="amber" count={statusCounts.amber} />
                      <OrgStatusCount label="red" count={statusCounts.red} />
                    </div>
                    <button
                      className="btn btn-sm btn-outline-secondary mt-2 mt-md-0"
                      onClick={() => setOpenOrg(isOpen ? null : orgId)}
                    >
                      {isOpen ? 'Hide' : 'View'}
                    </button>
                  </div>

                  {isOpen && (
                    <div className="table-responsive mt-3">
                      <table className="table table-sm table-hover mb-0 align-middle">
                        <thead className="table-light">
                          <tr>
                            <th style={{ width: '20%' }}>Name</th>
                            <th style={{ width: '30%' }}>Address</th>
                            <th style={{ width: '12%' }}>Status</th>
                            <th style={{ width: '10%' }} className="text-end">
                              Base £
                            </th>
                            <th style={{ width: '12%' }} className="text-end">
                              Priority £
                            </th>
                            <th style={{ width: '8%' }}>Wait</th>
                          </tr>
                        </thead>
                        <tbody>
                          {orgLocations.map((loc) => (
                            <tr key={loc.id}>
                              <td>{loc.name}</td>
                              <td className="small">{loc.address}</td>
                              <td>{renderStatus(loc.status)}</td>
                              <td className="text-end">
                                £{Number(loc.base_price || 0).toFixed(2)}
                              </td>
                              <td className="text-end">
                                £{Number(loc.priority_price || 0).toFixed(2)}
                              </td>
                              <td>{loc.wait_time_minutes ?? '—'}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}

function renderStatus(status: string) {
  const map: Record<string, string> = {
    green: 'success',
    amber: 'warning',
    red: 'danger',
  }
  const variant = map[status] || 'secondary'
  return (
    <span
      className={`badge text-bg-${variant}`}
      style={{ textTransform: 'capitalize' }}
    >
      {status}
    </span>
  )
}

function OrgStatusCount({ label, count }: { label: string; count?: number }) {
  if (!count) return null

  const colorMap: Record<string, string> = {
    green: 'success',
    amber: 'warning',
    red: 'danger',
  }

  return (
    <span
      className={`badge text-bg-${colorMap[label] || 'secondary'}`}
      style={{ textTransform: 'capitalize' }}
    >
      {label}: {count}
    </span>
  )
}