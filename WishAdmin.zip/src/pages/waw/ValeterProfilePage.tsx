// src/pages/waw/ValeterProfilePage.tsx
import { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { supabase } from '../../lib/supabaseClient'

type Profile = {
  id: string
  email: string | null
  name: string | null
  full_name: string | null
  phone: string | null
  role: string | null
  user_type: string | null
  is_verified: boolean | null
  documents_uploaded: boolean | null
  insurance_verified: boolean | null
  license_verified: boolean | null
  background_check_passed: boolean | null
  tier: string
  tier_points: number
  total_washes: number
  profile_picture: string | null
}

type ValeterDoc = {
  id: string
  name: string
  type: string
  status: string
  file_url: string | null
  uploaded_at: string | null
}

type Booking = {
  id: string
  service_type: string
  status: string
  price: number
  scheduled_at: string | null
  location_address: string | null
}

export default function ValeterProfilePage() {
  const { id } = useParams<{ id: string }>()
  const [profile, setProfile] = useState<Profile | null>(null)
  const [docs, setDocs] = useState<ValeterDoc[]>([])
  const [bookings, setBookings] = useState<Booking[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!id) return

    const load = async () => {
      setLoading(true)

      // 1) profile from public.profiles
      const { data: profileData } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', id)
        .maybeSingle()

      // 2) docs for this user
      const { data: docData } = await supabase
        .from('valeter_documents')
        .select('id, name, type, status, file_url, uploaded_at')
        .eq('user_id', id)
        .order('created_at', { ascending: false })

      // 3) bookings they handled
      const { data: bookingData } = await supabase
        .from('bookings')
        .select(
          'id, service_type, status, price, scheduled_at, location_address'
        )
        .eq('valeter_id', id)
        .order('created_at', { ascending: false })
        .limit(50)

      setProfile((profileData || null) as Profile | null)
      setDocs((docData || []) as ValeterDoc[])
      setBookings((bookingData || []) as Booking[])
      setLoading(false)
    }

    load()
  }, [id])

  const displayName =
    profile?.full_name || profile?.name || (id ? id.slice(0, 8) + '…' : 'Valeter')

  return (
    <div className="container-fluid px-0">
      <div className="d-flex justify-content-between align-items-center mb-3">
        <div>
          <h1 className="h4 mb-1">{displayName}</h1>
          <p className="text-muted mb-0">
            {profile?.role ? profile.role.toUpperCase() : 'VALETER'} • {id}
          </p>
        </div>
        <Link to="/wish-a-wash/documents" className="btn btn-sm btn-outline-secondary">
          ← Back to documents
        </Link>
      </div>

      {loading ? (
        <p>Loading…</p>
      ) : (
        <div className="row g-3">
          {/* left column: profile card */}
          <div className="col-12 col-lg-4">
            <div className="card border-0 shadow-sm mb-3">
              <div className="card-body">
                <div className="d-flex align-items-center gap-3 mb-3">
                  {profile?.profile_picture ? (
                    <img
                      src={profile.profile_picture}
                      alt="profile"
                      style={{ width: 52, height: 52, borderRadius: '9999px', objectFit: 'cover' }}
                    />
                  ) : (
                    <div
                      style={{
                        width: 52,
                        height: 52,
                        borderRadius: '9999px',
                        background:
                          'linear-gradient(135deg, #0f172a 0%, #38bdf8 100%)',
                      }}
                    />
                  )}
                  <div>
                    <h5 className="mb-0">{displayName}</h5>
                    <small className="text-muted">
                      {profile?.email || 'No email'}
                    </small>
                  </div>
                </div>

                <div className="mb-2 d-flex justify-content-between">
                  <span className="text-muted small">Phone</span>
                  <span className="small">{profile?.phone || '—'}</span>
                </div>
                <div className="mb-2 d-flex justify-content-between">
                  <span className="text-muted small">Tier</span>
                  <span className="badge text-bg-info text-uppercase">
                    {profile?.tier || 'bronze'}
                  </span>
                </div>
                <div className="mb-2 d-flex justify-content-between">
                  <span className="text-muted small">Total washes</span>
                  <span className="fw-semibold">{profile?.total_washes ?? 0}</span>
                </div>
                <div className="mb-3 d-flex flex-wrap gap-2">
                  {profile?.is_verified && (
                    <span className="badge text-bg-success">Platform verified</span>
                  )}
                  {profile?.documents_uploaded && (
                    <span className="badge text-bg-secondary">Docs uploaded</span>
                  )}
                  {profile?.insurance_verified && (
                    <span className="badge text-bg-success">Insurance OK</span>
                  )}
                  {profile?.license_verified && (
                    <span className="badge text-bg-success">License OK</span>
                  )}
                  {profile?.background_check_passed && (
                    <span className="badge text-bg-success">Background check</span>
                  )}
                </div>

                <p className="text-muted small mb-0">
                  User type: {profile?.user_type || 'valeter'}
                </p>
              </div>
            </div>

            {/* could add org info if organization_id is set */}
            {profile?.organization_id && (
              <div className="card border-0 shadow-sm">
                <div className="card-header bg-white">
                  <h6 className="mb-0">Organisation</h6>
                </div>
                <div className="card-body">
                  <p className="small mb-1">
                    Org ID: <code>{profile.organization_id}</code>
                  </p>
                  <p className="small text-muted mb-0">
                    Type: {profile.organization_type || '—'}
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* right column: docs + bookings */}
          <div className="col-12 col-lg-8 d-flex flex-column gap-3">
            {/* documents */}
            <div className="card border-0 shadow-sm">
              <div className="card-header bg-white d-flex justify-content-between align-items-center">
                <h6 className="mb-0">Documents</h6>
                <span className="badge text-bg-secondary">{docs.length}</span>
              </div>
              <div className="table-responsive">
                {docs.length === 0 ? (
                  <p className="p-3 mb-0 text-muted">No documents for this valeter.</p>
                ) : (
                  <table className="table table-sm mb-0 align-middle">
                    <thead className="table-light">
                      <tr>
                        <th>Name</th>
                        <th>Type</th>
                        <th>Status</th>
                        <th>Uploaded</th>
                        <th>File</th>
                      </tr>
                    </thead>
                    <tbody>
                      {docs.map((d) => (
                        <tr key={d.id}>
                          <td>{d.name}</td>
                          <td className="small text-muted">{d.type}</td>
                          <td>{renderStatus(d.status)}</td>
                          <td className="small text-muted">
                            {d.uploaded_at
                              ? new Date(d.uploaded_at).toLocaleString()
                              : '—'}
                          </td>
                          <td>
                            {d.file_url ? (
                              <a
                                href={d.file_url}
                                target="_blank"
                                rel="noreferrer"
                                className="btn btn-link btn-sm p-0"
                              >
                                View
                              </a>
                            ) : (
                              <span className="text-muted small">No file</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            </div>

            {/* bookings */}
            <div className="card border-0 shadow-sm">
              <div className="card-header bg-white d-flex justify-content-between align-items-center">
                <h6 className="mb-0">Bookings handled</h6>
                <span className="badge text-bg-secondary">{bookings.length}</span>
              </div>
              <div className="table-responsive">
                {bookings.length === 0 ? (
                  <p className="p-3 mb-0 text-muted">No bookings linked to this valeter.</p>
                ) : (
                  <table className="table table-sm mb-0 align-middle">
                    <thead className="table-light">
                      <tr>
                        <th>Service</th>
                        <th>Status</th>
                        <th className="text-end">£</th>
                        <th>Scheduled</th>
                        <th>Location</th>
                      </tr>
                    </thead>
                    <tbody>
                      {bookings.map((b) => (
                        <tr key={b.id}>
                          <td>{b.service_type}</td>
                          <td>{renderBookingStatus(b.status)}</td>
                          <td className="text-end">
                            £{Number(b.price || 0).toFixed(2)}
                          </td>
                          <td className="small text-muted">
                            {b.scheduled_at
                              ? new Date(b.scheduled_at).toLocaleString()
                              : '—'}
                          </td>
                          <td className="small">
                            {b.location_address || <span className="text-muted">—</span>}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function renderStatus(status: string) {
  const map: Record<string, string> = {
    pending: 'warning',
    approved: 'success',
    rejected: 'danger',
  }
  const variant = map[status] || 'secondary'
  return (
    <span className={`badge text-bg-${variant}`} style={{ textTransform: 'capitalize' }}>
      {status}
    </span>
  )
}

function renderBookingStatus(status: string) {
  const map: Record<string, string> = {
    completed: 'success',
    in_progress: 'primary',
    scheduled: 'info',
    cancelled: 'danger',
  }
  const variant = map[status] || 'secondary'
  return (
    <span className={`badge text-bg-${variant}`} style={{ textTransform: 'capitalize' }}>
      {status}
    </span>
  )
}