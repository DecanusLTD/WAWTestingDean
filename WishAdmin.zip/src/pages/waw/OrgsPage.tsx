import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../../lib/supabaseClient'

type Org = {
  id: string
  name: string
  contact_email: string
  status: string
  is_verified: boolean
  insurance_verified: boolean
  license_verified: boolean
  created_at: string
}

export default function OrgsPage() {
  const [orgs, setOrgs] = useState<Org[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const load = async () => {
      const { data, error } = await supabase
        .from('organizations')
        .select(
          'id, name, contact_email, status, is_verified, insurance_verified, license_verified, created_at'
        )
        .order('created_at', { ascending: false })
        .limit(100)

      if (!error) setOrgs((data || []) as Org[])
      setLoading(false)
    }

    load()
  }, [])

  const verifyOrg = async (id: string) => {
    const { error } = await supabase
      .from('organizations')
      .update({
        status: 'active',
        is_verified: true,
        updated_at: new Date().toISOString(),
      })
      .eq('id', id)

    if (!error) {
      setOrgs((prev) =>
        prev.map((o) =>
          o.id === id ? { ...o, status: 'active', is_verified: true } : o
        )
      )
    }
  }

  return (
    <div className="container-fluid px-0">
      <h1 className="h4 mb-3">Organisations</h1>
      <p className="text-muted mb-4">
        Approve and monitor organisation accounts.
      </p>

      <div className="card shadow-sm border-0">
        <div className="card-header bg-white d-flex justify-content-between align-items-center">
          <h6 className="mb-0">Organisation accounts</h6>
          <span className="badge text-bg-secondary">{orgs.length} total</span>
        </div>

        <div className="table-responsive">
          {loading ? (
            <p className="p-3 mb-0">Loading…</p>
          ) : (
            <table className="table table-sm table-hover mb-0 align-middle">
              <thead className="table-light">
                <tr>
                  <th style={{ width: '20%' }}>Name</th>
                  <th style={{ width: '22%' }}>Email</th>
                  <th style={{ width: '12%' }}>Status</th>
                  <th style={{ width: '10%' }}>Verified</th>
                  <th style={{ width: '14%' }}>Created</th>
                  <th style={{ width: '22%' }}></th>
                </tr>
              </thead>
              <tbody>
                {orgs.map((org) => (
                  <tr key={org.id}>
                    <td>{org.name}</td>
                    <td className="small text-muted">{org.contact_email}</td>
                    <td>{renderStatus(org.status)}</td>
                    <td>
                      {org.is_verified ? (
                        <span className="badge text-bg-success">Yes</span>
                      ) : (
                        <span className="badge text-bg-secondary">No</span>
                      )}
                    </td>
                    <td className="small text-muted">
                      {org.created_at
                        ? new Date(org.created_at).toLocaleDateString()
                        : '—'}
                    </td>
                    <td className="text-end">
                      <div className="btn-group btn-group-sm" role="group">
                        {org.status === 'pending' ? (
                          <button
                            className="btn btn-outline-success"
                            onClick={() => verifyOrg(org.id)}
                          >
                            Approve
                          </button>
                        ) : (
                          <button
                            className="btn btn-outline-secondary"
                            disabled
                          >
                            Approved
                          </button>
                        )}
                        <Link
                          to={`/wish-a-wash/organizations/${org.id}/locations`}
                          className="btn btn-outline-primary"
                        >
                          Locations
                        </Link>
                      </div>
                    </td>
                  </tr>
                ))}

                {!loading && orgs.length === 0 && (
                  <tr>
                    <td colSpan={6} className="text-center py-4 text-muted">
                      No organisations found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  )
}

function renderStatus(status: string) {
  const map: Record<string, string> = {
    pending: 'warning',
    active: 'success',
    suspended: 'danger',
  }
  const variant = map[status] || 'secondary'

  return (
    <span
      className={`badge text-bg-${variant}`}
      style={{ textTransform: 'capitalize' }}
    >
      {status}
    </span>
  )
}