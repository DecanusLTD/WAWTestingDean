// src/pages/waw/DocumentsPage.tsx
import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../../lib/supabaseClient'

type ValeterDoc = {
  id: string
  user_id: string
  name: string
  type: string
  status: string
  file_url: string | null
  uploaded_at: string | null
}

export default function DocumentsPage() {
  const [docs, setDocs] = useState<ValeterDoc[]>([])
  const [loading, setLoading] = useState(true)
  const [openValeter, setOpenValeter] = useState<string | null>(null)

  useEffect(() => {
    const load = async () => {
      const { data, error } = await supabase
        .from('valeter_documents')
        .select('id, user_id, name, type, status, file_url, uploaded_at')
        .order('created_at', { ascending: false })
        .limit(100)

      if (!error) setDocs((data || []) as ValeterDoc[])
      setLoading(false)
    }
    load()
  }, [])

  const updateStatus = async (id: string, status: 'approved' | 'rejected') => {
    const { error } = await supabase
      .from('valeter_documents')
      .update({
        status,
        approved_at: status === 'approved' ? new Date().toISOString() : null,
      })
      .eq('id', id)

    if (!error) {
      setDocs((prev) => prev.map((d) => (d.id === id ? { ...d, status } : d)))
    }
  }

  // group by user_id
  const groups: Record<string, ValeterDoc[]> = docs.reduce((acc, doc) => {
    if (!acc[doc.user_id]) acc[doc.user_id] = []
    acc[doc.user_id].push(doc)
    return acc
  }, {} as Record<string, ValeterDoc[]>)

  const valeterIds = Object.keys(groups)

  return (
    <div className="container-fluid px-0">
      <h1 className="h4 mb-3">Valeter Documents</h1>
      <p className="text-muted mb-4">
        Review and approve documents uploaded by valeters.
      </p>

      <div className="card shadow-sm border-0">
        <div className="card-header bg-white d-flex justify-content-between align-items-center">
          <h6 className="mb-0">Documents</h6>
          <span className="badge text-bg-secondary">{docs.length} total</span>
        </div>

        {loading ? (
          <p className="p-3 mb-0">Loading…</p>
        ) : valeterIds.length === 0 ? (
          <p className="p-3 mb-0 text-muted">No documents found.</p>
        ) : (
          <div className="list-group list-group-flush">
            {valeterIds.map((valeterId) => {
              const valsDocs = groups[valeterId]
              const isOpen = openValeter === valeterId

              // count statuses per valeter
              const counts = valsDocs.reduce(
                (acc, d) => {
                  acc[d.status] = (acc[d.status] || 0) + 1
                  return acc
                },
                {} as Record<string, number>
              )

              return (
                <div key={valeterId} className="list-group-item bg-white">
                  {/* header row per valeter */}
                  <div className="d-flex justify-content-between align-items-center flex-wrap">
                    <div className="d-flex align-items-center gap-2 flex-wrap">
                      <Link
                        to={`/wish-a-wash/valeters/${valeterId}`}
                        className="text-decoration-none fw-semibold"
                      >
                        Valeter {valeterId.slice(0, 8)}…
                      </Link>

                      <span className="badge text-bg-light">
                        {valsDocs.length} total
                      </span>

                      {/* status summary badges */}
                      <StatusCountBadge label="pending" count={counts.pending} color="warning" />
                      <StatusCountBadge label="approved" count={counts.approved} color="success" />
                      <StatusCountBadge label="rejected" count={counts.rejected} color="danger" />
                    </div>

                    <button
                      className="btn btn-sm btn-outline-secondary mt-2 mt-md-0"
                      onClick={() => setOpenValeter(isOpen ? null : valeterId)}
                    >
                      {isOpen ? 'Hide' : 'View'}
                    </button>
                  </div>

                  {isOpen && (
                    <div className="table-responsive mt-3">
                      <table className="table table-sm table-hover mb-0 align-middle">
                        <thead className="table-light">
                          <tr>
                            <th>Name</th>
                            <th>Type</th>
                            <th>Status</th>
                            <th>Uploaded</th>
                            <th>File</th>
                            <th className="text-end">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {valsDocs.map((doc) => (
                            <tr key={doc.id}>
                              <td>{doc.name}</td>
                              <td className="text-muted small">{doc.type}</td>
                              <td>{renderStatus(doc.status)}</td>
                              <td className="small text-muted">
                                {doc.uploaded_at
                                  ? new Date(doc.uploaded_at).toLocaleString()
                                  : '—'}
                              </td>
                              <td>
                                {doc.file_url ? (
                                  <a
                                    href={doc.file_url}
                                    target="_blank"
                                    rel="noreferrer"
                                    className="btn btn-link btn-sm p-0"
                                  >
                                    View
                                  </a>
                                ) : (
                                  <span className="text-muted small">No file</span>
                                )}
                              </td>
                              <td className="text-end">
                                <div className="btn-group btn-group-sm" role="group">
                                  <button
                                    type="button"
                                    className="btn btn-outline-success"
                                    onClick={() => updateStatus(doc.id, 'approved')}
                                  >
                                    Approve
                                  </button>
                                  <button
                                    type="button"
                                    className="btn btn-outline-danger"
                                    onClick={() => updateStatus(doc.id, 'rejected')}
                                  >
                                    Reject
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}

function renderStatus(status: string) {
  const map: Record<string, string> = {
    pending: 'warning',
    approved: 'success',
    rejected: 'danger',
    not_uploaded: 'secondary',
  }
  const variant = map[status] || 'secondary'
  return (
    <span
      className={`badge text-bg-${variant}`}
      style={{ textTransform: 'capitalize' }}
    >
      {status.replace('_', ' ')}
    </span>
  )
}

function StatusCountBadge({
  label,
  count,
  color,
}: {
  label: string
  count?: number
  color: string
}) {
  if (!count) return null
  return (
    <span
      className={`badge text-bg-${color}`}
      style={{ textTransform: 'capitalize' }}
    >
      {label}: {count}
    </span>
  )
}