// src/pages/waw/BookingsPage.tsx
import { useEffect, useState } from 'react'
import { supabase } from '../../lib/supabaseClient'

type Booking = {
  id: string
  service_type: string
  status: string
  price: number
  scheduled_at: string | null
  location_address: string | null
  created_at: string
}

export default function BookingsPage() {
  const [bookings, setBookings] = useState<Booking[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const load = async () => {
      setLoading(true)
      const { data, error } = await supabase
        .from('bookings')
        .select(
          'id, service_type, status, price, scheduled_at, location_address, created_at'
        )
        .order('created_at', { ascending: false })
        .limit(50)

      if (!error) {
        setBookings((data || []) as Booking[])
      }
      setLoading(false)
    }

    load()
  }, [])

  return (
    <div className="container-fluid px-0">
      <h1 className="h4 mb-3">Bookings</h1>
      <p className="text-muted mb-4">Latest bookings across the platform.</p>

      <div className="card shadow-sm border-0">
        <div className="card-header bg-white d-flex justify-content-between align-items-center">
          <h6 className="mb-0">Recent bookings</h6>
          <span className="badge text-bg-secondary">{bookings.length} loaded</span>
        </div>

        <div className="table-responsive">
          {loading ? (
            <p className="p-3 mb-0">Loading…</p>
          ) : (
            <table className="table table-sm table-hover mb-0 align-middle">
              <thead className="table-light">
                <tr>
                  <th style={{ width: '20%' }}>Service</th>
                  <th style={{ width: '12%' }}>Status</th>
                  <th style={{ width: '10%' }} className="text-end">
                    Price
                  </th>
                  <th style={{ width: '20%' }}>Scheduled / created</th>
                  <th>Location</th>
                </tr>
              </thead>
              <tbody>
                {bookings.map((b) => (
                  <tr key={b.id}>
                    <td>{b.service_type}</td>
                    <td>{renderStatus(b.status)}</td>
                    <td className="text-end">
                      £{Number(b.price || 0).toFixed(2)}
                    </td>
                    <td className="small text-muted">
                      {b.scheduled_at
                        ? new Date(b.scheduled_at).toLocaleString()
                        : new Date(b.created_at).toLocaleString()}
                    </td>
                    <td className="small">
                      {b.location_address ? b.location_address : <span className="text-muted">—</span>}
                    </td>
                  </tr>
                ))}

                {!loading && bookings.length === 0 && (
                  <tr>
                    <td colSpan={5} className="text-center py-4 text-muted">
                      No bookings found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  )
}

function renderStatus(status: string) {
  const map: Record<string, string> = {
    completed: 'success',
    in_progress: 'primary',
    scheduled: 'info',
    cancelled: 'danger',
  }
  const variant = map[status] || 'secondary'
  return (
    <span
      className={`badge text-bg-${variant}`}
      style={{ textTransform: 'capitalize' }}
    >
      {status.replace('_', ' ')}
    </span>
  )
}